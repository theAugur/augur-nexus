export class ShopTradePolicyRegistry {
    static #policies = new Map();

    static register(definition = {}) {
        const id = String(definition.id || "").trim();
        if (!id) throw new Error("Shop trade policies require an id.");
        const policy = {
            id,
            quoteCustomerPurchase: typeof definition.quoteCustomerPurchase === "function"
                ? definition.quoteCustomerPurchase
                : null,
            quoteCustomerSale: typeof definition.quoteCustomerSale === "function"
                ? definition.quoteCustomerSale
                : null
        };
        if (!policy.quoteCustomerPurchase && !policy.quoteCustomerSale) {
            throw new Error(`Shop trade policy ${id} does not provide a quote handler.`);
        }
        this.#policies.set(id, policy);
        return policy;
    }

    static get(id) {
        return this.#policies.get(String(id || "")) || null;
    }

    static unregister(id) {
        return this.#policies.delete(String(id || ""));
    }
}
