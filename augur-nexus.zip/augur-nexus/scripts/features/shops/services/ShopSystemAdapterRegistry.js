const REQUIRED_CAPABILITIES = [
    "resolveActor",
    "getDefaultWallet",
    "getDefaultInventoryHolder",
    "getEligibleWallets",
    "getEligibleInventoryHolders",
    "groupActors",
    "getActorView",
    "rememberWallet",
    "rememberInventoryHolder",
    "canAfford",
    "isEligibleWallet",
    "isEligibleInventoryHolder",
    "getInventoryItems",
    "getItemQuantity",
    "getSaleQuote",
    "buildItemData",
    "createSaleProduct",
    "createActorTradeSession",
    "formatPrice"
];

export class ShopSystemAdapterRegistry {
    static #adapters = new Map();

    static register(adapter) {
        if (!adapter?.id || typeof adapter.isAvailable !== "function") {
            throw new Error("Shop system adapters require an id and isAvailable().");
        }
        const missing = REQUIRED_CAPABILITIES.filter(capability => typeof adapter[capability] !== "function");
        if (missing.length) {
            throw new Error(`Shop system adapter ${adapter.id} is missing: ${missing.join(", ")}.`);
        }
        this.#adapters.set(adapter.id, adapter);
        return adapter;
    }

    static getActive() {
        return Array.from(this.#adapters.values()).find(adapter => adapter.isAvailable()) || null;
    }
}
