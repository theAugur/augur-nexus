import { ShopStore } from "./ShopStore.js";

export class ShopDeletionWorkflow {
    static async confirm(idOrUuid) {
        const shop = ShopStore.getShop(idOrUuid);
        if (!game.user.isGM || !shop) return false;
        const recoveryHint = String(shop.lifecycle?.recoveryHint || "").trim();
        const confirmed = await foundry.applications.api.DialogV2.confirm({
            window: { title: "Delete Shop" },
            content: `<p>Delete <strong>${foundry.utils.escapeHTML(shop.name)}</strong>?</p>${recoveryHint ? `<p class="notification warning">${foundry.utils.escapeHTML(recoveryHint)}</p>` : ""}`,
            modal: true, rejectClose: false, yes: { label: "Delete" }, no: { label: "Cancel" }
        });
        if (!confirmed || !game.user.isGM || !ShopStore.getShop(idOrUuid)) return false;
        return ShopStore.deleteShop(idOrUuid);
    }
}
