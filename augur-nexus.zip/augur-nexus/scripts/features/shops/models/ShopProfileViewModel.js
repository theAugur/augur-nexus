import { ShopModel } from "./ShopModel.js";
import { ShopStore } from "../services/ShopStore.js";

export class ShopProfileViewModel {
    static fromShop(shop = {}, options = {}) {
        return {
            name: String(shop?.name || "Shop"),
            subtitle: ShopStore.getParentLabel(shop),
            imageSrc: ShopModel.getImage(shop),
            accent: ShopModel.getAccent(shop),
            stock: Array.isArray(options.stock) ? options.stock : [],
            showTabs: options.showTabs === true,
            showActions: options.showActions === true,
            showBody: options.showBody !== false,
            tabs: {
                isProfileTab: options.activeTab !== "journal",
                isJournalTab: options.activeTab === "journal"
            }
        };
    }
}
