export const SHADOWDARK_CURRENCY_ID = "shadowdark-cp";
export const SHADOWDARK_PHYSICAL_TYPES = new Set(["Armor", "Basic", "Gem", "Potion", "Scroll", "Wand", "Weapon"]);
export const SHADOWDARK_COMPENDIUM_PROVIDER_ID = "augur-nexus:shadowdark-compendium";
export const SHADOWDARK_ACQUIRED_PROVIDER_ID = "augur-nexus:shadowdark-acquired";

export function copperValue(coins = {}) {
    return [ ["gp", 100], ["sp", 10], ["cp", 1] ].reduce((sum, [key, value]) =>
        sum + Math.max(0, Math.floor(Number(coins[key]) || 0)) * value, 0);
}

export function copperToCoins(amount) {
    const cp = Math.max(0, Math.floor(Number(amount) || 0));
    return { gp: Math.floor(cp / 100), sp: Math.floor(cp % 100 / 10), cp: cp % 10 };
}

export function itemQuantity(item) {
    return Math.max(0, Math.floor(Number(item?.system?.quantity ?? 1) || 0));
}

// Basic supplies list the cost of a full bundle (arrows, spikes, rations).
// A saved price basis keeps resale independent of the remaining quantity.
export function priceQuantity(item) {
    return Math.max(1, Math.floor(Number(item?.flags?.["augur-nexus"]?.shadowdarkPriceQuantity
        ?? (item?.type === "Basic" ? item.system?.slots?.per_slot : 1)) || 1));
}

export function itemPrice(item, quantity = 1) {
    return Math.max(0, Math.floor(copperValue(item?.system?.cost) * quantity / priceQuantity(item)));
}

export function cleanItemSource(item, quantity = 1) {
    const data = foundry.utils.deepClone(typeof item.toObject === "function" ? item.toObject() : item);
    for (const key of ["_id", "folder", "sort", "ownership"]) delete data[key];
    data.system ||= {};
    data.system.quantity = quantity;
    data.system.equipped = false;
    data.system.stashed = false;
    if (data.system.light) data.system.light.active = false;
    data.flags ||= {};
    data.flags["augur-nexus"] ||= {};
    data.flags["augur-nexus"].shadowdarkPriceQuantity = priceQuantity(item);
    return data;
}

export function deliverySources(data) {
    const quantity = itemQuantity(data);
    const multiple = data.type !== "Gem" && !data.system?.light?.isSource
        && !["Scroll", "Wand", "Potion"].includes(data.type)
        && (data.system?.isAmmunition || Number(data.system?.slots?.per_slot) > 1);
    const capacity = multiple ? Math.max(1, Math.floor(Number(data.system.slots?.per_slot) || 1)) : 1;
    const result = [];
    for (let remaining = quantity; remaining > 0; remaining -= capacity) {
        const source = foundry.utils.deepClone(data);
        source.system.quantity = Math.min(remaining, capacity);
        result.push(source);
    }
    return result;
}
