import { ShopProductProviderRegistry } from "../../services/ShopProductProviderRegistry.js";
import {
    SHADOWDARK_PHYSICAL_TYPES, SHADOWDARK_CURRENCY_ID, SHADOWDARK_COMPENDIUM_PROVIDER_ID,
    SHADOWDARK_ACQUIRED_PROVIDER_ID, itemQuantity, itemPrice
} from "./ShadowdarkItemData.js";

const INDEX_FIELDS = ["img", "type", "system.cost", "system.quantity", "system.slots", "system.type",
    "system.description", "system.source.title", "system.magicItem", "system.properties",
    "system.identification.identified", "system.isAmmunition", "system.broken", "system.light",
    "flags.augur-nexus.shadowdarkPriceQuantity"];

export class ShadowdarkItemProvider {
    static #catalogs = new Map();
    static #properties = new Map();

    static async #propertyName(uuid) {
        if (!this.#properties.has(uuid)) {
            this.#properties.set(uuid, fromUuid(uuid).then(item => String(item?.name || "").toLowerCase()).catch(() => ""));
        }
        return this.#properties.get(uuid);
    }

    static async productFromItem(item, { id = item.uuid, sourceUuid = item.uuid, itemData = null, quantity = itemQuantity(item) } = {}) {
        const properties = await Promise.all((item.system?.properties || []).map(uuid => this.#propertyName(uuid)));
        const magical = item.system?.magicItem === true || ["Potion", "Scroll", "Wand"].includes(item.type);
        const shield = item.type === "Armor" && properties.includes("shield");
        const ammunition = item.type === "Basic" && item.system?.isAmmunition;
        const tags = [];
        if (item.type === "Weapon") tags.push(item.system?.type === "ranged" ? "ranged-weapon" : "melee-weapon");
        if (ammunition) tags.push("ammunition");
        if (item.type === "Potion") tags.push("apothecary");
        if (item.type === "Basic" && !ammunition && !magical) tags.push("outfitter");
        if (["Scroll", "Wand"].includes(item.type) || (item.type === "Basic" && magical)) tags.push("arcane-curio");
        const source = String(item.system?.source?.title || "Unspecified Source");
        const name = quantity > 1 ? `${item.name} (${quantity})` : item.name;
        return {
            id, providerId: SHADOWDARK_COMPENDIUM_PROVIDER_ID, productId: id,
            name, lotLabel: name, category: item.type, typeLabel: item.type,
            subtypeLabel: shield ? "Shield" : magical ? "Magical" : "Mundane",
            sourceLabel: source, imageSrc: item.img, description: String(item.system?.description || ""),
            price: { amount: itemPrice(item, quantity), currencyId: SHADOWDARK_CURRENCY_ID },
            requiresPrice: true,
            weight: { value: Math.ceil(quantity / Math.max(1, Number(item.system?.slots?.per_slot) || 1))
                * Math.max(0, Number(item.system?.slots?.slots_used) || 0), units: "slots" },
            cargoSlots: 1,
            sourceData: { sourceUuid, itemData, type: item.type, unitsPerPurchase: quantity },
            facets: {
                type: item.type, magical: magical ? "magical" : "mundane", shopTags: tags,
                merchandiseKind: shield ? "shield" : item.type === "Armor" ? "armor"
                    : item.type === "Weapon" ? "weapon" : ammunition ? "ammunition" : "",
                availability: magical ? "special" : "standard", rulesSource: source,
                stableKey: `${item.type}:${item.name.toLowerCase()}:${quantity}`, properties
            }
        };
    }

    static async #catalog(pack) {
        if (!this.#catalogs.has(pack.collection)) {
            const pending = (async () => {
                const entries = await pack.getIndex({ fields: INDEX_FIELDS });
                const products = [];
                for (const item of entries) {
                    if (!SHADOWDARK_PHYSICAL_TYPES.has(item.type) || !itemQuantity(item)
                        || item.system?.identification?.identified === false || item.system?.broken
                        || item.system?.light?.active) continue;
                    const uuid = `Compendium.${pack.collection}.Item.${item._id}`;
                    const product = await this.productFromItem(item, { id: uuid, sourceUuid: uuid });
                    products.push({ ...product, packId: pack.collection, packLabel: pack.metadata?.label || pack.title });
                }
                return products;
            })();
            this.#catalogs.set(pack.collection, pending);
        }
        try { return await this.#catalogs.get(pack.collection); }
        catch (error) { this.#catalogs.delete(pack.collection); throw error; }
    }

    static async getAvailablePacks({ packIds = [], recommendedOnly = false } = {}) {
        const result = [];
        for (const pack of game.packs?.contents || []) {
            if (pack.documentName !== "Item" || !pack.visible || (packIds.length && !packIds.includes(pack.collection))) continue;
            if (recommendedOnly && pack.collection !== "shadowdark.gear") continue;
            const products = await this.#catalog(pack);
            if (!products.length) continue;
            const packageId = pack.metadata?.packageName;
            const official = pack.metadata?.packageType === "system";
            const world = pack.collection.startsWith("world.");
            result.push({ id: pack.collection, label: pack.metadata?.label || pack.title || pack.collection,
                originLabel: official ? game.system.title : world ? "This World" : game.modules.get(packageId)?.title || packageId,
                group: official ? "official" : world ? "world" : "module", eligibleCount: products.length,
                recommended: pack.collection === "shadowdark.gear" });
        }
        return result.sort((a, b) => a.label.localeCompare(b.label));
    }

    static async getCatalog({ packIds = [], limit = 5000 } = {}) {
        const result = [];
        for (const pack of game.packs?.contents || []) {
            if (pack.documentName !== "Item" || !pack.visible || (packIds.length && !packIds.includes(pack.collection))) continue;
            result.push(...await this.#catalog(pack));
            if (result.length >= limit) break;
        }
        return result.slice(0, limit).sort((a, b) => a.name.localeCompare(b.name));
    }

    static async getCompendiumProduct(id) {
        const pack = (game.packs?.contents || []).find(pack => pack.documentName === "Item" && pack.visible
            && String(id).startsWith(`Compendium.${pack.collection}.Item.`));
        return pack ? (await this.#catalog(pack)).find(product => product.id === id) || null : null;
    }

    static async getAcquiredProduct(id, { shop } = {}) {
        const record = shop?.providerData?.[SHADOWDARK_ACQUIRED_PROVIDER_ID]?.[id];
        if (!record?.itemData) return null;
        return this.productFromItem(record.itemData, { id, sourceUuid: record.sourceUuid || "",
            itemData: foundry.utils.deepClone(record.itemData), quantity: record.unitsPerPurchase || 1 });
    }

    static getCatalogSchema() {
        return { id: "shadowdark-physical-items-v1",
            types: [...SHADOWDARK_PHYSICAL_TYPES].map(id => ({ id, label: id })),
            filterGroups: [
                { id: "magical", label: "Magic", dynamic: true, optionLabels: { mundane: "Mundane", magical: "Magical" } },
                { id: "shopTags", label: "Shop Category", dynamic: true },
                { id: "properties", label: "Properties", dynamic: true },
                { id: "rulesSource", label: "Source", dynamic: true, placement: "bottom" }
            ] };
    }

    static getStockTemplates() {
        return [
            ["blacksmith", "Blacksmith", ["Weapon", "Armor"], { magical: { mundane: 1 } }],
            ["general-store", "General Store", ["Basic"], { magical: { mundane: 1 } }],
            ["apothecary", "Apothecary", ["Potion"], {}],
            ["magic-shop", "Magic Shop", [...SHADOWDARK_PHYSICAL_TYPES], { magical: { magical: 1 } }]
        ].map(([id, name, activeTypes, filterState]) => ({ id, name, description: `Priced ${name.toLowerCase()} merchandise.`,
            count: { min: 6, max: 12 }, quantity: { min: 1, max: 3 },
            discovery: { activeTypes, filterState, price: { minimum: 1, maximum: null, requireListed: true } } }));
    }

    static register() {
        if (game.system?.id !== "shadowdark") return;
        ShopProductProviderRegistry.register({ id: SHADOWDARK_COMPENDIUM_PROVIDER_ID, label: "Shadowdark Compendium Items",
            merchandiseKinds: ["armor", "shield", "weapon", "ammunition"], cacheProducts: true,
            getProduct: id => this.getCompendiumProduct(id), getCatalog: options => this.getCatalog(options),
            getAvailablePacks: options => this.getAvailablePacks(options), getCatalogSchema: () => this.getCatalogSchema(),
            getStockTemplates: () => this.getStockTemplates() });
        ShopProductProviderRegistry.register({ id: SHADOWDARK_ACQUIRED_PROVIDER_ID, label: "Items Bought from Characters",
            getProduct: (id, context) => this.getAcquiredProduct(id, context) });
    }
}
