import { ShopSystemAdapterRegistry } from "../../services/ShopSystemAdapterRegistry.js";
import { SHADOWDARK_CURRENCY_ID, SHADOWDARK_PHYSICAL_TYPES, SHADOWDARK_COMPENDIUM_PROVIDER_ID,
    SHADOWDARK_ACQUIRED_PROVIDER_ID, copperValue, copperToCoins, itemQuantity, itemPrice,
    cleanItemSource, deliverySources } from "./ShadowdarkItemData.js";

const MODULE_ID = "augur-nexus";
const WALLET_FLAG = "tradingActorUuid";
const INVENTORY_FLAG = "tradingInventoryByWallet";

export const ShadowdarkTradeAdapter = {
    id: "shadowdark",
    label: "Shadowdark",
    currencyId: SHADOWDARK_CURRENCY_ID,

    isAvailable() { return game.system?.id === "shadowdark"; },

    assignmentKey(uuid) {
        return String(uuid || "").replaceAll(".", "%2E");
    },

    async getDefaultWallet() {
        const rememberedUuid = game.user?.getFlag(MODULE_ID, WALLET_FLAG);
        const remembered = rememberedUuid ? await this.resolveActor(rememberedUuid) : null;
        if (this.isEligibleWallet(remembered, game.user)) return remembered;
        if (this.isEligibleWallet(game.user?.character, game.user)) return game.user.character;
        const owned = this.getEligibleWallets(game.user);
        return owned.length === 1 ? owned[0] : null;
    },

    async getDefaultInventoryHolder(wallet) {
        if (!wallet) return null;
        const assignments = game.user?.getFlag(MODULE_ID, INVENTORY_FLAG) || {};
        const uuid = assignments[this.assignmentKey(wallet.uuid)];
        const remembered = uuid ? await this.resolveActor(uuid) : null;
        return this.isEligibleInventoryHolder(remembered, game.user) ? remembered : wallet;
    },

    getEligibleWallets(user = game.user) {
        return game.actors.filter(actor => this.isEligibleWallet(actor, user)).sort((a, b) => a.name.localeCompare(b.name));
    },

    getEligibleInventoryHolders(user = game.user) {
        return game.actors.filter(actor => this.isEligibleInventoryHolder(actor, user)).sort((a, b) => a.name.localeCompare(b.name));
    },

    isEligibleWallet(actor, user = game.user) {
        return this.isOwnedActorOfType(actor, user, ["Player"]);
    },

    isEligibleInventoryHolder(actor, user = game.user) {
        return this.isOwnedActorOfType(actor, user, ["Player"]);
    },

    isOwnedActorOfType(actor, user, types) {
        if (!actor || actor.documentName !== "Actor" || !types.includes(actor.type)) return false;
        return user?.isGM || actor.testUserPermission(user, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER);
    },

    async rememberWallet(actor) {
        if (!this.isEligibleWallet(actor, game.user)) throw new Error("Choose an owned Shadowdark Player wallet.");
        await game.user.setFlag(MODULE_ID, WALLET_FLAG, actor.uuid);
        return actor;
    },

    async rememberInventoryHolder(wallet, actor) {
        if (!this.isEligibleWallet(wallet, game.user)) throw new Error("Select a wallet first.");
        if (!this.isEligibleInventoryHolder(actor, game.user)) throw new Error("Choose an owned Shadowdark Player inventory.");
        const assignments = { ...(game.user?.getFlag(MODULE_ID, INVENTORY_FLAG) || {}) };
        assignments[this.assignmentKey(wallet.uuid)] = actor.uuid;
        await game.user.setFlag(MODULE_ID, INVENTORY_FLAG, assignments);
        return actor;
    },

    async resolveActor(uuid) {
        if (!uuid) return null;
        const actor = await fromUuid(uuid).catch(() => null);
        return actor?.documentName === "Actor" ? actor : null;
    },

    groupActors(actors, selectedUuid = "") {
        return [
            { id: "Player", label: "Characters" }
        ].map(group => ({
            ...group,
            actors: actors.filter(actor => actor.type === group.id).map(actor => ({
                uuid: actor.uuid,
                name: actor.name,
                img: actor.img,
                selected: actor.uuid === selectedUuid
            }))
        })).filter(group => group.actors.length);
    },


    async getActorView(actor) {
        if (!actor) return null;
        const value = Number(actor.system.getSlotUsage?.().total);
        const max = Number(actor.system.slots);
        const walletValue = this.getWalletValue(actor);
        return { uuid: actor.uuid, name: actor.name, img: actor.img, type: actor.type, typeLabel: "Character",
            wallet: this.formatPrice(walletValue), walletValue,
            weight: Number.isFinite(value) && Number.isFinite(max) ? `${value} / ${max} slots` : "Slots unavailable",
            weightValue: Number.isFinite(value) ? value : null, weightMax: Number.isFinite(max) ? max : null,
            weightUnits: "slots" };
    },

    getWalletValue(actor) { return copperValue(actor?.system?.coins); },
    getItemQuantity: itemQuantity,
    canAfford(actor, amount) { return this.getWalletValue(actor) >= Math.max(0, Math.round(Number(amount) || 0)); },
    formatPrice(amount) {
        const coins = copperToCoins(amount);
        return Object.entries(coins).filter(([, value]) => value).map(([key, value]) => `${value.toLocaleString()} ${key}`).join(" ") || "0 cp";
    },

    getCurrencyUpdate(actor, netAmount) {
        const coins = { ...copperToCoins(0), ...foundry.utils.deepClone(actor.system.coins) };
        if (netAmount <= 0) {
            const credit = copperToCoins(-netAmount);
            for (const key of ["gp", "sp", "cp"]) coins[key] += credit[key];
        } else {
            if (!this.canAfford(actor, netAmount)) throw new Error(`${actor.name} cannot afford this trade.`);
            let remaining = netAmount;
            for (const [key, value] of [["cp", 1], ["sp", 10], ["gp", 100]]) {
                const spent = Math.min(coins[key], Math.floor(remaining / value));
                coins[key] -= spent;
                remaining -= spent * value;
            }
            // Break only the smallest available coin; preserve the rest of the wallet.
            if (remaining) {
                const key = coins.sp > 0 && remaining < 10 ? "sp" : "gp";
                coins[key]--;
                const change = copperToCoins((key === "sp" ? 10 : 100) - remaining);
                for (const denomination of ["gp", "sp", "cp"]) coins[denomination] += change[denomination];
            }
        }
        return { "system.coins": coins };
    },

    async getSaleQuote(item) {
        let reason = "";
        if (!SHADOWDARK_PHYSICAL_TYPES.has(item?.type)) reason = "This is not a physical Shadowdark item.";
        else if (!itemQuantity(item)) reason = "This item is depleted.";
        else if (item.system?.equipped === true) reason = "Unequip this item before selling it.";
        else if (item.system?.identification?.identified === false) reason = "Identify this item before selling it.";
        else if (item.system?.broken) reason = "Broken items are not accepted.";
        else if (item.system?.light?.active) reason = "Extinguish this light before selling it.";
        else if (item.system?.stashed && !item.flags?.[MODULE_ID]?.tradeGood) reason = "Carry this item before selling it.";
        const baseAmount = reason ? 0 : itemPrice(item);
        if (!reason && !baseAmount) reason = "This item has no listed value per unit.";
        return { eligible: !reason, reason, baseAmount };
    },

    async getInventoryItems(actor, { shop } = {}) {
        if (!actor) return [];
        const products = [];
        for (const item of actor.items) {
            if (!SHADOWDARK_PHYSICAL_TYPES.has(item.type)) continue;
            const quote = await this.getSaleQuote(item);
            products.push({ itemId: item.id, uuid: item.uuid, name: item.name, imageSrc: item.img,
                type: item.type, quantity: itemQuantity(item), equipped: item.system.equipped === true, attuned: false,
                eligible: quote.eligible, reason: quote.reason, baseAmount: quote.baseAmount,
                saleAmount: Math.floor(quote.baseAmount * (shop?.configuration?.customerSaleMultiplier ?? 0.75)),
                weight: { value: Math.max(0, Number(item.system?.slots?.slots_used) || 0), units: "slots" } });
        }
        return products.sort((a, b) => a.name.localeCompare(b.name));
    },

    async buildItemData(product, quantity, context = {}) {
        let source = product.sourceData?.itemData;
        if (!source && product.sourceData?.sourceUuid) {
            const item = await fromUuid(product.sourceData.sourceUuid).catch(() => null);
            if (item?.documentName !== "Item") throw new Error(`The source for ${product.name} is unavailable.`);
            source = item.toObject();
        }
        const units = Math.max(1, Math.floor(Number(product.sourceData?.unitsPerPurchase) || 1));
        let data;
        if (source) {
            if (!SHADOWDARK_PHYSICAL_TYPES.has(source.type)) throw new Error("Only physical Shadowdark items can be purchased.");
            data = cleanItemSource(source, quantity * units);
            if (data.flags?.[MODULE_ID]?.tradeGood) data.system.stashed = true;
            if (!copperValue(data.system.cost) && context.priceEach > 0) {
                data.system.cost = copperToCoins(context.priceEach);
                data.flags[MODULE_ID].shadowdarkPriceQuantity = units;
            }
        } else {
            // Regional lots are cargo, kept in the native stash rather than assigned an invented pounds-to-slots conversion.
            data = { name: product.lotLabel || product.name, type: "Basic", img: product.imageSrc,
                system: { quantity, cost: copperToCoins(product.price?.amount),
                    description: `<p>${foundry.utils.escapeHTML(product.description || "")}</p><p>Trade cargo stored in the stash. Assign gear slots before carrying this lot.</p>`,
                    slots: { per_slot: 1, slots_used: 0, free_carry: 0 }, stashed: true, equipped: false, treasure: true },
                flags: { [MODULE_ID]: { tradeGood: true, tradeGoodId: product.productId, shadowdarkPriceQuantity: 1 } } };
        }
        data.flags ||= {};
        data.flags[MODULE_ID] ||= {};
        data.flags[MODULE_ID].shopProduct = { providerId: product.providerId, productId: product.productId,
            shopUuid: context.shopUuid || "", transactionId: context.transactionId || "",
            walletUuid: context.walletUuid || "", inventoryUuid: context.inventoryUuid || "",
            acquisitionPrice: context.priceEach || 0 };
        return data;
    },

    async createStockProduct(item) {
        if (item?.documentName !== "Item" || !SHADOWDARK_PHYSICAL_TYPES.has(item.type)) {
            throw new Error("Only physical Shadowdark items can be added to Shop stock.");
        }
        if (!itemQuantity(item) || item.system?.identification?.identified === false || item.system?.broken || item.system?.light?.active) {
            throw new Error("Stock an identified, usable item with a positive quantity and no active light.");
        }
        if (item.pack || item.uuid?.startsWith("Compendium.")) {
            return { providerId: SHADOWDARK_COMPENDIUM_PROVIDER_ID, productId: item.uuid, quantity: 1, sourceUuid: item.uuid };
        }
        const unitsPerPurchase = itemQuantity(item);
        return { providerId: SHADOWDARK_ACQUIRED_PROVIDER_ID, productId: foundry.utils.randomID(), quantity: 1,
            sourceUuid: item.uuid, productData: { itemData: cleanItemSource(item, unitsPerPurchase), unitsPerPurchase,
                sourceUuid: item.uuid, stockedByUserId: game.user?.id || "" } };
    },

    async createSaleProduct(item, quantity, context = {}) {
        return { providerId: SHADOWDARK_ACQUIRED_PROVIDER_ID, productId: foundry.utils.randomID(), quantity,
            productData: { itemData: cleanItemSource(item, 1), unitsPerPurchase: 1,
                sourceUuid: item._stats?.compendiumSource || "", sellerUuid: context.sellerUuid || "",
                transactionId: context.transactionId || "", acquisitionPrice: context.acquisitionPrice || 0 } };
    },

    async createActorTradeSession({ wallet, inventoryActor, purchasedItemData = [], sales = [], netAmount = 0 } = {}) {
        const originalCoins = foundry.utils.deepClone(wallet.system.coins);
        const originalSales = sales.map(sale => foundry.utils.deepClone(sale.item.toObject()));
        const sources = purchasedItemData.flatMap(deliverySources).map(data => ({ ...data, _id: foundry.utils.randomID() }));
        let currencyTouched = false;
        let inventoryTouched = false;
        return {
            apply: async () => {
                const walletUpdate = this.getCurrencyUpdate(wallet, netAmount);
                for (const sale of sales) {
                    const live = inventoryActor.items.get(sale.item.id);
                    if (!live || itemQuantity(live) !== sale.available || !(await this.getSaleQuote(live)).eligible) {
                        throw new Error("The inventory changed. Review this trade again.");
                    }
                }
                inventoryTouched = true;
                const updates = sales.filter(sale => sale.available > sale.line.quantity)
                    .map(sale => ({ _id: sale.item.id, "system.quantity": sale.available - sale.line.quantity }));
                const deletions = sales.filter(sale => sale.available === sale.line.quantity).map(sale => sale.item.id);
                if (updates.length) await inventoryActor.updateEmbeddedDocuments("Item", updates);
                if (deletions.length) await inventoryActor.deleteEmbeddedDocuments("Item", deletions);
                if (sources.length) {
                    const created = await inventoryActor.createEmbeddedDocuments("Item", sources, { keepId: true });
                    if (created.length !== sources.length) throw new Error("Not all purchased items could be delivered.");
                }
                if (netAmount) {
                    currencyTouched = true;
                    await wallet.update(walletUpdate);
                }
            },
            rollback: async () => {
                if (inventoryTouched) {
                    const createdIds = sources.map(source => source._id).filter(id => inventoryActor.items.has(id));
                    if (createdIds.length) await inventoryActor.deleteEmbeddedDocuments("Item", createdIds);
                    const existing = originalSales.filter(source => inventoryActor.items.has(source._id));
                    const missing = originalSales.filter(source => !inventoryActor.items.has(source._id));
                    if (existing.length) await inventoryActor.updateEmbeddedDocuments("Item", existing.map(source =>
                        ({ _id: source._id, "system.quantity": source.system.quantity })));
                    if (missing.length) await inventoryActor.createEmbeddedDocuments("Item", missing, { keepId: true });
                }
                if (currencyTouched) await wallet.update({ "system.coins": originalCoins });
            }
        };
    }
};

export function registerShadowdarkTradeAdapter() {
    ShopSystemAdapterRegistry.register(ShadowdarkTradeAdapter);
}

