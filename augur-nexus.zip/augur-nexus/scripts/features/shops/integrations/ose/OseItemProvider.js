import { ShopProductProviderRegistry } from "../../services/ShopProductProviderRegistry.js";
import {
    OSE_PHYSICAL_TYPES, OSE_CURRENCY_ID, OSE_COMPENDIUM_PROVIDER_ID,
    OSE_ACQUIRED_PROVIDER_ID, itemQuantity, itemPrice, coinValue, itemTags, usesChargeCounter
} from "./OseItemData.js";

const INDEX_FIELDS = ["img", "type", "system.cost", "system.quantity", "system.weight", "system.type",
    "system.description", "system.tags", "system.treasure", "system.bonus", "system.missile", "system.melee",
    "flags.augur-nexus.osePriceQuantity", "flags.augur-nexus.oseQuantityMode"];

const RECOMMENDED_PACKS = new Set(["equipment-adventuring-gear", "equipment-ammunition", "equipment-armour", "equipment-weapons"]
    .map(name => `classicfantasycompendium.${name}`));
const TYPE_LABELS = { item: "Gear & Treasure", weapon: "Weapon", armor: "Armor", container: "Container" };
const isEligiblePack = pack => pack.documentName === "Item" && pack.visible
    && (!pack.metadata?.system || pack.metadata.system === "ose");

export class OseItemProvider {
    static #catalogs = new Map();
    static async productFromItem(item, { id = item.uuid, sourceUuid = item.uuid, itemData = null,
        quantity = itemQuantity(item), packId = "", packLabel = "" } = {}) {
        const properties = itemTags(item);
        const text = `${item.name || ""} ${properties.join(" ")}`.toLowerCase();
        const apothecary = /\b(potion|poison|remedy|antitoxin|holy water|alchemical)\b/.test(text);
        const arcane = ["item", "container"].includes(item.type)
            && /\b(scroll|wand|staff|staves|spellbook|magic|magical)\b/.test(text);
        const magical = Number(item.system?.bonus) !== 0 && Number.isFinite(Number(item.system?.bonus))
            || /\b(magic|magical|enchanted|potion|scroll|wand)\b/.test(text) || /[+]\d+/.test(text);
        const shield = item.type === "armor" && item.system?.type === "shield";
        const ammunition = item.type === "item" && (packId.endsWith(".equipment-ammunition")
            || /\b(arrow|arrows|bolt|bolts|sling stone|sling stones|ammunition)\b/.test(text));
        const tags = [];
        if (item.type === "weapon") {
            const thrown = item.system?.melee !== false || properties.some(tag => /thrown|splash/.test(tag)) || /\bjavelin\b/.test(text);
            tags.push(item.system?.missile && !thrown ? "ranged-weapon" : "melee-weapon");
        }
        if (ammunition) tags.push("ammunition");
        if (apothecary) tags.push("apothecary");
        if (["item", "container"].includes(item.type) && !item.system?.treasure && !ammunition && !magical && !apothecary && !arcane) tags.push("outfitter");
        if (arcane || magical && !["weapon", "armor"].includes(item.type)) tags.push("arcane-curio");
        const source = packLabel || "World Item";
        const name = usesChargeCounter(item) ? `${item.name} (${quantity}/${item.system?.quantity?.max || quantity})`
            : quantity > 1 ? `${item.name} (${quantity})` : item.name;
        return {
            id, providerId: OSE_COMPENDIUM_PROVIDER_ID, productId: id,
            name, lotLabel: name, category: item.type, typeLabel: TYPE_LABELS[item.type] || item.type,
            subtypeLabel: shield ? "Shield" : magical ? "Magical" : "Mundane",
            sourceLabel: source, imageSrc: item.img, description: String(item.system?.description || ""),
            price: { amount: itemPrice(item, usesChargeCounter(item) ? 1 : quantity), currencyId: OSE_CURRENCY_ID },
            requiresPrice: true,
            weight: { value: Math.max(0, Number(item.system?.weight) || 0) * (usesChargeCounter(item) ? 1 : quantity), units: "cn" },
            cargoSlots: 1,
            sourceData: { sourceUuid, itemData, type: item.type, unitsPerPurchase: quantity },
            facets: {
                type: item.type, magical: magical ? "magical" : "mundane", shopTags: tags,
                merchandiseKind: shield ? "shield" : item.type === "armor" ? "armor"
                    : item.type === "weapon" ? "weapon" : ammunition ? "ammunition" : "",
                availability: magical ? "special" : "standard", rulesSource: source,
                stableKey: `${item.type}:${item.name.toLowerCase()}:${quantity}`, properties
            }
        };
    }

    static async #catalog(pack) {
        if (!this.#catalogs.has(pack.collection)) {
            const pending = (async () => {
                const entries = await pack.getIndex({ fields: INDEX_FIELDS });
                const products = [];
                for (const item of entries) {
                    if (!OSE_PHYSICAL_TYPES.has(item.type) || !itemQuantity(item) || coinValue(item)) continue;
                    const uuid = `Compendium.${pack.collection}.Item.${item._id}`;
                    const product = await this.productFromItem(item, { id: uuid, sourceUuid: uuid,
                        packId: pack.collection, packLabel: pack.metadata?.label || pack.title || pack.collection });
                    products.push({ ...product, packId: pack.collection, packLabel: pack.metadata?.label || pack.title });
                }
                return products;
            })();
            this.#catalogs.set(pack.collection, pending);
        }
        try { return await this.#catalogs.get(pack.collection); }
        catch (error) { this.#catalogs.delete(pack.collection); throw error; }
    }

    static async getAvailablePacks({ packIds = [], recommendedOnly = false } = {}) {
        const result = [];
        for (const pack of game.packs?.contents || []) {
            if (!isEligiblePack(pack) || (packIds.length && !packIds.includes(pack.collection))) continue;
            if (recommendedOnly && !RECOMMENDED_PACKS.has(pack.collection)) continue;
            const products = await this.#catalog(pack);
            if (!products.length) continue;
            const packageId = pack.metadata?.packageName;
            const official = pack.metadata?.packageType === "system";
            const world = pack.collection.startsWith("world.");
            result.push({ id: pack.collection, label: pack.metadata?.label || pack.title || pack.collection,
                originLabel: official ? game.system.title : world ? "This World" : game.modules.get(packageId)?.title || packageId,
                group: official ? "official" : world ? "world" : "module", eligibleCount: products.length,
                recommended: RECOMMENDED_PACKS.has(pack.collection) });
        }
        return result.sort((a, b) => a.label.localeCompare(b.label));
    }

    static async getCatalog({ packIds = [], limit = 5000 } = {}) {
        const result = [];
        for (const pack of game.packs?.contents || []) {
            if (!isEligiblePack(pack) || (packIds.length && !packIds.includes(pack.collection))) continue;
            result.push(...await this.#catalog(pack));
            if (result.length >= limit) break;
        }
        return result.slice(0, limit).sort((a, b) => a.name.localeCompare(b.name));
    }

    static async getCompendiumProduct(id) {
        const pack = (game.packs?.contents || []).find(pack => isEligiblePack(pack)
            && String(id).startsWith(`Compendium.${pack.collection}.Item.`));
        return pack ? (await this.#catalog(pack)).find(product => product.id === id) || null : null;
    }

    static async getAcquiredProduct(id, { shop } = {}) {
        const record = shop?.providerData?.[OSE_ACQUIRED_PROVIDER_ID]?.[id];
        if (!record?.itemData) return null;
        return this.productFromItem(record.itemData, { id, sourceUuid: record.sourceUuid || "",
            itemData: foundry.utils.deepClone(record.itemData), quantity: record.unitsPerPurchase || 1 });
    }

    static getCatalogSchema() {
        return { id: "ose-physical-items-v1",
            types: [...OSE_PHYSICAL_TYPES].map(id => ({ id, label: TYPE_LABELS[id] })),
            filterGroups: [
                { id: "magical", label: "Magic", dynamic: true, optionLabels: { mundane: "Mundane", magical: "Magical" } },
                { id: "shopTags", label: "Shop Category", dynamic: true },
                { id: "properties", label: "Properties", dynamic: true },
                { id: "rulesSource", label: "Source", dynamic: true, placement: "bottom" }
            ] };
    }

    static getStockTemplates() {
        return [
            ["blacksmith", "Blacksmith", ["weapon", "armor"], { magical: { mundane: 1 } }],
            ["general-store", "General Store", ["item", "container"], { shopTags: { outfitter: 1 } }],
            ["apothecary", "Apothecary", ["item"], { shopTags: { apothecary: 1 } }],
            ["magic-shop", "Magic Shop", [...OSE_PHYSICAL_TYPES], { magical: { magical: 1 } }]
        ].map(([id, name, activeTypes, filterState]) => ({ id, name, description: `Priced ${name.toLowerCase()} merchandise.`,
            count: { min: 6, max: 12 }, quantity: { min: 1, max: 3 },
            discovery: { activeTypes, filterState, price: { minimum: 1, maximum: null, requireListed: true } } }));
    }

    static register() {
        if (game.system?.id !== "ose") return;
        ShopProductProviderRegistry.register({ id: OSE_COMPENDIUM_PROVIDER_ID, label: "OSE Compendium Items",
            merchandiseKinds: ["armor", "shield", "weapon", "ammunition"], cacheProducts: true,
            getProduct: id => this.getCompendiumProduct(id), getCatalog: options => this.getCatalog(options),
            getAvailablePacks: options => this.getAvailablePacks(options), getCatalogSchema: () => this.getCatalogSchema(),
            getStockTemplates: () => this.getStockTemplates() });
        ShopProductProviderRegistry.register({ id: OSE_ACQUIRED_PROVIDER_ID, label: "Items Bought from Characters",
            getProduct: (id, context) => this.getAcquiredProduct(id, context) });
    }
}
