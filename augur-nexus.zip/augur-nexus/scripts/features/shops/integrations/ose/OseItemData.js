export const OSE_CURRENCY_ID = "ose-cp";
export const OSE_PHYSICAL_TYPES = new Set(["item", "weapon", "armor", "container"]);
export const OSE_COMPENDIUM_PROVIDER_ID = "augur-nexus:ose-compendium";
export const OSE_ACQUIRED_PROVIDER_ID = "augur-nexus:ose-acquired";

export function itemQuantity(item) {
    return Math.max(0, Math.floor(Number(item?.system?.quantity?.value ?? 1) || 0));
}

export function priceQuantity(item) {
    if (usesChargeCounter(item)) return 1;
    // Native catalogs use quantity.max for bundles such as quivers and lengths of rope.
    return Math.max(1, Math.floor(Number(item?.flags?.["augur-nexus"]?.osePriceQuantity
        ?? item?.system?.quantity?.max) || 1));
}

export function itemPrice(item, quantity = 1) {
    return Math.max(0, Math.floor((Number(item?.system?.cost) || 0) * 100 * quantity / priceQuantity(item) + 1e-8));
}

export function itemTags(item) {
    return (item?.system?.tags || []).map(tag => String(tag.value || tag.label || tag.title || "").toLowerCase());
}

export function usesChargeCounter(item) {
    // OSE has no quantity-mode field; the Classic Fantasy lantern stores fuel turns here.
    return item?.flags?.["augur-nexus"]?.oseQuantityMode === "charges"
        || item?.type === "item" && (/^lantern\b/i.test(String(item.name || "")) || itemTags(item).includes("charge-counter"));
}

export function tradeQuantity(item) {
    return usesChargeCounter(item) ? Number(itemQuantity(item) > 0) : itemQuantity(item);
}

export function coinValue(item) {
    if (item?.type !== "item" || !item.system?.treasure || item.flags?.["augur-nexus"]?.tradeGood) return 0;
    const name = String(item.name || "").trim().toLowerCase();
    const localized = ["short", "long"].map(key => game.i18n?.localize?.(`OSE.items.gp.${key}`)?.toLowerCase());
    const named = /^(cp|sp|ep|gp|pp)$/.test(name) || /\((cp|sp|ep|gp|pp)\)$/.test(name)
        || /^(copper|silver|electrum|gold|platinum)( coins?)?$/.test(name) || localized.includes(name);
    if (!named && !itemTags(item).some(tag => ["coin", "coins"].includes(tag))) return 0;
    // The native treasure cost is authoritative, including custom denomination values.
    return Math.max(0, Math.round((Number(item.system.cost) || 0) * 100));
}

export function copperToCoins(amount) {
    const cp = Math.max(0, Math.floor(Number(amount) || 0));
    return { gp: Math.floor(cp / 100), sp: Math.floor(cp % 100 / 10), cp: cp % 10 };
}

export function cleanItemSource(item, quantity = 1) {
    const data = foundry.utils.deepClone(typeof item.toObject === "function" ? item.toObject() : item);
    for (const key of ["_id", "folder", "sort", "ownership"]) delete data[key];
    data.system ||= {};
    data.system.quantity = { ...data.system.quantity, value: quantity };
    data.system.equipped = false;
    data.system.containerId = "";
    if (data.type === "container") data.system.itemIds = [];
    data.flags ||= {};
    data.flags.ose = { ...data.flags.ose, paid: true };
    data.flags["augur-nexus"] ||= {};
    data.flags["augur-nexus"].osePriceQuantity = priceQuantity(item);
    if (usesChargeCounter(item)) data.flags["augur-nexus"].oseQuantityMode = "charges";
    return data;
}

export function deliverySources(data) {
    const quantity = itemQuantity(data);
    const capacity = usesChargeCounter(data)
        ? Math.max(1, Math.floor(Number(data.flags?.["augur-nexus"]?.oseDeliveryQuantity) || quantity))
        : data.type === "item" ? Math.max(1, Math.floor(Number(data.system.quantity.max) || quantity)) : 1;
    const sources = [];
    for (let remaining = quantity; remaining > 0; remaining -= capacity) {
        const source = foundry.utils.deepClone(data);
        source.system.quantity.value = Math.min(remaining, capacity);
        if (source.flags?.["augur-nexus"]) delete source.flags["augur-nexus"].oseDeliveryQuantity;
        sources.push(source);
    }
    return sources;
}
