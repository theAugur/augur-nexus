import { ShopSystemAdapterRegistry } from "../../services/ShopSystemAdapterRegistry.js";
import { OSE_CURRENCY_ID, OSE_PHYSICAL_TYPES, OSE_COMPENDIUM_PROVIDER_ID,
    OSE_ACQUIRED_PROVIDER_ID, coinValue, copperToCoins, itemQuantity, itemPrice,
    cleanItemSource, deliverySources, tradeQuantity, usesChargeCounter } from "./OseItemData.js";

const MODULE_ID = "augur-nexus";
const WALLET_FLAG = "tradingActorUuid";
const INVENTORY_FLAG = "tradingInventoryByWallet";

export const OseTradeAdapter = {
    id: "ose",
    label: "Old-School Essentials",
    currencyId: OSE_CURRENCY_ID,

    isAvailable() { return game.system?.id === "ose"; },

    assignmentKey(uuid) {
        return String(uuid || "").replaceAll(".", "%2E");
    },

    async getDefaultWallet() {
        const rememberedUuid = game.user?.getFlag(MODULE_ID, WALLET_FLAG);
        const remembered = rememberedUuid ? await this.resolveActor(rememberedUuid) : null;
        if (this.isEligibleWallet(remembered, game.user)) return remembered;
        if (this.isEligibleWallet(game.user?.character, game.user)) return game.user.character;
        const owned = this.getEligibleWallets(game.user);
        return owned.length === 1 ? owned[0] : null;
    },

    async getDefaultInventoryHolder(wallet) {
        if (!wallet) return null;
        const assignments = game.user?.getFlag(MODULE_ID, INVENTORY_FLAG) || {};
        const uuid = assignments[this.assignmentKey(wallet.uuid)];
        const remembered = uuid ? await this.resolveActor(uuid) : null;
        return this.isEligibleInventoryHolder(remembered, game.user) ? remembered : wallet;
    },

    getEligibleWallets(user = game.user) {
        return game.actors.filter(actor => this.isEligibleWallet(actor, user)).sort((a, b) => a.name.localeCompare(b.name));
    },

    getEligibleInventoryHolders(user = game.user) {
        return game.actors.filter(actor => this.isEligibleInventoryHolder(actor, user)).sort((a, b) => a.name.localeCompare(b.name));
    },

    isEligibleWallet(actor, user = game.user) {
        return this.isOwnedActorOfType(actor, user, ["character"]);
    },

    isEligibleInventoryHolder(actor, user = game.user) {
        return this.isOwnedActorOfType(actor, user, ["character"]);
    },

    isOwnedActorOfType(actor, user, types) {
        if (!actor || actor.documentName !== "Actor" || !types.includes(actor.type)) return false;
        return user?.isGM || actor.testUserPermission(user, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER);
    },

    async rememberWallet(actor) {
        if (!this.isEligibleWallet(actor, game.user)) throw new Error("Choose an owned OSE character wallet.");
        await game.user.setFlag(MODULE_ID, WALLET_FLAG, actor.uuid);
        return actor;
    },

    async rememberInventoryHolder(wallet, actor) {
        if (!this.isEligibleWallet(wallet, game.user)) throw new Error("Select a wallet first.");
        if (!this.isEligibleInventoryHolder(actor, game.user)) throw new Error("Choose an owned OSE character inventory.");
        const assignments = { ...(game.user?.getFlag(MODULE_ID, INVENTORY_FLAG) || {}) };
        assignments[this.assignmentKey(wallet.uuid)] = actor.uuid;
        await game.user.setFlag(MODULE_ID, INVENTORY_FLAG, assignments);
        return actor;
    },

    async resolveActor(uuid) {
        if (!uuid) return null;
        const actor = await fromUuid(uuid).catch(() => null);
        return actor?.documentName === "Actor" ? actor : null;
    },

    groupActors(actors, selectedUuid = "") {
        return [
            { id: "character", label: "Characters" }
        ].map(group => ({
            ...group,
            actors: actors.filter(actor => actor.type === group.id).map(actor => ({
                uuid: actor.uuid,
                name: actor.name,
                img: actor.img,
                selected: actor.uuid === selectedUuid
            }))
        })).filter(group => group.actors.length);
    },


    async getActorView(actor) {
        if (!actor) return null;
        const encumbrance = actor.system.encumbrance;
        const value = Number(encumbrance?.value);
        const max = Number(encumbrance?.max);
        const units = encumbrance?.variant === "itembased" ? "slots" : "cn";
        const walletValue = this.getWalletValue(actor);
        return { uuid: actor.uuid, name: actor.name, img: actor.img, type: actor.type, typeLabel: "Character",
            wallet: this.formatPrice(walletValue), walletValue,
            weight: encumbrance?.enabled === false ? "Encumbrance disabled"
                : Number.isFinite(value) && Number.isFinite(max) ? `${value} / ${max} ${units}` : "Encumbrance unavailable",
            weightValue: Number.isFinite(value) ? value : null, weightMax: Number.isFinite(max) ? max : null,
            weightUnits: units };
    },

    getWalletCoins(actor) {
        return Array.from(actor?.items || []).filter(item => coinValue(item) && !item.system?.equipped);
    },
    getWalletValue(actor) {
        return this.getWalletCoins(actor).reduce((total, item) => total + coinValue(item) * itemQuantity(item), 0);
    },
    getItemQuantity: tradeQuantity,
    canAfford(actor, amount) { return this.getWalletValue(actor) >= Math.max(0, Math.round(Number(amount) || 0)); },
    formatPrice(amount) {
        const coins = copperToCoins(amount);
        return Object.entries(coins).filter(([, value]) => value).map(([key, value]) => `${value.toLocaleString()} ${key}`).join(" ") || "0 cp";
    },

    buildCoinChanges(actor, netAmount) {
        const coins = this.getWalletCoins(actor).map(item => ({ item, value: coinValue(item), quantity: itemQuantity(item) }))
            .sort((a, b) => a.value - b.value);
        let credit = Math.max(0, -netAmount);
        if (netAmount > 0) {
            if (!this.canAfford(actor, netAmount)) throw new Error(`${actor.name} cannot afford this trade.`);
            let remaining = netAmount;
            for (const coin of coins) {
                const spent = Math.min(coin.quantity, Math.floor(remaining / coin.value));
                coin.quantity -= spent;
                remaining -= spent * coin.value;
            }
            if (remaining) {
                const coin = coins.find(coin => coin.quantity > 0 && coin.value > remaining);
                coin.quantity--;
                credit = coin.value - remaining;
            }
        }
        const sources = [];
        for (const [denomination, quantity] of Object.entries(copperToCoins(credit))) {
            if (!quantity) continue;
            const value = { gp: 100, sp: 10, cp: 1 }[denomination];
            const existing = coins.find(coin => coin.value === value);
            if (existing) existing.quantity += quantity;
            else sources.push({ _id: foundry.utils.randomID(), name: denomination.toUpperCase(), type: "item",
                img: "systems/ose/assets/gold.png", system: { treasure: true, cost: value / 100,
                    weight: 1, itemslots: 0, quantity: { value: quantity, max: 0 }, containerId: "",
                    equipped: false, description: "", tags: [{ value: "coin" }] }, flags: { ose: { paid: true } } });
        }
        return { sources, updates: coins.filter(coin => coin.quantity !== itemQuantity(coin.item))
            .map(coin => ({ _id: coin.item.id, "system.quantity.value": coin.quantity })) };
    },

    async getSaleQuote(item) {
        let reason = "";
        if (!OSE_PHYSICAL_TYPES.has(item?.type)) reason = "This is not a physical OSE item.";
        else if (coinValue(item)) reason = "Coins belong in the trading wallet.";
        else if (!itemQuantity(item)) reason = "This item is depleted.";
        else if (item.system?.equipped === true) reason = "Unequip this item before selling it.";
        else if (item.system?.containerId) reason = "Remove this item from its container before selling it.";
        else if (item.type === "container" && (item.system?.itemIds?.length
            || Array.from(item.parent?.items || []).some(child => child.system?.containerId === item.id))) {
            reason = "Empty this container before selling it.";
        }
        const baseAmount = reason ? 0 : itemPrice(item);
        if (!reason && !baseAmount) reason = "This item has no listed value per unit.";
        return { eligible: !reason, reason, baseAmount };
    },

    async getInventoryItems(actor, { shop } = {}) {
        if (!actor) return [];
        const products = [];
        for (const item of actor.items) {
            if (!OSE_PHYSICAL_TYPES.has(item.type) || coinValue(item)) continue;
            const quote = await this.getSaleQuote(item);
            const name = usesChargeCounter(item) ? `${item.name} (${itemQuantity(item)}/${item.system.quantity.max || itemQuantity(item)})` : item.name;
            products.push({ itemId: item.id, uuid: item.uuid, name, imageSrc: item.img,
                type: item.type, quantity: tradeQuantity(item), equipped: item.system.equipped === true, attuned: false,
                eligible: quote.eligible, reason: quote.reason, baseAmount: quote.baseAmount,
                saleAmount: Math.floor(quote.baseAmount * (shop?.configuration?.customerSaleMultiplier ?? 0.75)),
                weight: { value: Math.max(0, Number(item.system?.weight) || 0), units: "cn" } });
        }
        return products.sort((a, b) => a.name.localeCompare(b.name));
    },

    async buildItemData(product, quantity, context = {}) {
        let source = product.sourceData?.itemData;
        if (!source && product.sourceData?.sourceUuid) {
            const item = await fromUuid(product.sourceData.sourceUuid).catch(() => null);
            if (item?.documentName !== "Item") throw new Error(`The source for ${product.name} is unavailable.`);
            source = item.toObject();
        }
        const units = Math.max(1, Math.floor(Number(product.sourceData?.unitsPerPurchase) || 1));
        let data;
        if (source) {
            if (!OSE_PHYSICAL_TYPES.has(source.type) || coinValue(source)) throw new Error("Only physical OSE merchandise can be purchased.");
            data = cleanItemSource(source, quantity * units);
            if (!itemPrice(data, units) && context.priceEach > 0) {
                data.system.cost = context.priceEach / 100;
                data.flags[MODULE_ID].osePriceQuantity = usesChargeCounter(data) ? 1 : units;
            }
        } else {
            data = { name: product.lotLabel || product.name, type: "item", img: product.imageSrc,
                system: { quantity: { value: quantity, max: 0 }, cost: (product.price?.amount || 0) / 100,
                    description: `<p>${foundry.utils.escapeHTML(product.description || "")}</p><p>Trade cargo. Set its carrying weight or item slots before adding it to carried equipment.</p>`,
                    weight: 0, itemslots: 0, containerId: "", equipped: false, treasure: true, tags: [] },
                flags: { [MODULE_ID]: { tradeGood: true, tradeGoodId: product.productId, osePriceQuantity: 1 } } };
        }
        data.flags ||= {};
        data.flags.ose = { ...data.flags.ose, paid: true };
        data.flags[MODULE_ID] ||= {};
        if (usesChargeCounter(data)) data.flags[MODULE_ID].oseDeliveryQuantity = units;
        data.flags[MODULE_ID].shopProduct = { providerId: product.providerId, productId: product.productId,
            shopUuid: context.shopUuid || "", transactionId: context.transactionId || "",
            walletUuid: context.walletUuid || "", inventoryUuid: context.inventoryUuid || "",
            acquisitionPrice: context.priceEach || 0 };
        return data;
    },

    async createStockProduct(item) {
        if (item?.documentName !== "Item" || !OSE_PHYSICAL_TYPES.has(item.type) || coinValue(item)) {
            throw new Error("Only physical OSE merchandise can be added to Shop stock.");
        }
        if (!itemQuantity(item)) {
            throw new Error("Stock an item with a positive quantity.");
        }
        if (item.pack || item.uuid?.startsWith("Compendium.")) {
            return { providerId: OSE_COMPENDIUM_PROVIDER_ID, productId: item.uuid, quantity: 1, sourceUuid: item.uuid };
        }
        const unitsPerPurchase = itemQuantity(item);
        return { providerId: OSE_ACQUIRED_PROVIDER_ID, productId: foundry.utils.randomID(), quantity: 1,
            sourceUuid: item.uuid, productData: { itemData: cleanItemSource(item, unitsPerPurchase), unitsPerPurchase,
                sourceUuid: item.uuid, stockedByUserId: game.user?.id || "" } };
    },

    async createSaleProduct(item, quantity, context = {}) {
        const unitsPerPurchase = usesChargeCounter(item) ? itemQuantity(item) : 1;
        return { providerId: OSE_ACQUIRED_PROVIDER_ID, productId: foundry.utils.randomID(), quantity,
            productData: { itemData: cleanItemSource(item, unitsPerPurchase), unitsPerPurchase,
                sourceUuid: item._stats?.compendiumSource || "", sellerUuid: context.sellerUuid || "",
                transactionId: context.transactionId || "", acquisitionPrice: context.acquisitionPrice || 0 } };
    },

    async createActorTradeSession({ wallet, inventoryActor, purchasedItemData = [], sales = [], netAmount = 0 } = {}) {
        const originalCoins = this.getWalletCoins(wallet).map(item => foundry.utils.deepClone(item.toObject()));
        const originalSales = sales.map(sale => foundry.utils.deepClone(sale.item.toObject()));
        const sources = purchasedItemData.flatMap(deliverySources).map(data => ({ ...data, _id: foundry.utils.randomID() }));
        let currencyTouched = false;
        let coinChanges;
        let inventoryTouched = false;
        return {
            apply: async () => {
                coinChanges = this.buildCoinChanges(wallet, netAmount);
                for (const sale of sales) {
                    const live = inventoryActor.items.get(sale.item.id);
                    const original = originalSales.find(source => source._id === sale.item.id);
                    if (!live || tradeQuantity(live) !== sale.available || itemQuantity(live) !== itemQuantity(original)
                        || !(await this.getSaleQuote(live)).eligible) {
                        throw new Error("The inventory changed. Review this trade again.");
                    }
                }
                inventoryTouched = true;
                const updates = sales.filter(sale => sale.available > sale.line.quantity)
                    .map(sale => ({ _id: sale.item.id, "system.quantity.value": sale.available - sale.line.quantity }));
                const deletions = sales.filter(sale => sale.available === sale.line.quantity).map(sale => sale.item.id);
                if (updates.length) await inventoryActor.updateEmbeddedDocuments("Item", updates);
                if (deletions.length) await inventoryActor.deleteEmbeddedDocuments("Item", deletions);
                if (sources.length) {
                    const created = await inventoryActor.createEmbeddedDocuments("Item", sources, { keepId: true });
                    if (created.length !== sources.length) throw new Error("Not all purchased items could be delivered.");
                }
                if (netAmount) {
                    currencyTouched = true;
                    if (coinChanges.updates.length) await wallet.updateEmbeddedDocuments("Item", coinChanges.updates);
                    if (coinChanges.sources.length) {
                        const created = await wallet.createEmbeddedDocuments("Item", coinChanges.sources, { keepId: true });
                        if (created.length !== coinChanges.sources.length) throw new Error("Not all change could be delivered.");
                    }
                }
            },
            rollback: async () => {
                if (inventoryTouched) {
                    const createdIds = sources.map(source => source._id).filter(id => inventoryActor.items.has(id));
                    if (createdIds.length) await inventoryActor.deleteEmbeddedDocuments("Item", createdIds);
                    const existing = originalSales.filter(source => inventoryActor.items.has(source._id));
                    const missing = originalSales.filter(source => !inventoryActor.items.has(source._id));
                    if (existing.length) await inventoryActor.updateEmbeddedDocuments("Item", existing.map(source =>
                        ({ _id: source._id, "system.quantity.value": source.system.quantity.value })));
                    if (missing.length) await inventoryActor.createEmbeddedDocuments("Item", missing, { keepId: true });
                }
                if (currencyTouched) {
                    const newCoins = coinChanges.sources.map(source => source._id).filter(id => wallet.items.has(id));
                    if (newCoins.length) await wallet.deleteEmbeddedDocuments("Item", newCoins);
                    if (originalCoins.length) await wallet.updateEmbeddedDocuments("Item", originalCoins.map(source =>
                        ({ _id: source._id, "system.quantity.value": source.system.quantity.value })));
                }
            }
        };
    }
};

export function registerOseTradeAdapter() {
    ShopSystemAdapterRegistry.register(OseTradeAdapter);
}

