import { Dnd5eItemProvider } from "./dnd5e/Dnd5eItemProvider.js";
import { registerDnd5eTradeAdapter } from "./dnd5e/Dnd5eTradeAdapter.js";
import { Pf2eItemProvider } from "./pf2e/Pf2eItemProvider.js";
import { registerPf2eTradeAdapter } from "./pf2e/Pf2eTradeAdapter.js";

export function registerBundledShopIntegrations() {
    Dnd5eItemProvider.register();
    registerDnd5eTradeAdapter();
    Pf2eItemProvider.register();
    registerPf2eTradeAdapter();
}