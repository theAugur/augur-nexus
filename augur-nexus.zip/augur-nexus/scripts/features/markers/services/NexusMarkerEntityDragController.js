import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { NexusMarkerService } from "./NexusMarkerService.js";
import { SiteRecordManager } from "../../site/services/SiteRecordManager.js";
import { SiteSceneVisibilityManager } from "../../site/services/SiteSceneVisibilityManager.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";

const DRAG_THRESHOLD = 7;
const DRAGGABLE_ENTITY_TYPES = new Set(["location", "npc", "ship", "quest"]);
const MOVABLE_ENTITY_TYPES = new Set(["npc", "ship", "quest"]);

export class NexusMarkerEntityDragController {
    static #state = null;

    static begin(placeable, originalEvent, { onClick = null } = {}) {
        if (Number(originalEvent?.button ?? 0) !== 0) return false;

        const source = this.#resolveSource(placeable);
        if (!source) return false;
        const { record, node } = source;
        const payload = ConnectionTargetResolver.getDragData(node);
        if (!payload) return false;

        const point = this.#eventPoint(originalEvent);
        if (!point) return false;

        this.cancel();
        this.#state = {
            placeable,
            record,
            node,
            payload: {
                ...payload,
                augurNexusDragOrigin: "map-marker"
            },
            onClick,
            origin: point,
            point,
            started: false,
            preview: null,
            dataTransfer: null,
            hoverTarget: null,
            overCanvas: false,
            accepted: false
        };
        this.#bindDocumentListeners();
        return true;
    }

    static #resolveSource(placeable) {
        let record = NexusMarkerService.getMarkerRecord(placeable);
        if (!record) {
            const doc = placeable?.document || placeable;
            if (!doc?.flags?.["augur-nexus"]?.site) return null;
            const site = SiteRecordManager.resolveSite({ parentScene: doc.parent || canvas.scene, placeable });
            if (!site?.parentSceneId || !site.siteId) return null;
            // Older tiles and notes need only a transient drag description, never marker conversion.
            record = {
                target: { kind: "nexus-site", parentSceneId: site.parentSceneId, siteId: site.siteId },
                presentation: { name: site.siteName, iconSrc: site.siteIconSrc }
            };
        }
        const target = record.target || {};
        let node;
        if (target.kind === "campaign-entity") {
            if (!DRAGGABLE_ENTITY_TYPES.has(target.entityType) || !target.entityId) return null;
            node = ConnectionTargetResolver.fromEntityReference({ entityId: target.entityId });
            if (!node || !ConnectionTargetResolver.canUserSeeNode(node)) return null;
        } else if (target.kind === "nexus-site") {
            const scene = game.scenes.get(target.parentSceneId);
            if (!scene || !NexusPlayerSceneAccess.canUserSeeSceneInNexus(scene)) return null;
            const site = SiteRecordManager.resolveSite({ parentScene: scene, siteId: target.siteId,
                journalEntryId: target.journalEntryId, pageId: target.pageId });
            if (!site || !SiteSceneVisibilityManager.canUserSeeSite({ scene, siteId: site.siteId, record: site })) return null;
            node = ConnectionTargetResolver.fromSiteRecord(site);
        } else if (target.kind === "nexus-scene") {
            const scene = game.scenes.get(target.sceneId);
            if (!scene || !NexusPlayerSceneAccess.canUserSeeSceneInNexus(scene)) return null;
            node = ConnectionTargetResolver.fromSceneReference({ sceneId: scene.id });
        } else return null;
        return node ? { record, node } : null;
    }

    static cancel() {
        if (!this.#state) return;
        this.#leaveCurrentTarget();
        this.#removePreview();
        this.#state = null;
        this.#unbindDocumentListeners();
    }

    static #onMove = event => {
        const state = this.#state;
        if (!state) return;
        const point = this.#eventPoint(event);
        if (!point) return;
        state.point = point;

        if (!state.started) {
            const distance = Math.hypot(point.x - state.origin.x, point.y - state.origin.y);
            if (distance < DRAG_THRESHOLD) return;
            state.started = true;
            state.dataTransfer = this.#createDataTransfer(state.payload);
            this.#createPreview();
            document.body.classList.add("augur-nexus-marker-entity-dragging");
        }

        event.preventDefault?.();
        this.#positionPreview(point);
        this.#updateHoverTarget(point);
    };

    static #onUp = event => {
        const state = this.#state;
        if (!state) return;
        const point = this.#eventPoint(event) || state.point;

        if (!state.started) {
            const onClick = state.onClick;
            this.cancel();
            onClick?.();
            return;
        }

        event.preventDefault?.();
        event.stopPropagation?.();
        this.#positionPreview(point);
        this.#updateHoverTarget(point);
        const shouldMoveMarker = state.overCanvas && state.record?.target?.kind === "campaign-entity"
            && MOVABLE_ENTITY_TYPES.has(state.record.target.entityType);
        if (state.accepted && state.hoverTarget) {
            this.#dispatchDragEvent("drop", state.hoverTarget, point);
        }
        this.cancel();
        if (shouldMoveMarker) this.#moveMarkerOnCanvas(state, point);
    };

    static #onCancel = () => this.cancel();

    static #onKeyDown = event => {
        if (event.key === "Escape") this.cancel();
    };

    static #bindDocumentListeners() {
        document.addEventListener("pointermove", this.#onMove, true);
        document.addEventListener("pointerup", this.#onUp, true);
        document.addEventListener("pointercancel", this.#onCancel, true);
        document.addEventListener("mousemove", this.#onMove, true);
        document.addEventListener("mouseup", this.#onUp, true);
        document.addEventListener("keydown", this.#onKeyDown, true);
        window.addEventListener("blur", this.#onCancel, true);
    }

    static #unbindDocumentListeners() {
        document.removeEventListener("pointermove", this.#onMove, true);
        document.removeEventListener("pointerup", this.#onUp, true);
        document.removeEventListener("pointercancel", this.#onCancel, true);
        document.removeEventListener("mousemove", this.#onMove, true);
        document.removeEventListener("mouseup", this.#onUp, true);
        document.removeEventListener("keydown", this.#onKeyDown, true);
        window.removeEventListener("blur", this.#onCancel, true);
    }

    static #updateHoverTarget(point) {
        const state = this.#state;
        if (!state?.started) return;
        const candidate = document.elementFromPoint(point.x, point.y);
        state.overCanvas = this.#isCanvasSurface(candidate);
        const nextTarget = state.overCanvas ? null : candidate;
        if (nextTarget !== state.hoverTarget) {
            if (state.hoverTarget) this.#dispatchDragEvent("dragleave", state.hoverTarget, point, nextTarget);
            if (nextTarget) this.#dispatchDragEvent("dragenter", nextTarget, point, state.hoverTarget);
            state.hoverTarget = nextTarget;
        }
        state.accepted = !!nextTarget && this.#dispatchDragEvent("dragover", nextTarget, point) === false;
    }

    static #leaveCurrentTarget() {
        const state = this.#state;
        if (!state?.hoverTarget) return;
        this.#dispatchDragEvent("dragleave", state.hoverTarget, state.point);
        state.hoverTarget = null;
        state.overCanvas = false;
        state.accepted = false;
    }

    static #dispatchDragEvent(type, target, point, relatedTarget = null) {
        if (!target || !this.#state?.dataTransfer) return true;
        const init = {
            bubbles: true,
            cancelable: true,
            composed: true,
            clientX: point?.x || 0,
            clientY: point?.y || 0,
            relatedTarget,
            dataTransfer: this.#state.dataTransfer
        };
        let event;
        try {
            event = new DragEvent(type, init);
        } catch (_error) {
            event = new Event(type, { bubbles: true, cancelable: true, composed: true });
            for (const [key, value] of Object.entries(init)) {
                if (key === "bubbles" || key === "cancelable" || key === "composed") continue;
                Object.defineProperty(event, key, { configurable: true, value });
            }
        }
        return target.dispatchEvent(event);
    }

    static #createDataTransfer(payload) {
        let transfer;
        try {
            transfer = new DataTransfer();
        } catch (_error) {
            const values = new Map();
            transfer = {
                effectAllowed: "copy",
                dropEffect: "copy",
                setData: (type, value) => values.set(type, String(value)),
                getData: type => values.get(type) || "",
                clearData: type => type ? values.delete(type) : values.clear()
            };
        }
        const serialized = JSON.stringify(payload);
        transfer.setData("text/plain", serialized);
        transfer.setData("application/json", serialized);
        try { transfer.effectAllowed = "copy"; } catch (_error) { /* Browser-owned DataTransfer state may be read-only. */ }
        return transfer;
    }

    static #createPreview() {
        const state = this.#state;
        if (!state || state.preview) return;
        const preview = document.createElement("div");
        preview.className = "augur-nexus-marker-entity-drag-preview is-marker-preview";

        const visual = document.createElement("div");
        visual.className = "augur-nexus-marker-entity-drag-visual";
        const doc = state.placeable?.document || state.placeable || null;
        const width = Math.max(1, Number(doc?.width || 1));
        const height = Math.max(1, Number(doc?.height || 1));
        const scale = Math.min(120 / width, 88 / height, 1);
        visual.style.width = `${Math.max(32, Math.round(width * scale))}px`;
        visual.style.height = `${Math.max(32, Math.round(height * scale))}px`;

        const imageSrc = state.record?.presentation?.iconSrc || doc?.texture?.src || state.node.img || "";
        if (imageSrc) {
            const image = document.createElement("img");
            image.src = imageSrc;
            image.alt = "";
            image.style.transform = `rotate(${Number(doc?.rotation || state.record?.placement?.rotation || 0)}deg)`;
            visual.append(image);
        } else {
            const icon = document.createElement("i");
            icon.className = this.#fallbackIcon(state.record?.target?.entityType);
            visual.append(icon);
        }
        preview.append(visual);

        const name = document.createElement("strong");
        name.textContent = state.record?.presentation?.name || state.node.name || "Marker";
        preview.append(name);
        document.body.append(preview);
        state.preview = preview;
        this.#positionPreview(state.point);
    }

    static #positionPreview(point) {
        const preview = this.#state?.preview;
        if (!preview || !point) return;
        preview.style.left = `${Math.round(point.x)}px`;
        preview.style.top = `${Math.round(point.y)}px`;
    }

    static #removePreview() {
        this.#state?.preview?.remove();
        if (this.#state) this.#state.preview = null;
        document.body.classList.remove("augur-nexus-marker-entity-dragging");
    }

    static #eventPoint(event) {
        const x = Number(event?.clientX);
        const y = Number(event?.clientY);
        if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
        return { x, y };
    }

    static #isCanvasSurface(target) {
        const board = document.getElementById("board");
        return !!target && !!board && (target === board || board.contains(target));
    }

    static #moveMarkerOnCanvas(state, point) {
        if (!game.user?.isGM) {
            ui.notifications.warn("Only the GM can move Nexus markers.");
            return;
        }
        if (!canvas?.scene || !canvas.canvasCoordinatesFromClient) return;
        const position = canvas.canvasCoordinatesFromClient({ x: point.x, y: point.y });
        if (!position || !canvas.dimensions?.rect?.contains(position.x, position.y)) return;
        NexusMarkerService.moveMarker(state.placeable, position).catch(error => {
            console.error("Augur Nexus | Failed to move campaign entity marker.", error);
            ui.notifications.error("Could not move that Nexus marker.");
        });
    }

    static #fallbackIcon(entityType = "") {
        if (entityType === "npc") return "fas fa-user";
        if (entityType === "ship") return "fas fa-rocket";
        if (entityType === "quest") return "fas fa-scroll";
        return "fas fa-location-dot";
    }
}
