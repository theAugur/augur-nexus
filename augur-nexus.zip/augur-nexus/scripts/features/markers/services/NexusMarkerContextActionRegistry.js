export class NexusMarkerContextActionRegistry {
    static #actions = new Map();

    static register(definition = {}) {
        const id = String(definition.id || "").trim();
        const moduleId = String(definition.moduleId || "").trim();
        if (!id) throw new Error("Marker context actions require an id.");
        if (!moduleId) throw new Error(`Marker context action "${id}" requires a moduleId.`);
        if (typeof definition.onSelect !== "function") {
            throw new Error(`Marker context action "${id}" requires an onSelect handler.`);
        }

        const action = {
            id,
            moduleId,
            label: definition.label,
            icon: String(definition.icon || "fas fa-puzzle-piece").trim(),
            order: Number(definition.order) || 0,
            matches: typeof definition.matches === "function" ? definition.matches : () => true,
            onSelect: definition.onSelect
        };
        this.#actions.set(id, action);
        return { id, moduleId };
    }

    static unregister(id) {
        return this.#actions.delete(String(id || "").trim());
    }

    static listFor(context = {}) {
        return [...this.#actions.values()]
            .filter(action => {
                try { return action.matches(context) !== false; }
                catch (error) {
                    console.error(`Augur Nexus | Marker context action "${action.id}" match failed`, error);
                    return false;
                }
            })
            .sort((left, right) => left.order - right.order || left.id.localeCompare(right.id))
            .map(action => ({
                id: action.id,
                label: typeof action.label === "function"
                    ? String(action.label(context) || action.id)
                    : String(action.label || action.id),
                icon: action.icon,
                onSelect: () => action.onSelect(context)
            }));
    }
}
