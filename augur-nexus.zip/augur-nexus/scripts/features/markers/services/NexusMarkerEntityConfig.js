import { questMarkerConfig } from "../../quests/integration/QuestMarkerSupport.js";

export function getMarkerEntityConfig(type, placementTab) {
    return type === "quest" ? questMarkerConfig : placementTab.getConfig(type);
}
