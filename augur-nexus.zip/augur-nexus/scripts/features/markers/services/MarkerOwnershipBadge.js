import { MarkerOwnershipPresentationResolver } from "./MarkerOwnershipPresentationResolver.js";
import { CampaignEntityJournalStore } from "../../campaign-entities/services/CampaignEntityJournalStore.js";
import { FactionEntityModel } from "../../campaign-entities/models/FactionEntityModel.js";

const MODULE_ID = "augur-nexus";

/** Disposable canvas decoration. Ownership and emblem data stay on their existing authorities. */
export class MarkerOwnershipBadge {
    static #badges = new Map();
    static #bounds = new WeakMap();
    static #refreshTimer = null;

    static registerHooks() {
        Hooks.on("drawDrawing", drawing => {
            this.remove(drawing);
            this.refresh(drawing);
        });
        Hooks.on("refreshDrawing", drawing => this.refresh(drawing));
        Hooks.on("destroyDrawing", drawing => this.remove(drawing));
        Hooks.on("canvasTearDown", () => {
            clearTimeout(this.#refreshTimer);
            this.#refreshTimer = null;
            for (const drawing of this.#badges.keys()) this.remove(drawing);
        });
        for (const event of ["canvasReady", "augurNexusConnectionsReady", "augurNexusConnectionsChanged",
            "augurNexusCampaignEntitiesReady", "augurNexusCampaignEntitiesChanged", "augurNexusCampaignEntityVisibilityChanged"]) {
            Hooks.on(event, () => this.#queueRefresh());
        }
    }

    static refresh(drawing) {
        const flags = drawing?.document?.flags?.[MODULE_ID];
        const target = flags?.target;
        if (!flags?.markerLabel
            || !drawing.shape || drawing.shape.destroyed || drawing.destroyed) return this.remove(drawing);
        const ownership = MarkerOwnershipPresentationResolver.resolve({ target });
        if (!ownership.active) return this.remove(drawing);
        const sources = ownership.emblemFactionIds.map((id, index) => {
            const faction = CampaignEntityJournalStore.getFaction(id);
            return { src: faction ? FactionEntityModel.getImage(faction) : "", side: index === 0 ? "left" : "right" };
        }).filter(item => item.src);
        if (!sources.length) return this.remove(drawing);
        const key = JSON.stringify(sources);
        let badge = this.#badges.get(drawing);
        if (badge?.key === key && badge.parent === drawing.shape && badge.items.every(item => !item.sprite.destroyed)) {
            this.#position(drawing, badge);
            return;
        }
        this.remove(drawing);
        badge = { key, parent: drawing.shape, items: [] };
        this.#badges.set(drawing, badge);
        Promise.all(sources.map(({ src }) => foundry.canvas.loadTexture(src).catch(error => {
            console.warn("Augur Nexus | Could not load a location ownership badge.", error);
            return null;
        }))).then(textures => {
            // Loading can finish after reparenting, an artwork edit, or a scene switch.
            if (this.#badges.get(drawing) !== badge || drawing.destroyed || badge.parent.destroyed
                || drawing.shape !== badge.parent) return;
            for (const [index, texture] of textures.entries()) {
                if (!texture?.valid) continue;
                const sprite = new PIXI.Sprite(texture);
                sprite.eventMode = "none";
                badge.parent.addChild(sprite);
                badge.items.push({ sprite, bounds: this.#visibleBounds(texture), side: sources[index].side });
            }
            this.#position(drawing, badge);
        }).catch(error => console.warn("Augur Nexus | Could not display location ownership badges.", error));
    }

    static remove(drawing) {
        const badge = this.#badges.get(drawing);
        this.#badges.delete(drawing);
        // Foundry's shared textures must survive removal of individual labels.
        for (const item of badge?.items || []) {
            if (!item.sprite.destroyed) item.sprite.destroy({ texture: false, baseTexture: false });
        }
    }

    static #queueRefresh() {
        if (this.#refreshTimer) return;
        this.#refreshTimer = setTimeout(() => {
            this.#refreshTimer = null;
            for (const drawing of canvas.drawings?.placeables || []) this.refresh(drawing);
        }, 50);
    }

    static #position(drawing, badge) {
        const height = Number(drawing.document.shape?.height || drawing.document.fontSize || 22);
        const fontSize = Number(drawing.document.fontSize || 22);
        const badgeHeight = 1.5 * Math.min(height, fontSize * 1.5);
        const gap = Math.max(1, fontSize * 0.06) + Number(drawing.document.strokeWidth || 0) / 2;
        const width = Number(drawing.document.shape?.width || 0);
        // Parent on the left, local owner on the right; independent owners stay on the left.
        for (const { sprite, bounds, side } of badge.items) {
            const scale = Math.min(badgeHeight / bounds.height, badgeHeight * 1.25 / bounds.width);
            sprite.scale.set(scale);
            const x = side === "right" ? width + gap - bounds.x * scale : -gap - (bounds.x + bounds.width) * scale;
            sprite.position.set(x,
                height / 2 - (bounds.y + bounds.height / 2) * scale);
            sprite.alpha = drawing.document.textAlpha ?? 1;
        }
    }

    static #visibleBounds(texture) {
        if (this.#bounds.has(texture)) return this.#bounds.get(texture);
        const width = texture.orig.width;
        const height = texture.orig.height;
        let bounds = { x: 0, y: 0, width, height };
        const source = texture.baseTexture?.resource?.source;
        if (source) {
            try {
                // Measure once per shared texture; transparent margins should not become a label gap.
                const sample = document.createElement("canvas");
                sample.width = sample.height = 128;
                const context = sample.getContext("2d", { willReadFrequently: true });
                context.drawImage(source, 0, 0, 128, 128);
                const pixels = context.getImageData(0, 0, 128, 128).data;
                let left = 128, top = 128, right = -1, bottom = -1;
                for (let y = 0; y < 128; y++) {
                    for (let x = 0; x < 128; x++) {
                        if (pixels[(y * 128 + x) * 4 + 3] < 8) continue;
                        left = Math.min(left, x); right = Math.max(right, x);
                        top = Math.min(top, y); bottom = Math.max(bottom, y);
                    }
                }
                if (right >= left && bottom >= top) bounds = {
                    x: left / 128 * width, y: top / 128 * height,
                    width: (right - left + 1) / 128 * width, height: (bottom - top + 1) / 128 * height
                };
            } catch (_error) {
                // Images without readable pixels still retain their original proportions.
            }
        }
        this.#bounds.set(texture, bounds);
        return bounds;
    }
}
