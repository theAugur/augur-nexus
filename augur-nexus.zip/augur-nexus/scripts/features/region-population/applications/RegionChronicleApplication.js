import { RegionalChroniclePanel } from "../components/RegionalChroniclePanel.js";
import { ToolWindowLifecycle } from "../../../support/toolbar/ToolWindowLifecycle.js";
import { activateNexusThemeSurface, deactivateNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const instances = new Map();

export class RegionChronicleApplication extends HandlebarsApplicationMixin(ApplicationV2) {
    #sceneId;
    #chroniclePanel;
    #chronicleHookId = null;
    #entityHookId = null;
    #canvasHookId = null;

    static DEFAULT_OPTIONS = {
        id: "augur-region-chronicle",
        tag: "div",
        classes: ["augur-nexus", "augur-theme-fantasy", "augur-region-chronicle-app"],
        window: {
            title: "Regional Chronicle",
            icon: "fas fa-book-open",
            resizable: true,
            minimizable: true
        },
        position: { width: 1130, height: 780, left: 110, top: 60 },
    };

    static PARTS = {
        content: {
            template: "modules/augur-nexus/templates/region-population/region-chronicle.hbs",
            scrollable: [".chronicle-ledger__record"],
            templates: ["modules/augur-nexus/templates/region-population/chronicle-event-list.hbs"]
        }
    };

    static show({ sceneId = canvas.scene?.id } = {}) {
        const id = String(sceneId || "");
        if (!id) return null;
        return ToolWindowLifecycle.open("fantasy-region-chronicle", () => {
            let application = instances.get(id);
            if (!application) {
                application = new this({ sceneId: id }, { id: `augur-region-chronicle-${id}` });
                instances.set(id, application);
            }
            return application;
        });
    }

    constructor({ sceneId = canvas.scene?.id } = {}, options = {}) {
        super(options);
        this.#sceneId = String(sceneId || "");
        this.#chroniclePanel = new RegionalChroniclePanel({ sceneId: this.#sceneId });
        this.#chronicleHookId = Hooks.on("augurNexusRegionChronicleChanged", payload => {
            if (String(payload?.sceneId || "") !== this.#sceneId) return;
            if (payload.reason === "delete") void this.close();
            else void this.render({ force: true });
        });
        this.#entityHookId = Hooks.on("augurNexusCampaignEntitiesChanged", payload => {
            if (!["updateNpc", "updateFaction", "updateLocation", "updateShip"].includes(String(payload?.reason || ""))) return;
            void this.render({ force: true });
        });
        this.#canvasHookId = Hooks.on("canvasReady", activeCanvas => {
            const activeSceneId = String(activeCanvas?.scene?.id || canvas.scene?.id || "");
            if (activeSceneId && activeSceneId !== this.#sceneId) void this.close();
        });

    }

    get title() {
        return `${this.scene?.name || "Region"} — Regional Chronicle`;
    }
    get scene() {
        return game.scenes.get(this.#sceneId) || null;
    }

    async _prepareContext(options) {
        return { ...(super._prepareContext ? await super._prepareContext(options) : {}), ...this.#chroniclePanel.getContext() };
    }

    _onRender(context, options) {
        super._onRender(context, options);
        activateNexusThemeSurface(this, { windowClass: "augur-region-chronicle-app", surfaceSelector: ".chronicle-ledger" });
        this.#chroniclePanel.activateListeners(this.element);
    }

    _onClose(options) {
        deactivateNexusThemeSurface(this);
        ToolWindowLifecycle.released(this);
        this.#chroniclePanel.destroy();
        if (this.#chronicleHookId !== null) Hooks.off("augurNexusRegionChronicleChanged", this.#chronicleHookId);
        if (this.#entityHookId !== null) Hooks.off("augurNexusCampaignEntitiesChanged", this.#entityHookId);
        if (this.#canvasHookId !== null) Hooks.off("canvasReady", this.#canvasHookId);
        instances.delete(this.#sceneId);
        return super._onClose(options);
    }

}
