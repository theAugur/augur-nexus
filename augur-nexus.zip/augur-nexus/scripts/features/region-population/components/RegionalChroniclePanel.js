import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { prepareNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";
import { RegionChronicleService } from "../services/RegionChronicleService.js";
import { RegionChronicleViewModel } from "../services/RegionChronicleViewModel.js";
import { RegionPopulationRunStore } from "../services/RegionPopulationRunStore.js";

/** One regional record, shared by the standalone reader and expanded dossiers. */
export class RegionalChroniclePanel {
    #sceneId = "";
    #filters = { search: "", faction: "", actor: "", type: "", scope: "regional", yearFrom: "", yearTo: "" };
    #searchTimer = null;
    #readingOrder = "oldest";
    #filterRevision = 0;
    #root = null;
    #listeners = null;

    constructor({ sceneId = "" } = {}) { this.setSceneId(sceneId); }

    setSceneId(sceneId) {
        const next = String(sceneId || "");
        if (next === this.#sceneId) return;
        this.destroy();
        this.#sceneId = next;
        this.#filters = { search: "", faction: "", actor: "", type: "", scope: "regional", yearFrom: "", yearTo: "" };
        this.#readingOrder = "oldest";
    }

    get scene() { return game.scenes.get(this.#sceneId) || null; }

    getContext() {
        const scene = this.scene;
        const run = RegionPopulationRunStore.get(scene);
        const chronicle = RegionChronicleService.getData(scene, run);
        const events = Array.isArray(chronicle?.events) ? chronicle.events : [];
        const eventViews = events.map(event => RegionChronicleViewModel.prepareEvent(event));
        const yearValues = eventViews.map(event => Number(event.year || 0)).filter(Number.isFinite);
        const minYear = yearValues.length ? Math.min(...yearValues) : 1;
        const maxYear = yearValues.length ? Math.max(...yearValues) : Number(chronicle?.years || 1);
        const filtered = eventViews.filter(event => RegionChronicleViewModel.matchesFilters(event, this.#filters));
        const years = RegionChronicleViewModel.groupByYear(filtered);
        if (this.#readingOrder === "newest") years.reverse();

        return {
            available: !!chronicle,
            appearance: prepareNexusThemeSurface(),
            chronicle,
            filters: foundry.utils.deepClone(this.#filters),
            factionOptions: RegionChronicleViewModel.participantOptions(eventViews, "faction"),
            actorOptions: RegionChronicleViewModel.participantOptions(eventViews, "actor"),
            readingOrder: this.#readingOrder,
            orderOptions: [{ value: "oldest", label: "Oldest first" }, { value: "newest", label: "Newest first" }],
            typeOptions: RegionChronicleViewModel.typeOptions(eventViews),
            scopeOptions: [
                { value: "regional", label: "Regional record" },
                { value: "all", label: "All events" },
                { value: "personal", label: "Personal events" }
            ],
            minYear,
            maxYear,
            years,
            totalEvents: events.length,
            visibleEvents: filtered.length,
            summaryItems: RegionChronicleViewModel.summaryItems(chronicle, { includeEmpty: true }).filter(item => ["Years", "Settlements", "People", "Factions"].includes(item.label)).map(item => item.label === "Years" ? { ...item, label: "Year" } : item),
            hasFilters: Object.entries(this.#filters).some(([key, value]) => key === "scope" ? value !== "regional" : !!value)
        };
    }

    async render() {
        await foundry.applications.handlebars.loadTemplates([
            "modules/augur-nexus/templates/region-population/chronicle-event-list.hbs"
        ]);
        return foundry.applications.handlebars.renderTemplate(
            "modules/augur-nexus/templates/region-population/region-chronicle.hbs", this.getContext()
        );
    }

    activateListeners(root, { openParticipant } = {}) {
        this.destroy();
        const panel = root?.matches?.(".chronicle-ledger") ? root : root?.querySelector?.(".chronicle-ledger");
        if (!panel) return;
        this.#root = panel;
        this.#listeners = new AbortController();
        const options = { signal: this.#listeners.signal };
        for (const input of panel.querySelectorAll("[data-chronicle-filter]")) {
            input.addEventListener(input.dataset.chronicleFilter === "search" ? "input" : "change", () => this.#queueFilterRender(input), options);
        }
        panel.querySelector("[data-chronicle-order]")?.addEventListener("change", event => {
            this.#readingOrder = event.target.value === "newest" ? "newest" : "oldest";
            clearTimeout(this.#searchTimer);
            void this.#refreshRecord();
        }, options);
        // Delegate because filtering replaces the event list while controls stay mounted.
        panel.addEventListener("click", event => {
            const action = event.target.closest?.("[data-action]");
            if (!action || !panel.contains(action)) return;
            if (action.dataset.action === "resetFilters") {
                event.preventDefault();
                event.stopPropagation();
                void this.resetFilters();
            } else if (action.dataset.action === "openChronicleParticipant") {
                event.preventDefault();
                event.stopPropagation();
                const entityId = String(action.dataset.entityId || "");
                if (entityId) void (openParticipant ? openParticipant(entityId) : ConnectionTargetResolver.openNode(ConnectionTargetResolver.fromEntityReference({ entityId })));
            }
        }, options);
    }

    async resetFilters() {
        this.#filters = { search: "", faction: "", actor: "", type: "", scope: "regional", yearFrom: "", yearTo: "" };
        clearTimeout(this.#searchTimer);
        for (const input of this.#root?.querySelectorAll("[data-chronicle-filter]") || []) input.value = this.#filters[input.dataset.chronicleFilter];
        await this.#refreshRecord();
    }

    destroy() {
        this.#listeners?.abort();
        this.#listeners = null;
        clearTimeout(this.#searchTimer);
        this.#filterRevision++;
        this.#root = null;
    }

    #queueFilterRender(input) {
        const key = String(input.dataset.chronicleFilter || "");
        if (!Object.hasOwn(this.#filters, key)) return;
        this.#filters[key] = String(input.value || "");
        this.#filterRevision++;
        clearTimeout(this.#searchTimer);
        this.#searchTimer = setTimeout(() => void this.#refreshRecord(), key === "search" ? 160 : 0);
    }

    async #refreshRecord() {
        const revision = ++this.#filterRevision;
        const context = await this.getContext();
        const html = await foundry.applications.handlebars.renderTemplate(
            "modules/augur-nexus/templates/region-population/chronicle-event-list.hbs", { years: context.years }
        );
        if (revision !== this.#filterRevision) return;
        const record = this.#root?.querySelector(".chronicle-ledger__record");
        if (!record) return;
        // Keep controls mounted so typing, selection, and IME composition survive live filtering.
        record.innerHTML = html;
        record.scrollTop = 0;
        const count = this.#root.querySelector(".chronicle-ledger__result-count");
        count.innerHTML = `Showing <strong>${context.visibleEvents}</strong> of ${context.totalEvents} events`;
        this.#root.querySelector('[data-action="resetFilters"]').disabled = !context.hasFilters;
    }

}
