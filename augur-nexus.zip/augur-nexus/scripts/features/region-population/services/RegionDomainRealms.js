/** Rebuildable unions; direct membership remains the only stored territory. */
export function buildDomainRealms(domains, parents) {
    const byFaction = new Map(domains.map(domain => [domain.factionId, domain]));
    const unions = new Map(domains.map(domain => [domain.factionId, new Map(domain.hexes.map(hex => [`${hex.i},${hex.j}`, hex]))]));
    for (const domain of domains) {
        const visited = new Set([domain.factionId]);
        let parent = parents.get(domain.factionId);
        while (parent && byFaction.has(parent) && !visited.has(parent)) {
            visited.add(parent);
            for (const hex of domain.hexes) unions.get(parent).set(`${hex.i},${hex.j}`, hex);
            parent = parents.get(parent);
        }
    }
    return domains.map(domain => ({ ...domain, directCount: domain.hexes.length,
        realmCount: unions.get(domain.factionId).size, realmHexes: [...unions.get(domain.factionId).values()] }));
}
