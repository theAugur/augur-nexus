import { applyRegionDomains, supportsRegionDomains } from "../../../api/regions.js";

/** Observes successful operations; keeps geometry writes outside the generation algorithm. */
export class RegionDomainCoordinator {
    constructor({ scene, snapshot, survey, planner, source, runId, operations }) {
        Object.assign(this, { scene, planner, source, runId, operations });
        this.cells = new Map((snapshot.cells || []).map(cell => [cell.id, cell]));
        this.topology = (snapshot.cells || []).map(cell => ({ id: cell.id, offset: cell.offset, neighbors: cell.neighbors || [], water: !!cell.traits?.water }));
        this.locations = new Map((survey.locations || []).map(row => [row.key, row.placementCellIds || []]));
        this.fields = [...(snapshot.populationOverlays || [])];
        this.roads = new Map();
        this.dirty = true;
        this.enabled = !!planner && supportsRegionDomains(scene);
    }

    observe() {
        if (!this.enabled) return;
        for (const name of ["createLocation", "updateLocation", "setOwner", "setFactionParent", "appendRoads", "appendCellOverlays"]) {
            const original = this.operations[name];
            this.operations[name] = async (...args) => {
                const result = await original(...args);
                const definition = args[0];
                if (name === "createLocation" && result) this.locations.set(definition.key, [definition.cellId]);
                if (name === "appendRoads") for (const road of result?.routedPaths || []) {
                    this.roads.set([road.fromCellId, road.toCellId].sort().join("|"), road);
                }
                if (name === "appendCellOverlays") for (const field of definition || []) {
                    if (result?.appliedCellIds?.includes(field.cellId)) this.fields.push({
                        cellId: field.cellId, ownerEntityId: this.operations.getEntity(field.ownerKey)?.id
                    });
                }
                this.dirty = true;
                return result;
            };
        }
    }

    async flush() {
        if (!this.enabled || !this.dirty) return;
        const holdings = [];
        for (const [key, cells] of this.locations) {
            const entity = this.operations.getEntity(key);
            const owner = this.operations.getOwnership({ assetKey: key })?.owner;
            if (!entity || owner?.entityType !== "faction") continue;
            for (const cellId of cells) holdings.push({ entity, cellId, factionId: owner.entityId });
        }
        const domains = this.planner.plan({ holdings, roads: [...this.roads.values()], fields: this.fields });
        const factionIds = new Set(domains.map(domain => domain.factionId));
        for (const domain of domains) {
            const key = this.operations.findEntityKey(domain.factionId);
            const parent = key && this.operations.getFactionParent({ factionKey: key });
            if (parent?.entityId && !factionIds.has(parent.entityId)) {
                factionIds.add(parent.entityId);
                domains.push({ factionId: parent.entityId, hexes: [] });
            }
        }
        const centers = holdings.filter(holding => this.cells.has(holding.cellId)).map(holding => ({
            factionId: holding.factionId, hex: this.cells.get(holding.cellId).offset
        }));
        await applyRegionDomains(this.scene, { source: this.source, runId: this.runId, domains, centers, topology: this.topology });
        this.dirty = false;
    }
}
