const providers = new Map();

export class RegionProviderRegistry {
    static register(providerId, definition = {}) {
        const id = String(providerId || "").trim();
        if (!id) throw new Error("A region provider id is required.");
        if (typeof definition.matchesScene !== "function") throw new Error(`Region provider ${id} requires matchesScene(scene).`);
        if (typeof definition.getSnapshot !== "function") throw new Error(`Region provider ${id} requires getSnapshot(scene).`);
        providers.set(id, { ...definition, id });
        Hooks.callAll("augurNexusRegionProvidersChanged");
        return id;
    }

    static unregister(providerId) {
        const removed = providers.delete(String(providerId || "").trim());
        if (removed) Hooks.callAll("augurNexusRegionProvidersChanged");
        return removed;
    }

    static get(providerId) {
        return providers.get(String(providerId || "").trim()) || null;
    }

    static findForScene(scene) {
        if (!scene) return null;
        for (const provider of providers.values()) {
            try {
                if (provider.matchesScene(scene) === true) return provider;
            } catch (error) {
                console.warn(`Augur: Nexus | Region provider ${provider.id} failed to inspect a Scene.`, error);
            }
        }
        return null;
    }
}
