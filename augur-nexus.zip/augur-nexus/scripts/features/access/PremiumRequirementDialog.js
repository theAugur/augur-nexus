import { AUGUR_PATREON_URL } from "./PremiumAccess.js";

export class PremiumRequirementDialog {
    static async show({ feature, label, generator, modules, createBlank }) {
        const esc = foundry.utils.escapeHTML;
        const names = modules.map(module => `<strong>${esc(module.name)}</strong>`).join(", ");
        const message = generator
            ? `${esc(label)} with a generator requires an enabled module that provides it. Available providers include ${names}. Other premium modules unlock campaign creation without adding this generator.`
            : `${esc(label)} requires any one enabled premium module: ${names}.`;
        const action = await foundry.applications.api.DialogV2.wait({
            window: { title: generator ? "Generator Required" : "Premium Module Required", icon: "fas fa-circle-info" },
            position: { width: 440 }, rejectClose: false,
            modal: true,
            content: `<p>${message}</p>${feature === "playerCreation" ? "<p>This applies only to creating a character entry in Nexus. Creating and using regular Foundry Actors and character sheets is unaffected.</p>" : ""}<p class="notes">Existing campaign entries remain available. Campaign Nexus, site journals and connections, and basic scene creation remain free.</p>`,
            buttons: [
                { action: "close", label: "Close", icon: "fas fa-xmark" },
                ...(createBlank ? [{ action: "createBlank", label: "Create Blank Entry", icon: "fas fa-plus" }] : []),
                { action: "viewModules", label: "Explore Augur Modules", icon: "fas fa-up-right-from-square", default: true,
                    callback: () => globalThis.window?.open(AUGUR_PATREON_URL, "_blank", "noopener,noreferrer") }
            ]
        });
        return action === "createBlank" && createBlank ? createBlank() : null;
    }
}
