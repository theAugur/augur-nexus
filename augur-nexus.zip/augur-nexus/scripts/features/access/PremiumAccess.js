export const PREMIUM_MODULES = Object.freeze([
    { id: "augur-fantasy", name: "Augur: Fantasy" },
    { id: "augur-scifi", name: "Augur: Sci-Fi" },
    { id: "hexlands", name: "Augur: Hexlands" },
    { id: "instant-dungeons", name: "Augur: Instant Dungeons" }
]);
export const AUGUR_PATREON_URL = "https://www.patreon.com/TheAugur";

const FEATURES = {
    npc: "Creating people", faction: "Creating organizations", location: "Creating locations",
    ship: "Creating ships", quest: "Creating quests", playerSetup: "Player Setup",
    playerWheel: "The Player Wheel", playerCreation: "Creating a player's Nexus character entry"
};

export function hasPremiumAccess() {
    return PREMIUM_MODULES.some(module => globalThis.game?.modules?.get(module.id)?.active === true);
}

export function premiumRequirementMessage(feature) {
    return `${FEATURES[feature] || "This campaign feature"} requires an enabled Augur premium module.`;
}

export function requirePremiumAccess(feature) {
    if (!hasPremiumAccess()) throw new Error(premiumRequirementMessage(feature));
}

export async function requestPremiumAccess(feature) {
    if (hasPremiumAccess()) return true;
    await showPremiumRequirement(feature);
    return false;
}

/** Provider availability is separate from campaign access: an enabled module need not supply this generator. */
export async function showGeneratorRequirement(feature, { moduleIds, createBlank, label } = {}) {
    return showPremiumRequirement(feature, { moduleIds, generator: true, createBlank, label });
}

async function showPremiumRequirement(feature, { moduleIds, generator = false, createBlank, label } = {}) {
    const { PremiumRequirementDialog } = await import("./PremiumRequirementDialog.js");
    return PremiumRequirementDialog.show({ feature, label: label || FEATURES[feature] || "This campaign feature", generator,
        modules: moduleIds ? PREMIUM_MODULES.filter(module => moduleIds.includes(module.id)) : PREMIUM_MODULES,
        createBlank: hasPremiumAccess() ? createBlank : null });
}
