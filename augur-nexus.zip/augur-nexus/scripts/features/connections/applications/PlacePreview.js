import { SiteAdvancedMenu } from "../../site/services/SiteAdvancedMenu.js";
import { SiteLocationConversionRefresh } from "../../site/services/SiteLocationConversionRefresh.js";
import { isConnectionGraphLayoutUpdate } from "../services/ConnectionGraphLayoutUpdate.js";
import { renderDossierControls, bindDossierControls } from "../../campaign-entities/components/DossierHeaderControls.js";
import { prepareDossierCover } from "../../../support/appearance/DossierCoverPresentation.js";
import { bindConnectedObjectMenus, connectedObjectNode, connectedObjectSources, standaloneObjectNavigation } from "../services/ConnectedObjectMenu.js";
import { prepareNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";
import { ConnectionStore } from "../services/ConnectionStore.js";
import { openActionMenu, promptTextInput, showInfoDialog } from "../../../api/ui.js";
import { PlaceIconWorkflow } from "../../site/services/PlaceIconWorkflow.js";
import { SiteCoverPicker } from "../../site/applications/SiteCoverPicker.js";
import { SiteSubtitleDialog } from "../../site/applications/SiteSubtitleDialog.js";
import { NexusSceneTransition } from "../../nexus/services/NexusSceneTransition.js";
import { SiteMapManager } from "../../site/services/SiteMapManager.js";
import { SiteRecordManager } from "../../site/services/SiteRecordManager.js";
import { SiteSceneVisibilityManager } from "../../site/services/SiteSceneVisibilityManager.js";
import { ConnectionsBoard } from "../components/ConnectionsBoard.js";
import { ConnectionDossierRefresh } from "../services/ConnectionDossierRefresh.js";
import { ConnectionTargetResolver } from "../services/ConnectionTargetResolver.js";
import { JournalAssociationService } from "../services/JournalAssociationService.js";
import { PlayerSceneOpenDialog } from "../../nexus/applications/PlayerSceneOpenDialog.js";
import { PlayerNexusVisibilityDialog } from "../../nexus/applications/PlayerNexusVisibilityDialog.js";
import { NexusSceneRenameDialog } from "../../nexus/applications/NexusSceneRenameDialog.js";
import { attachDossierHelpButton, openHelp } from "../../../api/help.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";
import { NexusSceneOperations } from "../../nexus/services/NexusSceneOperations.js";
import { PlaceOwnershipViewModel } from "../models/PlaceOwnershipViewModel.js";
import { preparePlaceConnectionAtlas } from "../models/PlaceConnectionAtlas.js";
import { OwnershipService } from "../services/OwnershipService.js";
import { PlacePreviewActionRegistry } from "../services/PlacePreviewActionRegistry.js";
import { DossierCompactSections } from "../../campaign-entities/components/DossierCompactSections.js";
import { DevelopedRegionProviderRegistry } from "../../region-dossier/DevelopedRegionProviderRegistry.js";
import { prepareRegionDossier, regionDossierNode } from "../../region-dossier/RegionDossierViewModel.js";
import { RegionalChroniclePanel } from "../../region-population/components/RegionalChroniclePanel.js";
import { EXPANDED_DOSSIER_DEFAULT_SIZE } from "../../../support/ui/DossierWindowDefaults.js";
import { applySessionWindowPlacement, rememberSessionWindowPlacement } from "../../../api/window-placement.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

const MODULE_ID = "augur-nexus";
const REGION_PLACEMENT_KEY = "augur-nexus.region-dossier";
const GENERIC_SITE_DEFAULT_SIZE = Object.freeze({ width: 1030, height: 785 });
let placeViewSequence = 0;

export class PlacePreview extends HandlebarsApplicationMixin(ApplicationV2) {
    #scene = null;
    #record = null;
    #target = null;
    #sourceCover = null;
    #presentation = null;
    #connectionsBoard = null;
    #connectionsChangedHook = null;
    #playerAccessChangedHook = null;
    #sceneUpdatedHook = null;
    #sceneReplacementHook = null;
    #retiredPlaceId = null;
    #lastModel = null;
    #positionInitialized = false;
    #activeTab = null;
    #collapsedCategories = new Set();
    #category = "all";
    #viewId = `place-preview-${++placeViewSequence}`;
    #regionSections;
    #regionCategory = "all";
    #standaloneCompact = false;
    #expandedRegionPosition = null;
    #regionRefreshHook = null;
    #initialRegionPosition = null;
    #chroniclePanel = null;

    get connectionExplorer() { return this.#connectionsBoard?.explorer; }
    get previewCompact() { return this.#standaloneCompact; }
    get hasDedicatedPlaceProfile() { return false; }
    get ownsPlaceSurface() { return false; }

    snapshotView() { return { tab: this.#activeTab, category: this.#connectionsBoard?.activeCategory || this.#category, collapsedCategories: [...this.#collapsedCategories], regionSections: this.#regionSections.snapshot(), regionCategory: this.#regionCategory, connections: this.#connectionsBoard?.snapshot() || this.#boardSession }; }
    #boardSession = null;
    restoreView(state = {}) {
        this.#boardSession = state.connections || null;
        if (this.#connectionsBoard && this.#boardSession) this.#connectionsBoard.restore(this.#boardSession);
        this.#activeTab = ["profile", "journal", "connections", "chronicle"].includes(state.tab) ? state.tab : null;
        if (state.regionSections) this.#regionSections.restore(state.regionSections);
        this.#regionCategory = ["all", "powers", "places", "people"].includes(state.regionCategory) ? state.regionCategory : "all";
        this.#category = typeof state.category === "string" ? state.category : "all";
        this.#connectionsBoard?.setCategory?.(this.#category);
        this.#collapsedCategories = new Set((state.collapsedCategories || []).filter(id => typeof id === "string"));
    }

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-place-preview",
        classes: ["augur-nexus", "site-preview", "place-preview"],
        tag: "div",
        window: {
            title: "Connections",
            resizable: true,
            minimizable: true
        },
        position: { ...EXPANDED_DOSSIER_DEFAULT_SIZE },
        actions: {
            runPlacePreviewAction: async function (_event, button) {
                try {
                    const result = await PlacePreviewActionRegistry.run(button.dataset.provider, button.dataset.extensionAction, this.#actionContext());
                    if (result?.openTarget) return this.openPreviewTarget(result.openTarget);
                    if (result) return this.render({ parts: ["content"] });
                } catch (error) { console.error("Augur: Nexus | Place action failed.", error); ui.notifications.error(error.message || "The place action could not be completed."); }
            },
            setPlaceTab: function (_event, button) { this.#activeTab = ["connections", "journal", ...(this.#lastModel?.region ? ["chronicle"] : [])].includes(button.dataset.tab) ? button.dataset.tab : this.#lastModel?.tabs.hasProfile ? "profile" : "connections"; return this.render({ parts: ["content"] }); },
            regionDossierBrowse: function (_event, button) { this.#regionCategory = ["powers", "places", "people"].includes(button.dataset.category) ? button.dataset.category : "all"; this.#activeTab = "connections"; return this.render({ parts: ["content"] }); },
            regionDossierObject: async function (_event, button) { const node = regionDossierNode(button.dataset.regionNode); if (node) return this.navigateRegionObject(node); },
            openChronicleParticipant: async function (_event, button) { const node = regionDossierNode(`nexus-entity:${button.dataset.entityId}`); if (node) return this.navigateRegionObject(node); },
            openStandaloneRegionDossier: function () {
                if (!this.#lastModel?.region) return;
                return PlacePreview.show({ scene: this.#scene, record: this.#record, viewState: this.snapshotView() });
            },
            toggleRegionSection: function (_event, button) { return this.#regionSections.toggle(this.#target?.id || "", button.dataset.section, () => this.render({ parts: ["content"] }), () => this.element); },
            toggleRegionCompact: async function () {
                if (this.toggleHostedRegionCompact) return this.toggleHostedRegionCompact();
                if (!this.#standaloneCompact) {
                    if (this.#lastModel?.region) rememberSessionWindowPlacement(this, REGION_PLACEMENT_KEY);
                    this.#expandedRegionPosition = { ...this.position };
                }
                this.#standaloneCompact = !this.#standaloneCompact;
                this.setPosition(this.#standaloneCompact ? { width: this.#lastModel?.genericSite ? 420 : 600 } : this.#expandedRegionPosition
                    || { ...(this.#lastModel?.genericSite ? GENERIC_SITE_DEFAULT_SIZE : EXPANDED_DOSSIER_DEFAULT_SIZE) });
                return this.render({ parts: ["content"] });
            },
            togglePlaceCategory: async function (_event, button) {
                const id = button.dataset.category;
                if (!this.#lastModel?.connections?.board?.groups?.some(group => group.id === id)) return;
                if (this.#collapsedCategories.has(id)) this.#collapsedCategories.delete(id); else this.#collapsedCategories.add(id);
                await this.render({ parts: ["content"] });
                this.element?.querySelector(`[data-place-category-toggle][data-category="${CSS.escape(id)}"]`)?.focus();
            },
            openPlaceScene: PlacePreview._onOpenPlaceScene,
            viewPlaceScene: PlacePreview._onViewPlaceScene,
            openPlaceActions: PlacePreview._onOpenPlaceActions,
            createJournalPage: PlacePreview._onCreateJournalPage,
            openPlaceOwner: PlacePreview._onOpenPlaceOwner
        }
    };

    static PARTS = {
        content: {
            template: "modules/augur-nexus/templates/connections/place-preview.hbs",
            scrollable: [".place-preview-scroll", ".place-preview-generic-profile .entity-journal-reading"],
            templates: [
                "modules/augur-nexus/templates/connections/connections-board.hbs",
                "modules/augur-nexus/templates/campaign-entities/entity-journal-panel.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-portrait.hbs",
                "modules/augur-nexus/templates/site/site-cover-picker.hbs",
                "modules/augur-nexus/templates/region-dossier/region-content.hbs",
                "modules/augur-nexus/templates/region-population/chronicle-event-list.hbs"
            ]
        }
    };

    get title() {
        return this.#lastModel?.place?.name || this.#target?.name || this.#record?.siteName || this.#scene?.name || "Connections";
    }

    replacePlaceScene({ scene, record } = {}) {
        if (record) this.#record = record;
        else if (scene) {
            if (this.#scene?.id === scene.id) return this;
            this.#scene = scene; this.#target = null;
        }
        return this.render();
    }

    static show({ scene = null, sceneId = null, record = null, parentScene = canvas.scene, siteId = null, placeable = null, page = null, target = null, sourceCover = null, presentation = null, viewState = null } = {}) {
        if (target?.kind === "nexus-site" || record || siteId || placeable || page) {
            const resolvedRecord = record
                ? SiteRecordManager.normalizeRecord(record)
                : SiteRecordManager.resolveSite({
                    siteRecord: record,
                    parentScene: target?.parentSceneId ? game.scenes.get(target.parentSceneId) || parentScene : parentScene,
                    siteId: target?.siteId || siteId,
                    placeable,
                    page
            });
            if (!resolvedRecord) return null;
            const app = new this({ record: resolvedRecord, sourceCover, presentation });
            if (viewState) app.restoreView(viewState);
            app.render(true, { focus: true });
            return app;
        }

        const resolved = scene || (sceneId ? game.scenes.get(sceneId) || null : null);
        if (!resolved) return null;
        const app = new this({ scene: resolved, sourceCover, presentation });
        if (viewState) app.restoreView(viewState);
        app.render(true, { focus: true });
        return app;
    }

    constructor({ scene = null, record = null, target = null, sourceCover = null, presentation = null } = {}, options = {}) {
        super(options);
        this.#initialRegionPosition = options.position || null;
        this.#scene = scene || null;
        this.#record = record ? SiteRecordManager.normalizeRecord(record) : null;
        this.#regionSections = new DossierCompactSections({ sections: ["powers", "places", "chronicle"], sessionKey: `region:${this.#record?.siteId || scene?.id || ""}`, action: "toggleRegionSection" });
        this.#target = null;
        this.#sourceCover = this.#normalizeSourceCover(sourceCover || target);
        this.#presentation = this.#normalizePresentation(presentation || target);
        ConnectionDossierRefresh.watch(this);
        SiteLocationConversionRefresh.watch(this);
        this.#connectionsChangedHook = () => this.refreshConnectionDossier();
        this.#playerAccessChangedHook = scene => {
            if (!scene || this.#isRelatedScene(scene)) this.refreshConnectionDossier();
        };
        this.#sceneUpdatedHook = (scene, _changes, options) => {
            if (options?.augurNexusGraphLayout && isConnectionGraphLayoutUpdate(_changes, options)) return;
            if (this.#isRelatedScene(scene)) this.refreshConnectionDossier();
        };
        Hooks.on("augurNexusConnectionsChanged", this.#connectionsChangedHook);
        Hooks.on("augurNexusPlayerSceneAccessChanged", this.#playerAccessChangedHook);
        Hooks.on("updateScene", this.#sceneUpdatedHook);
        this.#sceneReplacementHook = ({ sourceId, destinationId } = {}) => {
            if (this.#record || sourceId !== `nexus-scene:${this.#scene?.id}`) return;
            const scene = game.scenes.get(String(destinationId || "").slice("nexus-scene:".length));
            if (scene) this.replacePlaceScene({ scene });
        };
        Hooks.on("augurNexusPlaceSceneReplaced", this.#sceneReplacementHook);
        this.#regionRefreshHook = () => this.refreshConnectionDossier();
        for (const name of ["augurNexusCampaignEntitiesChanged", "augurNexusRegionChronicleChanged", "augurNexusRegionDossierProvidersChanged", "augurNexusAppearanceChanged", "updateTile", "createTile", "deleteTile", "deleteScene", "updateUser"]) Hooks.on(name, this.#regionRefreshHook);
    }

    async _prepareContext() {
        this.#scene = this.#scene?.id ? game.scenes.get(this.#scene.id) || this.#scene : this.#scene;
        this.#record = this.#refreshRecord();
        if (this.#retiredPlaceId) return { unavailable: true, appearance: prepareNexusThemeSurface() };
        const target = this.#getTarget();
        this.#target = target;
        const regionScene = this.#record ? this.#getLinkedSiteScene() : this.#scene;
        const regionContext = { scene: regionScene, record: this.#record, target, user: game.user };
        const provider = regionScene && game.scenes.get(regionScene.id) ? DevelopedRegionProviderRegistry.find(regionContext) : null;
        if (!this.#connectionsBoard) this.#connectionsBoard = new ConnectionsBoard({ target, getCompact: () => this.previewCompact, selectFocusOnOpen: this.hasDedicatedPlaceProfile || !!provider, useTargetCategories: true, activeCategory: this.#category, isGM: game.user.isGM, openNode: node => this.openConnectionNode(node), getNavigationItems: node => this.objectNavigationItems?.(node) || standaloneObjectNavigation(node) });
        else this.#connectionsBoard.setTarget(target);

        if (this.#boardSession) { this.#connectionsBoard.restore(this.#boardSession); this.#boardSession = null; }
        const associatedPage = await JournalAssociationService.getJournalPage(target);
        const journalPage = game.user.isGM || associatedPage?.testUserPermission?.(game.user, "OBSERVER") ? associatedPage : null;
        const journalContent = await this.#enrichJournalContent(journalPage);
        const cover = prepareDossierCover(this.#getCoverImageSrc());
        const openScene = this.#buildOpenSceneModel();

        const icon = this.#presentation?.iconSrc || target?.img || "";
        const thumbnail = (this.#record ? this.#getLinkedSiteScene()?.thumb : this.#scene?.thumb) || "";
        const model = {
            profileActions: PlacePreviewActionRegistry.list(this.#actionContext()),
            tabs: { isProfile: this.#activeTab === "profile", isJournal: this.#activeTab === "journal" },
            compact: this.previewCompact === true,
            place: {
                name: target?.name || "Place",
                subtitle: this.#getSubtitle(),
                icon: icon || thumbnail,
                isThumbnail: !icon && !!thumbnail,
                openSceneLabel: openScene.label,
                canOpenScene: openScene.visible,
                openSceneDisabled: openScene.disabled,
                openSceneTitle: openScene.title,
                openSceneUnavailableReason: openScene.unavailableReason || ""
            },
            journal: {
                canEdit: game.user.isGM,
                hasPage: !!journalPage,
                entryId: journalPage?.parent?.id || "",
                pageId: journalPage?.id || "",
                content: journalContent,
                hasContent: !!String(journalPage?.text?.content || "").trim()
            },
            connections: { board: null },
            ownership: PlaceOwnershipViewModel.build(target),
            dossierCover: cover, appearance: prepareNexusThemeSurface(),
            isGM: game.user.isGM,
            canShowPlaceActions: game.user.isGM && this.#presentation?.actionMode !== "none"
        };
        if (provider) {
            try {
                const source = await provider.prepare(regionContext);
                if (source) model.region = prepareRegionDossier(source, { compact: model.compact, sections: this.#regionSections.context(target.id), category: this.#regionCategory });
            } catch (error) { console.warn("Augur: Nexus | Developed region dossier content could not be prepared.", error); }
        }
        model.genericSite = !model.region && !this.hasDedicatedPlaceProfile;
        const hasProfile = model.genericSite || !!model.region || this.hasDedicatedPlaceProfile;
        if (!this.#activeTab || ((!model.region || !game.user.isGM) && this.#activeTab === "chronicle") || (!hasProfile && this.#activeTab === "profile")) this.#activeTab = hasProfile ? "profile" : "connections";
        model.tabs = { hasProfile, isProfile: this.#activeTab === "profile", isJournal: this.#activeTab === "journal", isConnections: this.#activeTab === "connections", isChronicle: this.#activeTab === "chronicle" };
        // Profile borrows the same list projection without changing the Connections tab's saved display or graph session.
        const board = this.#connectionsBoard.getContext(model.genericSite && model.tabs.isProfile || model.region && model.tabs.isJournal ? { display: "list", hideViewToggle: true } : {});
        model.connections.board = { ...board, placePreview: true, hideFilter: (board.categories || []).length <= 2,
            groups: (board.groups || []).map((group, index) => ({ ...group, collapsed: this.#collapsedCategories.has(group.id), contentId: `${this.#viewId}-category-${index}`, count: group.cards.length })) };
        if (model.region) {
            model.appearance = prepareNexusThemeSurface();

            model.region.isProfile = model.tabs.isProfile;
            model.region.isConnections = model.tabs.isConnections;
            model.region.isChronicle = model.tabs.isChronicle;
            model.region.canOpenStandalone = !!this.toggleHostedRegionCompact;
            if (game.user.isGM && !this.#chroniclePanel) this.#chroniclePanel = new RegionalChroniclePanel({ sceneId: regionScene.id });
            else if (game.user.isGM) this.#chroniclePanel.setSceneId(regionScene.id);
            if (model.region.isChronicle && !model.compact) model.region.chronicleHtml = await this.#chroniclePanel.render();
        } else if (!model.genericSite) model.connections.board = preparePlaceConnectionAtlas(model.connections.board, id => {
            if (!id) return null;
            const node = ConnectionStore.getNode(id);
            if (!node) return null;
            return ConnectionTargetResolver.resolveDisplayNodeSync?.(node) || node;
        });
        const visibilityOptions = this.#getPlayerVisibilityOptions();
        const visibilityScene = this.#getPlayerVisibilityScene();
        const visible = visibilityOptions ? SiteSceneVisibilityManager.isSiteVisibleToPlayers(visibilityOptions)
            : NexusPlayerSceneAccess.isNexusVisibilityVisible(NexusPlayerSceneAccess.getSceneNexusVisibilityOverride(visibilityScene));
        const inherited = this.#getPlayerVisibilityLabel() === "Global";
        const visibilityControl = model.canShowPlaceActions && (visibilityOptions || visibilityScene)
            ? { label: `${visible ? "Visible to players" : "Hidden from players"}${inherited ? " (Global)" : ""}`, icon: visible ? "fas fa-eye" : "fas fa-eye-slash" } : null;
        model.regionFooterControlsHtml = model.region && game.user.isGM
            ? await renderDossierControls({ canEdit: false, showEdit: false, options: false, visibility: visibilityControl }) : "";
        model.controlsHtml = await renderDossierControls({ canEdit: model.canShowPlaceActions, showEdit: false, compact: model.compact, compactAction: "toggleRegionCompact", popout: !!this.toggleHostedRegionCompact, compactWithPopout: model.genericSite,
            sceneControl: model.genericSite || model.region && game.user.isGM ? null : { canOpen: openScene.visible, action: "openPlaceScene", label: openScene.label, title: openScene.title, icon: "fas fa-map-location-dot", unavailable: openScene.disabled, unavailableReason: openScene.unavailableReason },
            visibility: model.region ? null : visibilityControl });
        if (this.ownsPlaceSurface) model.surfaceControlsHtml = await renderDossierControls({ canEdit: false, showEdit: false, options: false, compact: model.compact,
            visibility: visibilityControl });
        this.#lastModel = model;
        return model;
    }

    _onRender(context, options) {
        super._onRender(context, options);
        attachDossierHelpButton(this, "place", { genericSite: context.genericSite });
        if (this.window?.title) this.window.title.textContent = this.title;
        this.activateContentListeners(this.element);
        if (!this.#positionInitialized) {
            if (context.region) applySessionWindowPlacement(this, REGION_PLACEMENT_KEY, this.#initialRegionPosition
                ? { position: this.#initialRegionPosition }
                : { fallback: "center", ...EXPANDED_DOSSIER_DEFAULT_SIZE });
            else this.setPosition(this.#getCenteredPosition(context.genericSite ? GENERIC_SITE_DEFAULT_SIZE : EXPANDED_DOSSIER_DEFAULT_SIZE));
            this.#positionInitialized = true;
        }
    }

    static async _onOpenPlaceOwner() {
        const app = this;
        const target = app.#getTarget();
        if (target) await OwnershipService.openOwner(target);
    }

    #actionContext() { return { scene: this.#scene, record: this.#record, target: this.#getTarget(), user: game.user }; }
    async openPreviewTarget(target) {
        await this.close();
        return ConnectionTargetResolver.openNode(target);
    }

    async openConvertedLocation(entity) {
        await this.close();
        return ConnectionTargetResolver.openNode(ConnectionTargetResolver.fromCampaignEntity(entity));
    }

    navigateRegionObject(node) { return ConnectionTargetResolver.openNode(node); }
    openConnectionNode(node) { return ConnectionTargetResolver.openNode(node); }

    activateContentListeners(root) {
        bindDossierControls(root, {
            popout: () => PlacePreview.show({ scene: this.#scene, record: this.#record, viewState: this.snapshotView() }),
            options: anchor => PlacePreview._onOpenPlaceActions.call(this, null, anchor),
            visibility: anchor => this.#openPlayerVisibilityMenu(anchor)
        });
        this.#chroniclePanel?.destroy();
        if (this.#lastModel?.region?.isChronicle && !this.#lastModel.compact) {
            const chronicleRoot = root?.querySelector?.(".region-chronicle-embed");
            if (chronicleRoot) this.#chroniclePanel?.activateListeners(chronicleRoot, {
                openParticipant: async entityId => {
                    const node = regionDossierNode(`nexus-entity:${entityId}`);
                    if (node) return this.navigateRegionObject(node);
                }
            });
        }
        bindConnectedObjectMenus(root, { getOwner: () => this.#getTarget(),
            // Derived regional membership is navigation, never an editable placement or edge.
            selector: `:is(${connectedObjectSources}):not(.nexus-region-dossier [data-navigation-only] *):not([data-place-profile] *)`,
            navigation: node => this.objectNavigationItems?.(node) || [{ id: "open-object", label: "Open Object", icon: "fas fa-up-right-from-square", onSelect: () => ConnectionTargetResolver.openNode(node) }],
            resolveNode: card => card.dataset.regionNode ? regionDossierNode(card.dataset.regionNode) : card.dataset.action === "openPlaceOwner"
                ? ConnectionStore.getNode(OwnershipService.getOwnership(this.#getTarget())?.ownerNodeId) : connectedObjectNode(card),
            getItems: ({ edge, card }) => this.#connectionsBoard?.getCardItems(edge.id, this, card), onChanged: () => this.render({ force: true }) });
        const boardRoot = this.#lastModel?.region ? root?.querySelector?.(".region-world-ties") : root?.querySelector?.(".place-preview-world-ties");
        if (boardRoot) this.#connectionsBoard?.activateListeners(boardRoot, this);
        else this.#connectionsBoard?.suspend?.();
        for (const element of root?.querySelectorAll?.("[data-region-node]") || []) {
            element.draggable = true;
            element.addEventListener("dragstart", event => { event.stopPropagation(); const node = regionDossierNode(element.dataset.regionNode); if (!node || !ConnectionTargetResolver.setDragData(event.dataTransfer, node, { effectAllowed: "all" })) event.preventDefault(); });
        }
    }

    async close(options) {
        if (!this.toggleHostedRegionCompact && this.#lastModel?.region && !this.#standaloneCompact) rememberSessionWindowPlacement(this, REGION_PLACEMENT_KEY);
        await this.#connectionsBoard?.destroy();
        this.#chroniclePanel?.destroy();
        ConnectionDossierRefresh.unwatch(this);
        SiteLocationConversionRefresh.unwatch(this);
        if (this.#connectionsChangedHook) Hooks.off("augurNexusConnectionsChanged", this.#connectionsChangedHook);
        if (this.#playerAccessChangedHook) Hooks.off("augurNexusPlayerSceneAccessChanged", this.#playerAccessChangedHook);
        if (this.#sceneUpdatedHook) Hooks.off("updateScene", this.#sceneUpdatedHook);
        if (this.#sceneReplacementHook) Hooks.off("augurNexusPlaceSceneReplaced", this.#sceneReplacementHook);
        if (this.#regionRefreshHook) for (const name of ["augurNexusCampaignEntitiesChanged", "augurNexusRegionChronicleChanged", "augurNexusRegionDossierProvidersChanged", "augurNexusAppearanceChanged", "updateTile", "createTile", "deleteTile", "deleteScene", "updateUser"]) Hooks.off(name, this.#regionRefreshHook);
        return super.close(options);
    }

    matchesConnectionDossierJournal({ entryId, pageId } = {}) {
        const journal = this.#lastModel?.journal || null;
        if (!journal?.entryId) return false;
        if (pageId) return journal.pageId === pageId;
        return journal.entryId === entryId;
    }

    refreshConnectionDossier() {
        if (this.rendered === false) return;
        this.render({ parts: ["content"] });
    }

    matchesConvertedPlace({ sourceIds = [] } = {}) {
        const id = this.#retiredPlaceId || (this.#record ? `nexus-site:${this.#record.parentSceneId}:${this.#record.siteId}` : `nexus-scene:${this.#scene?.id}`);
        return sourceIds.includes(id);
    }

    handlePlaceConverted() { return this.close(); }

    async #enrichJournalContent(page) {
        const content = page?.text?.content || "";
        if (!String(content).trim()) return "";
        try {
            return foundry.applications.ux.TextEditor.implementation.enrichHTML(content, {
                relativeTo: page,
                secrets: page.isOwner
            });
        } catch (err) {
            console.warn("Augur: Nexus | Failed to enrich place journal content.", err);
            return content;
        }
    }

    static async _onViewPlaceScene(event, target) {
        if (!game.user.isGM) return;
        return PlacePreview._onOpenPlaceScene.call(this, event, { dataset: { ...target?.dataset, audience: "self" } });
    }

    static async _onOpenPlaceScene(event, target) {
        const app = this;
        const unavailableReason = target?.dataset?.unavailableReason || "";
        if (unavailableReason) {
            await app.#showUnavailableSceneDialog(unavailableReason);
            return;
        }

        if (app.#record?.siteId) {
            if (!game.user.isGM) {
                await app.#viewLinkedSiteScene();
                return;
            }
            const scene = await SiteMapManager.openSite({
                siteRecord: app.#record,
                parentSceneId: app.#record.parentSceneId,
                siteId: app.#record.siteId,
                audience: target?.dataset?.audience === "self" ? "self" : "all"
            });
            if (scene) await app.close();
            return;
        }
        if (!app.#scene) return;
        if (!NexusPlayerSceneAccess.canUserViewScene(app.#scene)) {
            ui.notifications.warn("This scene is not currently available to view.");
            return;
        }
        if (game.user.isGM) {
            const audience = target?.dataset?.audience === "self" ? "self" : "all";
            await NexusSceneTransition.transitionToScene(app.#scene, { audience, ...(audience === "self" ? { transitionStyle: "none" } : {}) });
        } else await app.#scene.view();
        await app.close();
    }

    static async _onOpenPlaceActions(event, target) {
        const app = this;
        if (!game.user.isGM) return;
        const items = app.#presentation?.actionMode === "minimal" ? [{
            id: "edit-journal",
            label: "Edit Journal",
            icon: "fas fa-book-open",
            onSelect: () => app.#editJournal()
        }] : [];

        if (app.#presentation?.actionMode !== "minimal") {
            items.push(
                {
                    id: "change-icon",
                    label: "Change Icon",
                    icon: "fas fa-icons",
                    onSelect: () => app.#changeIcon()
                },
                {
                    id: "rename",
                    label: "Rename",
                    icon: "fas fa-pen",
                    onSelect: () => app.#renamePlace()
                },
                ...(app.#record?.siteId ? [{
                    id: "edit-subtitle",
                    label: "Edit Subtitle",
                    icon: "fas fa-font",
                    onSelect: () => app.#editSubtitle()
                }] : []),
                ...(prepareNexusThemeSurface().mode === "dark" ? [{
                    id: "change-cover",
                    label: "Change Cover Image",
                    icon: "fas fa-image",
                    onSelect: () => app.#changeCoverImage(target)
                }, ...(app.#getCoverImageSrc() ? [{ id: "world-cover", label: "Use World Cover", icon: "fas fa-rotate-left", onSelect: () => app.#setCoverImage("") }] : [])] : []),
                {
                    id: "player-nexus-visibility",
                    label: `Visible To Players: ${app.#getPlayerVisibilityLabel()}`,
                    icon: "fas fa-eye",
                    onSelect: () => app.#openPlayerVisibilityMenu(target)
                },
                {
                    id: "player-view-access",
                    label: `Player Scene Open: ${app.#getPlayerViewAccessLabel()}`,
                    icon: "fas fa-door-open",
                    onSelect: () => app.#openPlayerViewAccessMenu(target)
                }
            );
        }

        const advanced = SiteAdvancedMenu.menuItem({ scene: app.#scene, record: app.#record }, { anchor: target, onConverted: entity => app.openConvertedLocation(entity), onChanged: result => app.replacePlaceScene(result) });
        if (advanced) items.push(advanced);
        openActionMenu({
            anchor: target,
            className: "place-preview-actions-menu",
            items
        });
    }

    static async _onCreateJournalPage() {
        const app = this;
        if (game.user.isGM) await app.#editJournal();
    }

    async #editJournal() {
        const page = await JournalAssociationService.getOrCreateJournalPage(this.#target || this.#getTarget());
        if (!page) {
            ui.notifications.warn("Could not create journal notes for this object.");
            return;
        }
        this.render({ parts: ["content"] });
        JournalAssociationService.openPage(page, { edit: true });
    }

    async #renamePlace() {
        if (!game.user.isGM) return;

        if (!this.#record?.siteId) {
            if (this.#scene) NexusSceneRenameDialog.show(this.#scene);
            return;
        }

        const nextName = await promptTextInput({
            title: "Rename Site",
            label: "Site Name",
            value: this.#record.siteName || "",
            confirmLabel: "Rename"
        });
        if (!nextName) return;

        const parentScene = SiteRecordManager.getParentScene(this.#record);
        if (!parentScene) return;

        const linkedScene = this.#getLinkedSiteScene();
        if (linkedScene && linkedScene.name !== nextName) {
            await NexusSceneOperations.renameScene(linkedScene, nextName);
        }

        this.#record = SiteRecordManager.normalizeRecord({
            ...this.#record,
            siteName: nextName,
            linkedSceneName: linkedScene?.name || this.#record.linkedSceneName || ""
        }, { parentScene });
        await SiteRecordManager.upsertSceneRecord(parentScene, this.#record);
        await SiteRecordManager.syncRecordToVisuals(parentScene, this.#record);
        Hooks.callAll("augurNexusLineageChanged");
        this.render({ parts: ["content"] });
    }

    async #editSubtitle() {
        if (!game.user.isGM || !this.#record?.siteId) return;
        const update = await SiteSubtitleDialog.show(this.#record);
        if (!update) return;

        const parentScene = SiteRecordManager.getParentScene(this.#record);
        if (!parentScene) return;

        this.#record = SiteRecordManager.normalizeRecord({
            ...this.#record,
            ...update
        }, { parentScene });
        await SiteRecordManager.upsertSceneRecord(parentScene, this.#record);
        await SiteRecordManager.syncRecordToVisuals(parentScene, this.#record);
        Hooks.callAll("augurNexusLineageChanged");
        this.render({ parts: ["content"] });
    }

    #changeCoverImage(target) {
        if (!game.user.isGM || prepareNexusThemeSurface().mode !== "dark" || (!this.#scene && !this.#record)) return;
        SiteCoverPicker.show({
            current: prepareDossierCover(this.#getCoverImageSrc()).src,
            sourceCover: this.#sourceCover,
            onSelect: path => this.#setCoverImage(path || "")
        });
    }

    async #changeIcon() {
        return PlaceIconWorkflow.open({
            sceneId: this.#scene?.id,
            parentSceneId: this.#record ? SiteRecordManager.getParentScene(this.#record)?.id : null,
            siteId: this.#record?.siteId,
            onChanged: ({ record }) => {
                if (record) this.#record = record;
                this.render({ parts: ["content"] });
            }
        });
    }

    async #setCoverImage(path) {
        if (!game.user.isGM || prepareNexusThemeSurface().mode !== "dark") return;
        if (!game.user.isGM) return;
        if (this.#record?.siteId) {
            const parentScene = SiteRecordManager.getParentScene(this.#record);
            if (!parentScene) return;
            this.#record = SiteRecordManager.normalizeRecord({
                ...this.#record,
                coverImageSrc: path || ""
            }, { parentScene });
            await SiteRecordManager.upsertSceneRecord(parentScene, this.#record);
            await SiteRecordManager.syncRecordToVisuals(parentScene, this.#record);
            Hooks.callAll("augurNexusLineageChanged");
            this.render({ parts: ["content"] });
            return;
        }

        if (!this.#scene) return;
        await this.#scene.setFlag(MODULE_ID, "placePreview", {
            ...this.#getPlaceFlags(),
            coverImageSrc: path || ""
        });
        this.render({ parts: ["content"] });
    }

    #getPlaceFlags() {
        return this.#scene?.getFlag(MODULE_ID, "placePreview") || {};
    }

    #getCoverImageSrc() {
        if (this.#record?.siteId) return this.#record.coverImageSrc || "";
        return this.#getPlaceFlags().coverImageSrc || "";
    }

    #refreshRecord() {
        const reference = this.#record || (this.#retiredPlaceId ? { parentSceneId: this.#retiredPlaceId.split(":")[1], siteId: this.#retiredPlaceId.split(":").slice(2).join(":") } : null);
        if (!reference?.siteId) return null;
        const parentScene = SiteRecordManager.getParentScene(reference);
        const record = SiteRecordManager.resolveSite({ parentScene, siteId: reference.siteId });
        this.#retiredPlaceId = record ? null : `nexus-site:${reference.parentSceneId}:${reference.siteId}`;
        return record || null;
    }

    #getTarget() {
        if (this.#record?.siteId) return ConnectionTargetResolver.fromSiteRecord(this.#record);
        return {
            ...ConnectionTargetResolver.fromSceneReference({ sceneId: this.#scene?.id || null }),
            subtitle: this.#getSubtitle()
        };
    }



    #normalizeSourceCover(sourceCover = null) {
        const src = String(sourceCover?.src || sourceCover?.sourceCoverSrc || "").trim();
        if (!src) return null;
        return {
            src,
            label: String(sourceCover?.label || sourceCover?.sourceCoverLabel || "Source Background").trim() || "Source Background"
        };
    }

    #normalizePresentation(presentation = null) {
        const actionMode = ["full", "minimal", "none"].includes(presentation?.actionMode) ? presentation.actionMode : "";
        return {
            iconSrc: String(presentation?.iconSrc || "").trim(),
            suppressActions: presentation?.suppressActions === true,
            actionMode: actionMode || (presentation?.suppressActions === true ? "none" : "full")
        };
    }

    #getSubtitle() {
        if (this.#record?.siteId) {
            return SiteRecordManager.getDossierSubtitle(this.#record);
        }
        const lineage = this.#scene?.getFlag(MODULE_ID, "lineage") || {};
        const parent = lineage.parentSceneId ? game.scenes.get(lineage.parentSceneId) || null : null;
        if (parent) return `Scene - ${parent.name}`;
        return "Nexus Place";
    }

    #buildOpenSceneModel() {
        if (game.user.isGM) {
            return {
                visible: true,
                disabled: false,
                label: "Open Scene",
                title: "",
                unavailableReason: ""
            };
        }

        const scene = this.#record ? this.#getLinkedSiteScene() : this.#scene;
        if (!scene) {
            return {
                visible: false,
                disabled: true,
                label: "Scene Not Created",
                title: "Ask the GM to open or generate this scene first.",
                unavailableReason: "missing-scene"
            };
        }

        const allowed = NexusPlayerSceneAccess.canUserViewScene(scene);
        if (!allowed) {
            return {
                visible: false,
                disabled: true,
                label: "Scene Locked",
                title: "Ask the GM to allow player viewing from this panel.",
                unavailableReason: "locked"
            };
        }

        return {
            visible: true,
            disabled: false,
            label: "View Scene",
            title: "",
            unavailableReason: ""
        };
    }

    #getLinkedSiteSceneId() {
        return this.#record?.siteSceneId || this.#record?.linkedSceneId || null;
    }

    #getLinkedSiteScene() {
        const sceneId = this.#getLinkedSiteSceneId();
        return sceneId ? game.scenes.get(sceneId) || null : null;
    }

    #isRelatedScene(scene) {
        if (!scene?.id) return false;
        if (this.#scene?.id === scene.id) return true;
        return this.#getLinkedSiteSceneId() === scene.id;
    }

    async #viewLinkedSiteScene() {
        const scene = this.#getLinkedSiteScene();
        if (!scene || !NexusPlayerSceneAccess.canUserViewScene(scene)) {
            ui.notifications.warn("This site scene is not currently available to view.");
            return;
        }
        await this.close();
        await scene.view();
    }

    async #showUnavailableSceneDialog(reason) {
        if (reason === "missing-scene") {
            await showInfoDialog({
                title: "Scene Not Created",
                message: `
                    <p>This scene has not been created yet.</p>
                    <p>Ask the GM to open this panel and press <strong>Open/Create Scene</strong> once. After the scene exists, players can view it if Player Scene Open allows it.</p>
                `
            });
            return;
        }

        await showInfoDialog({
            title: "Scene Locked",
            message: `
                <p>This scene is not currently available for player viewing.</p>
                <p>Ask the GM to open this panel, use the <strong>...</strong> menu, and set <strong>Player Scene Open</strong> to <strong>Allowed</strong>.</p>
            `
        });
    }

    #getPlayerViewScene() {
        return this.#record ? this.#getLinkedSiteScene() : this.#scene;
    }

    #getPlayerViewAccessLabel() {
        return NexusPlayerSceneAccess.getSceneViewLabel(this.#getPlayerViewScene());
    }

    #getPlayerVisibilityScene() {
        return this.#record ? this.#getLinkedSiteScene() : this.#scene;
    }

    #getPlayerVisibilityOptions() {
        if (!this.#record?.siteId) return null;
        const parentScene = SiteRecordManager.getParentScene(this.#record);
        if (!parentScene) return null;
        return {
            scene: parentScene,
            siteId: this.#record.siteId,
            linkedScene: this.#getLinkedSiteScene(),
            record: this.#record
        };
    }

    #getPlayerVisibilityLabel() {
        const siteOptions = this.#getPlayerVisibilityOptions();
        if (siteOptions) return SiteSceneVisibilityManager.getSitePlayerVisibilityLabel(siteOptions);

        return NexusPlayerSceneAccess.getSceneNexusVisibilityLabel(this.#getPlayerVisibilityScene());
    }

    #getPlayerVisibilityIcon() {
        const siteOptions = this.#getPlayerVisibilityOptions();
        if (siteOptions) return SiteSceneVisibilityManager.getSitePlayerVisibilityIcon(siteOptions);

        return NexusPlayerSceneAccess.getNexusVisibilityIcon(
            NexusPlayerSceneAccess.getSceneNexusVisibilityOverride(this.#getPlayerVisibilityScene())
        );
    }

    #openPlayerVisibilityMenu(anchor) {
        const siteOptions = this.#getPlayerVisibilityOptions();
        const scene = this.#getPlayerVisibilityScene();
        if (!siteOptions && !scene) {
            ui.notifications.warn("Create or link a scene before setting player visibility.");
            return;
        }

        const current = siteOptions
            ? SiteSceneVisibilityManager.getSitePlayerVisibilityOverride(siteOptions)
            : NexusPlayerSceneAccess.getSceneNexusVisibilityOverride(scene);
        openActionMenu({
            anchor,
            className: "place-preview-player-access-menu",
            items: [
                {
                    id: "inherit",
                    label: current === "inherit" ? "Global (Current)" : "Global",
                    icon: "fas fa-layer-group",
                    onSelect: () => this.#setPlayerVisibility("inherit")
                },
                {
                    id: "show",
                    label: current === "show" ? "Yes (Current)" : "Yes",
                    icon: "fas fa-eye",
                    onSelect: () => this.#setPlayerVisibility("show")
                },
                {
                    id: "hide",
                    label: current === "hide" ? "No (Current)" : "No",
                    icon: "fas fa-eye-slash",
                    onSelect: () => this.#setPlayerVisibility("hide")
                },
                {
                    id: "change-global",
                    label: "Change Global Setting...",
                    icon: "fas fa-sliders",
                    onSelect: () => PlayerNexusVisibilityDialog.show()
                },
                {
                    id: "player-visibility-info",
                    label: "What's this?",
                    icon: "fas fa-circle-info",
                    onSelect: () => openHelp("augur-nexus:site-visibility")
                }
            ]
        });
    }

    async #setPlayerVisibility(value) {
        const siteOptions = this.#getPlayerVisibilityOptions();
        if (siteOptions) {
            await SiteSceneVisibilityManager.setSitePlayerVisibilityOverride({
                parentScene: siteOptions.scene,
                siteId: siteOptions.siteId,
                linkedScene: siteOptions.linkedScene,
                value
            });
            this.#record = SiteRecordManager.resolveSite({
                parentScene: siteOptions.scene,
                siteId: siteOptions.siteId
            }) || this.#record;
            this.render({ parts: ["content"] });
            return;
        }

        const scene = this.#getPlayerVisibilityScene();
        if (!scene) return;
        await NexusPlayerSceneAccess.setSceneNexusVisibilityOverride(scene, value);
        this.render({ parts: ["content"] });
    }

    #openPlayerViewAccessMenu(anchor) {
        const scene = this.#getPlayerViewScene();
        if (!scene) {
            ui.notifications.warn("Create or link a scene before setting player view access.");
            return;
        }

        const current = NexusPlayerSceneAccess.getSceneViewOverride(scene);
        openActionMenu({
            anchor,
            className: "place-preview-player-access-menu",
            items: [
                {
                    id: "inherit",
                    label: current === "inherit" ? "Global (Current)" : "Global",
                    icon: "fas fa-layer-group",
                    onSelect: () => this.#setPlayerViewAccess(scene, "inherit")
                },
                {
                    id: "allow",
                    label: current === "allow" ? "Allowed (Current)" : "Allowed",
                    icon: "fas fa-eye",
                    onSelect: () => this.#setPlayerViewAccess(scene, "allow")
                },
                {
                    id: "block",
                    label: current === "block" ? "Blocked (Current)" : "Blocked",
                    icon: "fas fa-eye-slash",
                    onSelect: () => this.#setPlayerViewAccess(scene, "block")
                },
                {
                    id: "change-global",
                    label: "Change Global Setting...",
                    icon: "fas fa-sliders",
                    onSelect: () => PlayerSceneOpenDialog.show()
                },
                {
                    id: "player-scene-open-info",
                    label: "What's this?",
                    icon: "fas fa-circle-info",
                    onSelect: () => openHelp("augur-nexus:scene-open")
                }
            ]
        });
    }

    async #setPlayerViewAccess(scene, value) {
        await NexusPlayerSceneAccess.setSceneViewOverride(scene, value);
        this.render({ parts: ["content"] });
    }

    #getCenteredPosition(size = EXPANDED_DOSSIER_DEFAULT_SIZE) {
        const width = Math.min(size.width, window.innerWidth - 40);
        const height = Math.min(size.height, window.innerHeight - 40);
        return {
            width,
            height,
            left: 20,
            top: 72
        };
    }
}
