import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { ShopStore } from "../../shops/services/ShopStore.js";

// Establishment cards project the child's parent reference, rather than a graph edge.
export function connectedObjectPlacementItems({ card, owner, onChanged } = {}) {
    if (card.closest?.("[data-navigation-only]")) return [];
    if (owner?.entityType !== "location" || !canControlPlayerEntity(owner)) return [];
    const kind = card.dataset.cardKind, id = card.dataset.cardId;
    const location = kind === "location" ? LocationEntityStore.getLocation(id) : null;
    const shop = kind === "shop" ? ShopStore.getShop(id) : null;
    const attached = () => kind === "location"
        ? LocationEntityStore.getLocation(id)?.hierarchy?.parent?.kind === "location"
            && LocationEntityStore.getLocation(id)?.hierarchy?.parent?.locationId === owner.entityId
        : kind === "shop" && ShopStore.getShop(id)?.hierarchy?.parentLocationId === owner.entityId;
    if ((!location && !shop) || !attached() || (location ? !canControlPlayerEntity(location) : !game.user.isGM)) return [];
    const permitted = () => canControlPlayerEntity(owner) && attached() && (location ? canControlPlayerEntity(LocationEntityStore.getLocation(id)) : game.user.isGM);
    return [
        ...(game.user.isGM ? [{ id: "delete-entity", label: "Delete Object…", status: "Permanent", icon: "fas fa-skull-crossbones", danger: true, className: "permanent-danger", onSelect: async () => {
            if (!game.user.isGM || !permitted()) return;
            if (location) {
                const { deleteLocation } = await import("../../../api/locations.js");
                await deleteLocation(id);
            } else {
                const { ShopDeletionWorkflow } = await import("../../shops/services/ShopDeletionWorkflow.js");
                await ShopDeletionWorkflow.confirm(id);
            }
            await onChanged?.();
        } }] : []),
        { id: "remove-connection", label: "Remove Connection", icon: "fas fa-unlink", onSelect: async () => {
            if (!permitted()) return;
            if (location) await LocationEntityStore.updateLocation(id, { hierarchy: { parent: null } });
            else await ShopStore.updateShop(id, { hierarchy: { parentLocationId: "" } });
            await onChanged?.();
        } }
    ];
}
