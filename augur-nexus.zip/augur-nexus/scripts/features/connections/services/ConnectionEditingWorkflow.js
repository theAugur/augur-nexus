import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { promptTextInput, openActionMenu } from "../../../api/ui.js";
import { ConnectionStore } from "./ConnectionStore.js";
import { ConnectionCategories } from "./ConnectionCategories.js";
import { ConnectionTargetResolver } from "./ConnectionTargetResolver.js";
import { ShopStore } from "../../shops/services/ShopStore.js";

export class ConnectionEditingWorkflow {
    static belongsTo(edgeId, nodeId) {
        const edge = ConnectionStore.getConnectionEdge(edgeId);
        return edge && [edge.sourceNodeId, edge.targetNodeId].includes(nodeId) ? edge : null;
    }

    static async editRole(edgeId, nodeId, onChanged) {
        if (!canControlPlayerEntity(ConnectionStore.getNode(nodeId))) return;
        const edge = this.belongsTo(edgeId, nodeId);
        if (!edge) return;
        const view = ConnectionStore.getConnectionView(edge, nodeId);
        const role = await promptTextInput({
            title: "Connection Role",
            label: "Role",
            value: view.role || ConnectionCategories.roleFor(view.category),
            placeholder: "Contact, Threat, Hidden Item...",
            confirmLabel: "Save",
            allowEmpty: false,
            emptyMessage: "Role cannot be empty."
        });
        if (role === null || !canControlPlayerEntity(ConnectionStore.getNode(nodeId)) || !this.belongsTo(edgeId, nodeId)) return;
        await ConnectionStore.setConnectionViewForNode(edgeId, nodeId, { role });
        await onChanged?.();
    }

    static async remove(edgeId, nodeId, onChanged) {
        if (!canControlPlayerEntity(ConnectionStore.getNode(nodeId))) return;
        const edge = this.belongsTo(edgeId, nodeId);
        if (!edge || !this.canRemove(edge)) return;
        await ConnectionStore.removeConnection(edgeId);
        await onChanged?.();
    }

    static canRemove(edge) {
        if (game.user.isGM) return true;
        if (!edge || edge.factionHierarchy) return false;
        const authority = edge.factionMembership?.factionNodeId || edge.factionSeat?.factionNodeId
            || edge.locationLeadership?.locationNodeId || edge.shipCaptain?.shipNodeId
            || edge.shipOwnership?.shipNodeId || edge.shipLocation?.shipNodeId;
        if (authority) return canControlPlayerEntity(ConnectionStore.getNode(authority));
        if (edge.relationType === "ship-crew") {
            const ship = [edge.sourceNodeId, edge.targetNodeId].map(id => ConnectionStore.getNode(id)).find(node => node?.entityType === "ship");
            return !!ship && canControlPlayerEntity(ship);
        }
        return !edge.relationType || [edge.sourceNodeId, edge.targetNodeId].every(id => canControlPlayerEntity(ConnectionStore.getNode(id)));
    }

    static memberItems({ owner, edgeId, onChanged } = {}) {
        const nodeId = ConnectionTargetResolver.getNodeId(owner);
        const edge = this.belongsTo(edgeId, nodeId);
        if (!edge || !canControlPlayerEntity(owner)) return [];
        const otherId = edge.sourceNodeId === nodeId ? edge.targetNodeId : edge.sourceNodeId;
        const person = ConnectionStore.getNode(otherId);
        if (person?.entityType !== "npc") return [];
        return [
            { id: "change-role", label: "Edit Role…", icon: "fas fa-pen-to-square", onSelect: () => this.editRole(edgeId, nodeId, onChanged) },
            ...this.deletionItems({ owner, node: person, edgeId, onChanged }),
            ...(this.canRemove(edge) ? [{ id: "remove-connection", label: "Remove Connection", icon: "fas fa-unlink", onSelect: () => this.remove(edgeId, nodeId, onChanged) }] : [])
        ];
    }

    static deletionItems({ owner, node, edgeId, onChanged } = {}) {
        const nodeId = ConnectionTargetResolver.getNodeId(owner);
        const edge = this.belongsTo(edgeId, nodeId);
        const shop = node?.kind === "foundry-document" && node.documentType === "JournalEntry" ? ShopStore.getShop(node.uuid) : null;
        if (!game.user.isGM || !canControlPlayerEntity(owner) || !edge || (node?.kind === "foundry-document" && !shop)
            || !(shop || ["npc", "faction", "ship", "location", "quest"].includes(node?.entityType) || ["nexus-site", "nexus-scene"].includes(node?.kind))
            || ![edge.sourceNodeId, edge.targetNodeId].includes(node.id)) return [];
        return [{ id: "delete-entity", label: "Delete Object…", status: "Permanent", icon: "fas fa-skull-crossbones",
            danger: true, className: "permanent-danger", onSelect: async () => {
                const current = this.belongsTo(edgeId, nodeId);
                if (!game.user.isGM || !canControlPlayerEntity(owner) || !current
                    || ![current.sourceNodeId, current.targetNodeId].includes(node.id)) return;
                if (shop) {
                    const { ShopDeletionWorkflow } = await import("../../shops/services/ShopDeletionWorkflow.js");
                    const result = await ShopDeletionWorkflow.confirm(node.uuid); await onChanged?.(); return result;
                }
                if (node.entityType === "location") {
                    const { deleteLocation } = await import("../../../api/locations.js");
                    const result = await deleteLocation(node.entityId); await onChanged?.(); return result;
                }
                if (node.kind === "nexus-site") {
                    const { SiteDeletionManager } = await import("../../site/services/SiteDeletionManager.js");
                    const result = await SiteDeletionManager.deleteSiteIdentity({ parentScene: game.scenes.get(node.parentSceneId), siteId: node.siteId,
                        journalEntryId: node.journalEntryId, pageId: node.journalPageId, siteName: node.name });
                    await onChanged?.(); return result;
                }
                if (node.kind === "nexus-scene") {
                    const { NexusSceneDeletionCoordinator } = await import("../../nexus/services/NexusSceneDeletionCoordinator.js");
                    const result = await NexusSceneDeletionCoordinator.deleteSceneBranch(game.scenes.get(node.sceneId));
                    await onChanged?.(); return result;
                }
                if (node.entityType === "quest") {
                    const { getQuest, deleteQuest } = await import("../../../api/quests.js");
                    const quest = await getQuest(node.entityId);
                    if (!quest || !game.user.isGM) return;
                    const yes = await foundry.applications.api.DialogV2.confirm({ window: { title: "Delete quest?" }, content: "<p>Delete this quest, its goals, journal, contributions and quest links? Connected campaign entities will remain.</p>" });
                    if (!yes || !game.user.isGM || !this.belongsTo(edgeId, nodeId)) return;
                    const result = await deleteQuest(node.entityId, quest.revision); await onChanged?.(); return result;
                }
                const { CampaignEntityDeletion } = await import("../../campaign-entities/services/CampaignEntityDeletion.js");
                return CampaignEntityDeletion.confirm(node.entityType, node.entityId, { edgeId, ownerNodeId: nodeId, onChanged });
            } }];
    }

    static relationshipItems({ owner, node, edgeId, onChanged } = {}) {
        const nodeId = ConnectionTargetResolver.getNodeId(owner);
        const edge = this.belongsTo(edgeId, nodeId);
        if (!edge || !canControlPlayerEntity(owner) || ![edge.sourceNodeId, edge.targetNodeId].includes(node?.id)) return [];
        return [
            { id: "change-role", label: "Edit Role…", icon: "fas fa-pen-to-square", onSelect: () => this.editRole(edgeId, nodeId, onChanged) },
            ...this.questBindingItems({ owner, edge, onChanged }),
            ...this.deletionItems({ owner, node, edgeId, onChanged }),
            ...(this.canRemove(edge) ? [{ id: "remove-connection", label: "Remove Connection", icon: "fas fa-unlink", onSelect: () => this.remove(edgeId, nodeId, onChanged) }] : [])
        ];
    }

    static questBindingItems({ owner, edge, onChanged } = {}) {
        if (!game.user.isGM || !canControlPlayerEntity(owner)) return [];
        const nodeId = ConnectionTargetResolver.getNodeId(owner);
        return (edge?.questBindings || []).map(binding => ({ id: `remove-quest-role-${binding.id}`,
            label: `Remove ${binding.roles?.join(" · ") || binding.slot || "Quest Role"}`, icon: "fas fa-unlink", onSelect: async () => {
                const current = this.belongsTo(edge.id, nodeId);
                if (!game.user.isGM || !canControlPlayerEntity(owner) || !current?.questBindings?.some(row => row.id === binding.id && row.questId === binding.questId)) return;
                const { getQuest, disconnectQuestEntity } = await import("../../../api/quests.js");
                const quest = await getQuest(binding.questId);
                if (!game.user.isGM || !quest?.canEdit || !quest.connections.some(row => row.id === binding.id)) return;
                await disconnectQuestEntity(binding.questId, quest.revision, binding.id);
                await onChanged?.();
            } }));
    }

    static openMenu({ anchor, target, edgeId, onChanged, navigation } = {}) {
        const nodeId = ConnectionTargetResolver.getNodeId(target);
        const edge = this.belongsTo(edgeId, nodeId);
        if (!edge) return;
        const node = ConnectionStore.getNode(edge.sourceNodeId === nodeId ? edge.targetNodeId : edge.sourceNodeId);
        if (!node || !ConnectionTargetResolver.canUserSeeNode(node)) return;
        const items = this.relationshipItems({ owner: target, node, edgeId, onChanged });
        return openActionMenu({
            anchor,
            className: "connections-card-actions-menu",
            items: [
                ...(navigation?.(node) || [{ id: "open-object", label: "Open Object", icon: "fas fa-up-right-from-square", onSelect: () => ConnectionTargetResolver.openNode(node) }]),
                ...(items.length ? [{ type: "separator" }, ...items] : [])
            ]
        });
    }
}
