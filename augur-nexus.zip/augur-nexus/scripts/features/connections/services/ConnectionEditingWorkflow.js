import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { promptTextInput, openActionMenu } from "../../../api/ui.js";
import { ConnectionStore } from "./ConnectionStore.js";
import { ConnectionCategories } from "./ConnectionCategories.js";
import { ConnectionTargetResolver } from "./ConnectionTargetResolver.js";

export class ConnectionEditingWorkflow {
    static belongsTo(edgeId, nodeId) {
        const edge = ConnectionStore.getConnectionEdge(edgeId);
        return edge && [edge.sourceNodeId, edge.targetNodeId].includes(nodeId) ? edge : null;
    }

    static async editRole(edgeId, nodeId, onChanged) {
        const edge = this.belongsTo(edgeId, nodeId);
        if (!edge) return;
        const view = ConnectionStore.getConnectionView(edge, nodeId);
        const role = await promptTextInput({
            title: "Connection Role",
            label: "Role",
            value: view.role || ConnectionCategories.roleFor(view.category),
            placeholder: "Contact, Threat, Hidden Item...",
            confirmLabel: "Save",
            allowEmpty: false,
            emptyMessage: "Role cannot be empty."
        });
        if (role === null || !this.belongsTo(edgeId, nodeId)) return;
        await ConnectionStore.setConnectionViewForNode(edgeId, nodeId, { role });
        await onChanged?.();
    }

    static async remove(edgeId, nodeId, onChanged) {
        if (!this.belongsTo(edgeId, nodeId)) return;
        await ConnectionStore.removeConnection(edgeId);
        await onChanged?.();
    }

    static openMenu({ anchor, target, edgeId, onChanged } = {}) {
        const nodeId = ConnectionTargetResolver.getNodeId(target);
        if (!canControlPlayerEntity(target) || !this.belongsTo(edgeId, nodeId)) return;
        return openActionMenu({
            anchor,
            className: "connections-card-actions-menu",
            items: [
                { id: "change-role", label: "Edit Role...", icon: "fas fa-pen-to-square",
                    onSelect: () => this.editRole(edgeId, nodeId, onChanged) },
                { id: "remove-connection", label: "Remove Connection", icon: "fas fa-trash", danger: true,
                    onSelect: () => this.remove(edgeId, nodeId, onChanged) }
            ]
        });
    }
}
