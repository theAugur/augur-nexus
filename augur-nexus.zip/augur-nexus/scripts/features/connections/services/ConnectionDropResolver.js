import { ConnectionTargetResolver } from "./ConnectionTargetResolver.js";
import { ShopStore } from "../../shops/services/ShopStore.js";
import { CampaignEntityActorImportGateway } from "../../campaign-entities/services/CampaignEntityActorImportGateway.js";

export class ConnectionDropResolver {
    static async fromEvent(event, options = {}) {
        if (event?.augurNexusDropResolutionPromise) {
            return event.augurNexusDropResolutionPromise;
        }

        const resolution = this.#resolveEvent(event, options);
        if (event) event.augurNexusDropResolutionPromise = resolution;
        return resolution;
    }

    static async #resolveEvent(event, options = {}) {
        const data = this.#getDropData(event);
        if (!data) return null;

        if (data.kind === "nexus-site" || data.kind === "nexus-scene" || data.kind === "nexus-entity" || data.type === "AugurNexusSite" || data.type === "AugurNexusNode" || data.type === "AugurNexusEntity") {
            return ConnectionTargetResolver.fromNodePayload(data);
        }
        if (data.kind === "nexus-shop" || data.type === "AugurNexusShop") {
            const document = ShopStore.resolveDocument(data.shopId || data.uuid);
            return document ? ConnectionTargetResolver.fromDocument(document, { category: "service" }) : null;
        }

        if ((data.type || data.documentName) === "Actor") {
            if (event) event.augurNexusActorDrop = true;
            const actor = await this.#resolveActor(data);
            if (!actor) return null;
            if (options.convertActors === false) return ConnectionTargetResolver.fromDocument(actor);
            const result = await CampaignEntityActorImportGateway.resolve(actor, options);
            if (event) event.augurNexusActorImportMode = result?.mode || "";
            if (result?.mode === "entity") return ConnectionTargetResolver.fromCampaignEntity(result.entity);
            if (result?.mode === "actor") return ConnectionTargetResolver.fromDocument(actor);
            return null;
        }

        const uuid = data.uuid || this.#uuidFromData(data);
        if (!uuid) return null;
        if (String(uuid).startsWith("Scene.")) return null;
        return ConnectionTargetResolver.fromUuid(uuid);
    }

    static #getDropData(event) {
        const raw = event?.dataTransfer?.getData("text/plain")
            || event?.dataTransfer?.getData("application/json")
            || "";
        if (!raw) return null;
        try {
            return JSON.parse(raw);
        } catch (_err) {
            return null;
        }
    }

    static #uuidFromData(data = {}) {
        const type = data.type || data.documentName || "";
        const id = data.id || data._id || "";
        if (!type || !id) return "";
        if (type === "Scene") return "";

        if (type === "JournalEntryPage" && data.parentUuid) return `${data.parentUuid}.JournalEntryPage.${id}`;
        if (type === "JournalEntryPage" && data.journalEntryId) return `JournalEntry.${data.journalEntryId}.JournalEntryPage.${id}`;
        return `${type}.${id}`;
    }

    static wasActorDrop(event) {
        return event?.augurNexusActorDrop === true;
    }

    static getActorImportMode(event) {
        return String(event?.augurNexusActorImportMode || "");
    }

    static async #resolveActor(data = {}) {
        const uuid = data.uuid || this.#uuidFromData(data);
        const actor = uuid ? await fromUuid(uuid).catch(() => null) : null;
        if (!actor || actor.documentName !== "Actor" || actor.inCompendium) {
            ui.notifications.warn("Drop a world Actor from the Actors directory.");
            return null;
        }
        return actor;
    }
}
