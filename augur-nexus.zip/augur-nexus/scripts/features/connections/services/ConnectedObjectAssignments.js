import { LocationLeadershipModel } from "../models/LocationLeadershipModel.js";
import { promptTextInput } from "../../../api/ui.js";
import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { ConnectionEditingWorkflow } from "./ConnectionEditingWorkflow.js";
import { ConnectionStore } from "./ConnectionStore.js";

// Designations clear their own metadata; the underlying connection can have other uses.
export function connectedObjectAssignmentItems({ card, owner, node, edge, onChanged } = {}) {
    if (!canControlPlayerEntity(owner)) return [];
    const kind = card.dataset.shipDomainDrop || card.dataset.factionDomainDrop || card.dataset.settlementAuthorityDrop
        || (owner.entityType === "ship" && card.matches(".is-captain") ? "captain" : "")
        || (card.matches(".faction-parent-row") ? "parent" : card.dataset.action === "openPlaceOwner" ? "owner" : "");
    const assignment = (label, operation) => [
        { id: "edit-label", label: "Edit Label", icon: "fas fa-pen-to-square", onSelect: async () => {
            if (!canControlPlayerEntity(owner) || (kind === "parent" && !game.user.isGM)) return;
            const api = owner.entityType === "ship" ? await import("../../../api/ships.js") : await import("../../../api/factions.js");
            const get = owner.entityType === "ship" ? api.getShip : api.getFaction;
            const update = owner.entityType === "ship" ? api.updateShip : api.updateFaction;
            const current = get(owner.entityId);
            const defaults = { owner: "Owned by", captain: "Captained by", leader: "Ruled by", seat: "Seat of power", parent: "Parent organization" };
            const text = await promptTextInput({ title: "Edit Label", label: "Label", value: current?.dossier?.authorityLabels?.[kind] || defaults[kind],
                confirmLabel: "Save", allowEmpty: false, emptyMessage: "Label cannot be empty." });
            if (text === null || !canControlPlayerEntity(owner) || (kind === "parent" && !game.user.isGM)
                || !ConnectionEditingWorkflow.belongsTo(edge.id, owner.id)) return;
            const live = get(owner.entityId);
            await update(owner.entityId, { dossier: { ...live.dossier, authorityLabels: { ...live.dossier?.authorityLabels, [kind]: text.trim() } } });
            await onChanged?.();
        } }, action(label, operation)
    ];
    const action = (label, operation) => ({ id: `remove-${kind}`, label, icon: "fas fa-unlink", onSelect: async () => {
        if (!canControlPlayerEntity(owner) || !ConnectionEditingWorkflow.belongsTo(edge.id, owner.id)) return;
        await operation(); await onChanged?.();
    } });
    if (owner.entityType === "ship") {
        if (kind === "captain" && edge.shipCaptain) return assignment("Remove Captain", async () => {
            const { ShipCaptainService } = await import("./ShipCaptainService.js");
            if (ShipCaptainService.getCaptain(owner, { includeHidden: true })?.edgeId === edge.id) await ShipCaptainService.clearCaptain(owner);
        });
        if (kind === "owner" && edge.shipOwnership) return assignment("Remove Owner", async () => {
            const { ShipOwnershipService } = await import("./ShipOwnershipService.js");
            if (ShipOwnershipService.getOwner(owner, { includeHidden: true })?.edge.id === edge.id) await ShipOwnershipService.clearOwner(owner, { preserveConnection: true });
        });
        if (kind === "location" && edge.shipLocation) return [action("Remove Current Location", async () => {
            const { ShipLocationService } = await import("./ShipLocationService.js");
            if (ShipLocationService.getCurrentLocation(owner, { includeHidden: true, allowMarkerFallback: false })?.edge.id === edge.id) await ShipLocationService.clearCurrentLocation(owner, { preserveConnection: true, removeMarker: true });
        })];
    }
    if (owner.entityType === "faction") {
        if (kind === "leader" && edge.factionMembership?.tier === "leader") return assignment("Remove Ruler", async () => {
            const { FactionMembershipService } = await import("./FactionMembershipService.js");
            if (ConnectionStore.getConnectionEdge(edge.id)?.factionMembership?.tier !== "leader") return;
            await FactionMembershipService.setMember(owner, node, { edgeId: edge.id });
        });
        if (kind === "seat" && edge.factionSeat) return assignment("Remove Seat of Power", async () => {
            const { FactionSeatService } = await import("./FactionSeatService.js");
            await FactionSeatService.clearSeat(owner, { edgeId: edge.id });
        });
        if (kind === "parent" && edge.factionHierarchy && game.user.isGM) return assignment("Remove Parent Organization", async () => {
            if (!game.user.isGM) return;
            const { FactionHierarchyService } = await import("./FactionHierarchyService.js");
            await FactionHierarchyService.clearParent(owner, { edgeId: edge.id });
        });
    }
    if (kind === "leader" && owner.entityType === "location" && edge.locationLeadership) return [action(LocationLeadershipModel.getPresentation(edge.locationLeadership).removeLabel, async () => {
        const { LocationLeadershipService } = await import("./LocationLeadershipService.js");
        await LocationLeadershipService.clearLeader(owner, { edgeId: edge.id });
    })];
    if (kind === "owner" && edge.relationType === "ownership") return [action("Remove Owner", async () => {
        const { OwnershipService } = await import("./OwnershipService.js");
        await OwnershipService.clearOwner(owner, { edgeId: edge.id });
    })];
    return [];
}
