import { CampaignEntityJournalStore } from "../../campaign-entities/services/CampaignEntityJournalStore.js";
import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { QuestRecordStore } from "../../quests/storage/QuestRecordStore.js";
import { SiteRecordManager } from "../../site/services/SiteRecordManager.js";
import { SiteSceneVisibilityManager } from "../../site/services/SiteSceneVisibilityManager.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";
import { ConnectionTargetResolver } from "./ConnectionTargetResolver.js";

const MODULE = "augur-nexus";
const FLAG = "connectionGraphLayouts";
const position = value => typeof value?.x === "number" && Number.isFinite(value.x)
    && typeof value?.y === "number" && Number.isFinite(value.y) ? { x: value.x, y: value.y } : null;
const positions = value => Object.fromEntries(Object.entries(value && typeof value === "object" && !Array.isArray(value) ? value : {})
    .flatMap(([id, value]) => id && position(value) ? [[id, position(value)]] : []));
const layouts = value => Object.fromEntries(Object.entries(value && typeof value === "object" && !Array.isArray(value) ? value : {})
    .map(([key, value]) => [key, positions(value)]));

// Foundry expands dotted keys recursively even inside replacement flag values.
const encodeLayouts = value => Object.fromEntries(Object.entries(layouts(value)).map(([context, cards]) => [context,
    Object.fromEntries(Object.entries(cards).map(([id, point]) => [encodeURIComponent(id).replace(/\./g, "%2E"), point]))]));
const decodeLayouts = value => Object.fromEntries(Object.entries(value && typeof value === "object" ? value : {}).map(([context, cards]) => [context,
    Object.fromEntries(Object.entries(positions(cards)).flatMap(([id, point]) => {
        try { return [[decodeURIComponent(id), point]]; } catch { return []; }
    }))]));

/** Object-owned manual card positions. Camera, automatic layout and dossier sessions never enter this store. */
export class ConnectionGraphLayoutStore {
    static #queues = new Map();
    static #pending = new Map();
    static #sequence = 0;
    static #linking = new Set();

    static contextKey({ boundaryId = "", density = "detail" } = {}) {
        // Hex encoding keeps arbitrary boundary IDs out of Foundry's dotted update-path syntax.
        return `c${Array.from(JSON.stringify([String(boundaryId || ""), String(density || "detail")]))
            .map(character => character.codePointAt(0).toString(16)).join("_")}`;
    }

    static readSaved(target, context) {
        const owner = this.#resolve(target);
        return owner ? positions(owner.read()[this.contextKey(context)]) : {};
    }

    static read(target, context) {
        const owner = this.#resolve(target);
        if (!owner) return {};
        const key = this.contextKey(context), saved = positions(owner.read()[key]);
        for (const [id, intent] of this.#state(owner, key, false)?.moves || []) {
            Object.defineProperty(saved, id, { value: { ...intent.position }, enumerable: true, configurable: true, writable: true });
        }
        return saved;
    }

    static canArrange(target) {
        if (!game.user?.isGM) return false;
        const owner = this.#resolve(target);
        return !!owner && !this.#linking.has(owner.key) && !owner.document.pack && typeof owner.document.update === "function"
            && (typeof owner.document.canUserModify !== "function" || owner.document.canUserModify(game.user, "update"));
    }

    static getError(target, context) {
        const owner = this.#resolve(target);
        if (!owner) return null;
        const state = this.#state(owner, this.contextKey(context), false);
        return state?.resetError || [...(state?.moves.values() || [])].find(intent => intent.error)?.error || null;
    }

    static async savePosition(target, context, nodeId, value) {
        const next = position(value);
        if (!next || typeof nodeId !== "string" || !nodeId) return Promise.reject(new Error("Graph positions require a card ID and finite coordinates."));
        const owner = this.#writable(target), key = this.contextKey(context), state = this.#state(owner, key);
        const intent = { sequence: ++this.#sequence, position: next, error: null };
        // A later manual arrangement supersedes a failed or still-finishing reset.
        state.resetSequence = intent.sequence; state.resetError = null;
        state.moves.set(nodeId, intent);
        return this.#enqueue(owner, async () => {
            try {
                const fresh = this.#fresh(target, owner), current = fresh.read();
                const cards = positions(current[key]);
                Object.defineProperty(cards, nodeId, { value: next, enumerable: true, configurable: true, writable: true });
                current[key] = cards;
                await fresh.write(current);
                if (state.moves.get(nodeId) === intent) state.moves.delete(nodeId);
                globalThis.Hooks?.callAll?.("augurNexusGraphLayoutChanged");
            } catch (error) {
                if (state.moves.get(nodeId) === intent) intent.error = error;
                throw error;
            }
        });
    }

    static async clear(target, context) {
        const owner = this.#writable(target), key = this.contextKey(context), state = this.#state(owner, key);
        const sequence = ++this.#sequence;
        state.resetSequence = sequence; state.resetError = null;
        return this.#enqueue(owner, async () => {
            try {
                const fresh = this.#fresh(target, owner), current = fresh.read();
                delete current[key];
                await fresh.write(current);
                for (const [id, intent] of state.moves) if (intent.sequence <= sequence) state.moves.delete(id);
                if (state.resetSequence === sequence) state.resetError = null;
                globalThis.Hooks?.callAll?.("augurNexusGraphLayoutChanged");
            } catch (error) {
                if (state.resetSequence === sequence) state.resetError = error;
                throw error;
            }
        });
    }

    static async retry(target, context) {
        const owner = this.#writable(target), state = this.#state(owner, this.contextKey(context), false);
        if (state?.resetError) return this.clear(target, context);
        return Promise.all([...(state?.moves || [])].filter(([, intent]) => intent.error)
            .map(([id, intent]) => this.savePosition(target, context, id, intent.position)));
    }

    static async flush() {
        while (this.#queues.size) await Promise.all([...this.#queues.values()]);
    }

    /** Preserve a site's own layout when generation gives it a dedicated Scene backing. */
    static async linkSiteScene(target, scene, writeRecord) {
        if (!game.user?.isGM) throw new Error("Only a GM can link a site's graph layout.");
        const parent = game.scenes.get(target.parentSceneId);
        const record = parent && SiteRecordManager.getSceneRecord(parent, target.siteId);
        if (!record) throw new Error("The site is no longer available.");
        const owner = this.#resolve(target);
        if (!owner || record.siteSceneId || record.linkedSceneId || owner.document === scene) return writeRecord(record);
        if (!scene || game.scenes.get(scene.id) !== scene || scene.pack || typeof scene.update !== "function") throw new Error("The linked Scene is no longer available.");
        if (this.#linking.has(owner.key)) throw new Error("This site is already being linked.");
        this.#linking.add(owner.key);
        try {
            return await this.#enqueue(owner, async () => {
                const fresh = this.#fresh(target, owner), source = fresh.read();
                for (const [key, state] of this.#pending) {
                    if (state.document !== owner.document || state.ownerKey !== owner.key) continue;
                    const contextKey = state.contextKey;
                    const cards = positions(source[contextKey]);
                    for (const [id, intent] of state.moves) Object.defineProperty(cards, id, { value: { ...intent.position }, enumerable: true });
                    if (Object.keys(cards).length) source[contextKey] = cards;
                }
                const destination = this.#documentOwner(scene);
                await this.#enqueue(destination, async () => {
                    if (game.scenes.get(scene.id) !== scene) throw new Error("The linked Scene was deleted before its layout could be transferred.");
                    const merged = { ...source, ...destination.read() };
                    if (Object.keys(source).length) await destination.write(merged);
                });
                const current = SiteRecordManager.getSceneRecord(parent, target.siteId);
                if (!current) throw new Error("The site was deleted before linking finished.");
                const result = await writeRecord({ ...current, graphLayouts: {} });
                // SiteRecordManager merges flags; explicitly replace the old owned map after linking succeeds.
                if (fresh.document.documentName === "JournalEntryPage" || fresh.key !== fresh.queueKey) await fresh.write({});
                for (const [key, state] of this.#pending) if (state.document === owner.document && state.ownerKey === owner.key) this.#pending.delete(key);
                globalThis.Hooks?.callAll?.("augurNexusGraphLayoutChanged");
                return result;
            });
        } finally { this.#linking.delete(owner.key); }
    }

    static #state(owner, contextKey, create = true) {
        const key = `${owner.key}/${contextKey}`;
        const previous = this.#pending.get(key);
        if (previous?.document === owner.document) return previous;
        if (!create) return undefined;
        const state = { document: owner.document, ownerKey: owner.key, contextKey, moves: new Map(), resetError: null };
        this.#pending.set(key, state);
        return state;
    }

    static #enqueue(owner, operation) {
        const result = (this.#queues.get(owner.queueKey) || Promise.resolve()).then(operation);
        const tail = result.catch(() => {}).finally(() => { if (this.#queues.get(owner.queueKey) === tail) this.#queues.delete(owner.queueKey); });
        this.#queues.set(owner.queueKey, tail);
        return result;
    }

    static #writable(target, duringLink = false) {
        const owner = game.user?.isGM ? this.#resolve(target) : null;
        if (!owner || owner.document.pack || typeof owner.document.update !== "function"
            || (!duringLink && this.#linking.has(owner.key))
            || (typeof owner.document.canUserModify === "function" && !owner.document.canUserModify(game.user, "update"))) {
            throw new Error("Only a GM can arrange a graph backed by an available world object.");
        }
        return owner;
    }

    static #fresh(target, previous) {
        try {
            const current = this.#writable(target, true);
            if (current.key === previous.key && current.document === previous.document) return current;
        } catch { /* Losing an owner discards its obsolete optimistic overlay. */ }
        for (const [key, state] of this.#pending) if (state.ownerKey === previous.key && state.document === previous.document) this.#pending.delete(key);
        throw new Error("The graph's backing object changed before its layout could be saved.");
    }

    static #documentOwner(document) {
        if (!document) return null;
        const key = document.uuid || `${document.documentName}.${document.id}`;
        return { key, queueKey: key, document,
            read: () => decodeLayouts(document.getFlag(MODULE, FLAG)),
            write: value => document.update({ [`flags.${MODULE}.==${FLAG}`]: encodeLayouts(value) }, { augurNexusGraphLayout: true, render: false }) };
    }

    static #resolve(input) {
        const target = input?.target || input;
        if (!target || target.missing) return null;
        if (target.kind === "nexus-entity") {
            if (!ConnectionTargetResolver.canUserSeeNode(target)) return null;
            const id = target.entityId || String(target.id || "").replace(/^nexus-entity:/, "");
            const resolve = { npc: value => CampaignEntityJournalStore.resolveNpcDocument(value),
                faction: value => CampaignEntityJournalStore.resolveFactionDocument(value),
                ship: value => CampaignEntityJournalStore.resolveShipDocument(value),
                location: value => LocationEntityStore.resolveDocument(value), quest: value => QuestRecordStore.document(value) }[target.entityType];
            const document = resolve?.(id);
            return document && game.journal.get(document.id) === document ? this.#documentOwner(document) : null;
        }
        if (target.kind === "nexus-scene") {
            const scene = game.scenes.get(target.sceneId || String(target.id || "").replace(/^nexus-scene:/, ""));
            return scene && NexusPlayerSceneAccess.canUserSeeSceneInNexus(scene) ? this.#documentOwner(scene) : null;
        }
        if (target.kind !== "nexus-site") return null;
        const parent = game.scenes.get(target.parentSceneId);
        if (!parent) return null;
        const canonical = SiteRecordManager.getSceneRecord(parent, target.siteId);
        const record = canonical || SiteRecordManager.resolveSite({ parentScene: parent, siteId: target.siteId });
        if (!record || !SiteSceneVisibilityManager.canUserSeeSite({ scene: parent, siteId: target.siteId, record })) return null;
        const linkedId = record.siteSceneId || record.linkedSceneId;
        // A broken link must not silently move ownership to the parent record.
        if (linkedId) return this.#documentOwner(game.scenes.get(linkedId));
        const entry = record.journalEntryId ? game.journal.get(record.journalEntryId) : null;
        const page = entry?.pages?.get(record.journalPageId);
        const flags = page?.getFlag(MODULE, "siteId") === target.siteId && page?.getFlag(MODULE, "sitePage");
        if (flags && (!page.getFlag(MODULE, "parentSceneId") || page.getFlag(MODULE, "parentSceneId") === parent.id)) {
            if (!game.user?.isGM && !page.testUserPermission?.(game.user, "OBSERVER")) return null;
            return this.#documentOwner(page);
        }
        if (!canonical) return null;
        const owner = this.#documentOwner(parent);
        return { ...owner, key: `${owner.key}/site:${target.siteId}`,
            read: () => decodeLayouts(SiteRecordManager.getSceneRecord(parent, target.siteId)?.graphLayouts),
            write: async value => {
                const sites = foundry.utils.deepClone(parent.getFlag(MODULE, "sites") || {});
                const current = sites.records?.[target.siteId];
                if (!current) throw new Error("The site was deleted before its graph layout could be saved.");
                const update = /^[\w-]+$/.test(target.siteId)
                    ? { [`flags.${MODULE}.sites.records.${target.siteId}.==graphLayouts`]: encodeLayouts(value) }
                    : { [`flags.${MODULE}.==sites`]: { ...sites, records: { ...sites.records, [target.siteId]: { ...current, graphLayouts: encodeLayouts(value) } } } };
                return parent.update(update, { augurNexusGraphLayout: true, render: false });
            } };
    }
}
