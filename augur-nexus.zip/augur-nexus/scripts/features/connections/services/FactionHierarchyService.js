import { FactionHierarchyModel } from "../models/FactionHierarchyModel.js";
import { ConnectionStore } from "./ConnectionStore.js";
import { ConnectionTargetResolver } from "./ConnectionTargetResolver.js";

export class FactionHierarchyService {
    static getEntries({ user = game.user, includeHidden = false } = {}) {
        const { graph } = ConnectionStore.getGraphContext();
        return Object.values(graph.edges || {}).flatMap(edge => {
            const sourceNode = graph.nodes[edge.sourceNodeId];
            const targetNode = graph.nodes[edge.targetNodeId];
            const hierarchy = FactionHierarchyModel.normalize(edge.factionHierarchy, { sourceNode, targetNode });
            if (!hierarchy) return [];
            if (!includeHidden && (!ConnectionStore.canUserSeeConnection(edge, user)
                || !ConnectionTargetResolver.canUserSeeNode(sourceNode, user)
                || !ConnectionTargetResolver.canUserSeeNode(targetNode, user))) return [];
            return [{ ...hierarchy, edgeId: edge.id }];
        });
    }

    static getParentMap(options = {}) {
        return FactionHierarchyModel.buildParentMap(this.getEntries(options));
    }

    static getParent(child, options = {}) {
        const parentId = this.getParentMap(options).get(ConnectionTargetResolver.getNodeId(child));
        return parentId ? this.#display(parentId) : null;
    }

    static getChildren(parent, options = {}) {
        const parentId = ConnectionTargetResolver.getNodeId(parent);
        return [...this.getParentMap(options)]
            .filter(([, id]) => id === parentId)
            .map(([id]) => this.#display(id)).filter(Boolean)
            .sort((a, b) => a.name.localeCompare(b.name));
    }

    static canSetParent(child, parent) {
        const childNode = this.#node(child);
        const parentNode = this.#node(parent);
        return FactionHierarchyModel.canRepresent(parentNode, childNode)
            && !FactionHierarchyModel.wouldCreateCycle(childNode.id, parentNode.id, this.getEntries({ includeHidden: true }));
    }

    static async setParent(child, parent, { edgeId = "" } = {}) {
        if (!game.user?.isGM) throw new Error("Only the GM can change organization hierarchy.");
        return ConnectionStore.runBatch(async () => {
            const childNode = this.#node(child);
            const parentNode = this.#node(parent);
            if (!FactionHierarchyModel.canRepresent(parentNode, childNode)) throw new Error("Choose two different Nexus Organizations.");
            if ([parentNode, childNode].some(node => ConnectionTargetResolver.resolveDisplayNodeSync(node)?.missing)) {
                throw new Error("One of these Organizations no longer exists.");
            }
            if (!this.canSetParent(childNode, parentNode)) throw new Error("That parent would create a circular organization hierarchy.");
            const graph = ConnectionStore.getGraphContext().graph;
            const selected = edgeId ? graph.edges[edgeId] : Object.values(graph.edges).find(edge =>
                [edge.sourceNodeId, edge.targetNodeId].includes(childNode.id)
                && [edge.sourceNodeId, edge.targetNodeId].includes(parentNode.id));
            if (edgeId && (!selected || ![selected.sourceNodeId, selected.targetNodeId].includes(childNode.id)
                || ![selected.sourceNodeId, selected.targetNodeId].includes(parentNode.id))) {
                throw new Error("The selected Connection does not join these Organizations.");
            }
            for (const current of this.getEntries({ includeHidden: true })) {
                if (current.childNodeId === childNode.id && current.edgeId !== selected?.id) {
                    await ConnectionStore.updateConnection(current.edgeId, { factionHierarchy: null });
                }
            }
            const factionHierarchy = { schemaVersion: 1, parentNodeId: parentNode.id, childNodeId: childNode.id };
            if (selected) return ConnectionStore.updateConnection(selected.id, { factionHierarchy });
            return ConnectionStore.addConnection(parentNode, childNode, {
                factionHierarchy,
                sourceView: { category: "faction", role: "Related Organization" },
                targetView: { category: "faction", role: "Related Organization" }
            });
        }, { reason: "setFactionParent" });
    }

    static async clearParent(child, { edgeId = "" } = {}) {
        if (!game.user?.isGM) throw new Error("Only the GM can change organization hierarchy.");
        const childId = ConnectionTargetResolver.getNodeId(child);
        return ConnectionStore.runBatch(async () => {
            for (const entry of this.getEntries({ includeHidden: true })) {
                if (entry.childNodeId !== childId || (edgeId && entry.edgeId !== edgeId)) continue;
                await ConnectionStore.updateConnection(entry.edgeId, { factionHierarchy: null });
            }
        }, { reason: "clearFactionParent" });
    }

    static async removeForDeletedFaction(nodeId) {
        if (!game.user?.isGM) return;
        const entries = this.getEntries({ includeHidden: true })
            .filter(entry => entry.parentNodeId === nodeId || entry.childNodeId === nodeId);
        if (!entries.length) return;
        return ConnectionStore.runBatch(async () => {
            for (const entry of entries) await ConnectionStore.updateConnection(entry.edgeId, { factionHierarchy: null });
        }, { reason: "deletedFactionHierarchy" });
    }

    static #node(target) {
        const id = ConnectionTargetResolver.getNodeId(target);
        return { ...(ConnectionStore.getNode(id) || target), id };
    }

    static #display(id) {
        const node = ConnectionStore.getNode(id);
        const display = node && ConnectionTargetResolver.resolveDisplayNodeSync(node);
        if (!display || display.missing) return null;
        return { nodeId: id, entityId: node.entityId, name: display.name, imageSrc: display.img || "", subtitle: display.subtitle || "Organization" };
    }
}
