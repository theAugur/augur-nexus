import { openActionMenu } from "../../../api/ui.js";
import { ConnectionEditingWorkflow } from "./ConnectionEditingWorkflow.js";
import { ConnectionStore } from "./ConnectionStore.js";
import { ConnectionTargetResolver } from "./ConnectionTargetResolver.js";

// Both dossier hosts supply navigation; relationship actions have one authority.
export function bindOrganizationMemberMenus(root, { getOwner, navigation, onChanged }) {
    if (root.dataset.memberMenusBound) return;
    root.dataset.memberMenusBound = "true";
    let dragging = false, suppressUntil = 0;
    root.addEventListener("dragstart", event => {
        if (event.target.closest("[data-organization-member]")) dragging = true;
    }, true);
    root.addEventListener("dragend", () => {
        if (dragging) suppressUntil = Date.now() + 250;
        dragging = false;
    }, true);
    const open = event => {
        const card = event.target.closest("[data-organization-member]");
        if (!card || !root.contains(card)) return;
        event.preventDefault(); event.stopImmediatePropagation();
        if (dragging || Date.now() < suppressUntil) return;
        const person = ConnectionStore.getNode(card.dataset.memberNodeId);
        if (!person || !ConnectionTargetResolver.canUserSeeNode(person)) return;
        const owner = ConnectionTargetResolver.fromCampaignEntity(getOwner());
        const items = ConnectionEditingWorkflow.memberItems({ owner, edgeId: card.dataset.edgeId, onChanged });
        openActionMenu({ anchor: card, className: "connections-card-actions-menu",
            items: [...navigation(person), ...(items.length ? [{ type: "separator" }, ...items] : [])] });
    };
    root.addEventListener("click", open, true);
    root.addEventListener("contextmenu", open, true);
    root.addEventListener("keydown", event => {
        if (event.key === "ContextMenu" || (event.shiftKey && event.key === "F10")) open(event);
    }, true);
}
