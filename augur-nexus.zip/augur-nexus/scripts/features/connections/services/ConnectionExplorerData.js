import { connectionVisibility } from "./ConnectedObjectVisibility.js";
import { CampaignEntityIndex } from "../../campaign-entities/services/CampaignEntityIndex.js";
import { ConnectionOpinionService } from "./ConnectionOpinionService.js";
import { ConnectionStore } from "./ConnectionStore.js";
import { ConnectionTargetResolver } from "./ConnectionTargetResolver.js";
import { PlaceTypeRegistry } from "../../places/services/PlaceTypeRegistry.js";
import { PlaceHierarchyModel } from "../../places/models/PlaceHierarchyModel.js";
import { NexusDirectoryVisibility } from "../../nexus/services/NexusDirectoryVisibility.js";
import { NexusLineageManager } from "../../nexus/services/NexusLineageManager.js";
import { WorkspacePlaces } from "../../workspace/services/WorkspacePlaces.js";
import { RegionProviderRegistry } from "../../region-population/services/RegionProviderRegistry.js";
import { LocationGeneratorRegistry } from "../../campaign-entities/services/LocationGeneratorRegistry.js";

const typeFor = node => node.entityType || (["nexus-site", "nexus-scene"].includes(node.kind) ? "place" : node.documentType === "Actor" ? "npc" : node.category || "document");

export function canViewExplorerTarget(target, user = game.user) {
    if (!target || !ConnectionTargetResolver.canUserSeeNode(target, user)) return false;
    if (["nexus-site", "nexus-scene"].includes(target.kind)) return WorkspacePlaces.canView(WorkspacePlaces.get(target.id));
    if (target.kind === "foundry-document" && !user?.isGM) {
        const document = globalThis.foundry?.utils?.fromUuidSync?.(target.uuid, { strict: false });
        if (document?.testUserPermission) return document.testUserPermission(user, "LIMITED");
        const pack = document?.pack ? game.packs?.get(document.pack) : null;
        return !!pack && pack.getUserLevel(user) >= CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER;
    }
    return true;
}

// The direction comes from domain records, never from arbitrary endpoint ordering or role text.
export function explorerEdge(edge, sourceView = {}, targetView = {}) {
    let source = edge.sourceNodeId, target = edge.targetNodeId, label = "", directed = false, containment = null;
    const membership = edge.factionMembership, captain = edge.shipCaptain, ownership = edge.shipOwnership;
    if (membership) {
        source = membership.memberNodeId; target = membership.factionNodeId;
        label = membership.tier === "leader" ? "Leads" : "Member of"; directed = true;
        containment = { container: target, node: source, section: "People", label: membership.tier === "leader" ? "Leader" : membership.rank?.label || "Member", priority: membership.tier === "leader" ? 0 : 1 };
    } else if (captain) {
        source = captain.captainNodeId; target = captain.shipNodeId; label = "Captains"; directed = true;
        containment = { container: target, node: source, section: "People", label: "Captain", priority: 0 };
    } else if (ownership) {
        source = ownership.ownerNodeId; target = ownership.shipNodeId; label = "Owns"; directed = true;
        containment = { container: source, node: target, section: "Holdings", label: "Ship" };
    } else if (edge.relationType === "ownership") {
        label = "Owns"; directed = true; containment = { container: source, node: target, section: "Holdings", label: "Holding" };
    } else if (edge.locationLeadership) {
        source = edge.locationLeadership.leaderNodeId; target = edge.locationLeadership.locationNodeId;
        label = edge.locationLeadership.authorityType === "owner" ? "Owns" : "Rules"; directed = true;
        containment = { container: target, node: source, section: "People", label: label === "Owns" ? "Owner" : "Ruler", priority: 0 };
    } else if (edge.factionHierarchy) {
        source = edge.factionHierarchy.parentNodeId; target = edge.factionHierarchy.childNodeId; label = "Child organization"; directed = true;
    } else if (edge.shipLocation) {
        source = edge.shipLocation.shipNodeId; target = edge.shipLocation.placeNodeId; label = "Present in"; directed = true;
    } else if (edge.factionSeat) {
        source = edge.factionSeat.factionNodeId; target = edge.factionSeat.placeNodeId; label = "Seat of power"; directed = true;
        containment = { container: source, node: target, section: "Holdings", label: "Seat of power" };
    }
    const roles = { [edge.sourceNodeId]: String(sourceView.role || ""), [edge.targetNodeId]: String(targetView.role || "") };
    label ||= roles[source] || roles[target] || "Connection";
    const perspectiveLabels = {};
    const directional = (from, to) => { perspectiveLabels[source] = from; perspectiveLabels[target] = to; };
    if (membership) directional(membership.tier === "leader" ? "Leads" : "Member of", membership.tier === "leader" ? "Leader" : membership.rank?.label || "Member");
    else if (captain) directional("Captains", "Captain");
    else if (ownership || edge.relationType === "ownership") directional("Owns", "Owned by");
    else if (edge.locationLeadership) directional(label, label === "Owns" ? "Owned by" : "Ruled by");
    else if (edge.factionHierarchy) {
        perspectiveLabels[edge.factionHierarchy.parentNodeId] = "Child organization";
        perspectiveLabels[edge.factionHierarchy.childNodeId] = "Parent organization";
    }
    else if (edge.shipLocation) directional("Located at", "Present");
    else if (edge.factionSeat) directional("Seat of power", "Seat of");
    return { id: edge.id, source, target, label, directed, relationType: edge.relationType || "", roles, perspectiveLabels, containment,
        membership: membership ? { factionId: membership.factionNodeId, nodeId: membership.memberNodeId } : null,
        hierarchy: edge.factionHierarchy ? { parentId: edge.factionHierarchy.parentNodeId, childId: edge.factionHierarchy.childNodeId } : null,
        ownership: ownership || edge.relationType === "ownership" ? { ownerId: source, nodeId: target } : null,
        seat: edge.factionSeat ? { factionId: edge.factionSeat.factionNodeId, placeId: edge.factionSeat.placeNodeId } : null, placement: edge.shipLocation ? { nodeId: source, placeId: target } : null };
}

export function buildConnectionExplorerData({ extraTargets = [] } = {}) {
    const graph = ConnectionStore.getGraphContext().graph;
    const byId = new Map();
    const add = target => {
        if (!target?.id || byId.has(target.id) || !canViewExplorerTarget(target)) return;
        const display = ConnectionTargetResolver.resolveDisplayNodeSync(target);
        if (!display || display.missing) return;
        const node = { ...display, ...connectionVisibility(target), target: { ...target }, type: typeFor(display), scopeIds: [], siteIds: [], parentId: "" };
        byId.set(node.id, node);
    };
    for (const node of Object.values(graph.nodes || {})) add(node);
    for (const entity of [...CampaignEntityIndex.getNpcs(), ...CampaignEntityIndex.getFactions(), ...CampaignEntityIndex.getLocations(), ...CampaignEntityIndex.getShips()]) {
        const target = ConnectionTargetResolver.fromCampaignEntity(entity);
        add(target);
        const node = byId.get(target?.id);
        if (node?.type === "location") {
            node.isSettlement = entity.profile?.kindId === "settlement";
            node.placeCategory = node.isSettlement ? "settlement" : entity.profile?.kindId === "resource-site" ? "resource" : "holding";
            node.importance = LocationGeneratorRegistry.getConnectionExplorerProfile(entity).importance;
        }
    }
    for (const node of extraTargets) add(node);

    // The registered place providers unify lineage, Location parents, and generated Scene aliases.
    const placeNodes = PlaceTypeRegistry.getNodes({ isGM: !!game.user.isGM });
    const hierarchy = NexusDirectoryVisibility.filterRows(PlaceHierarchyModel.buildRows(placeNodes));
    const targetByKey = new Map();
    for (const row of hierarchy) {
        const target = row.connectionTarget || (row.parentSceneId && row.siteId
            ? ConnectionTargetResolver.fromSiteReference(row)
            : row.sceneId && row.type !== "location" ? ConnectionTargetResolver.fromSceneReference(row) : null);
        add(target);
        if (target && byId.has(target.id)) targetByKey.set(row.key, target.id);
    }
    const visibleRows = hierarchy.filter(row => targetByKey.has(row.key));
    const rowByKey = new Map(visibleRows.map(row => [row.key, row]));
    const rootSceneId = NexusLineageManager.getRootScene()?.id;
    const globalRoot = visibleRows.find(row => (row.sceneId === rootSceneId || row.primarySceneId === rootSceneId))?.key;
    // A region can itself be the Nexus root. Keep its geography while ordinary
    // world roots remain outside the explorer's regional scope choices.
    const rootIsRegion = !!RegionProviderRegistry.findForScene(game.scenes.get(rootSceneId));
    const excludedRoot = rootIsRegion ? null : globalRoot;
    const sites = new Map();
    for (const row of visibleRows) {
        const node = byId.get(targetByKey.get(row.key));
        node.parentId = targetByKey.get(row.parentNodeId) || "";
        node.isRegion = !!RegionProviderRegistry.findForScene(game.scenes.get(row.primarySceneId || row.sceneId));
        if (row.key === excludedRoot) continue;
        // Reconstruct every ancestor from visible authoritative parents. Hidden parents
        // cannot reappear through a breadcrumb or a derived scope name.
        const ancestors = [], seen = new Set([row.key]);
        let parent = rowByKey.get(row.parentNodeId);
        while (parent && parent.key !== excludedRoot && !seen.has(parent.key)) {
            seen.add(parent.key);
            ancestors.unshift(targetByKey.get(parent.key));
            parent = rowByKey.get(parent.parentNodeId);
        }
        node.scopeIds = [...ancestors, node.id];
        node.siteIds = [node.id];
        sites.set(node.id, { id: node.id, label: node.name, parentId: ancestors.at(-1) || "", rootId: ancestors[0] || node.id, ancestorIds: ancestors });
    }
    const aliases = PlaceTypeRegistry.getProjectionAliases(placeNodes);
    for (const node of byId.values()) if (node.kind === "nexus-scene") {
        const key = aliases.get(`scene:${node.sceneId}`), aliasId = targetByKey.get(key);
        if (aliasId && aliasId !== node.id) {
            node.placeId = aliasId; node.parentId = byId.get(aliasId).parentId;
            node.scopeIds = [...byId.get(aliasId).scopeIds];
            node.siteIds = [aliasId];
            node.isRegion = byId.get(aliasId).isRegion;
        }
    }
    const edges = [], opinionEdges = new Map(), opinionCache = new Map();
    for (const edge of Object.values(graph.edges || {})) {
        if (!byId.has(edge.sourceNodeId) || !byId.has(edge.targetNodeId) || !ConnectionStore.canUserSeeConnection(edge)) continue;
        const source = ConnectionStore.getConnectionView(edge, edge.sourceNodeId), target = ConnectionStore.getConnectionView(edge, edge.targetNodeId);
        if (![ [edge.sourceNodeId,source], [edge.targetNodeId,target] ].every(([id,view]) => ConnectionStore.canUserSeeCategoryGroup(id, view.category, game.user))) continue;
        const projected = explorerEdge(edge, source, target);
        projected.visibilityByNode = Object.fromEntries([[edge.sourceNodeId, target], [edge.targetNodeId, source]].map(([id, view]) => [id, connectionVisibility(byId.get(id), edge, { ownerNodeId: id === edge.sourceNodeId ? edge.targetNodeId : edge.sourceNodeId, categoryId: view.category })]));
        // Scene presence is stored as reciprocal endpoint views; geographic attribution alone is not presence.
        if (!projected.placement) for (const [subjectId,placeId] of [[projected.source,projected.target],[projected.target,projected.source]]) {
            if (["place","location"].includes(byId.get(placeId).type) && projected.roles[subjectId] === "Located At" && projected.roles[placeId] === "Present") projected.placement = { nodeId: subjectId, placeId };
        }
        if (edge.opinions) opinionEdges.set(edge.id,edge);
        if (edge.relationType === "ship-crew") {
            const ship = [byId.get(projected.source), byId.get(projected.target)].find(node => node.type === "ship");
            const person = [byId.get(projected.source), byId.get(projected.target)].find(node => node.type === "npc");
            if (ship && person) Object.assign(projected, { source: person.id, target: ship.id, label: "Crew of", directed: true, perspectiveLabels: { [person.id]: "Crew of", [ship.id]: "Crew" },
                containment: { container: ship.id, node: person.id, section: "People", label: "Crew", priority: 1 } });
        }
        edges.push(projected);
    }
    // Physical attribution comes only from direct place relationships. Personal
    // relationships and shared affiliations never spread a site to another person.
    const placeTypes = new Set(["place", "location"]);
    for (const edge of edges) for (const [a,b] of [[edge.source,edge.target],[edge.target,edge.source]]) {
        const node = byId.get(a), other = byId.get(b);
        if (!placeTypes.has(node.type) && placeTypes.has(other.type)) {
            node.scopeIds.push(...other.scopeIds);
            node.siteIds.push(other.placeId || other.id);
        }
    }
    // Organizations can be relevant through their local members, but that does
    // not attribute their other members or holdings to those members' sites.
    for (const edge of edges) if (edge.containment?.section === "People") {
        const organization = byId.get(edge.containment.container), member = byId.get(edge.containment.node);
        if (organization?.type === "faction" && member?.type === "npc") organization.scopeIds.push(...member.scopeIds);
    }
    for (const node of byId.values()) {
        node.scopeIds = [...new Set(node.scopeIds)];
        node.siteIds = [...new Set(node.siteIds)];
    }
    const orderedSites = [...sites.values()].sort((a,b) => a.label.localeCompare(b.label));
    // Opinion influences can be expensive. Only visible focused neighbors request a perspective.
    const getOpinionScore = (edgeId,observerId) => {
        const edge = opinionEdges.get(edgeId);
        if (!edge || ![edge.sourceNodeId,edge.targetNodeId].includes(observerId)) return null;
        const key = JSON.stringify([edgeId,observerId]);
        if (!opinionCache.has(key)) {
            const score = ConnectionOpinionService.resolvePerspective(edge,observerId)?.score;
            opinionCache.set(key,Number.isFinite(score)?score:null);
        }
        return opinionCache.get(key);
    };
    return { nodes: [...byId.values()], edges, sites: orderedSites, scopes: orderedSites.filter(site => !site.parentId), independentLabel: game.user.isGM ? "Independent" : "Other settlements", getOpinionScore };
}
