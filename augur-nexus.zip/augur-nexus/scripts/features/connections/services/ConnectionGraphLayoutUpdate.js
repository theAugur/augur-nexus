/** Tagged mixed updates still refresh normal dossier content. */
export function isConnectionGraphLayoutUpdate(changes, options) {
    if (options?.augurNexusGraphLayout !== true) return false;
    const onlyLayouts = (value, path = []) => {
        const key = path.join(".");
        if (key === "flags.augur-nexus.connectionGraphLayouts" || /^flags\.augur-nexus\.sites\.records\.[\w-]+\.graphLayouts$/.test(key)) return true;
        if (!value || typeof value !== "object" || Array.isArray(value)) return false;
        const entries = Object.entries(value).filter(([key]) => path.length || key !== "_id");
        return entries.length > 0 && entries.every(([key, value]) => onlyLayouts(value, [...path, ...key.split(".").map(part => part.replace(/^==/, ""))]));
    };
    return onlyLayouts(changes);
}
