import { openActionMenu } from "../../../api/ui.js";
import { CampaignEntityIndex } from "../../campaign-entities/services/CampaignEntityIndex.js";
import { CampaignEntityVisibilityManager } from "../../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { CampaignEntityDisclosureManager } from "../../campaign-entities/services/CampaignEntityDisclosureManager.js";
import { SiteRecordManager } from "../../site/services/SiteRecordManager.js";
import { SitePlayerVisibility } from "../../site/services/SitePlayerVisibility.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";
import { ConnectionStore } from "./ConnectionStore.js";
import { PlayerConnectionVisibilityDialog } from "../../nexus/applications/PlayerConnectionVisibilityDialog.js";
import { PlayerNpcVisibilityDialog } from "../../nexus/applications/PlayerNpcVisibilityDialog.js";
import { openHelp } from "../../../api/help.js";

const entityGetters = { npc: "getNpc", faction: "getFaction", location: "getLocation", ship: "getShip" };
const labels = { npc: "NPC", faction: "Organization", location: "Location", ship: "Ship" };

// These are general player-policy indicators; individual player-character access remains separate.
export function objectVisibility(node) {
    if (!node) return null;
    if (node.kind === "nexus-entity" && entityGetters[node.entityType]) {
        const entity = CampaignEntityIndex[entityGetters[node.entityType]](node.entityId);
        return entity ? { label: labels[entity.type], type: entity.type, value: CampaignEntityVisibilityManager.getPlayerVisibilityOverride(entity),
            visible: CampaignEntityVisibilityManager.isVisibleToPlayers(entity),
            detailsHidden: entity.type === "location" && !CampaignEntityDisclosureManager.canUserViewDetails(entity, { isGM: false }),
            set: value => CampaignEntityVisibilityManager.setPlayerVisibilityOverride(entity.id, entity.type, value) } : null;
    }
    if (node.kind === "nexus-scene") {
        const scene = game.scenes.get(node.sceneId);
        return scene ? { label: "Location", value: NexusPlayerSceneAccess.getSceneNexusVisibilityOverride(scene),
            visible: NexusPlayerSceneAccess.canUserSeeSceneInNexus(scene, { isGM: false }),
            set: value => NexusPlayerSceneAccess.setSceneNexusVisibilityOverride(scene, value) } : null;
    }
    if (node.kind === "nexus-site") {
        const scene = game.scenes.get(node.parentSceneId);
        const record = scene && SiteRecordManager.resolveSite({ parentScene: scene, siteId: node.siteId });
        const options = { scene, siteId: node.siteId, record };
        return record ? { label: "Location", value: SitePlayerVisibility.getOverride(options),
            visible: SitePlayerVisibility.isVisible(options),
            set: async value => {
                // Keep marker and placement workflows out of read-only dossier imports.
                const { SiteSceneVisibilityManager } = await import("../../site/services/SiteSceneVisibilityManager.js");
                return SiteSceneVisibilityManager.setSitePlayerVisibilityOverride({ parentScene: scene, siteId: node.siteId, value });
            } } : null;
    }
    return null;
}

export function connectionVisibility(node, edge = null, { ownerNodeId = "", categoryId = "" } = {}) {
    if (!game.user.isGM) return {};
    const object = objectVisibility(node);
    const objectHidden = object?.visible === false;
    const detailsHidden = object?.detailsHidden === true;
    const connectionHidden = !!edge && !ConnectionStore.isConnectionVisibleToPlayers(edge);
    const categoryHidden = !!ownerNodeId && !!categoryId && ConnectionStore.isCategoryGroupHiddenForNode(ownerNodeId, categoryId);
    const reasons = [objectHidden && "Object hidden from players", detailsHidden && "Object details hidden from players", connectionHidden && "Connection hidden from players", categoryHidden && "Connection category hidden from players"].filter(Boolean);
    return { isPlayerHidden: reasons.length > 0, visibilityTitle: reasons.join("; "), objectHidden, detailsHidden, connectionHidden, categoryHidden };
}

function openOptions(anchor, current, set, onChanged, type = "connection") {
    if (!game.user.isGM) return;
    return openActionMenu({ anchor, className: "connections-card-actions-menu", items: [
        ...[["inherit", "Global", "fas fa-layer-group"], ["show", "Yes", "fas fa-eye"], ["hide", "No", "fas fa-eye-slash"]]
            .map(([id, label, icon]) => ({ id, label: `${label}${current === id ? " (Current)" : ""}`, icon,
                onSelect: async () => { if (!game.user.isGM) return; await set(id); await onChanged?.(); } })),
        ...(["connection", "npc", "faction", "location", "ship"].includes(type) ? [{ id: "change-global", label: "Change Global Setting...", icon: "fas fa-sliders",
            onSelect: () => { if (game.user.isGM) return type === "connection" ? PlayerConnectionVisibilityDialog.show() : PlayerNpcVisibilityDialog.show(type); } }] : []),
        { id: "player-visibility-info", label: "What's this?", icon: "fas fa-circle-info",
            onSelect: () => openHelp(type === "connection" ? "augur-nexus:connection-visibility" : type === "place" ? "augur-nexus:site-visibility" : "augur-nexus:object-visibility") }
    ] });
}

export function connectedVisibilityItems({ node, edge, anchor, onChanged } = {}) {
    if (!game.user.isGM) return [];
    const object = objectVisibility(node);
    const valueLabel = value => value === "show" ? "Yes" : value === "hide" ? "No" : "Global";
    return [
        ...(object ? [{ id: "object-player-visibility", label: `${object.label} visible to players: ${valueLabel(object.value)}`,
            description: "Affects this object everywhere", icon: object.visible ? "fas fa-eye" : "fas fa-eye-slash",
            onSelect: () => { const current = objectVisibility(node); if (current) return openOptions(anchor, current.value, current.set, onChanged, current.type || "place"); } }] : []),
        ...(edge ? [{ id: "connection-player-visibility", label: `Connection visible to players: ${ConnectionStore.getConnectionPlayerVisibilityLabel(edge)}`,
            description: "Affects only this relationship", icon: "fas fa-link", iconBadge: ConnectionStore.isConnectionVisibleToPlayers(edge) ? "fas fa-eye" : "fas fa-eye-slash",
            onSelect: () => { const current = ConnectionStore.getConnectionEdge(edge.id); if (current) return openOptions(anchor, ConnectionStore.getConnectionPlayerVisibility(current), value => ConnectionStore.setConnectionPlayerVisibility(current.id, value), onChanged); } }] : [])
    ];
}

export function composeConnectedObjectMenu({ node, edge, anchor, onChanged, navigation = [], items = [] } = {}) {
    const visibility = connectedVisibilityItems({ node, edge, anchor, onChanged });
    const remaining = items.filter(item => !["player-visibility", "object-player-visibility", "connection-player-visibility"].includes(item.id));
    return [...visibility, ...(visibility.length && (navigation.length || remaining.length) ? [{ type: "separator" }] : []),
        ...navigation, ...(navigation.length && remaining.length ? [{ type: "separator" }] : []), ...remaining];
}
