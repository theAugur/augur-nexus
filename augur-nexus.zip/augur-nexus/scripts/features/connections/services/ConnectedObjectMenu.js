import { connectedObjectPlacementItems } from "./ConnectedObjectPlacements.js";
import { ShopStore } from "../../shops/services/ShopStore.js";
import { connectedObjectAssignmentItems } from "./ConnectedObjectAssignments.js";
import { openActionMenu } from "../../../api/ui.js";
import { ConnectionStore } from "./ConnectionStore.js";
import { ConnectionTargetResolver } from "./ConnectionTargetResolver.js";
import { ConnectionEditingWorkflow } from "./ConnectionEditingWorkflow.js";
import { composeConnectedObjectMenu } from "./ConnectedObjectVisibility.js";

export const connectedObjectSources = "[data-npc-life-node], [data-faction-domain-node], [data-ship-domain-node], [data-workspace-connection], [data-connection-node-id], [data-authority-entity-id], [data-settlement-person-card], [data-organization-id], [data-quest-id], [data-action='openPlaceOwner'], [data-card-kind], [data-action='openChronicleParticipant'], .content-link[data-uuid]";

export function connectedObjectNode(card) {
    const data = card.dataset;
    if (card.matches(".content-link[data-uuid]")) {
        try {
            const document = foundry.utils.fromUuidSync(data.uuid);
            if (!document || (!game.user.isGM && document.testUserPermission && !document.testUserPermission(game.user, "OBSERVER"))) return null;
            return ConnectionTargetResolver.fromDocument(document);
        } catch { return null; }
    }
    if (data.cardKind === "shop") return ConnectionTargetResolver.fromDocument(ShopStore.resolveDocument(data.cardId));
    if (data.cardKind === "site" && data.siteId) return ConnectionTargetResolver.fromSiteReference({ parentSceneId: data.parentSceneId, siteId: data.siteId });
    if (data.cardKind === "location") return ConnectionTargetResolver.fromEntityReference({ entityId: data.cardId });
    const nodeId = data.npcLifeNode || data.factionDomainNode || data.shipDomainNode || data.workspaceConnection || data.connectionNodeId;
    const entityId = data.authorityEntityId || data.personId || data.organizationId || data.questId || (data.action === "openChronicleParticipant" ? data.entityId : "");
    return nodeId ? ConnectionStore.getNode(nodeId) : entityId ? ConnectionTargetResolver.fromEntityReference({ entityId }) : null;
}

// Relationship identity comes from the edge, never from a displayed name or inferred hierarchy.
export function connectedObjectEdge(card, owner, node) {
    if (card.closest("[data-navigation-only]") || card.dataset.action === "openChronicleParticipant" || card.matches(".content-link")) return null;
    const ownerId = ConnectionTargetResolver.getNodeId(owner);
    const explicit = card.dataset.edgeId || card.dataset.npcLifeEdge || card.dataset.connectionEdgeId
        || card.closest("[data-edge-id], [data-connection-edge-id]")?.dataset.edgeId
        || card.closest("[data-connection-edge-id]")?.dataset.connectionEdgeId || card.closest("[data-npc-life-edge]")?.dataset.npcLifeEdge;
    const edge = explicit ? ConnectionEditingWorkflow.belongsTo(explicit, ownerId)
        : ConnectionStore.getConnectionsForNode(ownerId).find(entry => entry.node.id === node?.id)?.edge;
    return edge && [edge.sourceNodeId, edge.targetNodeId].includes(node?.id) ? edge : null;
}

export function standaloneObjectNavigation(node) {
    return [{ id: "open-object", label: "Open Object", icon: "fas fa-up-right-from-square", onSelect: () => ConnectionTargetResolver.openNode(node) }];
}

export function openConnectedObjectMenu({ card, anchor = card, owner, navigation = standaloneObjectNavigation,
    node = connectedObjectNode(card), edge = connectedObjectEdge(card, owner, node), getItems, onChanged } = {}) {
    if (!node || !ConnectionTargetResolver.canUserSeeNode(node)) return;
    const items = edge ? (getItems?.({ card, owner, node, edge })
        ?? ConnectionEditingWorkflow.relationshipItems({ owner, node, edgeId: edge.id, onChanged })) : connectedObjectPlacementItems({ card, owner, onChanged });
    if (edge && items.length) items.unshift(...connectedObjectAssignmentItems({ card, owner, node, edge, onChanged }));
    const relationshipOwner = card.dataset.relationshipOwnerNode
        ? ConnectionStore.getNode(card.dataset.relationshipOwnerNode) : card.dataset.relationshipOwnerId
            ? ConnectionTargetResolver.fromEntityReference({ entityId: card.dataset.relationshipOwnerId }) : null;
    const relatedNavigation = relationshipOwner && ConnectionTargetResolver.canUserSeeNode(relationshipOwner)
        ? [{ id: "open-relationship-owner", label: "Open Organization with this Relationship", icon: "fas fa-sitemap", onSelect: () => navigation(relationshipOwner)[0]?.onSelect?.() }] : [];
    return openActionMenu({ anchor, className: "connections-card-actions-menu",
        items: composeConnectedObjectMenu({ node, edge, anchor, onChanged, navigation: [...navigation(node), ...relatedNavigation], items }) });
}

export function bindConnectedObjectMenus(root, { getOwner, navigation = standaloneObjectNavigation, resolveNode = connectedObjectNode,
    getItems, getEdge = connectedObjectEdge, onChanged, selector = connectedObjectSources, boundKey = "connectedObjectMenusBound" } = {}) {
    if (!root) return;
    let dragging = false, suppressUntil = 0;
    const sources = [...root.querySelectorAll(selector)].filter(card => !card.closest("[data-organization-member]")
        && !card.closest("[data-entity-disclosure-section]") && !card.matches("[data-connection-actions], [data-connection-opinion]"));
    for (const card of sources) {
        if (!resolveNode(card)) continue;
        card.setAttribute("aria-haspopup", "menu");
        let wrapper = card.closest(".connected-object-menu-wrapper, .faction-domain-connection-wrapper, .ship-domain-connection-wrapper, .faction-command-menu-wrapper, .ship-domain-command-wrapper, .faction-parent-menu-wrapper, .connection-card, .nexus-workspace-connection-card, .qv-entity-row, .npc-life-card, .npc-life-featured");
        if (wrapper && new Set([...wrapper.querySelectorAll(selector)].map(element => resolveNode(element)?.id).filter(Boolean)).size > 1) wrapper = null;
        if (!wrapper || !wrapper.contains(card)) {
            wrapper = document.createElement(card.matches(".content-link") ? "span" : "div");
            card.before(wrapper); wrapper.append(card);
        }
        wrapper.classList.add("connected-object-menu-wrapper");
        if (card.matches(".content-link")) wrapper.classList.add("connected-object-inline-reference");
        let dots = wrapper.querySelector(":scope > .faction-domain-hover-menu, :scope > .ship-domain-hover-menu, :scope > .faction-command-hover-menu, :scope > [data-connection-actions], :scope > [data-action='linkMenu'], :scope > [data-connected-object-menu]");
        if (!dots) { dots = document.createElement("button"); dots.type = "button"; dots.innerHTML = '<i class="fas fa-ellipsis"></i>'; wrapper.append(dots); }
        dots.dataset.connectedObjectMenu = "";
        dots.classList.add("connected-object-hover-menu");
        dots.setAttribute("aria-label", "Object and connection actions"); dots.setAttribute("aria-haspopup", "menu");
        dots.title = "Object and connection actions";
    }
    // ApplicationV2 retains the application root while replacing rendered parts.
    // Refresh card controls each render, but keep one set of delegated root listeners.
    if (root.dataset[boundKey]) return;
    root.dataset[boundKey] = "true";
    root.addEventListener("dragstart", event => { if (event.target.closest(selector)) dragging = true; }, true);
    root.addEventListener("dragend", () => { if (dragging) suppressUntil = Date.now() + 250; dragging = false; }, true);
    const open = event => {
        const dots = event.target.closest("[data-connected-object-menu]");
        const card = dots ? (dots.parentElement.matches(selector) ? dots.parentElement : dots.parentElement.querySelector(selector))
            : event.target.closest(selector) || event.target.closest(".connected-object-menu-wrapper")?.querySelector(selector);
        if (!card || !root.contains(card) || card.closest("[data-organization-member]")) return;
        if (event.type === "click" && !dots) {
            if (dragging || Date.now() < suppressUntil) { event.preventDefault(); event.stopImmediatePropagation(); }
            return;
        }
        if (event.target.closest("[data-connection-opinion], .connection-card-opinion, input, textarea, select, [contenteditable='true']")) return;
        const node = resolveNode(card);
        if (!node || !ConnectionTargetResolver.canUserSeeNode(node)) return;
        event.preventDefault(); event.stopImmediatePropagation();
        if (dragging || Date.now() < suppressUntil) return;
        const owner = getOwner();
        const edge = getEdge(card, owner, node);
        openConnectedObjectMenu({ card, anchor: dots || card, owner, node, edge, navigation, getItems, onChanged });
    };
    root.addEventListener("click", open, true);
    root.addEventListener("contextmenu", open, true);
    root.addEventListener("keydown", event => {
        if (event.key === "ContextMenu" || (event.shiftKey && event.key === "F10")) open(event);
    }, true);
}
