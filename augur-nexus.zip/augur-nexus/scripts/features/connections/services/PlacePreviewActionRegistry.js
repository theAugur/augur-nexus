/** Feature-owned GM actions for the shared Scene/Site preview, without content ownership. */
export class PlacePreviewActionRegistry {
    static #providers = new Map();
    static #running = new Set();

    static register({ id, moduleId, getActions } = {}) {
        if (!id || typeof getActions !== "function") throw new Error("Place preview actions require an id and getActions(context).");
        this.#providers.set(id, { id, moduleId, getActions });
        return () => this.#providers.delete(id);
    }
    static #actions(provider, context) {
        if (!game.user?.isGM || (provider.moduleId && !game.modules.get(provider.moduleId)?.active)) return [];
        try { return (provider.getActions(context) || []).filter(action => action?.id && typeof action.onSelect === "function"); }
        catch (error) { console.warn(`Augur: Nexus | Place actions ${provider.id} failed.`, error); return []; }
    }
    static list(context) {
        return [...this.#providers.values()].flatMap(provider => this.#actions(provider, context).map(action => ({
            providerId: provider.id, id: action.id, label: action.label || action.id, icon: action.icon || "fas fa-arrow-up-right-from-square"
        })));
    }
    static async run(providerId, actionId, context) {
        const provider = this.#providers.get(providerId);
        const key = `${providerId}:${actionId}:${context.target?.id || context.scene?.id || context.record?.siteId || ""}`;
        if (!provider || this.#running.has(key)) return null;
        const action = this.#actions(provider, context).find(candidate => candidate.id === actionId);
        if (!action) return null;
        this.#running.add(key);
        try { return await action.onSelect(); }
        finally { this.#running.delete(key); }
    }
}
