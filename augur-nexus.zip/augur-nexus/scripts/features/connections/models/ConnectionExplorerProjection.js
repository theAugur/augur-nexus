const sortName = (a, b) => String(a.name || "").localeCompare(String(b.name || "")) || a.id.localeCompare(b.id);
const leftOrder = type => type === "faction" ? 0 : ["place","location"].includes(type) ? 1 : type === "ship" ? 2 : 3;
const typeLabel = type => ({npc:"People", faction:"Organizations", place:"Places", location:"Places", ship:"Ships"}[type] || "Other connections");

const genericRole = role => /^(?:connected to(?: .+)?|connection|connected|related|person|contact|organization|linked place|ship|item|service|unassigned)$/i.test(role);
// These classifications can describe the connection from either endpoint; directional verbs cannot.
const sharedClassification = role => /^(?:notable person|affiliation|friend|ally|rival|enemy|associate|partner)$/i.test(role);
export function explorerRelationshipLabel(edge,focusId){
    if(edge.perspectiveLabels?.[focusId])return edge.perspectiveLabels[focusId];
    const own=String(edge.roles?.[focusId]||edge.label||"Connection").trim();
    const otherId=edge.source===focusId?edge.target:edge.source,reverse=String(edge.roles?.[otherId]||"").trim();
    return genericRole(own)&&sharedClassification(reverse)?reverse:own;
}
export const explorerLabelWidth = label => Math.min(270,String(label).length*6+18);

// Dropdowns use screen-space clearance, while their dimensions live in the scaled graph.
export function placeExplorerDropdown(card,viewport,{zoom=1,contentHeight=365,maxHeight=365,padding=8}={}){
    const desired=Math.min(contentHeight,maxHeight),below=Math.max(0,viewport.bottom-padding-card.bottom),above=Math.max(0,card.top-viewport.top-padding);
    const opensAbove=below<desired*zoom&&above>below;
    const viewportHeight=Math.max(0,viewport.height-padding*2)/zoom;
    let height=Math.min(desired,(opensAbove?above:below)/zoom,viewportHeight),top=opensAbove?-height:card.height/zoom;
    if(height*zoom<48){
        height=Math.min(desired,viewportHeight);
        top=(viewport.top+padding-card.top)/zoom;
    }
    // Panning may move the header partly outside the stage while its list is open.
    top=(Math.max(viewport.top+padding,Math.min(card.top+top*zoom,viewport.bottom-padding-height*zoom))-card.top)/zoom;
    return {top,maxHeight:height,placement:opensAbove?"above":"below"};
}

// A boundary belongs to the graph session; changing focus never changes its geography.
export function projectConnectionExplorer(data, state = {}) {
    const nodes=data.nodes||[], byId=new Map(nodes.map(node=>[node.id,node]));
    const boundaryId=state.boundaryId||"", sites=data.sites||[];
    const siteIds=new Set(sites.filter(site=>site.id===boundaryId||site.ancestorIds?.includes(boundaryId)).map(site=>site.id));
    if(boundaryId&&byId.has(boundaryId))siteIds.add(boundaryId);
    const belongs=node=>!boundaryId||siteIds.has(node.placeId||node.id)||(node.scopeIds||[]).some(id=>siteIds.has(id))||(node.siteIds||[]).some(id=>siteIds.has(id));
    const allowedIds=new Set(nodes.filter(belongs).map(node=>node.id));
    const allEdges=(data.edges||[]).filter(edge=>byId.has(edge.source)&&byId.has(edge.target));
    const focusedNode=byId.get(state.focusId),isPlace=node=>["place","location"].includes(node?.type);
    if(boundaryId&&!byId.get(boundaryId)?.isRegion&&isPlace(focusedNode)&&!focusedNode.isRegion){
        // Explicit place links belong on a place graph even across geography. Use the
        // original boundary once, so following a linked place cannot spread its scope.
        const geographicIds=new Set(allowedIds);
        for(const edge of allEdges){
            if(edge.derived||!isPlace(byId.get(edge.source))||!isPlace(byId.get(edge.target)))continue;
            if(geographicIds.has(edge.source))allowedIds.add(edge.target);
            if(geographicIds.has(edge.target))allowedIds.add(edge.source);
        }
    }
    const pairKey=(a,b)=>JSON.stringify([a,b].sort()),realPairs=new Set(allEdges.map(edge=>pairKey(edge.source,edge.target)));
    const hasPair=(a,b)=>realPairs.has(pairKey(a,b));
    // Parent references explain child sites only when a real connection does not already do so.
    for(const site of sites)if(site.parentId&&byId.has(site.parentId)&&byId.has(site.id)&&!hasPair(site.parentId,site.id))allEdges.push({id:`parent:${site.parentId}:${site.id}`,source:site.parentId,target:site.id,label:"Contains",directed:true,nodeIds:[site.parentId,site.id]});
    const focusedSite=sites.find(site=>site.id===state.focusId);
    const adjacency=new Map(),externalConnections=new Map();
    for(const edge of allEdges){
        const a=allowedIds.has(edge.source),b=allowedIds.has(edge.target);
        if(a&&b)for(const id of [edge.source,edge.target]){if(!adjacency.has(id))adjacency.set(id,[]);adjacency.get(id).push(edge);}
        else if(a!==b){const id=a?edge.source:edge.target;if(!externalConnections.has(id))externalConnections.set(id,[]);externalConnections.get(id).push({edge,node:byId.get(a?edge.target:edge.source)});}
    }
    const groups=[],edges=[],visibleIds=new Set(),focusId=state.focusId||"";
    const result=()=>({groups,edges,byId,adjacency,externalConnections,allowedIds,focusId,boundaryId,count:visibleIds.size});
    const anchor=byId.get(focusId);
    if(!anchor||!allowedIds.has(focusId))return result();
    const group=(node,extra={})=>{const g={id:node.id,node,name:node.name,img:node.img,type:node.type,sections:[],nodeIds:[node.id],count:0,...extra};groups.push(g);if(!g.virtual)visibleIds.add(node.id);return g;};
    if(anchor.isRegion){
        const regionId=anchor.placeId||anchor.id;
        const localSiteIds=new Set(sites.filter(site=>site.id===regionId||site.ancestorIds?.includes(regionId)).map(site=>site.id));
        const owners=new Map(),seats=new Map();
        for(const edge of data.edges||[]){
            if(edge.relationType==="ownership"&&byId.get(edge.source)?.type==="faction"&&allowedIds.has(edge.source))owners.set(byId.get(edge.target)?.placeId||edge.target,edge.source);
            if(edge.seat&&byId.get(edge.seat.factionId)?.type==="faction"&&allowedIds.has(edge.seat.factionId)){
                const placeId=byId.get(edge.seat.placeId)?.placeId||edge.seat.placeId;
                if(!seats.has(placeId))seats.set(placeId,new Set());seats.get(placeId).add(edge.seat.factionId);
            }
        }
        // Geography and explicit domain relationships bound these lists. A ruler's
        // membership or a generic role cannot give their faction territorial control.
        const places=nodes.filter(node=>allowedIds.has(node.id)&&localSiteIds.has(node.placeId||node.id)&&node.id!==regionId&&!node.placeId&&(node.type==="location"||node.isSettlement||owners.has(node.id)||seats.has(node.id)));
        const buckets=new Map(),query=(state.search||"").trim().toLocaleLowerCase(),independentLabel=data.independentLabel||"Independent";
        for(const place of places){
            const factionIds=new Set([owners.get(place.id),...seats.get(place.id)||[]].filter(Boolean));
            for(const ownerId of factionIds.size?factionIds:[null]){
                const owner=byId.get(ownerId),isSeat=!!seats.get(place.id)?.has(ownerId),owned=owners.get(place.id)===ownerId;
                if(query&&![place.name,owner?.name||independentLabel].some(name=>name.toLocaleLowerCase().includes(query)))continue;
                const id=owner?.id||`independent:${regionId}`;
                if(!buckets.has(id))buckets.set(id,{owner,rows:[]});
                const category=place.placeCategory||(place.isSettlement?"settlement":"holding"),description=place.subtitle||(category==="settlement"?"Settlement":category==="resource"?"Resource":"Place");
                buckets.get(id).rows.push({...place,placeCategory:category,isSeat,owned,relation:isSeat?`Seat of power · ${description}`:description});
            }
        }
        for(const [id,{owner,rows}]of [...buckets].sort((a,b)=>Number(!a[1].owner)-Number(!b[1].owner)||sortName(a[1].owner||{id:a[0],name:"Independent"},b[1].owner||{id:b[0],name:"Independent"}))){
            const g=group(owner||{id,name:independentLabel,type:"group",img:"",subtitle:"No visible faction owner"},{virtual:!owner,regional:true});
            const rank={settlement:0,holding:1,resource:2};
            rows.sort((a,b)=>Number(b.isSeat)-Number(a.isSeat)||(rank[a.placeCategory]??1)-(rank[b.placeCategory]??1)||(b.importance||0)-(a.importance||0)||sortName(a,b));
            g.sections=[{label:"Places",rows}];g.nodeIds.push(...rows.map(node=>node.id));g.count=rows.length;
            g.countSummary=[...["settlement","holding","resource"].map(category=>{const count=rows.filter(row=>row.placeCategory===category).length;return count?`${count} ${category}${count===1?"":"s"}`:"";})].filter(Boolean).join(" · ");
            for(const node of rows)visibleIds.add(node.id);
        }
        const factionIds=new Set(groups.filter(g=>g.type==="faction").map(g=>g.id));
        for(const edge of data.edges||[])if(factionIds.has(edge.source)&&factionIds.has(edge.target)&&!edge.derived){
            const label=explorerRelationshipLabel(edge,edge.source);
            edges.push({...edge,label,labelWidth:explorerLabelWidth(label),nodeIds:[edge.source,edge.target],edgeIds:[edge.id]});
        }
        return result();
    }
    group(anchor,{anchor:true});
    const siteGraph=!!focusedSite;
    const factionBadges=new Map();
    if(siteGraph)for(const edge of allEdges){
        const factionId=edge.membership?.factionId||edge.ownership?.ownerId;
        const nodeId=edge.membership?.nodeId||edge.ownership?.nodeId;
        const faction=byId.get(factionId);
        if(faction?.type!=="faction"||!nodeId)continue;
        if(!factionBadges.has(nodeId))factionBadges.set(nodeId,new Map());
        factionBadges.get(nodeId).set(factionId,{id:faction.id,name:faction.name,img:faction.img});
    }
    const direct=adjacency.get(focusId)||[],query=(state.search||"").trim().toLocaleLowerCase(),details=new Map();
    for(const edge of direct){
        const id=edge.source===focusId?edge.target:edge.source;
        if(!details.has(id))details.set(id,{edges:[],score:null,opinionEdgeId:""});
        const detail=details.get(id);detail.edges.push(edge);
        const score=["npc","faction"].includes(anchor.type)&&["npc","faction"].includes(byId.get(id).type)?(edge.opinionScores?.[focusId]??data.getOpinionScore?.(edge.id,focusId)):null;if(Number.isFinite(score)&&detail.score===null){detail.score=score;detail.opinionEdgeId=edge.id;}
    }
    const neighbors=[...details].map(([id,detail])=>{
        const node=byId.get(id),place=["place","location"].includes(node.type);
        const presence=place&&["npc","ship"].includes(anchor.type)&&detail.edges.some(edge=>edge.placement?.nodeId===focusId&&edge.placement?.placeId===id);
        const seat=place&&anchor.type==="faction"&&detail.edges.some(edge=>edge.seat?.factionId===focusId&&edge.seat?.placeId===id);
        const parent=place&&["place","location"].includes(anchor.type)&&anchor.parentId===id;
        const factionParent=anchor.type==="faction"&&node.type==="faction"&&detail.edges.some(edge=>edge.hierarchy?.parentId===id&&edge.hierarchy?.childId===focusId);
        const owner=siteGraph&&detail.edges.some(edge=>edge.relationType==="ownership"&&edge.source===id&&edge.target===focusId);
        const zone=presence||seat||parent||owner||factionParent?"top":node.type==="npc"?"right":"left";
        const ranked=[...detail.edges].sort((a,b)=>(a.placement?0:Object.keys(a.perspectiveLabels||{}).length?1:2)-(b.placement?0:Object.keys(b.perspectiveLabels||{}).length?1:2)||a.id.localeCompare(b.id));
        const relationships=[...new Set(ranked.map(edge=>explorerRelationshipLabel(edge,focusId)))];
        const relation=relationships[0]+(relationships.length>1?` +${relationships.length-1}`:"");
        const visibility = ranked.map(edge => edge.visibilityByNode?.[id]).filter(Boolean);
        const hidden = node.isPlayerHidden || (visibility.length > 0 && visibility.every(view => view.isPlayerHidden));
        return {...node,isPlayerHidden:hidden,visibilityTitle:node.visibilityTitle || (hidden ? [...new Set(visibility.map(view => view.visibilityTitle).filter(Boolean))].join("; ") : ""),relation:owner?"Owned by":relation,relationships,isSeat:seat,isPlaceOwner:owner,factionBadges:[...factionBadges.get(id)?.values()||[]].sort(sortName),opinionScore:detail.score,opinionEdgeId:detail.opinionEdgeId,zone,zoneLabel:owner?"Owned by":presence?"Located at":seat?"Seat of power":parent?"Parent place":""};
    }).filter(node=>!query||node.name.toLocaleLowerCase().includes(query));
    const compare=(a,b)=>{
        if(a.type!==b.type)return String(a.type).localeCompare(String(b.type));
        if(a.type===b.type&&["npc","faction"].includes(a.type)){
            const aKnown=Number.isFinite(a.opinionScore),bKnown=Number.isFinite(b.opinionScore);
            if(aKnown!==bKnown)return aKnown?-1:1;
            if(aKnown&&a.opinionScore!==b.opinionScore)return b.opinionScore-a.opinionScore;
        }
        return sortName(a,b);
    };
    neighbors.sort(compare);
    const representatives=new Map([[focusId,focusId]]);
    // Faction relationships stay readable; only their places share a compact list.
    const individual=node=>anchor.type==="faction"&&["place","location"].includes(node.type)?false
        :node.isPlaceOwner||anchor.type==="npc"||neighbors.length<=10||(anchor.type==="faction"&&["npc","faction"].includes(node.type));
    for(const node of neighbors.filter(individual)){group(node,{leaf:true,zone:node.zone,relation:node.relation,order:leftOrder(node.type)});representatives.set(node.id,node.id);}
    const bundled=neighbors.filter(node=>!individual(node));
    if(bundled.length){
        const buckets=new Map();
        for(const node of bundled){const factionPlaces=anchor.type==="faction"&&["place","location"].includes(node.type),label=factionPlaces?"Places":node.zoneLabel||typeLabel(node.type),zone=factionPlaces?"bottom":node.zone,key=`${zone}:${label}`;if(!buckets.has(key))buckets.set(key,{label,zone,rows:[],placesOverlay:factionPlaces});buckets.get(key).rows.push(node);}
        for(const {label,zone,rows,placesOverlay}of buckets.values()){
            if(placesOverlay)rows.sort((a,b)=>Number(b.isSeat)-Number(a.isSeat)||Number(!!b.isSettlement)-Number(!!a.isSettlement)||(b.importance||0)-(a.importance||0)||sortName(a,b));
            const g=group({id:`focus-group:${label}`,name:label,type:"group",img:""},{virtual:true,zone,placesOverlay,order:leftOrder(rows[0]?.type)});
            for(const node of rows){representatives.set(node.id,g.id);visibleIds.add(node.id);}
            g.sections=[{label,rows}];g.nodeIds.push(...rows.map(node=>node.id));g.count=rows.length;
        }
    }
    const pairs=new Map();
    for(const edge of direct){const source=representatives.get(edge.source),target=representatives.get(edge.target);if(!source||!target)continue;
        const key=[source,target].sort().join("|");let summary=pairs.get(key);
        if(!summary){summary={id:`between:${key}`,source,target,label:explorerRelationshipLabel(edge,focusId),directed:!!edge.directed,nodeIds:[],edgeIds:[]};pairs.set(key,summary);}
        summary.nodeIds.push(edge.source,edge.target);summary.edgeIds.push(edge.id);
        if(summary.edgeIds.length>1)summary.directed=false;
    }
    const neighborById=new Map(neighbors.map(node=>[node.id,node])),neighborOrder=new Map(neighbors.map((node,index)=>[node.id,index]));
    for(const summary of pairs.values()){
        const targets=[...new Set(summary.nodeIds.filter(id=>id!==focusId))].sort((a,b)=>neighborOrder.get(a)-neighborOrder.get(b));
        const labels=[...new Set(targets.map(id=>neighborById.get(id)?.relation).filter(Boolean))];
        summary.label=labels.length?labels[0]+(labels.length>1?` +${labels.length-1}`:""):summary.label;
        summary.labelWidth=explorerLabelWidth(summary.label);
    }
    edges.push(...pairs.values());
    const groupById=new Map(groups.map(group=>[group.id,group]));
    for(const edge of edges)for(const id of [edge.source,edge.target]){const g=groupById.get(id);g.labelWidth=Math.max(g.labelWidth||0,edge.labelWidth);}
    return result();
}
// Stable, bounded grid packing. No force simulation and no persisted world content.
export function layoutConnectionExplorer(groups, { width = 1000, height = 650, focusId = "", compact = false, positions = {} } = {}) {
    const result = new Map();
    if (focusId && groups.some(group => group.id === focusId) && groups.every(group=>group.anchor||group.zone)) {
        const anchor=groups.find(group=>group.id===focusId),others=groups.filter(group=>group!==anchor),cardWidth=Math.max(220,...groups.map(group=>group.width||320));
        const gap=Math.max(90,...others.filter(group=>group.zone!=="top").map(group=>(group.labelWidth||100)*1.6+48)),verticalGap=45,topGap=90;
        const measure=group=>group.height||90,columns=[others.filter(group=>group.zone==="left"),others.filter(group=>group.zone==="right")];
        for(const column of columns)column.sort((a,b)=>(a.order||0)-(b.order||0));
        const tops=others.filter(group=>group.zone==="top"),topHeight=Math.max(0,...tops.map(measure)),lowerY=tops.length?topHeight+topGap:20;
        const columnHeight=column=>column.reduce((sum,group)=>sum+measure(group),0)+Math.max(0,column.length-1)*verticalGap;
        const lowerHeight=Math.max(measure(anchor),...columns.map(columnHeight)),centerX=cardWidth+gap;
        result.set(anchor.id,{x:centerX+(cardWidth-(anchor.width||cardWidth))/2,y:lowerY+(lowerHeight-measure(anchor))/2,w:anchor.width||cardWidth,h:measure(anchor)});
        const topWidth=tops.reduce((sum,group)=>sum+(group.width||cardWidth),0)+Math.max(0,tops.length-1)*verticalGap;
        let topX=centerX+cardWidth/2-topWidth/2;
        for(const group of tops){result.set(group.id,{x:topX,y:topHeight-measure(group),w:group.width||cardWidth,h:measure(group)});topX+=(group.width||cardWidth)+verticalGap;}
        columns.forEach((column,index)=>{let y=lowerY+(lowerHeight-columnHeight(column))/2;for(const group of column){result.set(group.id,{x:index?(cardWidth+gap)*2:0,y,w:group.width||cardWidth,h:measure(group)});y+=measure(group)+verticalGap;}});
        const bottoms=others.filter(group=>group.zone==="bottom"),bottomWidth=bottoms.reduce((sum,group)=>sum+(group.width||cardWidth),0)+Math.max(0,bottoms.length-1)*verticalGap;
        let bottomX=centerX+cardWidth/2-bottomWidth/2;
        const anchorPosition=result.get(anchor.id),bottomY=anchorPosition.y+anchorPosition.h+topGap;
        for(const group of bottoms){result.set(group.id,{x:bottomX,y:bottomY,w:group.width||cardWidth,h:measure(group)});bottomX+=(group.width||cardWidth)+verticalGap;}
    } else {
        const cardWidth = Math.max(220, ...groups.map(group => group.width || 320));
        const cardHeight = Math.max(80, ...groups.map(group => group.height || 200));
        const gapX = compact ? 115 : 150, gapY = compact ? 55 : 100;
        const aspect = Math.max(.7, width / Math.max(250, height));
        const columns = Math.max(1, Math.min(12, Math.ceil(Math.sqrt(groups.length * (cardHeight + gapY) / (cardWidth + gapX) * aspect))));
        const heights = Array(columns).fill(55);
        groups.forEach((group, index) => {
            const column = index % columns, x = 35 + column * (cardWidth + gapX), y = heights[column];
            result.set(group.id, { x, y, w: group.width || cardWidth, h: group.height || cardHeight });
            heights[column] += (group.height || cardHeight) + gapY;
        });
    }
    for (const [id, position] of Object.entries(positions || {})) {
        if (result.has(id) && Number.isFinite(position.x) && Number.isFinite(position.y)) Object.assign(result.get(id), { x: position.x, y: position.y });
    }
    return result;
}
export function explorerCurve(a,b,lane=0){
    const ac={x:a.x+a.w/2,y:a.y+a.h/2},bc={x:b.x+b.w/2,y:b.y+b.h/2};const dx=bc.x-ac.x,dy=bc.y-ac.y;
    let start,end,c1,c2;
    if(Math.abs(dx)>Math.abs(dy)*.75){start={x:dx>0?a.x+a.w:a.x,y:ac.y+lane*25};end={x:dx>0?b.x:b.x+b.w,y:bc.y+lane*25};const x=(start.x+end.x)/2;c1={x,y:start.y};c2={x,y:end.y};}
    else{start={x:ac.x+lane*25,y:dy>0?a.y+a.h:a.y};end={x:bc.x+lane*25,y:dy>0?b.y:b.y+b.h};const y=(start.y+end.y)/2;c1={x:start.x,y};c2={x:end.x,y};}
    const mid={x:(start.x+3*c1.x+3*c2.x+end.x)/8,y:(start.y+3*c1.y+3*c2.y+end.y)/8};
    const points=[.5,.35,.65,.2,.8].map(t=>{const u=1-t;return {x:u*u*u*start.x+3*u*u*t*c1.x+3*u*t*t*c2.x+t*t*t*end.x,y:u*u*u*start.y+3*u*u*t*c1.y+3*u*t*t*c2.y+t*t*t*end.y};});
    return {path:`M${start.x},${start.y} C${c1.x},${c1.y} ${c2.x},${c2.y} ${end.x},${end.y}`,x:mid.x,y:mid.y,points};
}


// Prefer the curve midpoint; nearby curve samples preserve the label's visual connection.
export function placeExplorerLabel(curve,cards,width,height=24){
    const candidates=curve.points||[{x:curve.x,y:curve.y}];
    const clear=({x,y})=>cards.every(card=>x+width/2+6<=card.x||x-width/2-6>=card.x+card.w||y+height/2+6<=card.y||y-height/2-6>=card.y+card.h);
    let point=candidates.find(clear);
    if(!point){
        const base=candidates[0];
        for(let distance=36;distance<=720&&!point;distance+=36)for(const offset of [{x:0,y:-distance},{x:0,y:distance},{x:-distance,y:0},{x:distance,y:0}]){const candidate={x:base.x+offset.x,y:base.y+offset.y};if(clear(candidate)){point=candidate;break;}}
    }
    point||=candidates[0];
    return {...point,bounds:{x:point.x-width/2,y:point.y-height/2,w:width,h:height}};
}
