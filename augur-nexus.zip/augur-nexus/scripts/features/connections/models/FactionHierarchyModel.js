export class FactionHierarchyModel {
    static canRepresent(parent, child) {
        return [parent, child].every(node => node?.kind === "nexus-entity" && node.entityType === "faction" && node.id)
            && parent.id !== child.id;
    }

    static normalize(value, { sourceNode, targetNode } = {}) {
        if (!value || !this.canRepresent(sourceNode, targetNode)) return null;
        const ids = new Set([sourceNode.id, targetNode.id]);
        if (!ids.has(value.parentNodeId) || !ids.has(value.childNodeId) || value.parentNodeId === value.childNodeId) return null;
        return { schemaVersion: 1, parentNodeId: value.parentNodeId, childNodeId: value.childNodeId };
    }

    static wouldCreateCycle(childId, parentId, entries) {
        const parents = new Map();
        for (const entry of entries) {
            if (!parents.has(entry.childNodeId)) parents.set(entry.childNodeId, []);
            parents.get(entry.childNodeId).push(entry.parentNodeId);
        }
        const pending = [parentId];
        const visited = new Set();
        while (pending.length) {
            const id = pending.pop();
            if (id === childId) return true;
            if (visited.has(id)) continue;
            visited.add(id);
            pending.push(...(parents.get(id) || []));
        }
        return false;
    }

    // A disposable forest keeps malformed imported graphs navigable without repairing saved data on read.
    static buildParentMap(entries) {
        const parents = new Map();
        for (const entry of [...entries].sort((a, b) => String(a.edgeId).localeCompare(String(b.edgeId)))) {
            if (parents.has(entry.childNodeId)) continue;
            let cursor = entry.parentNodeId;
            while (cursor && cursor !== entry.childNodeId) cursor = parents.get(cursor);
            if (cursor === entry.childNodeId) continue;
            parents.set(entry.childNodeId, entry.parentNodeId);
        }
        return parents;
    }

    static buildRows(rows, parents, { sceneEntityIds = null } = {}) {
        const byNode = new Map(rows.map(row => [row.nodeId, row]));
        const visibleParents = new Map([...parents].filter(([child, parent]) => byNode.has(child) && byNode.has(parent)));
        const included = new Set(rows.filter(row => !sceneEntityIds || sceneEntityIds.has(row.entityId)).map(row => row.nodeId));
        for (const id of [...included]) {
            let parent = visibleParents.get(id);
            const visited = new Set([id]);
            while (parent && !visited.has(parent)) {
                visited.add(parent);
                included.add(parent);
                parent = visibleParents.get(parent);
            }
        }
        const buckets = new Map();
        for (const row of rows) {
            if (!included.has(row.nodeId)) continue;
            const parent = visibleParents.get(row.nodeId) || "";
            if (!buckets.has(parent)) buckets.set(parent, []);
            buckets.get(parent).push(row);
        }
        for (const bucket of buckets.values()) bucket.sort((a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id));
        const result = [];
        const visited = new Set();
        const walk = (roots, depth = 0) => {
            const pending = [...roots].reverse().map(row => ({ row, depth, parentId: "" }));
            while (pending.length) {
                const { row, depth: level, parentId } = pending.pop();
                if (visited.has(row.nodeId)) continue;
                visited.add(row.nodeId);
                const children = buckets.get(row.nodeId) || [];
                result.push({ ...row, depth: level, hierarchyParentId: parentId,
                    hasChildren: children.length > 0, childCount: children.length,
                    isHierarchyContext: !!sceneEntityIds && !sceneEntityIds.has(row.entityId) });
                for (let i = children.length - 1; i >= 0; i--) pending.push({ row: children[i], depth: level + 1, parentId: row.id });
            }
        };
        walk(buckets.get("") || []);
        // Defensive fallback for callers presenting an invalid parent map.
        for (const row of rows) if (included.has(row.nodeId) && !visited.has(row.nodeId)) walk([row]);
        return result;
    }
}
