const SCHEMA_VERSION = 1;

export class ShipCaptainModel {
    static SCHEMA_VERSION = SCHEMA_VERSION;

    static create(shipNode, captainNode) {
        const endpoints = this.resolveEndpoints(shipNode, captainNode);
        if (!endpoints) return null;
        return {
            schemaVersion: SCHEMA_VERSION,
            shipNodeId: endpoints.shipNode.id,
            captainNodeId: endpoints.captainNode.id
        };
    }

    static normalize(value, { sourceNode = null, targetNode = null } = {}) {
        if (!value || typeof value !== "object" || Array.isArray(value)) return null;
        return this.create(sourceNode, targetNode);
    }

    static resolveEndpoints(leftNode = {}, rightNode = {}) {
        if (this.#isEntity(leftNode, "ship") && this.#isEntity(rightNode, "npc")) {
            return { shipNode: leftNode, captainNode: rightNode };
        }
        if (this.#isEntity(rightNode, "ship") && this.#isEntity(leftNode, "npc")) {
            return { shipNode: rightNode, captainNode: leftNode };
        }
        return null;
    }

    static isCaptain(edge = {}) {
        return !!edge?.shipCaptain || edge?.relationType === "ship-captain";
    }

    static #isEntity(node = {}, entityType = "") {
        return node?.kind === "nexus-entity" && node.entityType === entityType && !!node.id;
    }
}
