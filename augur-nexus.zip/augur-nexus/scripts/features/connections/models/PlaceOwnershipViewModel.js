import { connectionVisibility } from "../services/ConnectedObjectVisibility.js";
import { ConnectionStore } from "../services/ConnectionStore.js";
import { FactionSeatService } from "../services/FactionSeatService.js";
import { OwnershipService } from "../services/OwnershipService.js";

export class PlaceOwnershipViewModel {
    static build(target, options = {}) {
        const ownership = OwnershipService.getOwnership(target, options);
        if (!ownership) return { hasOwner: false };
        return {
            hasOwner: true,
            ...connectionVisibility(ConnectionStore.getNode(ownership.ownerNodeId), ConnectionStore.getConnectionEdge(ownership.edgeId)),
            edgeId: ownership.edgeId,
            ownerNodeId: ownership.ownerNodeId,
            name: ownership.owner.name,
            imageSrc: ownership.owner.imageSrc,
            subtitle: ownership.owner.subtitle || (ownership.owner.entityType === "faction" ? "Organization" : "Owner"),
            isFaction: ownership.owner.entityType === "faction",
            isSeat: FactionSeatService.isSeatEdge(ownership.edgeId)
        };
    }
}
