// Presentation only: category order, relationship identity and visibility remain owned by the board.
export function preparePlaceConnectionAtlas(board, resolveNode = () => null) {
    return { ...board, connectionAtlas: true,
        emptyLabel: board.canEdit
            ? "Drag a Person, Organization, Ship, Place, Item, or Journal here to create a connection."
            : "No connections are visible here yet.",
        groups: (board.groups || []).map(group => ({ ...group, cards: group.cards.map(card => {
            const node = resolveNode(card.nodeId) || {}, type = node.entityType || node.type;
            return { ...card,
                isPersonImage: type === "npc" || node.documentType === "Actor" || card.categoryId === "npc",
                isPlaceImage: type === "location" || ["nexus-scene", "nexus-site"].includes(node.kind) || card.categoryId === "place",
                isEmblemImage: type === "faction" || card.categoryId === "faction"
            };
        }) })) };
}
