import { projectConnectionExplorer, layoutConnectionExplorer, explorerCurve, explorerRelationshipLabel, explorerLabelWidth, placeExplorerLabel, placeExplorerDropdown } from "../models/ConnectionExplorerProjection.js";
import { openActionMenu, closeActionMenu, confirmDestructiveAction } from "../../../api/ui.js";
import { openHelp } from "../../../api/help.js";
const escape = value => String(value ?? "").replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const labels={npc:"Person",faction:"Organization",location:"Place",place:"Place",ship:"Ship",group:"Group"};
let nextId=0;

export class ConnectionExplorer {
    constructor({data={nodes:[],edges:[]},focusId="",boundaryId,onOpenBeside=null,onDisplayChange=null,state=null,onSelect=null,onOpen=null,onMenu=null,onStateChange=null,getConnectionActions=null,onOpinion=null,canDrop=null,onDrop=null,dropOwnerName="",layout=null,selectFocusOnOpen=true}={}) {
        this.layoutProvider=layout;this.selectFocusOnOpen=selectFocusOnOpen;
        this.dropOwnerName=dropOwnerName;this.data=data;this.onDisplayChange=onDisplayChange;this.homeFocus=focusId;this.onSelect=onSelect;this.onOpen=onOpen;this.onOpenBeside=onOpenBeside;this.onMenu=onMenu;this.onStateChange=onStateChange;this.getConnectionActions=getConnectionActions;this.onOpinion=onOpinion;this.canDrop=canDrop;this.onDrop=onDrop;
        const site=(data.sites||[]).find(site=>site.id===focusId||site.id===data.nodes.find(node=>node.id===focusId)?.placeId);
        this.boundaryId=boundaryId??state?.boundaryId??site?.id??"";
        // Generic places open on guidance; a restored session still owns its explicit selection.
        this.state={search:"",focusId,selected:selectFocusOnOpen?focusId:"",camera:null,fitToView:true,compact:false,positions:{},expanded:[],regionalExpanded:""};
        for(const key of Object.keys(this.state))if(state&&Object.hasOwn(state,key))this.state[key]=state[key];
        this.state.boundaryId=this.boundaryId;
        this.history=state?.history||[];this.uid=`nce-${++nextId}`;
        this.hydrateLayout();
    }
    root=null;projection=null;positions=new Map();elements=new Map();edgeElements=new Map();refs={};drag=null;abort=null;observer=null;frame=null;searchTimer=null;changeTimer=null;
    mount(root){this.detach();this.root=root;root.classList.add("nexus-connection-explorer");this.abort=new AbortController();this.render();this.bind();
        this.stopLayoutWatch=this.layoutProvider?.watch?.(()=>this.refreshSavedLayout());
        let initial=true;this.observer=new ResizeObserver(()=>{if(initial){initial=false;return}cancelAnimationFrame(this.frame);this.frame=requestAnimationFrame(()=>{if(this.root?.isConnected){if(this.state.fitToView)this.fit();else this.transform()}})});this.observer.observe(this.stage);const mounted=root;globalThis.document?.fonts?.ready.then(()=>{if(this.root===mounted&&mounted.isConnected&&this.state.fitToView)this.fit()});return this;}
    update({data=this.data,focusId}={}){this.data=data;if(focusId!==undefined&&focusId!==this.homeFocus){this.homeFocus=focusId;this.state.focusId=focusId;this.state.selected=this.selectFocusOnOpen?focusId:"";this.state.camera=null;this.state.fitToView=true;this.history=[]}if(this.root)this.render();}
    snapshot(){const state={...this.state,boundaryId:this.boundaryId,history:this.history};if(this.layoutProvider)delete state.positions;return structuredClone(state);}
    detach(){if(this.objectMenuOpen)closeActionMenu();this.stopLayoutWatch?.();this.stopLayoutWatch=null;clearTimeout(this.changeTimer);this.abort?.abort();this.observer?.disconnect();clearTimeout(this.searchTimer);cancelAnimationFrame(this.frame);this.drag=null;this.observer=null;this.abort=null;}
    destroy(){this.detach();this.root=null;this.projection=null;this.positions.clear();this.elements.clear();this.edgeElements.clear();this.refs={};}
    changed(defer=false){clearTimeout(this.changeTimer);if(defer){this.changeTimer=setTimeout(()=>this.changed(),120);return}this.onStateChange?.(this.snapshot());}
    get stage(){return this.refs.stage;}
    get layer(){return this.refs.layer;}
    get key(){return `${this.boundaryId}|${this.state.focusId}|${this.state.compact?"compact":"detail"}`;}
    layoutContext(){const node=this.data.nodes.find(node=>node.id===this.state.focusId);return {focusId:this.state.focusId,boundaryId:this.boundaryId,density:this.state.compact?"compact":"detail",target:node?.target||node};}
    hydrateLayout(){if(this.layoutProvider)this.state.positions={[this.key]:this.layoutProvider.read(this.layoutContext())||{}};}
    refreshSavedLayout(){
        if(!this.layoutProvider||!this.root)return;
        if(this.drag||this.layoutBusy){this.layoutRefreshPending=true;return;}
        this.layoutRefreshPending=false;
        const positions=this.layoutProvider.read(this.layoutContext())||{};
        if(JSON.stringify(positions)!==JSON.stringify(this.state.positions[this.key]||{})){
            this.state.positions={[this.key]:positions};this.positions=this.layout();this.drawPositions();this.changed();
        }
        this.refreshLayoutControls();
    }
    canArrange(){return !!globalThis.game?.user?.isGM&&!!this.layoutProvider?.canArrange(this.layoutContext());}
    layoutBusy=false;
    layoutControlsHtml(){if(!this.canArrange())return "";const context=this.layoutContext();return `${this.layoutProvider.hasSaved(context)?`<button type="button" data-explorer-reset-layout ${this.layoutBusy?"disabled":""}>Reset Layout</button>`:""}${this.layoutProvider.error?.(context)?`<button type="button" data-explorer-retry-layout ${this.layoutBusy?"disabled":""}>Retry Layout Save</button>`:""}`;}
    refreshLayoutControls(){const controls=this.root?.querySelector?.("[data-explorer-layout-controls]");if(controls)controls.innerHTML=this.layoutControlsHtml();}
    async saveManualPosition(context,id,position){
        try{await this.layoutProvider.save(context,id,position);}catch(error){globalThis.ui?.notifications?.error?.(`Could not save graph layout: ${error.message}`);}finally{this.refreshLayoutControls();}
    }
    async retryLayout(){
        if(!this.canArrange()||this.layoutBusy)return;const context=this.layoutContext();
        try{
            await this.layoutProvider.retry(context);
            if(this.state.focusId===context.focusId&&this.boundaryId===context.boundaryId&&(this.state.compact?"compact":"detail")===context.density&&!Object.keys(this.layoutProvider.read(context)||{}).length){this.state.camera=null;this.state.fitToView=true;this.render();this.changed();}
        }catch(error){globalThis.ui?.notifications?.error?.(`Could not save graph layout: ${error.message}`);}finally{this.refreshLayoutControls();}
    }
    async resetLayout(){
        if(!this.canArrange()||this.layoutBusy)return;const context=this.layoutContext();if(!this.layoutProvider.hasSaved(context))return;
        this.layoutBusy=true;this.refreshLayoutControls();
        try{
            const yes=await confirmDestructiveAction({title:"Reset Connections Layout",subject:context.target?.name||"this object",message:`Reset the Connections layout for <strong>${escape(context.target?.name||"this object")}</strong>?`,warning:"This removes only saved card positions for the current graph view.",confirmLabel:"Reset Layout"});
            if(!yes||!this.layoutProvider.canArrange(context))return;
            await this.layoutProvider.clear(context);
            if(this.state.focusId===context.focusId&&this.boundaryId===context.boundaryId&&(this.state.compact?"compact":"detail")===context.density){this.state.camera=null;this.state.fitToView=true;this.render();this.changed();}
        }catch(error){globalThis.ui?.notifications?.error?.(`Could not reset graph layout: ${error.message}`);}finally{this.layoutBusy=false;this.refreshLayoutControls();if(this.layoutRefreshPending)this.refreshSavedLayout();}
    }
    async flushLayout(){try{await this.layoutProvider?.flush?.();}catch(error){globalThis.ui?.notifications?.error?.(`Could not save graph layout: ${error.message}`);}}
    render(){this.hydrateLayout();if(!this.root)return;
        this.state.boundaryId=this.boundaryId;
        this.projection=projectConnectionExplorer(this.data,this.state);
        if(this.state.selected&&!this.projection.allowedIds.has(this.state.selected))this.state.selected=this.selectFocusOnOpen?this.state.focusId:"";
        const title=this.projection.byId.get(this.state.focusId)?.name||"Connections";
        this.root.innerHTML=`<nav class="nce-toolbar" aria-label="Connection explorer controls"><button type="button" data-explorer-back ${this.history.length?"":"disabled"}>← Back</button><button type="button" data-explorer-reset ${this.state.focusId===this.homeFocus?"disabled":""}>Return to start</button><strong class="nce-focus-label" title="${escape(title)}">${escape(title)}</strong><input type="search" data-explorer-search placeholder="Find connections…" value="${escape(this.state.search)}" aria-label="Find connections"><span class="nce-layout-controls" data-explorer-layout-controls>${this.layoutControlsHtml()}</span><div class="nce-zoom"><button type="button" data-explorer-fit>Fit</button><button type="button" data-explorer-zoom="out" aria-label="Zoom out">−</button><output data-explorer-zoom-value>100%</output><button type="button" data-explorer-zoom="in" aria-label="Zoom in">+</button></div>${this.onDisplayChange?'<div class="nce-display" role="group" aria-label="Connections display"><button type="button" data-explorer-display="graph" class="is-active" aria-pressed="true">Graph</button><button type="button" data-explorer-display="list" aria-pressed="false">List</button><button type="button" data-explorer-help data-tooltip="Help: Connections" aria-label="Help: Connections"><i class="fas fa-question" aria-hidden="true"></i></button></div>':""}</nav><div class="nce-body"><div class="nce-main"><div class="nce-stage" data-explorer-stage tabindex="0" aria-label="Connection graph. Right-drag to pan, wheel to zoom.${this.canArrange()?" Left-drag container headers to arrange cards.":""}"><div class="nce-layer" data-explorer-layer><svg class="nce-edges" width="1" height="1" aria-hidden="true"><defs><marker id="${this.uid}-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8"/></marker></defs><g data-explorer-paths></g></svg><div data-explorer-groups>${this.projection.groups.map(group=>this.groupHtml(group)).join("")}</div></div>${this.projection.groups.length?"":'<div class="nce-empty">'+(this.projection.byId.get(this.state.focusId)?.isRegion?'No visible places in this region.':'Open a dossier to explore its connections.')+'</div>'}<div class="nce-guide">Right-drag to pan · Scroll to zoom · Double-click an object to explore its connections${this.canArrange()?" · Drag headers to arrange":""}${this.onDrop&&this.canDrop?.(this.state.focusId)?" · Drop objects here to connect them.":""}</div></div></div><aside class="nce-inspector" data-explorer-inspector></aside></div>`;
        this.refs={stage:this.root.querySelector("[data-explorer-stage]"),layer:this.root.querySelector("[data-explorer-layer]"),paths:this.root.querySelector("[data-explorer-paths]"),zoom:this.root.querySelector("[data-explorer-zoom-value]"),inspector:this.root.querySelector("[data-explorer-inspector]")};
        this.elements=new Map([...this.root.querySelectorAll("[data-explorer-container]")].map(el=>[el.dataset.explorerContainer,el]));this.edgeElements.clear();
        this.root.classList.toggle("can-arrange",this.canArrange());this.root.classList.toggle("is-focused",!!this.state.focusId);this.root.classList.toggle("is-overview",!!this.state.compact);
        const groups=this.projection.groups;for(const group of groups){const el=this.groupElement(group.id);group.width=el.offsetWidth;group.height=el.offsetHeight;}this.alignOpinionChips();
        this.positions=this.layout();this.drawPositions();this.inspector();this.highlight();if(this.observer){this.observer.disconnect();this.observer.observe(this.stage);}
        if(this.state.camera&&!this.state.fitToView)this.transform();else this.fit();
    }
    visibilityHtml(node){return node.isPlayerHidden?`<i class="fas fa-eye-slash dossier-hidden-indicator" title="${escape(node.visibilityTitle||"Hidden from players")}" aria-label="${escape(node.visibilityTitle||"Hidden from players")}"></i>`:"";}
    image(node,className=""){return node.img?`<img class="${className}" src="${escape(node.img)}" alt="" draggable="false" loading="lazy">`:`<span class="nce-image-fallback ${className}" aria-hidden="true">${node.type==="faction"?"⚑":node.type==="npc"?"♙":"◇"}</span>`;}
    opinionHtml(node){if(!this.onOpinion||!Number.isFinite(node.opinionScore)||!node.opinionEdgeId)return "";const score=node.opinionScore,text=score>0?`+${score}`:String(score),direction=`${this.projection.byId.get(this.state.focusId)?.name||"Focus"} toward ${node.name}`;
        return `<button type="button" class="nce-opinion ${score>0?"is-positive":score<0?"is-negative":"is-neutral"}" data-explorer-opinion="${escape(node.id)}" data-explorer-opinion-edge="${escape(node.opinionEdgeId)}" title="${escape(`${direction}: ${text}. Show opinion breakdown`)}" aria-label="${escape(`${text} opinion from ${direction}. Show opinion breakdown`)}">${escape(text)}</button>`;
    }
    alignOpinionChips(){for(const chip of this.root.querySelectorAll("[data-explorer-opinion]")){const subtitle=chip.parentElement.querySelector(".nce-container-identity small");chip.style.top=`${subtitle.offsetTop+(subtitle.offsetHeight-chip.offsetHeight)/2}px`;chip.style.bottom="auto";}}
    sectionRowsHtml(group,limit=Infinity){let remaining=limit;
        return group.sections.map(section=>{const rows=section.rows.slice(0,remaining);remaining-=rows.length;if(!rows.length)return "";
            return `<section class="nce-section"><div class="nce-section-label">${escape(section.label)}</div>${rows.map(row=>`<button type="button" class="nce-row${row.isPlayerHidden?" is-player-hidden":""}" data-explorer-select="${escape(row.id)}" data-explorer-node="${escape(row.id)}">${this.image(row)}<span><strong>${row.isSeat?'<span class="nce-seat-crown" aria-label="Seat of power">♛</span> ':""}${this.visibilityHtml(row)}${escape(row.name)}</strong><small class="nce-relation-row"><span class="nce-relation-text">${escape(row.relation||row.subtitle||labels[row.type]||row.type)}</span>${this.factionBadgesHtml(row)}</small></span></button>`).join("")}</section>`;
        }).join("");
    }
    regionalGroupHtml(group){const expanded=this.state.regionalExpanded===group.id;
        return `<article class="nce-container is-regional ${expanded?"is-expanded":""}" data-explorer-container="${escape(group.id)}"><header class="nce-container-header" data-explorer-drag="${escape(group.id)}"><button type="button" class="nce-container-identity" data-explorer-select="${escape(group.node.id)}" data-explorer-node="${escape(group.node.id)}" ${group.virtual?"disabled":""}>${this.image(group.node)}<span><strong>${this.visibilityHtml(group.node)}${escape(group.name)}</strong><small>${escape(group.node.subtitle||labels[group.type]||group.type)}</small></span></button><span class="nce-drag" aria-hidden="true">⠿</span><button type="button" class="nce-place-count" data-explorer-places="${escape(group.id)}" aria-expanded="${expanded}" aria-label="${escape(`${expanded?"Hide":"Show"} places for ${group.name}`)}">${escape(group.countSummary||`${group.count} places`)} <span aria-hidden="true">${expanded?"▴":"▾"}</span></button></header><div class="nce-container-content nce-regional-list" ${expanded?"":"hidden"}>${expanded?this.sectionRowsHtml(group):""}</div></article>`;
    }
    refreshRegionalLists(){for(const group of this.projection.groups.filter(group=>group.regional||group.placesOverlay)){const element=this.groupElement(group.id),template=document.createElement("template");template.innerHTML=this.groupHtml(group);const fresh=template.content.firstElementChild; element.classList.toggle("is-expanded",this.state.regionalExpanded===group.id);element.querySelector(".nce-regional-list")?.replaceWith(fresh.querySelector(".nce-regional-list"));const count=element.querySelector("[data-explorer-places]"),freshCount=fresh.querySelector("[data-explorer-places]");if(count&&freshCount){count.innerHTML=freshCount.innerHTML;count.setAttribute("aria-expanded",freshCount.getAttribute("aria-expanded"));count.setAttribute("aria-label",freshCount.getAttribute("aria-label"));}}this.positionRegionalList();}
    positionRegionalList(){const element=this.groupElement(this.state.regionalExpanded),list=element?.querySelector(".nce-regional-list");if(!list||list.hidden||!this.state.camera||!this.stage)return;const card=element.getBoundingClientRect(),viewport=this.stage.getBoundingClientRect(),zoom=this.state.camera.zoom,width=Math.min(card.width,Math.max(0,viewport.width-16)),left=Math.max(viewport.left+8,Math.min(card.left,viewport.right-8-width));list.style.width=`${width/zoom}px`;list.style.left=`${(left-card.left)/zoom}px`;list.style.right="auto";const position=placeExplorerDropdown(card,viewport,{zoom,contentHeight:list.scrollHeight+2});list.style.top=`${position.top}px`;list.style.maxHeight=`${position.maxHeight}px`;list.dataset.placement=position.placement;}
    toggleRegionalPlaces(id){const group=this.projection.groups.find(group=>(group.regional||group.placesOverlay)&&group.id===id);if(!group)return;this.state.regionalExpanded=this.state.regionalExpanded===id?"":id;if(!group.virtual)this.state.selected=id;else this.state.selected="";this.refreshRegionalLists();this.highlight();this.inspector();if(!group.virtual)this.onSelect?.(group.node);this.changed();}
    factionBadgesHtml(node){
        const badges=node.factionBadges||[];if(!badges.length)return "";
        const shown=badges.slice(0,3),overflow=badges.slice(3);
        return `<span class="nce-faction-badges" aria-label="Organizations">${shown.map(faction=>`<span class="nce-faction-badge" title="${escape(faction.name)}" aria-label="${escape(faction.name)}">${faction.img?`<img src="${escape(faction.img)}" alt="" draggable="false" loading="lazy">`:'<i class="fas fa-shield-halved" aria-hidden="true"></i>'}</span>`).join("")}${overflow.length?`<span class="nce-faction-overflow" title="${escape(overflow.map(faction=>faction.name).join(", "))}">+${overflow.length}</span>`:""}</span>`;
    }
    groupHtml(group){if(group.regional)return this.regionalGroupHtml(group);const expanded=this.state.expanded.includes(group.id),overlayExpanded=this.state.regionalExpanded===group.id,limit=group.placesOverlay?2:expanded?Infinity:10,sections=this.state.compact?"":this.sectionRowsHtml(group,limit);const total=group.sections.reduce((n,s)=>n+s.rows.length,0),opinion=this.opinionHtml(group.node);
        return `<article class="nce-container ${group.node.isPlayerHidden?"is-player-hidden":""} ${group.anchor?"is-anchor":""} ${group.leaf?"is-leaf":""} ${opinion?"has-opinion":""} ${group.placesOverlay?"has-places-overlay":""} ${group.placesOverlay&&overlayExpanded?"is-expanded":""}" data-explorer-container="${escape(group.id)}"><header class="nce-container-header" data-explorer-drag="${escape(group.id)}"><button type="button" class="nce-container-identity" data-explorer-select="${escape(group.node.id)}" data-explorer-node="${escape(group.node.id)}" ${group.virtual?"disabled":""}>${this.image(group.node)}<span><strong>${group.node.isPlaceOwner?'<i class="fas fa-crown nce-owner-crown" title="Place owner" aria-label="Place owner"></i> ':""}${this.visibilityHtml(group.node)}${escape(group.name)}</strong><small class="nce-relation-row"><span class="nce-relation-text">${escape(group.leaf?(group.relation||labels[group.type]||group.type):(group.node.subtitle||labels[group.type]||group.type))}${group.count?` · ${group.count} ${group.regional?`settlement${group.count===1?"":"s"}`:"objects"}`:""}</span>${this.factionBadgesHtml(group.node)}</small></span></button>${opinion}<span class="nce-drag" aria-hidden="true">⠿</span></header><div class="nce-container-content">${sections}${group.placesOverlay&&total>2?`<button type="button" class="nce-expand" data-explorer-places="${escape(group.id)}" aria-expanded="${overlayExpanded}" aria-label="${overlayExpanded?"Hide":"Show"} all places">${overlayExpanded?"Show fewer":`Show more (${total-2})`}</button>`:""}${!group.placesOverlay&&!this.state.compact&&total>10?`<button type="button" class="nce-expand" data-explorer-expand="${escape(group.id)}">${expanded?"Show fewer":`Show ${total-Math.min(total,limit)} more connections`}</button>`:""}${group.anchor?`<p>${this.projection.adjacency.get(group.id)?.length||0} immediate connections</p>`:""}</div>${group.placesOverlay&&total>2?`<div class="nce-container-content nce-regional-list" ${overlayExpanded?"":"hidden"}>${overlayExpanded?this.sectionRowsHtml(group):""}</div>`:""}</article>`;}
    groupElement(id){return this.elements.get(id);}
    layout(){return layoutConnectionExplorer(this.projection.groups,{focusId:this.state.focusId,width:this.stage.clientWidth,height:this.stage.clientHeight,compact:this.state.compact,positions:this.state.positions[this.key]});}
    drawPositions(){for(const[id,p]of this.positions){const el=this.groupElement(id);if(el){el.style.left=`${p.x}px`;el.style.top=`${p.y}px`;}}this.drawEdges();}
    drawEdges(){const paths=this.refs.paths;if(!paths)return;const lanes=new Map(),labelBounds=[];
        for(const edge of this.projection.edges){const a=this.positions.get(edge.source),b=this.positions.get(edge.target);if(!a||!b)continue;
            const key=[edge.source,edge.target].sort().join("|"),lane=lanes.get(key)||0;lanes.set(key,lane+1);const curve=explorerCurve(a,b,lane?-2:0);
            let entry=this.edgeElements.get(edge.id);
            if(!entry){const width=edge.labelWidth||explorerLabelWidth(edge.label);paths.insertAdjacentHTML("beforeend",`<g class="nce-edge ${edge.dashed?"is-shared":""}" data-explorer-edge="${escape(edge.id)}"><title>${escape(edge.label)}</title><path ${edge.directed?`marker-end="url(#${this.uid}-arrow)"`:""}/><g class="nce-edge-position"><g class="nce-edge-label"><rect x="${-width/2}" y="-12" width="${width}" height="24" rx="3"/><text text-anchor="middle" dominant-baseline="central">${escape(edge.label.length>40?edge.label.slice(0,38)+"…":edge.label)}</text></g></g></g>`);const el=paths.lastElementChild;entry={el,path:el.querySelector("path"),label:el.querySelector(".nce-edge-position")};this.edgeElements.set(edge.id,entry);}
            entry.path.setAttribute("d",curve.path);const scale=this.state.compact?1.6:1,label=placeExplorerLabel(curve,[...this.positions.values(),...labelBounds],(edge.labelWidth||explorerLabelWidth(edge.label))*scale,24*scale);
            entry.bounds=label.bounds;labelBounds.push(label.bounds);entry.label.setAttribute("transform",`translate(${label.x},${label.y})`);
        }this.highlightEdges();this.positionRegionalList();
    }
    highlightEdges(){const visibleSelection=this.projection.groups.some(group=>group.nodeIds.includes(this.state.selected));for(const edge of this.projection.edges){const el=this.edgeElements.get(edge.id)?.el;if(!el)continue;const selected=this.edgeSelected(edge);el.classList.toggle("is-selected",selected);el.classList.toggle("is-muted",visibleSelection&&!selected);}}
    edgeSelected(edge){return !!this.state.selected&&([edge.source,edge.target,...edge.nodeIds||[]].includes(this.state.selected));}
    highlight(){const selected=this.projection.groups.some(group=>group.nodeIds.includes(this.state.selected))?this.state.selected:"",related=new Set();for(const edge of this.projection.edges)if(this.edgeSelected(edge)){related.add(edge.source);related.add(edge.target)}for(const group of this.projection.groups){const el=this.groupElement(group.id),active=group.nodeIds.includes(selected);el.classList.toggle("is-selected",active);el.classList.toggle("is-muted",!!selected&&!active&&!related.has(group.id))}for(const row of this.root.querySelectorAll("[data-explorer-select]"))row.classList.toggle("is-selected",row.dataset.explorerSelect===selected);this.highlightEdges();}
    inspector(){const el=this.refs.inspector,node=this.projection.byId.get(this.state.selected);if(!node){el.innerHTML='<p>Select an object to inspect its connections.</p>'+(this.onDrop&&this.canDrop?.(this.state.focusId)?`<p class="nce-drop-guidance">Drag Actors, Sites, or other supported objects onto the graph to connect them to <strong>${escape(this.dropOwnerName||this.projection.byId.get(this.homeFocus)?.name||"this dossier")}</strong>.</p>`:"");return}
        const connections=this.projection.adjacency.get(node.id)||[],external=this.projection.externalConnections?.get(node.id)||[];
        const summary=connections.slice(0,this.inspectorExpanded===node.id?undefined:5).map(edge=>{const other=this.projection.byId.get(edge.source===node.id?edge.target:edge.source);return `<button type="button" class="nce-inspector-link" data-explorer-select="${escape(other?.id)}"><span>${escape(explorerRelationshipLabel(edge,node.id))}</span><strong>${escape(other?.name)}</strong></button>`}).join("");
        el.innerHTML=`<div class="nce-kicker">Selected ${escape(labels[node.type]||node.type)}</div>${this.image(node,"nce-inspector-image")}<h3>${escape(node.name)}</h3><div class="nce-inspector-subtitle">${escape(node.subtitle||"")}</div><p>${connections.length} connection${connections.length===1?"":"s"}</p><button type="button" class="nce-primary" data-explorer-focus="${escape(node.id)}" ${node.id===this.state.focusId?"disabled":""}>Explore connections</button>${this.onOpenBeside?`<button type="button" data-explorer-beside="${escape(node.id)}">Open beside</button>`:""}<button type="button" data-explorer-open="${escape(node.id)}">${node.kind==="foundry-document"?"Open object":"Open dossier"} ↗</button>${this.onMenu?`<button type="button" data-explorer-menu="${escape(node.id)}">⋯ Connection actions</button>`:""}<div class="nce-inspector-facts">${summary}${connections.length>5?`<button type="button" data-explorer-details="${escape(node.id)}">${this.inspectorExpanded===node.id?"Show fewer relationships":`Show ${connections.length-5} more relationships`}</button>`:""}</div>${external.length?`<div class="nce-external"><div class="nce-kicker">Outside this area · ${external.length}</div>${external.slice(0,this.externalExpanded===node.id?undefined:8).map(({edge,node:other})=>`<div class="nce-external-reference"><strong>${escape(other.name)}</strong><small>${escape(explorerRelationshipLabel(edge,node.id))}</small><button type="button" data-explorer-open="${escape(other.id)}">Open dossier ↗</button></div>`).join("")}${external.length>8?`<button type="button" data-explorer-external="${escape(node.id)}">${this.externalExpanded===node.id?"Show fewer":`Show ${external.length-8} more outside connections`}</button>`:""}</div>`:""}`;
    }
    select(id){if(!this.projection.allowedIds.has(id))return;const expanded=this.projection.groups.find(group=>(group.regional||group.placesOverlay)&&group.id===this.state.regionalExpanded);if(expanded&&!expanded.nodeIds.includes(id)){this.state.regionalExpanded="";this.refreshRegionalLists();}this.state.selected=id;this.highlight();this.inspector();this.onSelect?.(this.projection.byId.get(id));this.changed();}
    connectionContext(nodeId,anchor,edgeIds){const focusId=this.state.focusId;return {focusId,nodeId,anchor,edgeIds:edgeIds||(this.data.edges||[]).filter(edge=>!edge.derived&&((edge.source===focusId&&edge.target===nodeId)||(edge.target===focusId&&edge.source===nodeId))).map(edge=>edge.id)};}
    openObjectMenu(id,anchor,position){const node=this.projection.byId.get(id);if(!node||!this.projection.allowedIds.has(id))return;this.select(id);
        const actions=this.getConnectionActions?.(this.connectionContext(id,anchor))||[];
        const items=[...actions,...(actions.length?[{type:"separator"}]:[]),...(this.onOpenBeside?[{id:"open-beside",label:"Open Beside",icon:"fas fa-columns",onSelect:()=>this.onOpenBeside(node)}]:[]),
            {id:"explore-connections",label:"Explore Connections",icon:"fas fa-diagram-project",unavailable:id===this.state.focusId,onSelect:()=>this.focus(id)},
            {id:"open-dossier",label:node.kind==="foundry-document"?"Open Object":"Open Dossier",icon:"fas fa-up-right-from-square",unavailable:!this.onOpen,onSelect:()=>this.onOpen?.(node)}];
        this.objectMenuOpen=true;openActionMenu({anchor,position,items,className:"nce-object-menu",onClose:()=>{this.objectMenuOpen=false;}});
    }
    clearSelection(){if(!this.state.selected&&!this.state.regionalExpanded)return;this.state.selected="";this.state.regionalExpanded="";this.refreshRegionalLists();this.inspectorExpanded="";this.externalExpanded="";this.highlight();this.inspector();this.changed();}
    push(){const {positions,expanded,boundaryId,...state}=this.state;this.history.push(structuredClone(state));if(this.history.length>40)this.history.shift();}
    focus(id){if(!this.projection.allowedIds.has(id)||id===this.state.focusId)return;this.push();this.state.focusId=id;this.state.selected=id;this.state.regionalExpanded="";this.state.search="";this.state.camera=null;this.state.fitToView=true;this.render();this.changed();}
    back(){const previous=this.history.pop();if(!previous)return;Object.assign(this.state,previous);this.render();this.changed();}
    reset(){if(this.state.focusId===this.homeFocus)return;this.focus(this.homeFocus);}
    resetAfterDrop(){
        if(this.state.focusId!==this.homeFocus)this.push();
        // A new dossier connection should be visible in its owner's automatic layout.
        Object.assign(this.state,{focusId:this.homeFocus,selected:this.selectFocusOnOpen?this.homeFocus:this.state.selected,search:"",regionalExpanded:"",camera:null,fitToView:true});
        this.changed();
    }
    transform(){const camera=this.state.camera;if(!this.layer||!camera)return;this.layer.style.transform=`translate(${camera.x}px,${camera.y}px) scale(${camera.zoom})`;this.root.style.setProperty("--nce-label-scale",Math.min(1.6,1/camera.zoom));this.refs.zoom.textContent=`${Math.round(camera.zoom*100)}%`;this.positionRegionalList();}
    fit(){if(!this.stage||!this.positions.size)return;this.state.fitToView=true;
        for(const group of this.projection.groups){const element=this.groupElement(group.id);group.width=element.offsetWidth;group.height=element.offsetHeight;}
        this.alignOpinionChips();
        this.positions=this.layout();this.drawPositions();
        const p=[...this.positions.values(),...[...this.edgeElements.values()].map(entry=>entry.bounds).filter(Boolean)],x=Math.min(...p.map(n=>n.x))-25,y=Math.min(...p.map(n=>n.y))-35,w=Math.max(...p.map(n=>n.x+n.w))-x+25,h=Math.max(...p.map(n=>n.y+n.h))-y+35;
        const zoom=Math.max(.035,Math.min(1,(this.stage.clientWidth-24)/w,(this.stage.clientHeight-60)/h));this.state.camera={zoom,x:(this.stage.clientWidth-w*zoom)/2-x*zoom,y:25+(this.stage.clientHeight-60-h*zoom)/2-y*zoom};this.transform();this.changed();
    }
    zoom(factor,x=this.stage.clientWidth/2,y=this.stage.clientHeight/2){if(!this.state.camera)return;this.state.fitToView=false;const c=this.state.camera,z=Math.max(.035,Math.min(2.5,c.zoom*factor));c.x=x-(x-c.x)*z/c.zoom;c.y=y-(y-c.y)*z/c.zoom;c.zoom=z;this.transform();this.changed(true);}
    bind(){const root=this.root,signal=this.abort.signal;const listen=(type,fn,options={})=>root.addEventListener(type,fn,{...options,signal});
        listen("click",event=>{if(this.suppressClick){this.suppressClick=false;event.stopPropagation();event.preventDefault();return}const b=event.target.closest("button");if(!b){if(event.button===0&&event.target.closest("[data-explorer-stage]")&&!event.target.closest("[data-explorer-container],.nce-edge"))this.clearSelection();return;}const d=b.dataset;
            if(Object.hasOwn(d,"explorerResetLayout")){event.preventDefault();event.stopPropagation();void this.resetLayout();return;}
            if(Object.hasOwn(d,"explorerRetryLayout")){event.preventDefault();event.stopPropagation();void this.retryLayout();return;}
            if(Object.hasOwn(d,"explorerHelp")){event.preventDefault();event.stopPropagation();openHelp("augur-nexus:connections");return;}
            if(d.explorerDisplay){event.preventDefault();event.stopPropagation();if(d.explorerDisplay==="list")this.onDisplayChange?.("list");return;}
            if(d.explorerPlaces){this.toggleRegionalPlaces(d.explorerPlaces);return;}
            if(d.explorerOpinion){event.preventDefault();event.stopPropagation();this.onOpinion?.(this.connectionContext(d.explorerOpinion,b,[d.explorerOpinionEdge]));return;}
            if(d.explorerSelect)this.select(d.explorerSelect);if(d.explorerFocus)this.focus(d.explorerFocus);if(d.explorerOpen)this.onOpen?.(this.projection.byId.get(d.explorerOpen));if(d.explorerBeside)this.onOpenBeside?.(this.projection.byId.get(d.explorerBeside));if(d.explorerMenu)this.onMenu?.(this.projection.byId.get(d.explorerMenu),b);
            if(d.explorerDetails){this.inspectorExpanded=this.inspectorExpanded===d.explorerDetails?"":d.explorerDetails;this.inspector();}
            if(d.explorerExternal){this.externalExpanded=this.externalExpanded===d.explorerExternal?"":d.explorerExternal;this.inspector();}
            if(Object.hasOwn(d,"explorerFit"))this.fit();if(d.explorerZoom)this.zoom(d.explorerZoom==="in"?1.2:1/1.2);if(Object.hasOwn(d,"explorerBack"))this.back();if(Object.hasOwn(d,"explorerReset"))this.reset();
            if(d.explorerExpand){const ids=new Set(this.state.expanded);ids.has(d.explorerExpand)?ids.delete(d.explorerExpand):ids.add(d.explorerExpand);this.state.expanded=[...ids];this.render();this.changed()}
        });
        listen("dblclick",event=>{
            if(event.button!==0||!event.target.closest("[data-explorer-stage]"))return;
            const object=event.target.closest("[data-explorer-node]");
            if(!object&&event.target.closest("button"))return;
            let id=object?.dataset.explorerNode||event.target.closest("[data-explorer-container]")?.dataset.explorerContainer;
            // Header capture retargets the browser's double-click to the stage.
            const header=this.lastHeaderActivation;
            if(!id&&header&&Math.hypot(event.clientX-header.x,event.clientY-header.y)<4)id=header.id;
            if(!id)return;event.preventDefault();event.stopPropagation();this.focus(id);
        });
        listen("input",event=>{if(!event.target.matches("[data-explorer-search]"))return;const value=event.target.value;clearTimeout(this.searchTimer);this.searchTimer=setTimeout(()=>{this.state.search=value;this.state.camera=null;this.state.fitToView=true;this.render();const input=root.querySelector("[data-explorer-search]");input.focus();input.setSelectionRange(value.length,value.length);this.changed()},160)});
        listen("contextmenu",event=>{if(event.target.closest("[data-explorer-stage]")){event.preventDefault();event.stopPropagation()}});
        listen("dragover",event=>{if(!event.target.closest("[data-explorer-stage]"))return;event.stopPropagation();if(this.onDrop&&this.canDrop?.(this.state.focusId)){event.preventDefault();if(event.dataTransfer)event.dataTransfer.dropEffect="copy";}});
        listen("drop",async event=>{if(!event.target.closest("[data-explorer-stage]"))return;event.preventDefault();event.stopPropagation();if(!this.onDrop||!this.canDrop?.(this.state.focusId))return;try{await this.onDrop({event,focusId:this.state.focusId});}catch(error){globalThis.ui?.notifications?.error?.(error.message||"Could not create that connection.");}});
        listen("wheel",event=>{if(!event.target.closest("[data-explorer-stage]")||event.target.closest(".nce-regional-list"))return;event.preventDefault();event.stopPropagation();const r=this.stage.getBoundingClientRect();this.zoom(Math.exp(-event.deltaY*.0015),event.clientX-r.left,event.clientY-r.top)},{passive:false});
        listen("pointerdown",event=>{this.lastHeaderActivation=null;if(![0,2].includes(event.button)||!event.target.closest("[data-explorer-stage]"))return;if(event.button===0&&event.target.closest("[data-explorer-places], [data-explorer-opinion]"))return;const header=event.target.closest("[data-explorer-drag]"),pan=event.button===2;if(!pan&&(!header||!this.canArrange()||this.layoutBusy)||!this.state.camera)return;const position=header&&this.positions.get(header.dataset.explorerDrag);if(pan&&this.objectMenuOpen)closeActionMenu();const object=event.target.closest("[data-explorer-node]"),card=event.target.closest("[data-explorer-container]");this.drag={pan,menuId:object?.dataset.explorerNode||card?.dataset.explorerContainer,menuAnchor:object||card,id:pan?null:header.dataset.explorerDrag,x:event.clientX,y:event.clientY,pointerId:event.pointerId,origin:{...(pan?this.state.camera:position)},context:this.layoutContext(),key:this.key,moved:false};this.suppressClick=false;event.preventDefault();event.stopPropagation();this.stage.setPointerCapture(event.pointerId)});
        listen("pointermove",event=>{const d=this.drag;if(!d||d.pointerId!==event.pointerId)return;if(!d.pan&&(!this.canArrange()||this.layoutBusy)){finish({pointerId:event.pointerId,type:"pointercancel"});return;}const dx=event.clientX-d.x,dy=event.clientY-d.y;if(!d.moved&&Math.hypot(dx,dy)<4)return;d.moved=true;if(d.pan){this.state.fitToView=false;this.state.camera.x=d.origin.x+dx;this.state.camera.y=d.origin.y+dy;this.transform()}else{const p=this.positions.get(d.id);p.x=d.origin.x+dx/this.state.camera.zoom;p.y=d.origin.y+dy/this.state.camera.zoom;const el=this.groupElement(d.id);el.style.left=`${p.x}px`;el.style.top=`${p.y}px`;this.drawEdges()}event.stopPropagation()});
        const finish=event=>{
            const d=this.drag;if(!d||event.pointerId!==d.pointerId)return;
            const commit=event.type==="pointerup";
            this.suppressClick=!d.pan&&commit;
            if(!d.pan){
                if(d.moved){
                    const position=this.positions.get(d.id);
                    if(commit&&this.canArrange()&&!this.layoutBusy&&position&&Number.isFinite(position.x)&&Number.isFinite(position.y)){
                        const manual={x:position.x,y:position.y};
                        this.state.positions[d.key]={...this.state.positions[d.key],[d.id]:manual};
                        void this.saveManualPosition(d.context,d.id,manual);
                    }else if(position){Object.assign(position,{x:d.origin.x,y:d.origin.y});this.drawPositions();}
                }else if(commit){this.select(d.id);this.lastHeaderActivation={id:d.id,x:event.clientX,y:event.clientY};}
            }
            this.drag=null;
            if(this.layoutRefreshPending)this.refreshSavedLayout();
            if(d.pan&&!d.moved&&commit)this.openObjectMenu(d.menuId,d.menuAnchor,{left:event.clientX,top:event.clientY});
            if(this.stage?.hasPointerCapture(event.pointerId))this.stage.releasePointerCapture(event.pointerId);
            this.changed();
        };listen("pointerup",finish);listen("pointercancel",finish);listen("lostpointercapture",finish);

        listen("keydown",event=>{if(!event.target.matches("[data-explorer-stage]")||!this.state.camera)return;const move={ArrowLeft:[40,0],ArrowRight:[-40,0],ArrowUp:[0,40],ArrowDown:[0,-40]}[event.key];if(move){event.preventDefault();this.state.fitToView=false;this.state.camera.x+=move[0];this.state.camera.y+=move[1];this.transform();this.changed(true)}if(["+","=","-"].includes(event.key)){event.preventDefault();this.zoom(event.key==="-"?1/1.2:1.2)}});
    }
}
