import { EntityArtworkService } from "../services/EntityArtworkService.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class EntityArtworkApplication extends HandlebarsApplicationMixin(ApplicationV2) {
    static instances = new Map();
    static DEFAULT_OPTIONS = {
        id: "nexus-entity-artwork", tag: "form", classes: ["augur-nexus", "augur-theme-fantasy", "entity-artwork-panel"],
        window: { title: "Portraits & artwork", resizable: true }, position: { width: 540, height: 620 },
        form: { closeOnSubmit: false },
        actions: { choose: EntityArtworkApplication.action, copyNexus: EntityArtworkApplication.action, copyActor: EntityArtworkApplication.action }
    };
    static PARTS = { body: { template: "modules/augur-nexus/templates/campaign-entities/entity-artwork.hbs" } };

    static async show({ entityId, onChooseArtwork }) {
        let app = this.instances.get(entityId);
        if (!app) { app = new this({ entityId, onChooseArtwork }); this.instances.set(entityId, app); }
        app.onChooseArtwork = onChooseArtwork;
        await app.render({ force: true }); app.bringToFront();
        return app;
    }
    constructor({ entityId, onChooseArtwork }) {
        super({ id: `nexus-entity-artwork-${entityId}` });
        this.entityId = entityId; this.onChooseArtwork = onChooseArtwork;
        this.includeToken = false; this.message = ""; this.busy = false;
    }
    async _prepareContext() {
        try {
            const state = await EntityArtworkService.inspect(this.entityId);
            this.snapshot = { actorUuid: state.actorUuid, entityImage: state.entityImage, actorImage: state.actorImage, entityTokenImage: state.entityTokenImage };
            return { name: state.entity.display?.name || state.document.name, entityImage: state.entityImage,
                isShip: state.entity.type === "ship", actorName: state.actor?.name, actorImage: state.actorImage,
                tokenImage: state.tokenImage, hasActor: !!state.actor, hasLink: !!state.actorUuid,
                canEdit: state.canEdit, canCopy: state.canCopy, syncActorPortrait: state.syncActorPortrait, syncActorToken: state.syncActorToken, copyNexus: state.canCopy && !!state.entityImage,
                copyActor: state.canCopy && !!state.actorImage, includeToken: this.includeToken, message: this.message, busy: this.busy };
        } catch (error) { this.snapshot = null; return { error: error.message }; }
    }
    _onChangeForm(config, event) {
        if (event.target.name === "includeToken") this.includeToken = event.target.checked;
        if (["syncActorPortrait", "syncActorToken"].includes(event.target.name)) {
            void this.setArtworkLink(event.target.name, event.target.checked);
        }
        super._onChangeForm(config, event);
    }
    async setArtworkLink(key, enabled) {
        if (this.busy) return;
        this.busy = true;
        const expected = this.snapshot;
        try {
            this.message = await EntityArtworkService.setLink(this.entityId, { key, enabled, expected });
        } catch (error) { this.message = error.message; }
        finally { this.busy = false; }
        if (this.rendered) await this.render({ force: true });
    }
    _onRender(context, options) {
        super._onRender(context, options);
        if (!this.hooks) {
            const refresh = () => { if (this.rendered && !this.busy) void this.render({ force: true }); };
            this.hooks = ["updateActor", "updateJournalEntry", "deleteActor", "deleteJournalEntry", "augurNexusPlayerContextChanged", "augurNexusCampaignEntitiesChanged"]
                .map(name => [name, Hooks.on(name, refresh)]);
        }
    }
    async close(options) {
        for (const [name, id] of this.hooks || []) Hooks.off(name, id);
        this.hooks = null; this.constructor.instances.delete(this.entityId);
        return super.close(options);
    }
    static async action(event, button) {
        event.preventDefault();
        if (this.busy) return;
        this.busy = true; this.message = "";
        const expected = this.snapshot;
        try {
            if (button.dataset.action === "choose") {
                await EntityArtworkService.inspect(this.entityId);
                await this.onChooseArtwork?.();
            } else {
                this.message = await EntityArtworkService.copy(this.entityId, {
                    source: button.dataset.action === "copyNexus" ? "nexus" : "actor", includeToken: this.includeToken, expected
                });
            }
        } catch (error) { this.message = error.message; }
        finally { this.busy = false; }
        if (this.rendered) await this.render({ force: true });
    }
}
