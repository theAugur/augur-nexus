import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { getPlayerEntityRevision } from "../../player-context/PlayerEntityRequests.js";
import { getLocation, getLocationGeneratorProfileOptions, updateLocation } from "../../../api/locations.js";
import { promptTextInput } from "../../../api/ui.js";
import { SiteIconPicker } from "../../site/applications/SiteIconPicker.js";
import { SitePanel } from "../../site/applications/SitePanel.js";
import { LocationEntityModel } from "../models/LocationEntityModel.js";
import { LocationParentReference } from "../models/LocationParentReference.js";
import { PlaceParentService } from "../../places/services/PlaceParentService.js";
import { LocationEditorSectionRegistry } from "../services/LocationEditorSectionRegistry.js";

import { EntityEditorAutosave } from "../services/EntityEditorAutosave.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const THREAD_FIELDS = [
    { key: "state", label: "State", help: "The location's present condition." },
    { key: "pressure", label: "Pressure", help: "What is currently affecting it." },
    { key: "opportunity", label: "Opportunity", help: "What could be gained here." },
    { key: "secret", label: "Secret", help: "What remains concealed." }
];

export class LocationDataEditor extends HandlebarsApplicationMixin(ApplicationV2) {
    #locationId = "";
    #candidate = null;
    #onSave = null;
    #autosave = null;
    #saveTimer = null;
    #formSnapshot = null;
    #listeners = null;
    #closed = false;
    #positionInitialized = false;
    #operation = null;
    #completion = null;

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-location-data-editor",
        classes: ["augur-nexus", "augur-theme-fantasy", "npc-data-editor", "location-data-editor"],
        tag: "div",
        window: { title: "Edit Location", resizable: true, minimizable: true },
        position: { width: 520, height: 700 },
        actions: {
            retrySave: LocationDataEditor._onRetrySave,
            applyLocationSection: LocationDataEditor._onApplyLocationSection,
            renameLocation: LocationDataEditor._onRenameLocation,
            changeLocationIcon: LocationDataEditor._onChangeLocationIcon,
            addProfileField: LocationDataEditor._onAddProfileField,
            deleteProfileField: LocationDataEditor._onDeleteProfileField,
            moveProfileFieldUp: LocationDataEditor._onMoveProfileFieldUp,
            moveProfileFieldDown: LocationDataEditor._onMoveProfileFieldDown
        }
    };

    static PARTS = { content: { template: "modules/augur-nexus/templates/campaign-entities/location-data-editor.hbs" } };

    static show({ locationId = "", candidate = null, onSave = null } = {}) {
        if ((!game.user.isGM && (!locationId || !canControlPlayerEntity(locationId))) || (!locationId && !candidate)) return null;
        const app = new this({ locationId, candidate, onSave });
        app.render(true, { focus: true });
        return app;
    }

    constructor({ locationId = "", candidate = null, onSave = null } = {}, options = {}) {
        super(options);
        this.#locationId = locationId;
        this.#candidate = candidate ? foundry.utils.deepClone(candidate) : null;
        this.#onSave = typeof onSave === "function" ? onSave : null;
    }

    async _prepareContext() {
        const entity = this.#session()?.draft;
        const parentKey = LocationParentReference.toNodeKey(entity?.hierarchy?.parent);
        const profileOptions = await getLocationGeneratorProfileOptions(entity?.generation?.generatorId || "", {
            templateId: entity?.generation?.templateId || ""
        });
        return {
            saveStatus: this.#saveStatus(),
            saveFailed: !!this.#autosave?.error,
            missing: !entity,
            location: entity ? {
                id: entity.id,
                name: LocationEntityModel.getName(entity),
                subtitle: LocationEntityModel.getSubtitle(entity),
                imageSrc: LocationEntityModel.getThumbnail(entity)
            } : { name: "Missing Location" },
            profileFields: (entity?.profile?.fields || []).map(field => ({
                ...field,
                multiline: field.type === "multiline"
            })),
            currentThreadFields: THREAD_FIELDS.map(field => ({
                ...field,
                value: String(entity?.currentThread?.[field.key] || ""),
                options: this.#buildOptions(profileOptions.fields?.[field.key] || [])
            })),
            editorSections: await LocationEditorSectionRegistry.renderFor(entity, {
                candidate: !!this.#candidate
            }),
            isRootSelected: !parentKey,
            parentOptions: PlaceParentService.getParentOptions({
                childType: "location",
                childKey: entity?.id ? `location:${entity.id}` : null,
                selectedKey: parentKey
            })
        };
    }

    _onRender(context, options) {
        super._onRender(context, options);
        if (!this.#positionInitialized) {
            this.setPosition(this.#getCenteredPosition());
            this.#positionInitialized = true;
        }
        this.#updateSaveStatus();
    }

    _attachPartListeners(partId, root, options) {
        super._attachPartListeners?.(partId, root, options);
        this.#listeners?.abort();
        this.#listeners = new AbortController();
        const { signal } = this.#listeners;
        const form = root.matches("form") ? root : root.querySelector("form");
        this.#formSnapshot = form ? this.#readForm(form) : null;
        form?.addEventListener("submit", event => { event.preventDefault(); void this.flushPendingSaves(); }, { signal });
        form?.addEventListener("input", () => {
            this.#captureForm();
            clearTimeout(this.#saveTimer);
            this.#saveTimer = setTimeout(() => { void this.flushPendingSaves(); }, 450);
        }, { signal });
        form?.addEventListener("change", () => { void this.flushPendingSaves(); }, { signal });
    }

    static async _onRetrySave() {
        clearTimeout(this.#saveTimer);
        this.#captureForm();
        const saved = await this.#autosave?.retry();
        if (saved) await this.#refreshHeader();
        return saved;
    }

    static async _onRenameLocation() {
        const entity = this.#entity;
        if (!entity) return;
        const name = await promptTextInput({
            title: "Rename Location",
            label: "Name",
            value: LocationEntityModel.getName(entity),
            confirmLabel: "Rename"
        });
        if (!name) return;
        await this.#saveSelection({ "display.name": name });
    }

    static async _onChangeLocationIcon() { await this.#changeLocationIcon(); }

    static async _onAddProfileField() {
        const container = this.element.querySelector("[data-profile-fields]");
        if (!container) return;
        const id = `field.${foundry.utils.randomID()}`;
        const row = document.createElement("div");
        row.className = "npc-data-custom-field-row";
        row.dataset.profileFieldRow = id;
        row.innerHTML = this.#renderProfileFieldRow({ id, label: "", value: "", type: "text" });
        container.append(row);
        row.querySelector("[name='profileField.label']")?.focus();
        await this.flushPendingSaves();
    }

    static async _onDeleteProfileField(event, target) { target?.closest?.("[data-profile-field-row]")?.remove(); await this.flushPendingSaves(); }
    static async _onMoveProfileFieldUp(event, target) { this.#moveField(target, -1); }
    static async _onMoveProfileFieldDown(event, target) { this.#moveField(target, 1); }

    #session() {
        if (this.#autosave) return this.#autosave;
        if (!this.#entity) return null;
        this.#autosave = new EntityEditorAutosave({ ...this.#entity, editorOperation: this.#operation }, {
            label: "Location",
            read: () => this.#entity ? { ...this.#entity, editorOperation: this.#operation } : null,
            write: (patch, current) => this.#writePatch(patch, current),
            changed: () => this.#updateSaveStatus()
        });
        return this.#autosave;
    }

    async #writePatch({ editorOperation, ...patch }, current) {
        if (patch.profile?.fields?.some(field => !field.label.trim() && field.value.trim())) {
            throw new Error("Add a label to each profile field containing a value. Your input is retained.");
        }
        const context = { candidate: !!this.#candidate, sectionId: editorOperation?.sectionId };
        const data = new FormData();
        for (const [key, value] of editorOperation?.entries || []) data.append(key, value);
        // Preserve the original transition if its follow-up fails after the entity write.
        let updated;
        if (this.#completion) {
            const pending = this.#completion;
            updated = await LocationEditorSectionRegistry.afterSave(pending.entity, pending.updated, pending.data, pending.context);
            if (Object.keys(patch).length) {
                updated = await updateLocation(updated.id, patch, { expectedRevision: getPlayerEntityRevision(this.#entity) });
            }
            this.#completion = null;
        } else {
            const transformed = editorOperation
                ? await LocationEditorSectionRegistry.transformPatch(current, data, patch, context)
                : { patch, moduleId: "" };
            updated = this.#candidate
                ? this.#applyCandidatePatch(this.#candidate, transformed.patch)
                : await updateLocation(current.id, transformed.patch, {
                    moduleId: transformed.moduleId || "", expectedRevision: getPlayerEntityRevision(current)
                });
            if (editorOperation && !this.#candidate) {
                this.#completion = { entity: current, updated, data, context };
                updated = await LocationEditorSectionRegistry.afterSave(current, updated, data, context);
                this.#completion = null;
            }
        }
        if (editorOperation) this.#operation = editorOperation;
        if (this.#candidate) await this.#onSave?.(updated);
        else {
            try { await this.#onSave?.(updated); }
            catch (error) { console.error("Augur Nexus | Location editor refresh failed", error); }
        }
        return { ...updated, editorOperation: this.#operation };
    }

    #readForm(form) {
        const data = new FormData(form);
        const values = {
            "profile.fields": this.#collectProfileFields(form),
            ...Object.fromEntries(THREAD_FIELDS.map(field => [
                `currentThread.${field.key}`, String(data.get(`currentThread.${field.key}`) || "").trim()
            ]))
        };
        if (data.has("hierarchy.parentKey")) values["hierarchy.parent"] = LocationParentReference.fromNodeKey(data.get("hierarchy.parentKey"));
        return values;
    }

    static async _onApplyLocationSection(event, target) {
        if (!await this.flushPendingSaves()) return;
        const section = target?.closest("[data-location-editor-section]");
        if (!section) return;
        const form = document.createElement("form");
        for (const input of section.querySelectorAll("input,select,textarea")) {
            const copy = input.cloneNode(true);
            copy.value = input.value;
            if ("checked" in input) copy.checked = input.checked;
            form.append(copy);
        }
        target.disabled = true;
        try {
            await this.#saveSelection({ editorOperation: {
                id: foundry.utils.randomID(), sectionId: section.dataset.locationEditorSection,
                entries: [...new FormData(form)]
            } });
        } finally { target.disabled = false; }
    }

    #captureForm() {
        const form = this.element?.querySelector("form");
        if (!form || !this.#formSnapshot) return;
        const next = this.#readForm(form);
        for (const [path, value] of Object.entries(next)) {
            if (JSON.stringify(value) !== JSON.stringify(this.#formSnapshot[path])) this.#session()?.set(path, value);
        }
        this.#formSnapshot = next;
    }

    async flushPendingSaves() {
        clearTimeout(this.#saveTimer);
        this.#saveTimer = null;
        this.#captureForm();
        if (!this.#autosave) return true;
        const saved = await this.#autosave.flush();
        this.#updateSaveStatus();
        if (saved) await this.#refreshHeader();
        return saved;
    }

    async close(options = {}) {
        if (!await this.flushPendingSaves()) {
            ui.notifications.error(this.#autosave.error);
            return this;
        }
        this.#listeners?.abort();
        clearTimeout(this.#saveTimer);
        this.#closed = true;
        return super.close(options);
    }

    #saveStatus() {
        if (this.#autosave?.error) return this.#autosave.error;
        if (this.#autosave?.dirty || this.#autosave?.saving) return "Saving…";
        return this.#candidate ? "Preview changes saved automatically" : "Changes saved automatically";
    }

    #updateSaveStatus() {
        const status = this.element?.querySelector("[data-save-status]");
        if (status) status.textContent = this.#saveStatus();
        const retry = this.element?.querySelector('[data-action="retrySave"]');
        if (retry) retry.hidden = !this.#autosave?.error;
    }

    async #saveSelection(values) {
        if (this.#closed) {
            ui.notifications.warn("The Location editor has closed. Reopen it to change this selection.");
            return false;
        }
        this.#captureForm();
        for (const [path, value] of Object.entries(values)) this.#session()?.set(path, value);
        return this.flushPendingSaves();
    }


    async #refreshHeader() {
        const entity = this.#entity;
        if (!entity || this.#closed) return;
        const name = this.element?.querySelector(".npc-data-editor-header h3");
        if (name) name.textContent = LocationEntityModel.getName(entity);
        const subtitle = this.element?.querySelector(".npc-data-editor-header p");
        if (subtitle) subtitle.textContent = LocationEntityModel.getSubtitle(entity);
        const src = LocationEntityModel.getThumbnail(entity);
        const viewport = this.element?.querySelector(".npc-data-editor-portrait");
        if (viewport && src) {
            let image = viewport.querySelector("img");
            if (!image) { image = document.createElement("img"); viewport.replaceChildren(image); }
            image.src = src; image.alt = LocationEntityModel.getName(entity);
        }
        if (this.#operation && this.#operation.id !== this.element.dataset.appliedOperation) {
            const sections = await LocationEditorSectionRegistry.renderFor(entity, { candidate: !!this.#candidate });
            for (const section of this.element.querySelectorAll("[data-location-editor-section]")) {
                section.innerHTML = sections.find(value => value.id === section.dataset.locationEditorSection)?.html || "";
            }
            this.element.dataset.appliedOperation = this.#operation.id;
        }
    }

    async #changeLocationIcon() {
        if (!await this.flushPendingSaves()) return;
        const entity = this.#entity;
        if (!entity) return;
        const icons = await SitePanel.getAllBuiltInIcons();
        const currentSrc = LocationEntityModel.getImage(entity);
        const currentIconId = icons.find(icon => icon.src === currentSrc)?.id || (currentSrc ? "custom" : null);
        new SiteIconPicker(icons, currentIconId, "landmark", selection => {
            const nextSrc = typeof selection === "object" && selection?.id === "custom"
                ? selection.src || ""
                : icons.find(icon => icon.id === selection)?.src || currentSrc;
            if (nextSrc) return this.#setLocationIcon(nextSrc);
        }, {
            currentCustomIconSrc: currentIconId === "custom" ? currentSrc : "",
            allBuiltInIcons: icons,
            showThemeIconsOnly: false,
            filterByRole: false
        }).render(true);
    }

    async #setLocationIcon(path) {
        if (path) return this.#saveSelection({ "display.imageSrc": path, "display.thumbnailSrc": "" });
    }

    #applyCandidatePatch(entity, patch) {
        this.#candidate = foundry.utils.mergeObject(foundry.utils.deepClone(entity), patch, { inplace: false, recursive: true });
        return foundry.utils.deepClone(this.#candidate);
    }

    #collectProfileFields(form) {
        return [...form.querySelectorAll("[data-profile-field-row]")]
            .map(row => ({
                id: row.querySelector("[name='profileField.id']")?.value || row.dataset.profileFieldRow || "",
                label: row.querySelector("[name='profileField.label']")?.value || "",
                value: row.querySelector("[name='profileField.value']")?.value || "",
                type: row.querySelector("[name='profileField.type']")?.value === "multiline" ? "multiline" : "text"
            }));
    }

    #buildOptions(options = []) {
        return [...new Set((Array.isArray(options) ? options : [])
            .map(option => String(option?.value || option?.label || option || "").trim())
            .filter(Boolean))];
    }

    #renderProfileFieldRow(field = {}) {
        const safe = value => foundry.utils.escapeHTML(String(value || ""));
        return `<input type="hidden" name="profileField.id" value="${safe(field.id)}"><input type="hidden" name="profileField.type" value="${safe(field.type || "text")}"><input type="text" name="profileField.label" value="${safe(field.label)}" placeholder="Field" autocomplete="off"><input type="text" name="profileField.value" value="${safe(field.value)}" placeholder="Value" autocomplete="off"><button type="button" class="npc-data-custom-field-move" data-action="moveProfileFieldUp" title="Move field up" aria-label="Move field up"><i class="fas fa-arrow-up"></i></button><button type="button" class="npc-data-custom-field-move" data-action="moveProfileFieldDown" title="Move field down" aria-label="Move field down"><i class="fas fa-arrow-down"></i></button><button type="button" class="npc-data-custom-field-delete" data-action="deleteProfileField" title="Delete field" aria-label="Delete field"><i class="fas fa-trash"></i></button>`;
    }

    #moveField(target, direction) {
        const row = target?.closest?.("[data-profile-field-row]");
        if (!row) return;
        if (direction < 0 && row.previousElementSibling?.matches("[data-profile-field-row]")) row.previousElementSibling.before(row);
        if (direction > 0 && row.nextElementSibling?.matches("[data-profile-field-row]")) row.nextElementSibling.after(row);
        void this.flushPendingSaves();
    }

    #getCenteredPosition() {
        const width = Math.max(460, Math.min(560, window.innerWidth - 40));
        const height = Math.max(600, Math.min(760, window.innerHeight - 40));
        return {
            width,
            height,
            left: Math.max(20, Math.round((window.innerWidth - width) / 2)),
            top: Math.max(20, Math.round((window.innerHeight - height) / 2))
        };
    }

    get #entity() {
        return this.#candidate || getLocation(this.#locationId);
    }
}
