import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { getPlayerEntityRevision } from "../../player-context/PlayerEntityRequests.js";
import { getShip, getShipGeneratorProfileOptions, updateShip } from "../../../api/ships.js";
import { promptTextInput } from "../../../api/ui.js";
import { ShipEntityModel } from "../models/ShipEntityModel.js";
import { ShipImagePicker } from "./ShipImagePicker.js";

import { EntityEditorAutosave } from "../services/EntityEditorAutosave.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const FIELD_DEFINITIONS = [
    { key: "model", label: "Model" },
    { key: "class", label: "Class" },
    { key: "role", label: "Role" },
    { key: "action", label: "Action" },
    { key: "theme", label: "Theme" },
    { key: "focus", label: "Focus" }
];

export class ShipDataEditor extends HandlebarsApplicationMixin(ApplicationV2) {
    #shipId = "";
    #candidate = null;
    #onSave = null;
    #autosave = null;
    #saveTimer = null;
    #formSnapshot = null;
    #listeners = null;
    #closed = false;
    #positionInitialized = false;

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-ship-data-editor",
        classes: ["augur-nexus", "npc-data-editor", "ship-data-editor", "augur-theme-fantasy"],
        tag: "div",
        window: { title: "Edit Ship", resizable: true, minimizable: true },
        position: { width: 440, height: 560 },
        actions: {
            retrySave: ShipDataEditor._onRetrySave,
            toggleCombo: ShipDataEditor._onToggleCombo,
            selectComboOption: ShipDataEditor._onSelectComboOption,
            renameShip: ShipDataEditor._onRenameShip,
            changeShipImage: ShipDataEditor._onChangeShipImage,
            addCustomField: ShipDataEditor._onAddCustomField,
            deleteCustomField: ShipDataEditor._onDeleteCustomField,
            toggleDefaultField: ShipDataEditor._onToggleDefaultField,
            moveCustomFieldUp: ShipDataEditor._onMoveCustomFieldUp,
            moveCustomFieldDown: ShipDataEditor._onMoveCustomFieldDown
        }
    };

    static PARTS = { content: { template: "modules/augur-nexus/templates/campaign-entities/ship-data-editor.hbs" } };

    static show({ shipId = "", candidate = null, onSave = null } = {}) {
        if ((!game.user.isGM && (!shipId || !canControlPlayerEntity(shipId))) || (!shipId && !candidate)) return null;
        const app = new this({ shipId, candidate, onSave });
        app.render(true, { focus: true });
        return app;
    }

    constructor({ shipId = "", candidate = null, onSave = null } = {}, options = {}) {
        super(options);
        this.#shipId = shipId || "";
        this.#candidate = candidate ? foundry.utils.deepClone(candidate) : null;
        this.#onSave = typeof onSave === "function" ? onSave : null;
    }

    async _prepareContext() {
        const entity = this.#session()?.draft;
        const hiddenDefaultFields = this.#getHiddenDefaultFields(entity);
        const profileOptions = await getShipGeneratorProfileOptions(entity?.generation?.generatorId || "");
        return {
            saveStatus: this.#saveStatus(),
            saveFailed: !!this.#autosave?.error,
            missing: !entity,
            ship: entity ? { id: entity.id, name: ShipEntityModel.getName(entity), subtitle: ShipEntityModel.getSubtitle(entity), imageSrc: ShipEntityModel.getImage(entity) } : { name: "Missing Ship" },
            fields: FIELD_DEFINITIONS.map(definition => {
                const value = String(entity?.profile?.[definition.key] || "");
                return { ...definition, value, hidden: hiddenDefaultFields.has(definition.key), options: this.#buildOptions(profileOptions.fields?.[definition.key] || [], value) };
            }),
            customFields: entity?.profile?.customFields || []
        };
    }

    _onRender(context, options) {
        super._onRender(context, options);
        if (!this.#positionInitialized) {
            this.setPosition(this.#getCenteredPosition());
            this.#positionInitialized = true;
        }
        this.#updateSaveStatus();
    }

    _attachPartListeners(partId, root, options) {
        super._attachPartListeners?.(partId, root, options);
        this.#listeners?.abort();
        this.#listeners = new AbortController();
        const { signal } = this.#listeners;
        const form = root.matches("form") ? root : root.querySelector("form");
        this.#formSnapshot = form ? this.#readForm(form) : null;
        form?.addEventListener("submit", event => { event.preventDefault(); void this.flushPendingSaves(); }, { signal });
        form?.addEventListener("input", () => {
            this.#captureForm();
            clearTimeout(this.#saveTimer);
            this.#saveTimer = setTimeout(() => { void this.flushPendingSaves(); }, 450);
        }, { signal });
        form?.addEventListener("change", () => { void this.flushPendingSaves(); }, { signal });
        root.addEventListener("click", event => {
            if (!event.target?.closest?.(".npc-data-combo")) this.#closeCombos();
        }, { signal });
    }

    static async _onRetrySave() {
        clearTimeout(this.#saveTimer);
        this.#captureForm();
        const saved = await this.#autosave?.retry();
        if (saved) await this.#refreshHeader();
        return saved;
    }

    static async _onRenameShip() {
        const entity = this.#getEntity();
        if (!entity) return;
        const name = await promptTextInput({ title: "Rename Ship", label: "Name", value: ShipEntityModel.getName(entity), confirmLabel: "Rename" });
        if (!name) return;
        await this.#saveSelection({ "display.name": name });
    }

    static async _onChangeShipImage() {
        if (!await this.flushPendingSaves()) return;
        const entity = this.#getEntity();
        if (!entity) return;
        const moduleData = entity.moduleData?.[entity.sourceModule] || entity.moduleData?.["augur-scifi"] || {};
        new ShipImagePicker({
            currentShipImageSrc: ShipEntityModel.getImage(entity),
            selectedModelId: moduleData.modelId || "",
            onSelect: selection => this.#setShipImage(selection)
        }).render(true, { focus: true });
    }

    static async _onToggleCombo(event, target) {
        const key = target?.dataset?.comboKey || "";
        const combo = key ? this.element.querySelector(`[data-combo="${CSS.escape(key)}"]`) : null;
        if (!combo) return;
        const wasOpen = combo.classList.contains("open");
        this.#closeCombos();
        combo.classList.toggle("open", !wasOpen);
        combo.querySelector("input")?.focus();
    }

    static async _onSelectComboOption(event, target) {
        const key = target?.dataset?.comboKey || "";
        const combo = key ? this.element.querySelector(`[data-combo="${CSS.escape(key)}"]`) : null;
        const input = combo?.querySelector("input");
        if (!input) return;
        input.value = target?.dataset?.comboValue || "";
        this.#closeCombos();
        input.focus();
        await this.flushPendingSaves();
    }

    static async _onAddCustomField() {
        const container = this.element.querySelector("[data-custom-fields]");
        if (!container) return;
        const id = `field.${foundry.utils.randomID()}`;
        const row = document.createElement("div");
        row.className = "npc-data-custom-field-row";
        row.dataset.customFieldRow = id;
        row.innerHTML = this.#renderCustomFieldRow({ id, label: "", value: "" });
        container.append(row);
        row.querySelector("[name='customField.label']")?.focus();
        await this.flushPendingSaves();
    }

    static async _onDeleteCustomField(event, target) { target?.closest?.("[data-custom-field-row]")?.remove(); await this.flushPendingSaves(); }
    static async _onToggleDefaultField(event, target) { this.#toggleDefaultFieldButton(target); }
    static async _onMoveCustomFieldUp(event, target) { this.#moveCustomField(target, -1); }
    static async _onMoveCustomFieldDown(event, target) { this.#moveCustomField(target, 1); }

    #session() {
        if (this.#autosave) return this.#autosave;
        const entity = this.#getEntity();
        if (!entity) return null;
        this.#autosave = new EntityEditorAutosave(entity, {
            label: "Ship", read: () => this.#getEntity(),
            write: (patch, current) => this.#writePatch(patch, current),
            changed: () => this.#updateSaveStatus()
        });
        return this.#autosave;
    }

    async #writePatch(patch, current) {
        if (patch.profile?.customFields?.some(field => !field.label.trim() && field.value.trim())) {
            throw new Error("Add a label to each custom field containing a value. Your input is retained.");
        }
        // Module namespaces are replaced by the store; preserve their latest unrelated fields.
        const moduleId = Object.keys(patch.moduleData || {})[0] || "";
        if (moduleId) patch.moduleData[moduleId] = { ...current.moduleData?.[moduleId], ...patch.moduleData[moduleId] };
        const updated = this.#candidate
            ? this.#applyCandidatePatch(current, patch)
            : await updateShip(current.id, patch, { moduleId, expectedRevision: getPlayerEntityRevision(current) });
        if (this.#candidate) await this.#onSave?.(updated);
        else {
            try { await this.#onSave?.(updated); }
            catch (error) { console.error("Augur Nexus | Ship editor refresh failed", error); }
        }
        return updated;
    }

    #readForm(form) {
        const data = new FormData(form);
        return {
            ...Object.fromEntries(FIELD_DEFINITIONS.map(field => [`profile.${field.key}`, String(data.get(`profile.${field.key}`) || "").trim()])),
            "profile.customFields": this.#collectCustomFields(form),
            "dossier.hiddenDefaultFields": this.#collectHiddenDefaultFields(form)
        };
    }

    #captureForm() {
        const form = this.element?.querySelector("form");
        if (!form || !this.#formSnapshot) return;
        const next = this.#readForm(form);
        for (const [path, value] of Object.entries(next)) {
            if (JSON.stringify(value) !== JSON.stringify(this.#formSnapshot[path])) this.#session()?.set(path, value);
        }
        this.#formSnapshot = next;
    }

    async flushPendingSaves() {
        clearTimeout(this.#saveTimer);
        this.#saveTimer = null;
        this.#captureForm();
        if (!this.#autosave) return true;
        const saved = await this.#autosave.flush();
        this.#updateSaveStatus();
        if (saved) await this.#refreshHeader();
        return saved;
    }

    async close(options = {}) {
        if (!await this.flushPendingSaves()) {
            ui.notifications.error(this.#autosave.error);
            return this;
        }
        this.#listeners?.abort();
        clearTimeout(this.#saveTimer);
        this.#closed = true;
        return super.close(options);
    }

    #saveStatus() {
        if (this.#autosave?.error) return this.#autosave.error;
        if (this.#autosave?.dirty || this.#autosave?.saving) return "Saving…";
        return this.#candidate ? "Preview changes saved automatically" : "Changes saved automatically";
    }

    #updateSaveStatus() {
        const status = this.element?.querySelector("[data-save-status]");
        if (status) status.textContent = this.#saveStatus();
        const retry = this.element?.querySelector('[data-action="retrySave"]');
        if (retry) retry.hidden = !this.#autosave?.error;
    }

    async #saveSelection(values) {
        if (this.#closed) {
            ui.notifications.warn("The Ship editor has closed. Reopen it to change this selection.");
            return false;
        }
        this.#captureForm();
        for (const [path, value] of Object.entries(values)) this.#session()?.set(path, value);
        if (Object.hasOwn(values, "profile.model")) {
            const input = this.element?.querySelector('[name="profile.model"]');
            if (input) input.value = values["profile.model"];
            if (this.#formSnapshot) this.#formSnapshot["profile.model"] = values["profile.model"];
        }
        return this.flushPendingSaves();
    }


    async #refreshHeader() {
        const entity = this.#autosave?.draft || this.#getEntity();
        if (!entity || this.#closed) return;
        const name = this.element?.querySelector(".npc-data-editor-header h3");
        if (name) name.textContent = ShipEntityModel.getName(entity);
        const subtitle = this.element?.querySelector(".npc-data-editor-header p");
        if (subtitle) subtitle.textContent = ShipEntityModel.getSubtitle(entity);
        const src = ShipEntityModel.getImage(entity);
        const viewport = this.element?.querySelector(".npc-data-editor-portrait");
        if (viewport && src) {
            let image = viewport.querySelector("img");
            if (!image) { image = document.createElement("img"); viewport.replaceChildren(image); }
            image.src = src; image.alt = ShipEntityModel.getName(entity);
        }
    }

    async #setShipImage(selection = {}) {
        const entity = this.#getEntity();
        if (!entity || !selection.src) return;
        const moduleId = entity.sourceModule || "augur-scifi";
        const values = {
            "display.imageSrc": selection.src,
            [`moduleData.${moduleId}.modelId`]: selection.modelId || "",
            [`moduleData.${moduleId}.styleId`]: selection.styleId || ""
        };
        if (!selection.custom && selection.modelLabel) values["profile.model"] = selection.modelLabel;
        return this.#saveSelection(values);
    }

    #getEntity() { return this.#candidate || getShip(this.#shipId); }
    #applyCandidatePatch(entity, patch) { this.#candidate = foundry.utils.mergeObject(foundry.utils.deepClone(entity), patch, { inplace: false, recursive: true }); return foundry.utils.deepClone(this.#candidate); }
    #buildOptions(options = [], currentValue = "") {
        const values = new Set((options || []).map(option => String(option?.value || option?.label || option || "").trim()).filter(Boolean));
        if (currentValue) values.add(currentValue);
        return [...values].map(value => ({ value, label: value, selected: value === currentValue }));
    }
    #getHiddenDefaultFields(entity = {}) { return new Set(Array.isArray(entity?.dossier?.hiddenDefaultFields) ? entity.dossier.hiddenDefaultFields : []); }
    #collectHiddenDefaultFields(form) { return [...form.querySelectorAll("input[name='defaultFieldHidden']:checked")].map(input => input.value).filter(Boolean); }
    #collectCustomFields(form) {
        return [...form.querySelectorAll("[data-custom-field-row]")].map(row => ({ id: row.querySelector("[name='customField.id']")?.value || row.dataset.customFieldRow || "", label: row.querySelector("[name='customField.label']")?.value || "", value: row.querySelector("[name='customField.value']")?.value || "" }));
    }
    #renderCustomFieldRow(field = {}) {
        const safe = value => foundry.utils.escapeHTML(String(value || ""));
        return `<input type="hidden" name="customField.id" value="${safe(field.id)}"><input type="text" name="customField.label" value="${safe(field.label)}" placeholder="Field" autocomplete="off"><input type="text" name="customField.value" value="${safe(field.value)}" placeholder="Value" autocomplete="off"><button type="button" class="npc-data-custom-field-move" data-action="moveCustomFieldUp" title="Move field up" aria-label="Move field up"><i class="fas fa-arrow-up"></i></button><button type="button" class="npc-data-custom-field-move" data-action="moveCustomFieldDown" title="Move field down" aria-label="Move field down"><i class="fas fa-arrow-down"></i></button><button type="button" class="npc-data-custom-field-delete" data-action="deleteCustomField" title="Delete field" aria-label="Delete field"><i class="fas fa-trash"></i></button>`;
    }
    #toggleDefaultFieldButton(target) {
        const button = target?.closest?.(".npc-data-field-visibility") || target;
        const input = button?.querySelector?.("input[name='defaultFieldHidden']");
        if (!input) return;
        input.checked = !input.checked;
        button.classList.toggle("is-hidden-field", input.checked);
        button.title = input.checked ? "Show field" : "Hide field";
        button.setAttribute("aria-label", button.title);
        const icon = button.querySelector("i");
        icon?.classList.toggle("fa-eye", !input.checked);
        icon?.classList.toggle("fa-eye-slash", input.checked);
        void this.flushPendingSaves();
    }
    #moveCustomField(target, direction) {
        const row = target?.closest?.("[data-custom-field-row]");
        if (!row) return;
        if (direction < 0 && row.previousElementSibling) row.previousElementSibling.before(row);
        if (direction > 0 && row.nextElementSibling) row.nextElementSibling.after(row);
        void this.flushPendingSaves();
    }
    #closeCombos() { for (const combo of this.element.querySelectorAll(".npc-data-combo.open")) combo.classList.remove("open", "drop-up"); }
    #getCenteredPosition() {
        const width = Math.max(380, Math.min(460, window.innerWidth - 40));
        const height = Math.max(500, Math.min(640, window.innerHeight - 40));
        return { width, height, left: Math.max(20, Math.round((window.innerWidth - width) / 2)), top: Math.max(20, Math.round((window.innerHeight - height) / 2)) };
    }
}
