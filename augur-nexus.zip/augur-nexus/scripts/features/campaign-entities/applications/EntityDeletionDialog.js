import { CampaignEntityDeletion } from "../services/CampaignEntityDeletion.js";
import { ConnectionEditingWorkflow } from "../../connections/services/ConnectionEditingWorkflow.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class EntityDeletionDialog extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
        classes: ["augur-nexus", "augur-theme-fantasy", "entity-deletion-dialog"],
        window: { title: "Delete Campaign Object", resizable: true },
        position: { width: 510, height: "auto" },
        actions: {
            cancel: function() { return this.close(); },
            removeConnection: function() { return this.submit("connection"); },
            deleteEntity: function() { return this.submit("entity"); }
        }
    };
    static PARTS = { content: { template: "modules/augur-nexus/templates/campaign-entities/entity-deletion-dialog.hbs" } };
    static show(plan, options) {
        return new Promise((resolve, reject) => {
            const app = new this();
            app.plan = plan; app.deletionContext = options; app.resolve = resolve;
            app.render({ force: true }).catch(reject);
        });
    }
    busy = false;
    error = "";
    result = false;
    get title() { return `Delete ${this.plan?.label || "Campaign Object"}`; }
    async _prepareContext() {
        const pending = CampaignEntityDeletion.pending.has(this.plan.id);
        const edge = this.deletionContext?.edgeId && ConnectionEditingWorkflow.belongsTo(this.deletionContext.edgeId, this.deletionContext.ownerNodeId);
        return { ...this.plan, busy: this.busy, error: this.error, pending,
            canRemoveConnection: !pending && !!edge && [edge.sourceNodeId, edge.targetNodeId].includes(this.plan.nodeId) };
    }
    async submit(choice) {
        if (this.busy) return;
        this.busy = true; this.error = "";
        try {
            await this.render();
            CampaignEntityDeletion.requireGM();
            if (choice === "connection") {
                const edge = ConnectionEditingWorkflow.belongsTo(this.deletionContext.edgeId, this.deletionContext.ownerNodeId);
                if (!edge || ![edge.sourceNodeId, edge.targetNodeId].includes(this.plan.nodeId)) throw new Error("This connection no longer exists.");
                await ConnectionEditingWorkflow.remove(this.deletionContext.edgeId, this.deletionContext.ownerNodeId);
                this.result = "connection";
            } else {
                const pending = CampaignEntityDeletion.pending.get(this.plan.id);
                const latest = pending ? CampaignEntityDeletion.previewCleanup(pending) : CampaignEntityDeletion.preview(this.plan.type, this.plan.id);
                if (!latest) throw new Error("This object no longer exists.");
                if (latest.fingerprint !== this.plan.fingerprint) {
                    this.plan = latest;
                    throw new Error("Deletion impact changed. Review this updated summary and confirm again.");
                }
                if (!await CampaignEntityDeletion.execute(this.plan)) throw new Error("This object could not be deleted.");
                this.result = "deleted";
            }
            try { await this.deletionContext?.onChanged?.(); }
            catch (error) { ui.notifications.error(`The change completed, but the view could not refresh: ${error.message}`); }
            this.busy = false;
            await this.close();
        } catch (error) {
            this.error = error.message;
            const pending = CampaignEntityDeletion.pending.get(this.plan.id);
            if (pending) {
                try { this.plan = CampaignEntityDeletion.previewCleanup(pending); }
                catch { /* Keep the last impact summary if the database is unavailable. */ }
            }
        }
        finally { this.busy = false; if (!this.result) this.render(); }
    }
    async close(options) {
        if (this.busy) return this;
        const result = await super.close(options);
        this.resolve?.(this.result);
        return result;
    }
}
