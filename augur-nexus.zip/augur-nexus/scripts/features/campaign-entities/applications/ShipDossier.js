import { attachDossierHelpButton } from "../../../api/help.js";
import { openEntityDossierVisibility, renderDossierControls, bindDossierControls } from "../components/DossierHeaderControls.js";
import { prepareNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";
import { prepareDossierCover, prepareDossierBackdrop } from "../../../support/appearance/DossierCoverPresentation.js";
import { DossierCompactSections } from "../components/DossierCompactSections.js";
import { bindConnectedObjectMenus, openConnectedObjectMenu } from "../../connections/services/ConnectedObjectMenu.js";
import { CampaignEntityDeletion } from "../services/CampaignEntityDeletion.js";
import { CampaignEntityCreation } from "../services/CampaignEntityCreation.js";
import { bindEntityDisclosureControls, openEntityDisclosureMenu } from "../services/EntityDisclosureControls.js";
import { ConnectionEditingWorkflow } from "../../connections/services/ConnectionEditingWorkflow.js";
import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { canRerollShipCurrentAssignment, getShip, rerollShipCurrentAssignment, updateShip } from "../../../api/ships.js";
import { openActionMenu, promptTextInput } from "../../../api/ui.js";
import { ConnectionsBoard } from "../../connections/components/ConnectionsBoard.js";
import { ConnectionDropResolver } from "../../connections/services/ConnectionDropResolver.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { ShipCaptainService } from "../../connections/services/ShipCaptainService.js";
import { ShipCrewService } from "../../connections/services/ShipCrewService.js";
import { ShipLocationService } from "../../connections/services/ShipLocationService.js";
import { ShipOwnershipService } from "../../connections/services/ShipOwnershipService.js";
import { NexusMarkerService } from "../../markers/services/NexusMarkerService.js";
import { SiteCoverPicker } from "../../site/applications/SiteCoverPicker.js";
import { SiteCoverCatalog } from "../../site/services/SiteCoverCatalog.js";
import { ShipDossierTabRegistry } from "../services/ShipDossierTabRegistry.js";
import { ShipDossierPresentationRegistry } from "../services/ShipDossierPresentationRegistry.js";
import { ShipEntityModel } from "../models/ShipEntityModel.js";
import { ShipProfileViewModel } from "../models/ShipProfileViewModel.js";
import { ShipDomainViewModel } from "../models/ShipDomainViewModel.js";
import { CampaignEntityActorBridge } from "../services/CampaignEntityActorBridge.js";
import { CampaignEntityDossierRefresh } from "../services/CampaignEntityDossierRefresh.js";
import { CampaignEntityJournalStore } from "../services/CampaignEntityJournalStore.js";
import { CampaignEntityVisibilityManager } from "../services/CampaignEntityVisibilityManager.js";
import { PlayerNpcVisibilityDialog } from "../../nexus/applications/PlayerNpcVisibilityDialog.js";
import { openHelp } from "../../../api/help.js";
import { DossierTabPreference } from "../../nexus/services/DossierTabPreference.js";
import { applySessionWindowPlacement, rememberSessionWindowPlacement } from "/modules/augur-nexus/scripts/api/window-placement.js";
import { ShipDataEditor } from "./ShipDataEditor.js";
import { EntityArtworkApplication } from "./EntityArtworkApplication.js";
import { ShipImagePicker } from "./ShipImagePicker.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const PLACEMENT_KEY = "augur-nexus.ship-dossier";
const COMPACT_WIDTH = 420;
let shipDossierCompactPreference = false;

export class ShipDossier extends HandlebarsApplicationMixin(ApplicationV2) {
    #shipId = "";
    #contentHost = null;
    #disposed = false;
    #contentScroll = [];
    #compactSections;
    #activeTab = "profile";
    #collectionTab = "crew";
    #connectionsBoard = null;
    #connectionsChangedHook = null;
    #entitiesChangedHook = null;
    #lastModel = null;
    #positionInitialized = false;
    #isCompact = false;
    #expandedPosition = null;
    #actorHooks = [];

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-ship-dossier",
        classes: ["augur-nexus", "npc-dossier", "ship-dossier", "augur-theme-fantasy"],
        tag: "div",
        window: { title: "Ship", resizable: true, minimizable: true },
        position: { width: 1420, height: 780 },
        actions: {
            toggleDossierCompactSection: function (_event, button) {
                if (this.#isCompact) return this.#compactSections.toggle(this.#shipId, button.dataset.section, () => this.render({ parts: ["content"] }), () => this.contentElement);
            },
            entityDisclosureMenu: function(_event, button) { return openEntityDisclosureMenu(this.#shipId, button, "ship"); },
            openShipCommandMenu: function (event, button) {
                event.stopPropagation();
                this.#openDomainCardMenu(button, button.dataset.kind);
            },
            openShipConnectionMenu: function (event, button) {
                event.stopPropagation();
                this.#openConnectionMenu(button);
            },
            setShipDossierTab: function (_event, target) {
                const tab = target.dataset.tab;
                this.#activeTab = ["profile", "journal", "connections", ...(this.#lastModel?.extensionTabs || []).map(entry => entry.id)].includes(tab) ? tab : "profile";
                this.render({ parts: ["content"] });
            },
            openShipDossierActor: function () { return this.#openLinkedActor(); },
            setShipCollectionTab: function (_event, target) {
                this.#collectionTab = target.dataset.tab === "ties" ? "ties" : "crew";
                this.render({ parts: ["content"] });
            }
        }
    };

    static PARTS = {
        content: {
            template: "modules/augur-nexus/templates/campaign-entities/ship-dossier.hbs",
            scrollable: [".ship-profile-scroll", ".connections-map"],
            templates: [
                "modules/augur-nexus/templates/campaign-entities/compact-section-heading.hbs",
                "modules/augur-nexus/templates/campaign-entities/ship-crew-manifest.hbs",
                "modules/augur-nexus/templates/campaign-entities/ship-world-ties.hbs",
                "modules/augur-nexus/templates/campaign-entities/quest-world-ties.hbs",
                "modules/augur-nexus/templates/connections/connections-board.hbs",
                "modules/augur-nexus/templates/connections/dossier-connections-surface.hbs",
                "modules/augur-nexus/templates/campaign-entities/ship-profile-panel.hbs",
                "modules/augur-nexus/templates/campaign-entities/ship-command-cards.hbs",
                "modules/augur-nexus/templates/campaign-entities/ship-location-control.hbs",
                "modules/augur-nexus/templates/campaign-entities/ship-domain-overview.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-portrait.hbs",
                "modules/augur-nexus/templates/campaign-entities/ship-assignment.hbs",
                "modules/augur-nexus/templates/site/site-cover-picker.hbs"
            ]
        }
    };

    get title() { return this.#lastModel?.ship?.name || "Ship"; }

    static show({ shipId } = {}) {
        if (!shipId) return null;
        const app = new this({ shipId });
        app.render(true, { focus: true });
        return app;
    }

    constructor({ shipId, contentHost = null } = {}, options = {}) {
        super(options);
        this.#shipId = shipId || "";
        this.#contentHost = contentHost;
        this.#compactSections = new DossierCompactSections({ sections: ["information", "thread", "crew", "ties"], sessionKey: `ship:${this.#shipId}` });
        this.#isCompact = shipDossierCompactPreference;
        this.#activeTab = DossierTabPreference.getDefaultTab(getShip(this.#shipId));
        this.#connectionsChangedHook = () => this.refresh();
        this.#entitiesChangedHook = event => { if (!event?.entity || event.entity.id === this.#shipId) this.refresh(); };
        Hooks.on("augurNexusConnectionsChanged", this.#connectionsChangedHook);
        Hooks.on("augurNexusAppearanceChanged", this.#connectionsChangedHook);
        Hooks.on("augurNexusCampaignEntitiesChanged", this.#entitiesChangedHook);
        CampaignEntityDossierRefresh.watch(this);
        const refreshActor = actor => {
            const uuid = getShip(this.#shipId)?.projections?.actorUuid;
            if (actor.uuid === uuid || actor.uuid === this.#lastModel?.ship?.profile?.linkedActor?.uuid) this.refresh();
        };
        for (const hook of ["updateActor", "deleteActor"]) this.#actorHooks.push([hook, Hooks.on(hook, refreshActor)]);
    }

    // Both hosts use this controller and the complete dossier template. Only the
    // enclosing window, navigation and available width belong to the host.
    get connectionExplorerHost() { return this.#contentHost?.connectionExplorer; }
    get contentElement() { return this.#contentHost?.element() || this.element; }
    render(...args) {
        if (!this.#contentHost) return super.render(...args);
        if (this.#disposed) return Promise.resolve(this);
        this.#contentHost.onStateChange?.(this.snapshotContent());
        return this.#contentHost.redraw();
    }
    snapshotContent() {
        const selectors = [".ship-profile-scroll", ".ship-domain-collection", ".npc-dossier-journal-body", ".connections-board-list", ".connections-map"];
        if (this.contentElement) this.#contentScroll = selectors.flatMap(selector => {
            const element = this.contentElement.querySelector(selector);
            return element ? [{ selector, top: element.scrollTop, left: element.scrollLeft }] : [];
        });
        return { tab: this.#activeTab, collection: this.#collectionTab, sections: this.#compactSections.snapshot(), connections: this.#connectionsBoard?.snapshot() || this.#boardSession, scroll: this.#contentScroll };
    }
    #boardSession = null;
    restoreContent(state = {}) {
        this.#boardSession = state.connections || null;
        if (this.#connectionsBoard && this.#boardSession) this.#connectionsBoard.restore(this.#boardSession);
        this.#activeTab = state.tab || "profile";
        this.#collectionTab = state.collection === "ties" ? "ties" : "crew";
        if (state.sections) this.#compactSections.restore(state.sections);
        this.#contentScroll = state.scroll || [];
    }
    async prepareContent({ compact, tab } = {}) {
        this.#isCompact = compact === true;
        if (tab) this.#activeTab = tab;
        const model = await this._prepareContext();
        await foundry.applications.handlebars.loadTemplates(ShipDossier.PARTS.content.templates);
        const html = await foundry.applications.handlebars.renderTemplate(ShipDossier.PARTS.content.template, model);
        return `<div class="ship-dossier npc-dossier nexus-workspace-ship-content">${html}</div>`;
    }
    activateContent(root) {
        if (!root) return;
        bindConnectedObjectMenus(root, { getOwner: () => ConnectionTargetResolver.fromCampaignEntity(getShip(this.#shipId)),
            navigation: node => this.#contentHost?.navigation?.(node), onChanged: () => this.refresh(),
            getItems: ({ edge, card }) => this.#connectionsBoard?.getCardItems(edge.id, this, card) });
        this.#activateActionListeners(root);
        this.#connectionsBoard?.activateListeners(root, this);
        for (const position of this.#contentScroll) {
            const element = root.querySelector(position.selector);
            if (element) { element.scrollTop = position.top; element.scrollLeft = position.left; }
        }
        if (root.dataset.shipContentBound) return;
        root.dataset.shipContentBound = "true";
        root.addEventListener("click", event => {
            const button = event.target.closest("[data-action]");
            const handler = ShipDossier.DEFAULT_OPTIONS.actions[button?.dataset.action];
            if (!handler) return;
            event.preventDefault(); event.stopPropagation();
            void handler.call(this, event, button);
        });
    }
    handlesContentAction(action) { return Object.hasOwn(ShipDossier.DEFAULT_OPTIONS.actions, action); }
    handleContentAction(action, button) { return ShipDossier.DEFAULT_OPTIONS.actions[action]?.call(this, { stopPropagation() {}, preventDefault() {} }, button); }
    openContentNode(node) { return this.#contentHost?.openNode ? this.#contentHost.openNode(node) : ConnectionTargetResolver.openNode(node); }

    async _prepareContext() {
        const entity = getShip(this.#shipId);
        if (!entity) return { missing: true, ship: { name: "Missing Ship" }, connections: { board: null } };
        const target = ConnectionTargetResolver.fromCampaignEntity(entity);
        await ShipLocationService.adoptExistingMarkerLocation(target);
        if (!this.#connectionsBoard) this.#connectionsBoard = new ConnectionsBoard({ target, getCompact: () => this.#isCompact, isGM: game.user.isGM, openNode: node => this.openContentNode(node), getNavigationItems: node => this.#contentHost?.navigation?.(node) });
        else this.#connectionsBoard.setTarget(target);
        if (this.#boardSession) { this.#connectionsBoard.restore(this.#boardSession); this.#boardSession = null; }
        const associatedPage = CampaignEntityJournalStore.getJournalPage(entity.id);
        const page = game.user.isGM || associatedPage?.testUserPermission?.(game.user, "OBSERVER") ? associatedPage : null;
        const content = await this.#enrichJournalContent(page);
        const linkedActor = await this.#getLinkedActorContext(entity);
        const actor = linkedActor?.uuid ? await fromUuid(linkedActor.uuid) : null;
        const extensionTabs = await ShipDossierTabRegistry.buildTabs({ actor, entity });
        if (!["profile", "journal", "connections", ...extensionTabs.map(tab => tab.id)].includes(this.#activeTab)) this.#activeTab = "profile";
        for (const tab of extensionTabs) tab.active = tab.id === this.#activeTab;
        const domain = ShipDomainViewModel.fromEntity(entity, { isGM: game.user.isGM, canEdit: canControlPlayerEntity(this.#shipId) });
        const assignment = ShipProfileViewModel.assignmentFromEntity(entity);
        const appearance = prepareNexusThemeSurface();
        const model = {
            ship: {
                id: entity.id,
                name: ShipEntityModel.getName(entity),
                profile: ShipProfileViewModel.fromEntity(entity, {
                    showTabs: true,
                    showCompactToggle: true,
                    compactMode: this.#isCompact,
                    ...(this.#isCompact ? this.#compactSections.context(entity.id) : {}),
                    showActions: canControlPlayerEntity(this.#shipId),
                    activeTab: this.#activeTab,
                    linkedActor,
                    extensionTabs,
                    showAssignmentChips: false,
                    showBody: this.#activeTab === "profile"
                })
            },
            domain,
            extensionTabs,
            activeExtension: extensionTabs.find(tab => tab.active) || null,
            assignment,
            canRerollCurrentAssignment: canControlPlayerEntity(this.#shipId) && canRerollShipCurrentAssignment(entity),
            dossier: {
                isCompact: this.#isCompact,
                isCrewTab: this.#collectionTab === "crew",
                isWorldTiesTab: this.#collectionTab === "ties",
                isProfileTab: this.#activeTab === "profile",
                isJournalTab: this.#activeTab === "journal",
                isConnectionsTab: this.#activeTab === "connections"
            },
            journal: { hasPage: !!page, entryId: page?.parent?.id || entity.journalEntryId || "", pageId: page?.id || "", content, hasContent: !!String(page?.text?.content || "").trim() },
            connections: { board: this.#connectionsBoard.getContext() },
            appearance,
            dossierCover: (appearance.mode === "light" ? prepareDossierBackdrop : prepareDossierCover)(ShipEntityModel.getCoverImage(entity) || ShipDossierPresentationRegistry.getBackground(entity)
                || SiteCoverCatalog.getAbstractCover(entity.id || ShipEntityModel.getName(entity) || "ship")),
            isGM: game.user.isGM, canCreateRelated: game.user.isGM, canEdit: canControlPlayerEntity(this.#shipId)
        };
        model.ship.profile.controlsHtml = await renderDossierControls({ entity, canEdit: model.canEdit, compact: this.#isCompact, compactAction: "toggleShipDossierCompact", popout: !!this.#contentHost });
        model.connectionsHeader = {
            name: model.ship.profile.name, subtitle: model.ship.profile.subtitle,
            imageSrc: model.ship.profile.imageSrc, fallbackIcon: "fas fa-rocket",
            canDrag: game.user.isGM,
            controlsHtml: model.ship.profile.controlsHtml,
            tabs: [
                ...extensionTabs.map(tab => ({ id: tab.id, label: tab.label, active: tab.active, action: "setShipDossierTab" })),
                ...["profile", "journal", "connections"].map(id => ({ id, label: id[0].toUpperCase() + id.slice(1), active: this.#activeTab === id, action: "setShipDossierTab" })),
                ...(linkedActor ? [{ id: "linked-actor", label: "Open linked Actor", icon: "fas fa-user-circle", action: "openShipLinkedActor" }] : [])
            ]
        };
        this.#lastModel = model;
        return model;
    }

    _attachPartListeners(partId, htmlElement, options) {
        if (super._attachPartListeners) super._attachPartListeners(partId, htmlElement, options);
        this.#activateActionListeners(htmlElement instanceof HTMLElement ? htmlElement : htmlElement?.[0]);
    }

    _onRender(context, options) {
        super._onRender(context, options);
        attachDossierHelpButton(this, "ship");
        bindConnectedObjectMenus(this.contentElement, { getOwner: () => ConnectionTargetResolver.fromCampaignEntity(getShip(this.#shipId)), onChanged: () => this.refresh(), getItems: ({ edge, card }) => this.#connectionsBoard?.getCardItems(edge.id, this, card) });
        if (this.window?.title) this.window.title.textContent = this.title;
        this.#activateActionListeners(this.contentElement);
        this.#connectionsBoard?.activateListeners(this.contentElement, this);
        if (!this.#positionInitialized) {
            const expanded = applySessionWindowPlacement(this, PLACEMENT_KEY, { fallback: "center" });
            if (this.#isCompact) {
                this.#expandedPosition = expanded ? { ...expanded } : this.#getCurrentPosition();
                this.#applyCompactPosition(this.#expandedPosition);
            }
            this.#positionInitialized = true;
        }
    }

    async close(options) {
        for (const [hook, id] of this.#actorHooks) Hooks.off(hook, id);
        this.#actorHooks = [];
        if (!this.#contentHost && !this.#isCompact) rememberSessionWindowPlacement(this, PLACEMENT_KEY);
        CampaignEntityDossierRefresh.unwatch(this);
        if (this.#connectionsChangedHook) Hooks.off("augurNexusConnectionsChanged", this.#connectionsChangedHook);
        if (this.#connectionsChangedHook) Hooks.off("augurNexusAppearanceChanged", this.#connectionsChangedHook);
        if (this.#entitiesChangedHook) Hooks.off("augurNexusCampaignEntitiesChanged", this.#entitiesChangedHook);
        await this.#connectionsBoard?.destroy();
        this.#disposed = true;
        return this.#contentHost ? this : super.close(options);
    }

    matchesCampaignEntityJournal({ entryId, pageId } = {}) {
        const journal = this.#lastModel?.journal || null;
        if (!journal?.entryId) return false;
        if (pageId) return journal.pageId === pageId;
        return journal.entryId === entryId;
    }

    refreshCampaignEntityDossier() { this.refresh(); }

    refresh() { if (!this.#disposed && (this.#contentHost || this.rendered !== false)) this.render({ parts: ["content"] }); }

    #activateActionListeners(element) {
        bindDossierControls(element, { edit: () => this.#editShip(), options: anchor => this.#openActions(anchor), visibility: anchor => this.#openShipVisibilityMenu(anchor), popout: () => ShipDossier.show({ shipId: this.#shipId }) });
        bindEntityDisclosureControls(element, () => this.#shipId, { type: "ship" });
        if (!element) return;
        for (const shipImage of element.querySelectorAll("[data-ship-dossier-drag='true'], [data-dossier-object-drag]")) {
            if (shipImage.dataset.shipDossierDragBound) continue;
            shipImage.dataset.shipDossierDragBound = "true";
            shipImage.addEventListener("dragstart", event => {
                const ship = getShip(this.#shipId);
                const target = ship ? ConnectionTargetResolver.fromCampaignEntity(ship) : null;
                if (!ConnectionTargetResolver.setDragData(event.dataTransfer, target, { effectAllowed: "copy" })) event.preventDefault();
            });
        }
        const compactButton = element.querySelector("[data-action='toggleShipDossierCompact']");
        if (compactButton && !compactButton.dataset.shipDossierBound) compactButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            void this.#toggleCompactMode();
        });
        if (compactButton) compactButton.dataset.shipDossierBound = "true";
        const rerollAssignmentButton = element.querySelector("[data-action='rerollShipCurrentAssignment']");
        if (rerollAssignmentButton && !rerollAssignmentButton.dataset.shipDossierBound) rerollAssignmentButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            void this.#rerollCurrentAssignment(event.currentTarget);
        });
        if (rerollAssignmentButton) rerollAssignmentButton.dataset.shipDossierBound = "true";
        const createCrewButton = element.querySelector("[data-action='createShipCrewMember']");
        if (createCrewButton && !createCrewButton.dataset.shipDossierBound) createCrewButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            this.#createCrewMember(event.currentTarget);
        });
        if (createCrewButton) createCrewButton.dataset.shipDossierBound = "true";
        const actionsButton = element.querySelector("[data-action='openShipActions']");
        if (actionsButton && !actionsButton.dataset.shipDossierBound) actionsButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            this.#openActions(event.currentTarget);
        });
        if (actionsButton) actionsButton.dataset.shipDossierBound = "true";

        const createJournalButton = element.querySelector("[data-action='createShipJournal']");
        if (createJournalButton && !createJournalButton.dataset.shipDossierBound) createJournalButton.addEventListener("click", event => {
            event.preventDefault();
            this.#editJournal({ create: true });
        });
        if (createJournalButton) createJournalButton.dataset.shipDossierBound = "true";

        const openJournalButton = element.querySelector("[data-action='openShipJournal']");
        if (openJournalButton && !openJournalButton.dataset.shipDossierBound) openJournalButton.addEventListener("click", event => {
            event.preventDefault();
            this.#editJournal({ create: false });
        });
        if (openJournalButton) openJournalButton.dataset.shipDossierBound = "true";

        const openLinkedActorButton = element.querySelector("[data-action='openShipLinkedActor']");
        if (openLinkedActorButton && !openLinkedActorButton.dataset.shipDossierBound) openLinkedActorButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            void this.#openLinkedActor();
        });
        if (openLinkedActorButton) openLinkedActorButton.dataset.shipDossierBound = "true";

        const linkActorButton = element.querySelector("[data-action='linkShipActor']");
        if (linkActorButton && !linkActorButton.dataset.shipDossierBound) linkActorButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            void this.#linkActor();
        });
        if (linkActorButton) linkActorButton.dataset.shipDossierBound = "true";

        element.querySelectorAll("[data-ship-domain-node]").forEach(card => {
            if (card.dataset.shipDomainBound) return;
            card.dataset.shipDomainBound = "true";
            card.addEventListener("click", async event => {
                const node = ConnectionStore.getNode(event.currentTarget.dataset.shipDomainNode || "");
                if (node) await this.openContentNode(node);
            });
            if (card.draggable) card.addEventListener("dragstart", event => {
                const node = ConnectionStore.getNode(card.dataset.shipDomainNode || "");
                event.stopPropagation();
                if (!ConnectionTargetResolver.setDragData(event.dataTransfer, node, { effectAllowed: "copyMove" })) event.preventDefault();
            });
        });
        element.querySelectorAll("[data-ship-domain-menu]").forEach(card => {
            if (card.dataset.shipDomainMenuBound) return;
            card.dataset.shipDomainMenuBound = "true";
            card.addEventListener("contextmenu", event => {
                event.preventDefault();
                event.stopPropagation();
                this.#openDomainCardMenu(event.currentTarget, event.currentTarget.dataset.shipDomainMenu || "");
            });
        });
        this.#activateDomainDrops(element);
    }

    #openDomainCardMenu(anchor, _kind) { return this.#openConnectionMenu(anchor); }

    #openConnectionMenu(anchor) {
        const card = anchor.matches("[data-ship-domain-node]") ? anchor : anchor.parentElement?.querySelector("[data-ship-domain-node]");
        if (!card) return;
        return openConnectedObjectMenu({ card, anchor, navigation: node => this.#contentHost?.navigation?.(node), owner: ConnectionTargetResolver.fromCampaignEntity(getShip(this.#shipId)),
            getItems: ({ edge }) => this.#connectionsBoard?.getCardItems(edge.id, this, anchor), onChanged: () => this.refresh() });
    }

    async #toggleCompactMode() {
        if (this.#contentHost) return this.#contentHost.toggleCompact();
        if (!this.#isCompact) {
            rememberSessionWindowPlacement(this, PLACEMENT_KEY);
            this.#expandedPosition = this.#getCurrentPosition();
        }
        this.#isCompact = !this.#isCompact;
        shipDossierCompactPreference = this.#isCompact;
        await this.render({ parts: ["content"] });
        if (this.#isCompact) this.#applyCompactPosition(this.#expandedPosition);
        else if (this.#expandedPosition) this.setPosition(this.#expandedPosition);
        else applySessionWindowPlacement(this, PLACEMENT_KEY, { fallback: "center" });
    }

    async #rerollCurrentAssignment(button) {
        if (!canControlPlayerEntity(this.#shipId)) return;
        button.disabled = true;
        try {
            const updated = await rerollShipCurrentAssignment(this.#shipId);
            if (!updated) ui.notifications.warn("This ship's generator cannot reroll its Current Assignment.");
            else this.refresh();
        } catch (error) {
            console.error("Augur Nexus | Failed to reroll ship Current Assignment", error);
            ui.notifications.error(error?.message || "The ship's Current Assignment could not be rerolled.");
        } finally {
            button.disabled = false;
        }
    }

    #applyCompactPosition(source = null) {
        const current = source || this.#getCurrentPosition() || {};
        const oldWidth = Number(current.width || this.position?.width || this.contentElement?.offsetWidth || COMPACT_WIDTH);
        const oldLeft = Number(current.left ?? this.position?.left ?? 20);
        const width = Math.min(COMPACT_WIDTH, Math.max(320, window.innerWidth - 40));
        const right = oldLeft + oldWidth;
        const left = Math.min(Math.max(20, right - width), Math.max(20, window.innerWidth - width - 20));
        this.setPosition({
            left,
            top: Number(current.top ?? this.position?.top ?? 20),
            width,
            height: Number(current.height || this.position?.height || this.contentElement?.offsetHeight || 780)
        });
    }

    #getCurrentPosition() {
        const position = this.position || {};
        const left = Number(position.left ?? this.contentElement?.offsetLeft ?? NaN);
        const top = Number(position.top ?? this.contentElement?.offsetTop ?? NaN);
        if (!Number.isFinite(left) || !Number.isFinite(top)) return null;
        return {
            left,
            top,
            width: Number(position.width || this.contentElement?.offsetWidth || 1420),
            height: Number(position.height || this.contentElement?.offsetHeight || 780)
        };
    }

    #activateDomainDrops(element) {
        if (!canControlPlayerEntity(this.#shipId)) return;
        element.querySelectorAll("[data-ship-domain-drop]").forEach(zone => {
            if (zone.dataset.shipDomainDropBound) return;
            zone.dataset.shipDomainDropBound = "true";
            zone.addEventListener("dragover", event => {
                event.preventDefault();
                event.stopPropagation();
                if (event.dataTransfer) event.dataTransfer.dropEffect = "copy";
                zone.classList.add("is-ship-drop-target");
            });
            zone.addEventListener("dragleave", event => {
                if (!zone.contains(event.relatedTarget)) zone.classList.remove("is-ship-drop-target");
            });
            zone.addEventListener("drop", event => {
                event.preventDefault();
                event.stopPropagation();
                zone.classList.remove("is-ship-drop-target");
                void this.#handleDomainDrop(event, zone.dataset.shipDomainDrop || "");
            });
        });
    }

    async #handleDomainDrop(event, action) {
        const ship = getShip(this.#shipId);
        const shipTarget = ship ? ConnectionTargetResolver.fromCampaignEntity(ship) : null;
        const actorDropOptions = action === "captain" || action === "crew"
            ? { allowedEntityTypes: ["npc"], defaultEntityType: "npc" }
            : action === "owner"
                ? { allowedEntityTypes: ["npc", "faction"], defaultEntityType: "faction" }
                : action === "ties"
                    ? { allowedEntityTypes: ["npc", "faction", "ship"], defaultEntityType: "npc", allowActorOnly: true }
                    : { convertActors: false };
        const relatedTarget = await ConnectionDropResolver.fromEvent(event, actorDropOptions);
        if (!shipTarget || !relatedTarget) {
            if (!ConnectionDropResolver.wasActorDrop(event)) ui.notifications.warn("Drop a Nexus entity here.");
            return;
        }
        try {
            if (action === "captain" || action === "crew") {
                if (relatedTarget.kind !== "nexus-entity" || relatedTarget.entityType !== "npc") throw new Error("Only a Nexus Person can serve aboard a Ship.");
                if (action === "captain") await ShipCaptainService.setCaptain(shipTarget, relatedTarget);
                else await ShipCrewService.addCrew(shipTarget, relatedTarget);
            } else if (action === "owner") {
                if (relatedTarget.kind !== "nexus-entity" || !["npc", "faction"].includes(relatedTarget.entityType)) throw new Error("A Ship owner must be a Person or Organization.");
                await ShipOwnershipService.setOwner(shipTarget, relatedTarget);
            } else if (action === "location") {
                const isPlace = relatedTarget.kind === "nexus-site" || relatedTarget.kind === "nexus-scene" || (relatedTarget.kind === "nexus-entity" && relatedTarget.entityType === "location");
                if (!isPlace) throw new Error("Current Location requires a Nexus Place.");
                await ShipLocationService.setCurrentLocation(shipTarget, relatedTarget, { source: "manual" });
            } else if (action === "ties") {
                await ConnectionStore.addConnection(shipTarget, relatedTarget);
            }
            this.refresh();
        } catch (error) {
            console.error("Augur Nexus | Failed to update Ship dossier relationships.", error);
            ui.notifications.error(error?.message || "The Ship relationship could not be updated.");
        }
    }

    #createCrewMember(anchor) {
        const ship = getShip(this.#shipId);
        if (!game.user.isGM || !ship) return;
        return CampaignEntityCreation.menu("npc", anchor, {
            openAfterCreate: false,
            onCreated: async npc => {
                const shipTarget = ConnectionTargetResolver.fromCampaignEntity(ship);
                const npcTarget = ConnectionTargetResolver.fromCampaignEntity(npc);
                if (shipTarget && npcTarget) await ShipCrewService.addCrew(shipTarget, npcTarget);
                this.refresh();
            }
        }, "Crew Member");
    }

    #openActions(anchor) {
        if (!canControlPlayerEntity(this.#shipId)) return;
        const entity = getShip(this.#shipId);
        if (!entity) return;
        openActionMenu({
            anchor,
            className: "ship-dossier-actions-menu",
            items: [
                { id: "edit-ship", label: "Edit Ship", icon: "fas fa-sliders", onSelect: () => this.#editShip() },
                { id: "artwork", label: "Portraits & artwork", icon: "fas fa-images", onSelect: () => EntityArtworkApplication.show({ entityId: this.#shipId, onChooseArtwork: () => this.#changeShipImage() }) },
                { id: "linked-actor", label: entity.projections?.actorUuid ? "Linked Actor" : "Link Actor", icon: "fas fa-user-circle", onSelect: () => this.#manageActorLink() },
                ...(ShipOwnershipService.getOwner(ConnectionTargetResolver.fromCampaignEntity(entity), { includeHidden: true }) ? [{ id: "clear-owner", label: "Clear Ship Owner", icon: "fas fa-shield-halved", onSelect: () => this.#clearShipOwner() }] : []),
                ...(ShipCaptainService.getCaptain(ConnectionTargetResolver.fromCampaignEntity(entity), { includeHidden: true }) ? [{ id: "clear-captain", label: "Remove Captain", icon: "fas fa-user-minus", onSelect: () => this.#clearShipCaptain() }] : []),
                ...(ShipLocationService.getCurrentLocation(ConnectionTargetResolver.fromCampaignEntity(entity), { includeHidden: true }) ? [{ id: "clear-location", label: "Clear Current Location", icon: "fas fa-location-crosshairs", onSelect: () => this.#clearShipLocation() }] : []),
                {
                    id: "default-dossier-tab",
                    label: `Default Tab: ${DossierTabPreference.getTabLabel(DossierTabPreference.getDefaultTab(entity), this.#lastModel?.extensionTabs || [])}`,
                    icon: "fas fa-table-columns",
                    onSelect: () => this.#openDefaultDossierTabMenu(anchor)
                },
                { id: "change-cover", label: "Change Cover Image", icon: "fas fa-image", onSelect: () => this.#changeCoverImage() },
                ...(ShipEntityModel.getCoverImage(entity) ? [{ id: "clear-cover", label: "Use Default Ship Background", icon: "fas fa-rotate-left", onSelect: () => this.#setCoverImage("") }] : []),
                {
                    id: "player-ship-visibility",
                    label: `Visible To Players: ${CampaignEntityVisibilityManager.getPlayerVisibilityLabel(entity)}`,
                    icon: CampaignEntityVisibilityManager.getPlayerVisibilityIcon(entity),
                    onSelect: () => this.#openShipVisibilityMenu(anchor)
                },
                { id: "delete", label: "Delete Ship", status: "Permanent", icon: "fas fa-skull-crossbones", danger: true, className: "permanent-danger", onSelect: () => this.#deleteShip() }
            ].filter(item => !["change-cover", "clear-cover"].includes(item.id) || (game.user.isGM && prepareNexusThemeSurface().mode === "dark")).filter(item => game.user.isGM || ["rename","edit-ship","artwork","change-model","default-dossier-tab","change-cover","clear-cover","clear-owner","clear-captain","clear-location"].includes(item.id))
        });
    }

    #openDefaultDossierTabMenu(anchor) {
        const entity = getShip(this.#shipId);
        if (!canControlPlayerEntity(this.#shipId) || !entity) return;
        openActionMenu({
            anchor,
            className: "ship-dossier-actions-menu",
            items: DossierTabPreference.buildMenuItems(
                DossierTabPreference.getDefaultTab(entity),
                tab => this.#setDefaultDossierTab(tab),
                this.#lastModel?.extensionTabs || []
            )
        });
    }

    async #setDefaultDossierTab(tab) {
        const entity = getShip(this.#shipId);
        if (!canControlPlayerEntity(this.#shipId) || !entity) return;
        const defaultTab = DossierTabPreference.normalizeTab(tab);
        if (!["profile", "journal", ...(this.#lastModel?.extensionTabs || []).map(entry => entry.id)].includes(defaultTab)) return;
        await updateShip(entity.id, { dossier: { defaultTab } });
        this.#activeTab = defaultTab;
        this.refresh();
    }

    #openShipVisibilityMenu(anchor) {
        const entity = getShip(this.#shipId);
        return openEntityDossierVisibility(entity, anchor, () => this.refresh());
    }

    async #getLinkedActorContext(entity) {
        const actor = await CampaignEntityActorBridge.getLinkedActor(entity);
        if (!actor) return null;
        return {
            name: actor.name || "Actor",
            uuid: actor.uuid || "",
            type: actor.type || "Actor"
        };
    }

    async #openLinkedActor() {
        const entity = getShip(this.#shipId);
        if (!entity) return;
        const actor = await CampaignEntityActorBridge.getLinkedActor(entity);
        if (!actor) {
            ui.notifications.warn("No linked Actor was found for this ship.");
            return;
        }
        if (!game.user.isGM && !actor.testUserPermission(game.user, CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER)) {
            ui.notifications.warn("You do not have permission to view this Actor.");
            return;
        }
        actor.sheet?.render(true);
    }

    async #linkActor() {
        await this.#manageActorLink();
    }

    async #manageActorLink() {
        const entity = getShip(this.#shipId);
        if (!game.user.isGM || !entity) return;
        const result = await CampaignEntityActorBridge.manageActorLink(entity);
        if (result?.action && result.action !== "cancel" && result.action !== "open") this.refresh();
    }

    async #setShipPlayerVisibility(value) {
        const entity = getShip(this.#shipId);
        if (!game.user.isGM || !entity) return;
        await CampaignEntityVisibilityManager.setPlayerVisibilityOverride(entity.id, "ship", value);
        this.refresh();
    }

    async #clearShipOwner() {
        const entity = getShip(this.#shipId);
        const target = entity ? ConnectionTargetResolver.fromCampaignEntity(entity) : null;
        if (!target) return;
        await ShipOwnershipService.clearOwner(target, { preserveConnection: true });
        this.refresh();
    }

    async #clearShipCaptain() {
        const entity = getShip(this.#shipId);
        const target = entity ? ConnectionTargetResolver.fromCampaignEntity(entity) : null;
        if (!target) return;
        await ShipCaptainService.clearCaptain(target);
        this.refresh();
    }

    async #clearShipLocation() {
        const entity = getShip(this.#shipId);
        const target = entity ? ConnectionTargetResolver.fromCampaignEntity(entity) : null;
        if (!entity || !target) return;
        const current = ShipLocationService.getCurrentLocation(target, { includeHidden: true });
        if (current?.source === "marker" && current.markerId) {
            const ref = (entity.markerRefs || []).find(candidate => candidate.markerId === current.markerId);
            const scene = ref?.sceneId ? game.scenes.get(ref.sceneId) : null;
            const tile = scene && ref?.documentId ? scene.tiles.get(ref.documentId) : null;
            if (tile) await NexusMarkerService.deleteMarker(tile, { notify: false, scene });
            else {
                await NexusMarkerService.removeOwnerMarkerRef({ kind: "campaign-entity", entityType: "ship", entityId: entity.id }, current.markerId);
                await ShipLocationService.clearCurrentLocation(target, { markerId: current.markerId });
            }
        } else {
            await ShipLocationService.clearCurrentLocation(target);
        }
        this.refresh();
    }

    #editShip() { const entity = getShip(this.#shipId); if (entity) ShipDataEditor.show({ shipId: entity.id, onSave: () => this.refresh() }); }

    #changeShipImage() {
        const entity = getShip(this.#shipId);
        if (!entity) return;
        const moduleData = entity.moduleData?.[entity.sourceModule] || entity.moduleData?.["augur-scifi"] || {};
        new ShipImagePicker({
            currentShipImageSrc: ShipEntityModel.getImage(entity),
            selectedModelId: moduleData.modelId || "",
            onSelect: selection => this.#setShipImage(selection)
        }).render(true, { focus: true });
    }

    async #setShipImage(selection = {}) {
        const entity = getShip(this.#shipId);
        if (!entity || !selection.src) return;
        const moduleId = entity.sourceModule || "augur-scifi";
        const patch = {
            display: { imageSrc: selection.src },
            moduleData: { [moduleId]: { ...(entity.moduleData?.[moduleId] || {}), modelId: selection.modelId || "", styleId: selection.styleId || "" } }
        };
        if (!selection.custom && selection.modelLabel) patch.profile = { model: selection.modelLabel };
        await updateShip(entity.id, patch, { moduleId });
        this.refresh();
    }

    #changeCoverImage() {
        if (!game.user.isGM || prepareNexusThemeSurface().mode !== "dark") return;
        const entity = getShip(this.#shipId);
        if (entity) SiteCoverPicker.show({ current: prepareDossierCover(entity).src, onSelect: path => this.#setCoverImage(path || "") });
    }
    async #setCoverImage(path) {
        if (!game.user.isGM || prepareNexusThemeSurface().mode !== "dark") return;
        const entity = getShip(this.#shipId);
        if (!entity) return;
        await updateShip(entity.id, { display: { coverImageSrc: path || "" } });
        this.refresh();
    }

    async #editJournal({ create = true } = {}) {
        if (!game.user.isGM) return;
        const page = create ? await CampaignEntityJournalStore.getOrCreateJournalPage(this.#shipId) : CampaignEntityJournalStore.getJournalPage(this.#shipId);
        if (!page?.parent) { ui.notifications.warn("No journal page was found for this ship."); return; }
        page.sheet?.render(true);
    }

    async #deleteShip() {
        if (await CampaignEntityDeletion.confirm("ship", this.#shipId) === "deleted") await this.close();
    }

    async #enrichJournalContent(page) {
        if (!game.user.isGM && !page?.testUserPermission?.(game.user, "OBSERVER")) return "";
        const content = page?.text?.content || "";
        if (!String(content).trim()) return "";
        try { return foundry.applications.ux.TextEditor.implementation.enrichHTML(content, { relativeTo: page, secrets: page.isOwner }); } catch (_err) { return content; }
    }
}
