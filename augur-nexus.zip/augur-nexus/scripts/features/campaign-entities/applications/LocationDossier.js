import { attachDossierHelpButton } from "../../../api/help.js";
import { buildDossierActionItems } from "../components/DossierActionItems.js";
import { entityDossierVisibility, openEntityDossierVisibility, renderDossierControls, bindDossierControls } from "../components/DossierHeaderControls.js";
import { prepareNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";
import { prepareDossierCover } from "../../../support/appearance/DossierCoverPresentation.js";
import { bindConnectedObjectMenus } from "../../connections/services/ConnectedObjectMenu.js";
import { CampaignEntityCreation } from "../services/CampaignEntityCreation.js";
import { bindEntityDisclosureControls, openEntityDisclosureMenu } from "../services/EntityDisclosureControls.js";
import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { canRerollLocationCurrentThread, deleteLocation, getLocation, getLocationViews, openLocation, openLocationView, rerollLocationCurrentThread, updateLocation } from "../../../api/locations.js";
import { openShopCreator } from "../../../api/shops.js";
import { addConnection } from "../../../api/connections.js";
import { openActionMenu, promptTextInput } from "../../../api/ui.js";
import { ConnectionsBoard } from "../../connections/components/ConnectionsBoard.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { PlayerNpcVisibilityDialog } from "../../nexus/applications/PlayerNpcVisibilityDialog.js";
import { PlayerLocationDisclosureDialog } from "../../nexus/applications/PlayerLocationDisclosureDialog.js";
import { openHelp } from "../../../api/help.js";
import { DossierTabPreference } from "../../nexus/services/DossierTabPreference.js";
import { SiteCoverPicker } from "../../site/applications/SiteCoverPicker.js";
import { SiteIconPicker } from "../../site/applications/SiteIconPicker.js";
import { SitePanel } from "../../site/applications/SitePanel.js";
import { LocationEntityModel } from "../models/LocationEntityModel.js";
import { LocationProfileViewModel } from "../models/LocationProfileViewModel.js";
import { applySessionWindowPlacement, rememberSessionWindowPlacement } from "/modules/augur-nexus/scripts/api/window-placement.js";
import { CampaignEntityDossierRefresh } from "../services/CampaignEntityDossierRefresh.js";
import { CampaignEntityVisibilityManager } from "../services/CampaignEntityVisibilityManager.js";
import { CampaignEntityDisclosureManager } from "../services/CampaignEntityDisclosureManager.js";
import { LocationEntityStore } from "../services/LocationEntityStore.js";
import { LocationActionRegistry } from "../services/LocationActionRegistry.js";
import { LocationSceneService } from "../services/LocationSceneService.js";
import { LocationSceneWorkflow } from "../services/LocationSceneWorkflow.js";
import { LocationDataEditor } from "./LocationDataEditor.js";
import { EntityChroniclePanel } from "../../region-population/components/EntityChroniclePanel.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const PLACEMENT_KEY = "augur-nexus.location-dossier";

export class LocationDossier extends HandlebarsApplicationMixin(ApplicationV2) {
    #locationId = "";
    #activeTab = "profile";
    #connectionsBoard = null;
    #chroniclePanel = null;
    #connectionsChangedHook = null;
    #sceneAccessChangedHook = null;
    #entitiesChangedHook = null;
    #lastModel = null;
    #positionInitialized = false;

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-location-dossier",
        classes: ["augur-nexus", "npc-dossier", "location-dossier"],
        tag: "div",
        window: { title: "Location", resizable: true, minimizable: true },
        position: { width: 680, height: 600 },
        actions: {
            entityDisclosureMenu: function(_event, button) { return openEntityDisclosureMenu(this.#locationId, button, "location"); },
            setLocationDossierTab: LocationDossier._onSetTab,
            openLocationActions: LocationDossier._onActions,
            editLocation: LocationDossier._onEdit,
            openLocationJournal: LocationDossier._onJournal,
            createLocationJournal: LocationDossier._onJournal,
            openLocationScene: LocationDossier._onOpenScene,
            viewLocationScene: LocationDossier._onViewScene,
            openLocationSceneMenu: LocationDossier._onSceneMenu,
            openLocationCreateMenu: LocationDossier._onCreateMenu,
            openRegisteredLocationView: LocationDossier._onOpenRegisteredView,
            rerollLocationCurrentThread: LocationDossier._onRerollCurrentThread,
            deleteLocation: LocationDossier._onDelete
        }
    };

    static PARTS = {
        content: {
            template: "modules/augur-nexus/templates/campaign-entities/location-dossier.hbs",
            templates: [
                "modules/augur-nexus/templates/campaign-entities/location-dossier-footer.hbs",
                "modules/augur-nexus/templates/campaign-entities/entity-journal-panel.hbs",
                "modules/augur-nexus/templates/campaign-entities/quest-world-ties.hbs",
                "modules/augur-nexus/templates/connections/connections-board.hbs",
                "modules/augur-nexus/templates/campaign-entities/location-current-thread.hbs",
                "modules/augur-nexus/templates/campaign-entities/location-profile-panel.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-portrait.hbs"
            ]
        }
    };

    get title() { return this.#lastModel?.location?.name || "Location"; }

    static show({ locationId = "" } = {}) {
        if (!locationId) return null;
        const entity = getLocation(locationId);
        if (!entity || !CampaignEntityVisibilityManager.canUserSee(entity, game.user)) return null;
        if (!CampaignEntityDisclosureManager.canUserViewDetails(entity, game.user)) return openLocation(entity);
        const app = new this({ locationId });
        app.render(true, { focus: true });
        return app;
    }

    constructor({ locationId = "" } = {}, options = {}) {
        super(options);
        this.#locationId = locationId;
        this.#chroniclePanel = new EntityChroniclePanel({ entityId: this.#locationId });
        this.#activeTab = DossierTabPreference.getDefaultTab(getLocation(this.#locationId));
        this.#connectionsChangedHook = () => this.refresh();
        this.#sceneAccessChangedHook = scene => {
            if (!scene || scene.id === LocationEntityStore.getLocation(this.#locationId)?.scenes?.primarySceneId) this.refresh();
        };
        this.#entitiesChangedHook = event => {
            if (!event?.entity || event.entity.id === this.#locationId) this.refresh();
        };
        Hooks.on("augurNexusConnectionsChanged", this.#connectionsChangedHook);
        Hooks.on("augurNexusPlayerSceneAccessChanged", this.#sceneAccessChangedHook);
        Hooks.on("updateScene", this.#sceneAccessChangedHook);
        Hooks.on("deleteScene", this.#sceneAccessChangedHook);
        Hooks.on("augurNexusAppearanceChanged", this.#connectionsChangedHook);
        Hooks.on("augurNexusCampaignEntitiesChanged", this.#entitiesChangedHook);
        CampaignEntityDossierRefresh.watch(this);
    }

    async _prepareContext() {
        const entity = getLocation(this.#locationId);
        if (!entity) return { missing: true, location: { name: "Missing Location" }, connections: { board: null } };

        const target = ConnectionTargetResolver.fromCampaignEntity(entity);
        if (!this.#connectionsBoard) this.#connectionsBoard = new ConnectionsBoard({ target, isGM: game.user.isGM });
        else this.#connectionsBoard.setTarget(target);

        const page = LocationEntityStore.getJournalPage(entity.id);
        // Chronicle summaries have no per-entry disclosure projection.
        const hasChronicle = game.user.isGM && this.#chroniclePanel.hasEvents();
        const canRerollCurrentThread = canControlPlayerEntity(this.#locationId) && canRerollLocationCurrentThread(entity);
        if (this.#activeTab === "chronicle" && !hasChronicle) this.#activeTab = "profile";
        const model = {
            missing: false,
            isGM: game.user.isGM, canEdit: canControlPlayerEntity(this.#locationId),
            location: {
                id: entity.id,
                name: LocationEntityModel.getName(entity),
                profile: LocationProfileViewModel.fromEntity(entity, {
                    activeTab: this.#activeTab,
                    hasChronicle,
                    showTabs: true,
                    showActions: canControlPlayerEntity(this.#locationId),
                    showBody: this.#activeTab === "profile",
                    canRerollCurrentThread
                })
            },
            dossier: {
                isProfileTab: this.#activeTab === "profile",
                isJournalTab: this.#activeTab === "journal",
                isChronicleTab: this.#activeTab === "chronicle"
            },
            chronicleHtml: hasChronicle ? await this.#chroniclePanel.render() : "",
            journal: {
                hasPage: !!page,
                entryId: page?.parent?.id || entity.journalEntryId || "",
                pageId: page?.id || "",
                hasContent: !!String(page?.text?.content || "").trim(),
                content: await this.#enrich(page)
            },
            connections: { board: this.#connectionsBoard.getContext(this.#activeTab === "journal" ? { display: "list", hideViewToggle: true } : {}) },
            locationViews: getLocationViews(entity),
            sceneControl: LocationSceneWorkflow.getControlModel(entity.id),
            appearance: prepareNexusThemeSurface(),
            dossierCover: prepareDossierCover(entity)
        };
        model.hasProfileActions = model.locationViews.length > 0;
        model.locationSceneControl = model.sceneControl;
        model.locationFooterControlsHtml = game.user.isGM ? await renderDossierControls({ entity, showEdit: false, options: false }) : "";
        model.location.profile.controlsHtml = await renderDossierControls({ entity, canEdit: model.canEdit, compact: false, compactAction: "", visibility: game.user.isGM ? null : entityDossierVisibility(entity), sceneControl: null });
        this.#lastModel = model;
        return model;
    }

    _onRender(context, options) {
        super._onRender(context, options);
        attachDossierHelpButton(this, "location");
        bindDossierControls(this.element, { edit: () => LocationDossier._onEdit.call(this), options: anchor => LocationDossier._onActions.call(this, null, anchor), visibility: anchor => this.#openLocationVisibilityMenu(anchor) });
        bindConnectedObjectMenus(this.element, { getOwner: () => ConnectionTargetResolver.fromCampaignEntity(getLocation(this.#locationId)), onChanged: () => this.refresh(), getItems: ({ edge, card }) => this.#connectionsBoard?.getCardItems(edge.id, this, card) });
        if (this.window?.title) this.window.title.textContent = this.title;
        bindEntityDisclosureControls(this.element, () => this.#locationId, { type: "location" });
        this.#connectionsBoard?.activateListeners(this.element, this);
        this.#chroniclePanel?.activateListeners(this.element, this);
        if (!this.#positionInitialized) {
            applySessionWindowPlacement(this, PLACEMENT_KEY, { fallback: "center" });
            this.#positionInitialized = true;
        }
    }

    async close(options) {
        await this.#connectionsBoard?.destroy();
        rememberSessionWindowPlacement(this, PLACEMENT_KEY);
        CampaignEntityDossierRefresh.unwatch(this);
        this.#chroniclePanel?.destroy();
        if (this.#connectionsChangedHook) Hooks.off("augurNexusConnectionsChanged", this.#connectionsChangedHook);
        if (this.#connectionsChangedHook) Hooks.off("augurNexusPlayerSceneAccessChanged", this.#sceneAccessChangedHook);
        if (this.#connectionsChangedHook) Hooks.off("updateScene", this.#sceneAccessChangedHook);
        if (this.#connectionsChangedHook) Hooks.off("deleteScene", this.#sceneAccessChangedHook);
        if (this.#connectionsChangedHook) Hooks.off("augurNexusAppearanceChanged", this.#connectionsChangedHook);
        if (this.#entitiesChangedHook) Hooks.off("augurNexusCampaignEntitiesChanged", this.#entitiesChangedHook);
        return super.close(options);
    }

    matchesCampaignEntityJournal({ entryId, pageId } = {}) {
        const journal = this.#lastModel?.journal || null;
        if (!journal?.entryId) return false;
        if (pageId) return journal.pageId === pageId;
        return journal.entryId === entryId;
    }

    refreshCampaignEntityDossier() { this.refresh(); }
    refresh() {
        const entity = getLocation(this.#locationId);
        if (!entity || !CampaignEntityVisibilityManager.canUserSee(entity, game.user)) {
            void this.close();
            return;
        }
        if (!CampaignEntityDisclosureManager.canUserViewDetails(entity, game.user)) {
            void this.close().then(() => openLocation(entity));
            return;
        }
        if (this.rendered !== false) this.render({ parts: ["content"] });
    }

    static async _onOpenRegisteredView(event, target) {
        const viewId = target?.dataset?.locationViewId || "";
        const entity = getLocation(this.#locationId);
        if (viewId && entity) await openLocationView(viewId, entity);
    }

    static async _onRerollCurrentThread(_event, target) {
        if (!canControlPlayerEntity(this.#locationId) || target?.disabled) return;
        target.disabled = true;
        try {
            const updated = await rerollLocationCurrentThread(this.#locationId);
            if (!updated) ui.notifications.warn("This location's generator cannot reroll its Current Thread.");
            this.refresh();
        } catch (error) {
            console.error("Augur Nexus | Failed to reroll location Current Thread", error);
            ui.notifications.error("The Current Thread could not be rerolled.");
        } finally {
            target.disabled = false;
        }
    }

    static async _onSetTab(event, target) {
        const tab = target?.dataset?.tab || "profile";
        this.#activeTab = ["journal", "chronicle"].includes(tab) ? tab : "profile";
        this.render({ parts: ["content"] });
    }

    static async _onEdit() {
        LocationDataEditor.show({ locationId: this.#locationId, onSave: () => this.refresh() });
    }

    static async _onJournal() {
        const page = await LocationEntityStore.getOrCreateJournalPage(this.#locationId);
        page?.sheet?.render(true);
    }

    static async _onViewScene() {
        if (await LocationSceneService.view(this.#locationId)) await this.close();
    }

    static async _onOpenScene() {
        if (await LocationSceneWorkflow.open(this.#locationId)) await this.close();
    }

    static _onSceneMenu(_event, target) {
        return LocationSceneWorkflow.openMenu(this.#locationId, target, { onChanged: () => this.refresh() });
    }

    static async _onCreateMenu(_event, target) {
        if (!game.user.isGM) return;
        const location = getLocation(this.#locationId);
        const locationActions = LocationActionRegistry.listFor(location, { onChanged: () => this.refresh() });
        openActionMenu({
            anchor: target,
            className: "location-dossier-create-menu",
            items: [
                { id: "generate-person", label: "Generate Resident", icon: "fas fa-dice", onSelect: () => this.#createPerson(true) },
                { id: "person", label: "New Resident", icon: "fas fa-user-plus", onSelect: () => this.#createPerson() },
                { id: "shop", label: "Shop", icon: "fas fa-store", onSelect: () => openShopCreator({ locationId: this.#locationId, onSaved: () => this.refresh() }) },
                ...locationActions
            ]
        });
    }

    async #createPerson(generate = false) {
        const location = getLocation(this.#locationId);
        if (!location) return;
        return CampaignEntityCreation.open("npc", { generate,
            onCreated: async npc => {
                const locationTarget = ConnectionTargetResolver.fromCampaignEntity(location);
                const npcTarget = ConnectionTargetResolver.fromCampaignEntity(npc);
                if (locationTarget && npcTarget) {
                    await addConnection(locationTarget, npcTarget, {
                        sourceView: { category: "npc", role: "Resident" },
                        targetView: { category: "place", role: "Located At" }
                    });
                }
                this.refresh();
            }
        }).catch(error => ui.notifications.error(error.message));
    }

    static async _onActions(event, target) {
        const entity = getLocation(this.#locationId);
        if (!canControlPlayerEntity(this.#locationId) || !entity) return;
        const locationViews = getLocationViews(entity);
        openActionMenu({
            anchor: target,
            className: "location-dossier-actions-menu",
            items: buildDossierActionItems({ entity, hasCover: !!LocationEntityModel.getCoverImage(entity), dark: prepareNexusThemeSurface().mode === "dark",
                extras: [...locationViews.map(view => ({ id: `location-view:${view.id}`, label: view.label, icon: view.icon, onSelect: () => openLocationView(view.id, entity) })), ...LocationSceneWorkflow.getMenuItems(entity.id, { anchor: target, onChanged: () => this.refresh(), onOpened: () => this.close() })],
                actions: { rename: () => this.#renameLocation(), edit: () => LocationDossier._onEdit.call(this), changeIcon: () => this.#changeIcon(), journal: () => LocationDossier._onJournal.call(this),
                    defaultTab: () => this.#openDefaultDossierTabMenu(target), changeCover: () => this.#changeCoverImage(), clearCover: () => this.#setCoverImage(""),
                    visibility: () => this.#openLocationVisibilityMenu(target), disclosure: () => PlayerLocationDisclosureDialog.openEntityMenu({ anchor: target, location: entity, onChanged: () => this.refresh() }), delete: () => LocationDossier._onDelete.call(this) }
            })
        });
    }

    async #renameLocation() {
        const entity = getLocation(this.#locationId);
        if (!canControlPlayerEntity(this.#locationId) || !entity) return;
        const name = await promptTextInput({
            title: "Rename Location",
            label: "Name",
            value: LocationEntityModel.getName(entity),
            confirmLabel: "Rename"
        });
        if (!name) return;
        await updateLocation(entity.id, { display: { name } });
        this.refresh();
    }

    async #changeIcon() {
        const entity = getLocation(this.#locationId);
        if (!canControlPlayerEntity(this.#locationId) || !entity) return;
        const icons = await SitePanel.getAllBuiltInIcons();
        const currentSrc = LocationEntityModel.getImage(entity);
        const currentIconId = icons.find(icon => icon.src === currentSrc)?.id || (currentSrc ? "custom" : null);
        new SiteIconPicker(icons, currentIconId, "landmark", selection => {
            const nextSrc = typeof selection === "object" && selection?.id === "custom"
                ? selection.src || ""
                : icons.find(icon => icon.id === selection)?.src || currentSrc;
            if (nextSrc) void this.#setIcon(nextSrc);
        }, {
            currentCustomIconSrc: currentIconId === "custom" ? currentSrc : "",
            allBuiltInIcons: icons,
            showThemeIconsOnly: false,
            filterByRole: false
        }).render(true);
    }

    async #setIcon(path) {
        const entity = getLocation(this.#locationId);
        if (!canControlPlayerEntity(this.#locationId) || !entity || !path) return;
        await updateLocation(entity.id, { display: { imageSrc: path, thumbnailSrc: "" } });
        this.refresh();
    }

    #openDefaultDossierTabMenu(anchor) {
        const entity = getLocation(this.#locationId);
        if (!canControlPlayerEntity(this.#locationId) || !entity) return;
        openActionMenu({
            anchor,
            className: "location-dossier-actions-menu",
            items: DossierTabPreference.buildMenuItems(
                DossierTabPreference.getDefaultTab(entity),
                tab => this.#setDefaultDossierTab(tab)
            )
        });
    }

    async #setDefaultDossierTab(tab) {
        const entity = getLocation(this.#locationId);
        if (!canControlPlayerEntity(this.#locationId) || !entity) return;
        const defaultTab = DossierTabPreference.normalizeTab(tab);
        await updateLocation(entity.id, { dossier: { defaultTab } });
        this.#activeTab = defaultTab;
        this.refresh();
    }

    #changeCoverImage() {
        if (!game.user.isGM || prepareNexusThemeSurface().mode !== "dark") return;
        const entity = getLocation(this.#locationId);
        if (!canControlPlayerEntity(this.#locationId) || !entity) return;
        SiteCoverPicker.show({
            current: prepareDossierCover(entity).src,
            onSelect: path => this.#setCoverImage(path || "")
        });
    }

    async #setCoverImage(path) {
        if (!game.user.isGM || prepareNexusThemeSurface().mode !== "dark") return;
        const entity = getLocation(this.#locationId);
        if (!canControlPlayerEntity(this.#locationId) || !entity) return;
        await updateLocation(entity.id, { display: { coverImageSrc: path || "" } });
        this.refresh();
    }

    #openLocationVisibilityMenu(anchor) {
        const entity = getLocation(this.#locationId);
        return openEntityDossierVisibility(entity, anchor, () => this.refresh());
    }

    async #setLocationPlayerVisibility(value) {
        const entity = getLocation(this.#locationId);
        if (!game.user.isGM || !entity) return;
        await CampaignEntityVisibilityManager.setPlayerVisibilityOverride(entity.id, "location", value);
        this.refresh();
    }

    static async _onDelete() {
        const entity = getLocation(this.#locationId);
        if (!entity) return;
        if (await deleteLocation(entity.id)) await this.close();
    }

    async #enrich(page) {
        const content = page?.text?.content || "";
        if (!String(content).trim()) return "";
        try {
            return foundry.applications.ux.TextEditor.implementation.enrichHTML(content, { relativeTo: page, secrets: page.isOwner });
        } catch (_error) {
            return content;
        }
    }

}
