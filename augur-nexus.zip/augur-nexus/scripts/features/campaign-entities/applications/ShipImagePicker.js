import { getShipModels } from "../../../api/ships.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const FilePicker = foundry.applications.apps.FilePicker.implementation;

const MODULE_ID = "augur-nexus";
const IMAGE_EXTENSIONS = [".png", ".jpg", ".jpeg", ".webp", ".gif", ".avif"];

export class ShipImagePicker extends HandlebarsApplicationMixin(ApplicationV2) {
    #onSelect = null;
    #selectedModelId = "";
    #initialTab = "";

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-ship-image-picker",
        classes: ["augur-nexus", "npc-portrait-picker-dialog", "site-icon-picker-dialog", "ship-image-picker-dialog"],
        tag: "div",
        window: { title: "Select Ship Model", resizable: true, minimizable: false },
        position: { width: 860, height: 620 }
    };

    static PARTS = { main: { template: "modules/augur-nexus/templates/campaign-entities/ship-image-picker.hbs" } };

    constructor({ currentShipImageSrc = "", selectedModelId = "", onSelect = null } = {}, options = {}) {
        super(options);
        this.currentShipImageSrc = currentShipImageSrc || "";
        this.#selectedModelId = selectedModelId || "";
        this.currentTab = options.currentTab || "built-in";
        this.#initialTab = options.currentTab || "";
        this.#onSelect = onSelect;
    }

    async _prepareContext() {
        const customFolder = this.#getCustomFolderSetting();
        const models = await getShipModels();
        if (!this.#initialTab) {
            this.currentTab = this.#isBuiltInImage(models, this.currentShipImageSrc) ? "built-in" : "custom";
            this.#initialTab = this.currentTab;
        }
        const selectedModel = this.currentTab === "built-in" && this.#selectedModelId
            ? models.find(model => model.modelId === this.#selectedModelId)
            : null;
        const customImages = await this.#getCustomFolderImages(customFolder);
        return {
            models,
            selectedModel,
            currentShipImageSrc: this.currentShipImageSrc,
            currentTab: this.currentTab,
            pickerLabel: this.currentTab === "custom" ? "Custom" : "Built-In",
            customFolderPath: customFolder.path || "",
            hasCustomFolder: !!customFolder.path,
            customImages
        };
    }

    _attachPartListeners(partId, htmlElement, options) {
        super._attachPartListeners(partId, htmlElement, options);
        const el = htmlElement instanceof HTMLElement ? htmlElement : htmlElement?.[0];
        if (!el) return;

        el.querySelectorAll("[data-ship-image-tab]").forEach(button => {
            button.addEventListener("click", event => {
                event.preventDefault();
                const nextTab = event.currentTarget.dataset.shipImageTab;
                if (!nextTab || nextTab === this.currentTab) return;
                this.currentTab = nextTab;
                this.#selectedModelId = "";
                this.render();
            });
        });

        el.querySelectorAll("[data-ship-model-id]").forEach(card => {
            card.addEventListener("click", event => {
                event.preventDefault();
                this.#selectedModelId = event.currentTarget.dataset.shipModelId || "";
                this.render();
            });
        });
        el.querySelectorAll("[data-ship-image-src]").forEach(card => {
            card.addEventListener("click", event => {
                event.preventDefault();
                this.#onSelect?.({
                    src: event.currentTarget.dataset.shipImageSrc || "",
                    modelId: event.currentTarget.dataset.modelId || "",
                    styleId: event.currentTarget.dataset.styleId || "",
                    custom: event.currentTarget.dataset.customShipImage === "true"
                });
                this.close();
            });
        });
        el.querySelector("[data-action='backToShipModels']")?.addEventListener("click", event => {
            event.preventDefault();
            this.#selectedModelId = "";
            this.render();
        });

        el.querySelector("[data-action='chooseCustomShipImageFile']")?.addEventListener("click", event => {
            event.preventDefault();
            this.#openCustomShipImageFilePicker();
        });

        el.querySelector("[data-action='chooseCustomShipImageFolder']")?.addEventListener("click", event => {
            event.preventDefault();
            this.#openCustomFolderPicker();
        });

        el.querySelector("[data-action='clearCustomShipImageFolder']")?.addEventListener("click", async event => {
            event.preventDefault();
            await game.settings.set(MODULE_ID, "shipCustomImageFolder", {
                source: "data",
                path: ""
            });
            this.render();
        });
    }

    #openCustomFolderPicker() {
        const currentFolder = this.#getCustomFolderSetting();
        const picker = new FilePicker({
            type: "folder",
            current: currentFolder.path || "",
            activeSource: currentFolder.source || "data",
            callback: async (path, pickerApp) => {
                await game.settings.set(MODULE_ID, "shipCustomImageFolder", {
                    source: pickerApp.activeSource || currentFolder.source || "data",
                    path: path || ""
                });
                this.currentTab = "custom";
                this.#selectedModelId = "";
                this.render();
            },
            top: (this.position?.top ?? 100) + 40,
            left: (this.position?.left ?? 100) + 10
        });

        picker.render({ force: true });
    }

    #openCustomShipImageFilePicker() {
        const picker = new FilePicker({
            type: "image",
            callback: path => {
                if (!path) return;
                this.#onSelect?.({ src: path, modelId: "", styleId: "", custom: true });
                this.close();
            },
            top: (this.position?.top ?? 100) + 40,
            left: (this.position?.left ?? 100) + 10
        });

        picker.render({ force: true });
    }

    #getCustomFolderSetting() {
        const stored = game.settings.get(MODULE_ID, "shipCustomImageFolder") || {};
        return {
            source: stored.source || "data",
            path: stored.path || ""
        };
    }

    async #getCustomFolderImages(folder) {
        if (!folder?.path) return [];

        try {
            const browseResult = await FilePicker.browse(folder.source || "data", folder.path, {
                extensions: IMAGE_EXTENSIONS
            });

            return (browseResult.files || []).map(src => ({
                id: src,
                imageSrc: src,
                label: this.#getFileLabel(src)
            }));
        } catch (err) {
            console.warn("Augur: Nexus | Failed to browse custom ship image folder.", err);
            return [];
        }
    }

    #isBuiltInImage(models = [], imageSrc = "") {
        if (!imageSrc) return true;
        return models.some(model => (model.variants || []).some(variant => variant.imageSrc === imageSrc));
    }

    #getFileLabel(src) {
        return String(src || "")
            .split(/[\\/]/)
            .pop()
            ?.replace(/\.[^.]+$/, "") || "Custom Ship";
    }
}
