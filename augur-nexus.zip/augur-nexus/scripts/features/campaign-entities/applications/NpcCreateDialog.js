import { createNpc, generateNpc, getNpcGeneratorOptions, getNpcGenerators, openNpcDossier } from "../../../api/npcs.js";
import { isNpcRaceVisible } from "../../../api/npc-races.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { NpcProfileViewModel } from "../models/NpcProfileViewModel.js";
import { GeneratorSessionPreference } from "../services/GeneratorSessionPreference.js";
import { NpcDataEditor } from "./NpcDataEditor.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class NpcCreateDialog extends HandlebarsApplicationMixin(ApplicationV2) {
    static #instance = null;
    #selectedGeneratorId = null;
    #selectedGender = "random";
    #selectedRoleId = "random";
    #selectedSpeciesId = "";
    #generationRequest = 0;
    #generatorOptions = {};
    #candidate = null;
    #candidateEditor = null;
    #onCreated = null;
    #openAfterCreate = true;
    #generationContext = {};
    #sceneConnectionId = "";
    #connectToScene = true;
    #accepting = false;
    #templatesHook = null;

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-npc-create",
        classes: ["augur-nexus", "npc-create-dialog", "augur-theme-fantasy"],
        tag: "div",
        window: {
            title: "New Person",
            resizable: false,
            minimizable: false
        },
        position: {
            width: 420,
            height: "auto"
        },
        actions: {
            acceptCandidate: NpcCreateDialog._onAcceptCandidate,
            cancel: NpcCreateDialog._onCancel,
            rerollCandidate: NpcCreateDialog._onRerollCandidate,
            editCandidate: NpcCreateDialog._onEditCandidate
        }
    };

    static PARTS = {
        content: {
            template: "modules/augur-nexus/templates/campaign-entities/npc-create-dialog.hbs",
            forms: { ".npc-create-form": { handler: NpcCreateDialog._onCreateNpc, closeOnSubmit: false } },
            templates: [
                "modules/augur-nexus/templates/campaign-entities/quest-world-ties.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-profile-panel.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-portrait.hbs"
            ]
        }
    };

    static show(options = {}) {
        if (this.#instance) {
            if (this.#instance.rendered) this.#instance.bringToFront();
            if (options.onCreated && options.onCreated !== this.#instance.#onCreated) {
                ui.notifications.warn("Finish or close the existing New Person window before starting another creation.");
                return null;
            }
            return this.#instance;
        }
        const app = new this(options);
        this.#instance = app;
        app.render(true, { focus: true });
        return app;
    }

    constructor({
        onCreated = null,
        openAfterCreate = true,
        generationContext = {},
        connectToSceneId = "",
        connectToScene = true
    } = {}, options = {}) {
        super(options);
        this.#onCreated = typeof onCreated === "function" ? onCreated : null;
        this.#openAfterCreate = openAfterCreate !== false;
        this.#generationContext = foundry.utils.deepClone(generationContext || {});
        this.#sceneConnectionId = String(connectToSceneId || "").trim();
        this.#connectToScene = connectToScene !== false;
        this.#templatesHook = Hooks.on("augurNexusWorldTemplatesChanged", ({ deletedId = "" } = {}) => {
            this.#generationRequest++;
            const raceId = this.#candidate?.generation?.raceTemplateId;
            if (raceId && (raceId === deletedId || !isNpcRaceVisible(raceId))) this.#candidate = null;
            if (this.rendered) this.render();
        });
    }

    async close(options = {}) {
        if (!await this.#finishCandidateEditing()) return this;
        const result = await super.close(options);
        Hooks.off("augurNexusWorldTemplatesChanged", this.#templatesHook);
        if (NpcCreateDialog.#instance === this) NpcCreateDialog.#instance = null;
        return result;
    }

    async _prepareContext() {
        const generators = getNpcGenerators();
        if (this.#selectedGeneratorId === null) {
            this.#selectedGeneratorId = GeneratorSessionPreference.resolve("npc", generators, { allowManual: true });
        }
        this.#generatorOptions = this.#selectedGeneratorId ? await getNpcGeneratorOptions(this.#selectedGeneratorId) : {};
        if (!(this.#generatorOptions.roles || []).some(role => role.id === this.#selectedRoleId)) this.#selectedRoleId = this.#generatorOptions.defaults?.roleId || "random";
        if (this.#candidate && this.#generatorOptions.requiresRole && !this.#generatorOptions.roles.some(role => role.id === this.#candidate.generation?.templateId)) this.#candidate = null;
        const roles = this.#buildOptions(this.#generatorOptions.roles || [], this.#selectedRoleId || this.#generatorOptions.defaults?.roleId || "random");
        const genders = this.#buildOptions(this.#generatorOptions.genders || [], this.#selectedGender || this.#generatorOptions.defaults?.gender || "random");
        const speciesOptions = this.#generatorOptions.species || [];
        if (!speciesOptions.some(option => option.id === this.#selectedSpeciesId)) {
            this.#selectedSpeciesId = speciesOptions.find(option => option.id === this.#generatorOptions.defaults?.speciesId)?.id || speciesOptions[0]?.id || "";
        }
        const species = speciesOptions.map(option => ({ ...option, selected: option.id === this.#selectedSpeciesId }));
        const connectionScene = this.#sceneConnectionId ? game.scenes.get(this.#sceneConnectionId) || null : null;
        return {
            name: "New Person",
            generators: [
                {
                    id: "",
                    label: "Manual Person",
                    selected: !this.#selectedGeneratorId
                },
                ...generators.map(generator => ({
                    ...generator,
                    selected: generator.id === this.#selectedGeneratorId
                }))
            ],
            hasGenerators: generators.length > 0,
            hasGeneratorSelected: !!this.#selectedGeneratorId,
            selectedGeneratorId: this.#selectedGeneratorId,
            generatorOptions: {
                roles,
                genders,
                species,
                hasSpecies: species.length > 0,
                noSpecies: this.#generatorOptions.requiresSpecies && !species.length,
                hasRoles: roles.length > 0,
                noRoles: this.#generatorOptions.requiresRole && !roles.length,
                hasGenders: genders.length > 0
            },
            candidate: this.#candidate ? {
                profile: NpcProfileViewModel.fromCandidate(this.#candidate, {
                    compactMode: true,
                    includeDescriptorInSubtitle: true,
                    showDefaultFields: false,
                    emptyTraitsLabel: "No personality traits rolled."
                }),
                data: this.#candidate
            } : null,
            hasCandidate: !!this.#candidate,
            sceneConnection: {
                available: !!connectionScene,
                sceneName: connectionScene?.name || "",
                checked: !!connectionScene && this.#connectToScene
            }
        };
    }

    async _onChangeForm(config, event) {
        super._onChangeForm(config, event);
        const { name, value, checked } = event.target;
        if (name === "generatorId") {
            this.#generationRequest++;
            this.#selectedGeneratorId = value || "";
            GeneratorSessionPreference.remember("npc", this.#selectedGeneratorId, getNpcGenerators());
            this.#selectedRoleId = "random";
            this.#selectedGender = "random";
            this.#selectedSpeciesId = "";
            this.#candidate = null;
            this.render({ parts: ["content"] });
        } else if (["generatorRoleId", "generatorGender", "generatorSpeciesId"].includes(name)) {
            if (name === "generatorRoleId") this.#selectedRoleId = value || "random";
            if (name === "generatorGender") this.#selectedGender = value || "random";
            if (name === "generatorSpeciesId") this.#selectedSpeciesId = value || "";
            if (this.#candidate || name === "generatorSpeciesId") await this.#generateCandidate(this.element?.querySelector?.("form") || this.element);
        } else if (name === "connectToCurrentScene") {
            this.#connectToScene = checked;
        }
    }

    static async _onCreateNpc(event) {
        event?.preventDefault?.();
        const app = this;
        if (app.#accepting) return;
        const form = app.element?.querySelector?.("form") || app.element;
        app.#syncSceneConnection(form);
        const formData = new FormData(form);
        const generatorId = String(formData.get("generatorId") || "").trim();
        if (app.#candidate) {
            return;
        }
        if (generatorId) {
            await app.#generateCandidate(form);
            return;
        }
        app.#accepting = true;

        const name = String(formData.get("name") || "New Person").trim() || "New Person";
        const roleLabel = String(formData.get("roleLabel") || "").trim();
        let npc;
        try {
            npc = await createNpc({
            sourceModule: "augur-nexus",
            display: {
                name,
                color: "#55bdec"
            },
            role: {
                roleId: roleLabel.toLocaleLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, ""),
                roleLabel
            }
        });
        } catch (error) {
            app.#accepting = false;
            throw error;
        }
        await app.#connectNpcToScene(npc);
        await app.close();
        if (app.#onCreated) await app.#onCreated(npc, { candidate: null });
        if (app.#openAfterCreate) await openNpcDossier(npc.id);
    }

    static async _onCancel() {
        await this.close();
    }

    static async _onRerollCandidate() {
        const form = this.element?.querySelector?.("form") || this.element;
        await this.#generateCandidate(form);
    }

    static async _onEditCandidate() {
        if (!this.#candidate) return;
        if (this.#candidateEditor?.rendered) return this.#candidateEditor.bringToFront();
        this.#candidateEditor = NpcDataEditor.show({
            candidate: this.#candidate,
            onSave: updated => {
                this.#candidate = updated;
                this.render({ parts: ["content"] });
            }
        });
    }

    static async _onAcceptCandidate() {
        if (!this.#candidate) return;
        if (this.#accepting) return;
        if (!await this.#finishCandidateEditing()) return;
        const options = await getNpcGeneratorOptions(this.#selectedGeneratorId);
        if (options.requiresSpecies && !options.species.some(race => race.id === this.#candidate.generation?.raceTemplateId)) {
            this.#candidate = null;
            this.render();
            return ui.notifications.warn("This race is no longer available. Generate a new candidate.");
        }
        if (options.requiresRole && !options.roles.some(role => role.id === this.#candidate.generation?.templateId)) {
            this.#candidate = null; this.render();
            return ui.notifications.warn("This role is no longer available. Generate a new candidate.");
        }
        this.#accepting = true;
        this.#syncSceneConnection(this.element?.querySelector?.("form") || this.element);
        let npc;
        try {
            npc = await createNpc(this.#candidate);
        } catch (error) {
            this.#accepting = false;
            throw error;
        }
        await this.#connectNpcToScene(npc);
        const candidate = this.#candidate;
        await this.close();
        if (this.#onCreated) await this.#onCreated(npc, { candidate });
        if (this.#openAfterCreate) await openNpcDossier(npc.id);
    }

    async #finishCandidateEditing() {
        const editor = this.#candidateEditor;
        if (!editor) return true;
        if (!await editor.flushPendingSaves()) { editor.bringToFront(); return false; }
        await editor.close();
        if (editor.rendered) return false;
        this.#candidateEditor = null;
        return true;
    }

    async #generateCandidate(form) {
        if (!await this.#finishCandidateEditing()) return;
        const request = ++this.#generationRequest;
        const formData = new FormData(form);
        this.#syncSceneConnection(form);
        const generatorId = String(formData.get("generatorId") || this.#selectedGeneratorId || "").trim();
        if (!generatorId) return;
        const available = await getNpcGeneratorOptions(generatorId);
        if (request !== this.#generationRequest) return;
        if (available.requiresSpecies && !available.species.length) {
            this.#candidate = null;
            this.render();
            return ui.notifications.warn("No races are available. Show or create a race in World Templates.");
        }
        this.#selectedGeneratorId = generatorId;
        GeneratorSessionPreference.remember("npc", generatorId, getNpcGenerators());
        this.#selectedRoleId = String(formData.get("generatorRoleId") || "random").trim() || "random";
        this.#selectedGender = String(formData.get("generatorGender") || "random").trim() || "random";
        this.#selectedSpeciesId = String(formData.get("generatorSpeciesId") || this.#selectedSpeciesId || "").trim();
        let candidate;
        try { candidate = await generateNpc(generatorId, {
            ...(this.#selectedSpeciesId ? { speciesId: this.#selectedSpeciesId } : {}),
            roleId: this.#selectedRoleId,
            gender: this.#selectedGender,
            context: foundry.utils.deepClone(this.#generationContext)
        }); } catch (error) {
            if (request !== this.#generationRequest) return;
            this.#candidate = null;
            ui.notifications.error(error.message);
            this.render();
            return;
        }
        if (request !== this.#generationRequest || this.#accepting || this.rendered === false) return;
        this.#candidate = candidate;
        this.render({ parts: ["content"] });
    }

    #syncSceneConnection(form) {
        if (!this.#sceneConnectionId || !form) return;
        this.#connectToScene = new FormData(form).has("connectToCurrentScene");
    }

    async #connectNpcToScene(npc) {
        if (!this.#connectToScene || !this.#sceneConnectionId || !npc) return null;
        const sceneTarget = ConnectionTargetResolver.fromSceneReference({ sceneId: this.#sceneConnectionId });
        const npcTarget = ConnectionTargetResolver.fromCampaignEntity(npc);
        if (!sceneTarget || !npcTarget) return null;
        try {
            return await ConnectionStore.addConnection(sceneTarget, npcTarget, {
                sourceView: { category: "npc", role: "Present" },
                targetView: { category: "place", role: "Located At" }
            });
        } catch (error) {
            console.error("Augur: Nexus | Failed to connect a newly created Person to the current Scene.", error);
            ui.notifications.warn("The Person was created, but could not be connected to the current scene.");
            return null;
        }
    }

    #buildOptions(options = [], selectedId = "random") {
        const rows = options.map(option => ({
            ...option,
            selected: option.id === selectedId
        }));
        if (!rows.some(option => option.id === "random")) {
            rows.unshift({
                id: "random",
                label: "Any",
                selected: selectedId === "random"
            });
        }
        return rows.map(option => ({
            ...option,
            label: option.id === "random" ? "Any" : option.label
        }));
    }
}
