import { attachDossierHelpButton } from "../../../api/help.js";
import { buildDossierActionItems } from "../components/DossierActionItems.js";
import { renderDossierControls, bindDossierControls } from "../components/DossierHeaderControls.js";
import { prepareNpcDossierFooter, openNpcLinkedActor, manageNpcActorLink } from "../components/NpcDossierFooter.js";
import { prepareDossierCover } from "../../../support/appearance/DossierCoverPresentation.js";
import { prepareNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";
import { NpcReadingViewModel } from "../models/NpcReadingViewModel.js";
import { bindConnectedObjectMenus } from "../../connections/services/ConnectedObjectMenu.js";
import { CampaignEntityDeletion } from "../services/CampaignEntityDeletion.js";
import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { openActionMenu, promptTextInput } from "../../../api/ui.js";
import { canRerollNpcCurrentThread, getNpc, rerollNpcCurrentThread, updateNpc } from "../../../api/npcs.js";
import { ConnectionsBoard } from "../../connections/components/ConnectionsBoard.js";
import { ConnectionOpinionService } from "../../connections/services/ConnectionOpinionService.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { SiteCoverPicker } from "../../site/applications/SiteCoverPicker.js";
import { NpcHeaderModel } from "../models/NpcHeaderModel.js";
import { PlayerNpcVisibilityDialog } from "../../nexus/applications/PlayerNpcVisibilityDialog.js";
import { openHelp } from "../../../api/help.js";
import { DossierTabPreference } from "../../nexus/services/DossierTabPreference.js";
import { applySessionWindowPlacement, rememberSessionWindowPlacement } from "/modules/augur-nexus/scripts/api/window-placement.js";
import { NpcEntityModel } from "../models/NpcEntityModel.js";
import { NpcLifeViewModel } from "../models/NpcLifeViewModel.js";
import { NpcProfileViewModel } from "../models/NpcProfileViewModel.js";
import { NpcCompactProfile } from "../components/NpcCompactProfile.js";
import { bindEntityDisclosureControls, openEntityDisclosureMenu } from "../services/EntityDisclosureControls.js";
import { CampaignEntityDossierRefresh } from "../services/CampaignEntityDossierRefresh.js";
import { CampaignEntityJournalStore } from "../services/CampaignEntityJournalStore.js";
import { CampaignEntityVisibilityManager } from "../services/CampaignEntityVisibilityManager.js";
import { NpcVisibilityManager } from "../services/NpcVisibilityManager.js";
import { NpcDataEditor } from "./NpcDataEditor.js";
import { EntityArtworkApplication } from "./EntityArtworkApplication.js";
import { NpcPortraitPicker } from "./NpcPortraitPicker.js";
import { EntityChroniclePanel } from "../../region-population/components/EntityChroniclePanel.js";
import { EXPANDED_DOSSIER_DEFAULT_SIZE } from "../../../support/ui/DossierWindowDefaults.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const PLACEMENT_KEY = "augur-nexus.npc-dossier";
const COMPACT_WIDTH = 420;
let npcDossierCompactPreference = false;


export class NpcDossier extends HandlebarsApplicationMixin(ApplicationV2) {
    #npcId = "";
    #activeTab = "profile";
    #connectionsBoard = null;
    #chroniclePanel = null;
    #connectionsChangedHook = null;
    #entitiesChangedHook = null;
    #lastModel = null;
    #positionInitialized = false;
    #isCompact = false;
    #expandedPosition = null;
    #compactProfile = new NpcCompactProfile();

    static DEFAULT_OPTIONS = {
        actions: { entityDisclosureMenu: function(_event, button) { return openEntityDisclosureMenu(this.#npcId, button); },
            toggleNpcCompactSection: function(_event, button) { return this.#compactProfile.toggle(this.#npcId, button.dataset.section, () => this.render({ parts: ["content"] }), () => this.element); } },
        id: "augur-nexus-npc-dossier",
        classes: ["augur-nexus", "npc-dossier", "augur-theme-fantasy"],
        tag: "div",
        window: {
            title: "Person",
            resizable: true,
            minimizable: true
        },
        position: { ...EXPANDED_DOSSIER_DEFAULT_SIZE }
    };

    static PARTS = {
        content: {
            template: "modules/augur-nexus/templates/campaign-entities/npc-dossier.hbs",
            scrollable: [".entity-journal-reading", ".npc-life-dossier > .npc-dossier-section", ".npc-life-world-ties-scroll", ".npc-reading-character"],
            templates: [
                "modules/augur-nexus/templates/campaign-entities/npc-dossier-footer.hbs",
                "modules/augur-nexus/templates/campaign-entities/entity-journal-panel.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-reading-profile.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-current-thread.hbs",
                "modules/augur-nexus/templates/campaign-entities/quest-world-ties.hbs",
                "modules/augur-nexus/templates/connections/connections-board.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-life-overview.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-world-ties.hbs",
                "modules/augur-nexus/templates/campaign-entities/compact-section-heading.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-profile-panel.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-portrait.hbs",
                "modules/augur-nexus/templates/site/site-cover-picker.hbs"
            ]
        }
    };

    get title() {
        return this.#lastModel?.npc?.name || "Person";
    }

    static show({ npcId } = {}) {
        if (!npcId) return null;
        const entity = getNpc(npcId);
        if (entity && !NpcVisibilityManager.canUserSeeNpc(entity)) {
            ui.notifications.warn("That person is not currently visible.");
            return null;
        }
        const app = new this({ npcId });
        app.render(true, { focus: true });
        return app;
    }

    constructor({ npcId } = {}, options = {}) {
        super(options);
        this.#isCompact = npcDossierCompactPreference;
        this.#npcId = npcId || "";
        this.#chroniclePanel = new EntityChroniclePanel({ entityId: this.#npcId });
        this.#activeTab = DossierTabPreference.getDefaultTab(getNpc(this.#npcId));
        this.#connectionsChangedHook = () => this.refresh();
        this.#entitiesChangedHook = event => {
            const changedEntityId = event?.entity?.id || "";
            const currentNodeId = ConnectionTargetResolver.getEntityNodeId(this.#npcId);
            const changedNodeId = ConnectionTargetResolver.getEntityNodeId(changedEntityId);
            const affectsTrackedOpinion = changedEntityId && ConnectionStore.getConnectionsForNode(currentNodeId)
                .some(({ edge, node }) => node.id === changedNodeId && ConnectionOpinionService.isTracked(edge));
            const affectsLifeProjection = changedEntityId && ConnectionStore.getConnectionsForNode(currentNodeId)
                .some(({ node }) => node.id === changedNodeId);
            if (!changedEntityId || changedEntityId === this.#npcId || affectsTrackedOpinion || affectsLifeProjection) this.refresh();
        };
        Hooks.on("augurNexusConnectionsChanged", this.#connectionsChangedHook);
        Hooks.on("augurNexusAppearanceChanged", this.#connectionsChangedHook);
        Hooks.on("augurNexusCampaignEntitiesChanged", this.#entitiesChangedHook);
        CampaignEntityDossierRefresh.watch(this);
    }

    async _prepareContext() {
        const entity = getNpc(this.#npcId);
        if (entity && !NpcVisibilityManager.canUserSeeNpc(entity)) {
            return {
                missing: true,
                npc: { name: "Hidden Person" },
                connections: { board: null }
            };
        }
        if (!entity) {
            return {
                missing: true,
                npc: { name: "Missing Person" },
                connections: { board: null }
            };
        }

        const target = ConnectionTargetResolver.fromCampaignEntity(entity);
        if (!this.#connectionsBoard) this.#connectionsBoard = new ConnectionsBoard({ target, getCompact: () => this.#isCompact, isGM: game.user.isGM });
        else this.#connectionsBoard.setTarget(target);

        const page = CampaignEntityJournalStore.getJournalPage(entity.id);
        const hasChronicle = this.#chroniclePanel.hasEvents();
        if (this.#activeTab === "chronicle" && !hasChronicle) this.#activeTab = "profile";
        const content = await this.#enrichJournalContent(page);
        const npcFooter = await prepareNpcDossierFooter(entity);
        const linkedActor = npcFooter.linkedActor;
        const canRerollCurrentThread = canControlPlayerEntity(this.#npcId) && canRerollNpcCurrentThread(entity);
        const life = NpcLifeViewModel.fromEntity(entity, { canRerollCurrentThread });

        const model = {
            npc: {
                id: entity.id,
                name: NpcEntityModel.getName(entity),
                profile: NpcProfileViewModel.fromEntity(entity, {
                    ...this.#compactProfile.context(entity.id, life),
                    canToggleSections: this.#isCompact,
                    canEditTies: canControlPlayerEntity(this.#npcId),
                    showTabs: true,
                    showCompactToggle: true,
                    showDefaultFields: false,
                    includeDescriptorInSubtitle: true,
                    compactMode: this.#isCompact,
                    showActions: canControlPlayerEntity(this.#npcId),
                    activeTab: this.#activeTab,
                    hasChronicle,
                    linkedActor,
                    showBody: this.#activeTab === "profile",
                    showCore: this.#isCompact,
                    importance: life.importance,
                    currentThread: life.currentThread,
                    canRerollCurrentThread,
                    canDrag: canControlPlayerEntity(this.#npcId)
                })
            },
            life,
            npcFooter,
            npcManagement: game.user.isGM,
            dossier: {
                isCompact: this.#isCompact,
                isProfileTab: this.#activeTab === "profile",
                isJournalTab: this.#activeTab === "journal",
                isConnectionsTab: this.#activeTab === "connections",
                isChronicleTab: this.#activeTab === "chronicle"
            },
            chronicleHtml: hasChronicle ? await this.#chroniclePanel.render() : "",
            journal: {
                hasPage: !!page,
                entryId: page?.parent?.id || entity.journalEntryId || "",
                pageId: page?.id || "",
                content,
                hasContent: !!String(page?.text?.content || "").trim()
            },
            connections: {
                board: this.#connectionsBoard.getContext(this.#activeTab === "journal" ? { display: "list", hideViewToggle: true } : {})
            },
            appearance: prepareNexusThemeSurface(),
            dossierCover: prepareDossierCover(entity),
            isGM: game.user.isGM, canEdit: canControlPlayerEntity(this.#npcId)
        };
        model.npc.profile.hideLinkedActorTab = game.user.isGM;
        model.npc.profile.controlsHtml = await renderDossierControls({ entity, canEdit: model.canEdit, compact: this.#isCompact, compactAction: "toggleNpcDossierCompact", visibility: null });
        model.npc.header = { ...model.npc.profile, hidePortrait: model.dossier.isProfileTab, showBody: false };
        model.reading = NpcReadingViewModel.fromProfile(model.npc.profile, life);
        this.#lastModel = model;
        return model;
    }

    _attachPartListeners(partId, htmlElement, options) {
        if (super._attachPartListeners) super._attachPartListeners(partId, htmlElement, options);
        const element = htmlElement instanceof HTMLElement ? htmlElement : htmlElement?.[0];
        if (!element) return;

        this.#activateActionListeners(element);
    }

    #activateActionListeners(element) {
        bindDossierControls(element, { edit: () => this.#editNpc(), options: anchor => NpcDossier._onOpenNpcActions.call(this, null, anchor), visibility: anchor => this.#openNpcVisibilityMenu(anchor) });
        const root = element instanceof HTMLElement ? element : element?.[0] || element;
        if (root) bindEntityDisclosureControls(root, () => this.#npcId);
        const portrait = root?.querySelector("[data-npc-dossier-drag='true']");
        if (portrait && !portrait.dataset.npcDossierDragBound) {
            portrait.dataset.npcDossierDragBound = "true";
            portrait.addEventListener("dragstart", event => {
                const entity = getNpc(this.#npcId);
                const target = ConnectionTargetResolver.fromCampaignEntity(entity);
                if (!ConnectionTargetResolver.setDragData(event.dataTransfer, target, { effectAllowed: "copy" })) {
                    event.preventDefault();
                    return;
                }
                event.stopPropagation();
                portrait.classList.add("is-dragging");
            });
            portrait.addEventListener("dragend", () => portrait.classList.remove("is-dragging"));
        }

        root?.querySelectorAll("[data-action='setNpcDossierTab']").forEach(button => {
            if (button.dataset.npcDossierBound) return;
            button.dataset.npcDossierBound = "true";
            button.addEventListener("click", event => {
                event.preventDefault();
                event.stopPropagation();
                NpcDossier._onSetDossierTab.call(this, event, event.currentTarget);
            });
        });

        const actionsButton = root?.querySelector("[data-action='openNpcActions']");
        if (actionsButton && !actionsButton.dataset.npcDossierBound) actionsButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            NpcDossier._onOpenNpcActions.call(this, event, event.currentTarget);
        });
        if (actionsButton) actionsButton.dataset.npcDossierBound = "true";

        const compactButton = root?.querySelector("[data-action='toggleNpcDossierCompact']");
        if (compactButton && !compactButton.dataset.npcDossierBound) compactButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            void this.#toggleCompactMode();
        });
        if (compactButton) compactButton.dataset.npcDossierBound = "true";

        const createJournalButton = root?.querySelector("[data-action='createNpcJournal']");
        if (createJournalButton && !createJournalButton.dataset.npcDossierBound) createJournalButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            NpcDossier._onCreateNpcJournal.call(this, event, event.currentTarget);
        });
        if (createJournalButton) createJournalButton.dataset.npcDossierBound = "true";

        const openJournalButton = root?.querySelector("[data-action='openNpcJournal']");
        if (openJournalButton && !openJournalButton.dataset.npcDossierBound) openJournalButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            NpcDossier._onOpenNpcJournal.call(this, event, event.currentTarget);
        });
        if (openJournalButton) openJournalButton.dataset.npcDossierBound = "true";

        for (const openLinkedActorButton of root?.querySelectorAll("[data-action='openNpcLinkedActor']") || []) {
            if (!openLinkedActorButton.dataset.npcDossierBound) openLinkedActorButton.addEventListener("click", event => {
                event.preventDefault();
                event.stopPropagation();
                void this.#openLinkedActor();
            });
            openLinkedActorButton.dataset.npcDossierBound = "true";
        }

        for (const linkActorButton of root?.querySelectorAll("[data-action='manageNpcActorLink'], [data-action='linkNpcActor']") || []) {
            if (!linkActorButton.dataset.npcDossierBound) linkActorButton.addEventListener("click", event => {
                event.preventDefault();
                event.stopPropagation();
                void this.#manageActorLink();
            });
            linkActorButton.dataset.npcDossierBound = "true";
        }

        const rerollThreadButton = root?.querySelector("[data-action='rerollNpcCurrentThread']");
        if (rerollThreadButton && !rerollThreadButton.dataset.npcDossierBound) rerollThreadButton.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            void this.#rerollCurrentThread(event.currentTarget);
        });
        if (rerollThreadButton) rerollThreadButton.dataset.npcDossierBound = "true";

        root?.querySelectorAll("[data-npc-life-node]").forEach(button => {
            if (button.dataset.npcLifeBound) return;
            button.dataset.npcLifeBound = "true";
            button.addEventListener("click", async event => {
                const node = ConnectionStore.getNode(event.currentTarget.dataset.npcLifeNode || "");
                if (node) await ConnectionTargetResolver.openNode(node);
            });
            button.addEventListener("dragstart", event => {
                const node = ConnectionStore.getNode(event.currentTarget.dataset.npcLifeNode || "");
                if (node) ConnectionTargetResolver.setDragData(event.dataTransfer, node, { effectAllowed: "copyMove" });
            });
        });

        root?.querySelectorAll("[data-npc-life-opinion]").forEach(button => {
            if (button.dataset.npcLifeOpinionBound) return;
            button.dataset.npcLifeOpinionBound = "true";
            button.addEventListener("click", event => {
                event.preventDefault();
                event.stopPropagation();
                this.#connectionsBoard?.openOpinionSummary(button, this);
            });
        });

        const resetFeaturedButton = root?.querySelector("[data-action='resetNpcFeaturedConnection']");
        if (resetFeaturedButton && !resetFeaturedButton.dataset.npcFeaturedBound) {
            resetFeaturedButton.dataset.npcFeaturedBound = "true";
            resetFeaturedButton.addEventListener("click", event => {
                event.preventDefault();
                event.stopPropagation();
                void this.#setFeaturedConnection("");
            });
        }

        const featuredDrop = root?.querySelector("[data-npc-featured-drop]");
        if (canControlPlayerEntity(this.#npcId) && featuredDrop && !featuredDrop.dataset.npcFeaturedBound) {
            featuredDrop.dataset.npcFeaturedBound = "true";
            featuredDrop.addEventListener("dragover", event => {
                event.preventDefault();
                event.stopPropagation();
                if (event.dataTransfer) event.dataTransfer.dropEffect = "link";
                featuredDrop.classList.add("is-drop-target");
            });
            featuredDrop.addEventListener("dragleave", event => {
                if (featuredDrop.contains(event.relatedTarget)) return;
                featuredDrop.classList.remove("is-drop-target");
            });
            featuredDrop.addEventListener("drop", event => {
                event.preventDefault();
                event.stopPropagation();
                featuredDrop.classList.remove("is-drop-target");
                void this.#featureDroppedConnection(event);
            });
        }
    }


    async #featureDroppedConnection(event) {
        if (!canControlPlayerEntity(this.#npcId) || !this.#connectionsBoard) return;
        try {
            const edge = await this.#connectionsBoard.connectFromDrop(event);
            if (edge?.id) await this.#setFeaturedConnection(edge.id);
        } catch (error) {
            console.error("Augur Nexus | Failed to feature NPC connection", error);
            ui.notifications.error(error?.message || "That connection could not be featured.");
        }
    }

    async #setFeaturedConnection(edgeId = "") {
        const entity = getNpc(this.#npcId);
        if (!canControlPlayerEntity(this.#npcId) || !entity) return;
        await updateNpc(entity.id, {
            dossier: { featuredConnectionId: String(edgeId || "").trim() }
        });
        this.refresh();
    }
    _onRender(context, options) {
        super._onRender(context, options);
        attachDossierHelpButton(this, "npc");
        bindConnectedObjectMenus(this.element, { getOwner: () => ConnectionTargetResolver.fromCampaignEntity(getNpc(this.#npcId)), onChanged: () => this.refresh(), getItems: ({ edge, card }) => this.#connectionsBoard?.getCardItems(edge.id, this, card) });
        if (this.window?.title) this.window.title.textContent = this.title;
        this.#activateActionListeners(this.element);
        this.#connectionsBoard?.activateListeners(this.element, this);
        this.#chroniclePanel?.activateListeners(this.element, this);
        if (!this.#positionInitialized) {
            const expanded = applySessionWindowPlacement(this, PLACEMENT_KEY, { fallback: "center" });
            if (this.#isCompact) {
                this.#expandedPosition = expanded ? { ...expanded } : this.#getCurrentPosition();
                this.#applyCompactPosition(this.#expandedPosition);
            }
            this.#positionInitialized = true;
        }
    }

    async #toggleCompactMode() {
        if (!this.#isCompact) {
            rememberSessionWindowPlacement(this, PLACEMENT_KEY);
            this.#expandedPosition = this.#getCurrentPosition();
        }
        this.#isCompact = !this.#isCompact;
        npcDossierCompactPreference = this.#isCompact;
        await this.render({ parts: ["content"] });
        if (this.#isCompact) this.#applyCompactPosition(this.#expandedPosition);
        else if (this.#expandedPosition) this.setPosition(this.#expandedPosition);
        else applySessionWindowPlacement(this, PLACEMENT_KEY, { fallback: "center" });
    }

    #applyCompactPosition(source = null) {
        const current = source || this.#getCurrentPosition() || {};
        const oldWidth = Number(current.width || this.position?.width || this.element?.offsetWidth || COMPACT_WIDTH);
        const oldLeft = Number(current.left ?? this.position?.left ?? 20);
        const width = Math.min(COMPACT_WIDTH, Math.max(320, window.innerWidth - 40));
        const right = oldLeft + oldWidth;
        const left = Math.min(Math.max(20, right - width), Math.max(20, window.innerWidth - width - 20));
        const position = {
            left,
            top: Number(current.top ?? this.position?.top ?? 20),
            width,
            height: Number(current.height || this.position?.height || this.element?.offsetHeight || EXPANDED_DOSSIER_DEFAULT_SIZE.height)
        };
        this.setPosition(position);
    }

    #getCurrentPosition() {
        const position = this.position || {};
        const left = Number(position.left ?? this.element?.offsetLeft ?? NaN);
        const top = Number(position.top ?? this.element?.offsetTop ?? NaN);
        if (!Number.isFinite(left) || !Number.isFinite(top)) return null;
        return {
            left,
            top,
            width: Number(position.width || this.element?.offsetWidth || EXPANDED_DOSSIER_DEFAULT_SIZE.width),
            height: Number(position.height || this.element?.offsetHeight || EXPANDED_DOSSIER_DEFAULT_SIZE.height)
        };
    }

    async close(options) {
        await this.#connectionsBoard?.destroy();
        if (!this.#isCompact) rememberSessionWindowPlacement(this, PLACEMENT_KEY);
        CampaignEntityDossierRefresh.unwatch(this);
        this.#chroniclePanel?.destroy();
        if (this.#connectionsChangedHook) Hooks.off("augurNexusConnectionsChanged", this.#connectionsChangedHook);
        if (this.#connectionsChangedHook) Hooks.off("augurNexusAppearanceChanged", this.#connectionsChangedHook);
        if (this.#entitiesChangedHook) Hooks.off("augurNexusCampaignEntitiesChanged", this.#entitiesChangedHook);
        return super.close(options);
    }

    matchesCampaignEntityJournal({ entryId, pageId } = {}) {
        const journal = this.#lastModel?.journal || null;
        if (!journal?.entryId) return false;
        if (pageId) return journal.pageId === pageId;
        return journal.entryId === entryId;
    }

    refreshCampaignEntityDossier() {
        this.refresh();
    }

    refresh() {
        if (this.rendered === false) return;
        this.render({ parts: ["content"] });
    }

    static async _onSetDossierTab(_event, target) {
        const tab = target?.dataset?.tab || "profile";
        this.#activeTab = ["journal", "connections", "chronicle"].includes(tab) ? tab : "profile";
        this.render({ parts: ["content"] });
    }

    static async _onOpenNpcActions(_event, target) {
        const app = this;
        if (!canControlPlayerEntity(this.#npcId)) return;
        const entity = getNpc(app.#npcId);
        if (!entity) return;
        openActionMenu({
            anchor: target,
            className: "npc-dossier-actions-menu",
            items: buildDossierActionItems({ entity, hasCover: !!NpcEntityModel.getCoverImage(entity), dark: prepareNexusThemeSurface().mode === "dark", actions: {
                edit: () => app.#editNpc(),
                artwork: () => EntityArtworkApplication.show({ entityId: app.#npcId, onChooseArtwork: () => app.#changePortrait() }),
                linkedActor: () => app.#manageActorLink(), defaultTab: () => app.#openDefaultDossierTabMenu(target),
                changeCover: () => app.#changeCoverImage(), clearCover: () => app.#setCoverImage(""),
                visibility: () => app.#openNpcVisibilityMenu(target), delete: () => app.#deleteNpc()
            } })
        });
    }

    #openDefaultDossierTabMenu(anchor) {
        const entity = getNpc(this.#npcId);
        if (!canControlPlayerEntity(this.#npcId) || !entity) return;
        openActionMenu({
            anchor,
            className: "npc-dossier-actions-menu",
            items: DossierTabPreference.buildMenuItems(
                DossierTabPreference.getDefaultTab(entity),
                tab => this.#setDefaultDossierTab(tab)
            )
        });
    }

    async #setDefaultDossierTab(tab) {
        const entity = getNpc(this.#npcId);
        if (!canControlPlayerEntity(this.#npcId) || !entity) return;
        const defaultTab = DossierTabPreference.normalizeTab(tab);
        await updateNpc(entity.id, { dossier: { defaultTab } });
        this.#activeTab = defaultTab;
        this.refresh();
    }

    #openNpcVisibilityMenu(anchor) {
        const entity = getNpc(this.#npcId);
        if (!game.user.isGM || !entity) return;
        const current = CampaignEntityVisibilityManager.getPlayerVisibilityOverride(entity);
        openActionMenu({
            anchor,
            className: "nexus-scene-player-access-menu",
            items: [
                {
                    id: "inherit",
                    label: current === "inherit" ? "Global (Current)" : "Global",
                    icon: "fas fa-layer-group",
                    onSelect: () => this.#setNpcPlayerVisibility("inherit")
                },
                {
                    id: "show",
                    label: current === "show" ? "Yes (Current)" : "Yes",
                    icon: "fas fa-eye",
                    onSelect: () => this.#setNpcPlayerVisibility("show")
                },
                {
                    id: "hide",
                    label: current === "hide" ? "No (Current)" : "No",
                    icon: "fas fa-eye-slash",
                    onSelect: () => this.#setNpcPlayerVisibility("hide")
                },
                {
                    id: "change-global",
                    label: "Change Global Setting...",
                    icon: "fas fa-sliders",
                    onSelect: () => PlayerNpcVisibilityDialog.show("npc")
                },
                {
                    id: "player-visibility-info",
                    label: "What's this?",
                    icon: "fas fa-circle-info",
                    onSelect: () => openHelp("augur-nexus:object-visibility")
                }
            ]
        });
    }

    async #openLinkedActor() {
        return openNpcLinkedActor(getNpc(this.#npcId));
    }

    async #rerollCurrentThread(button) {
        if (!canControlPlayerEntity(this.#npcId)) return;
        button.disabled = true;
        try {
            const updated = await rerollNpcCurrentThread(this.#npcId);
            if (!updated) {
                ui.notifications.warn("This person's generator cannot reroll their Current Thread.");
                return;
            }
            this.refresh();
        } catch (error) {
            console.error("Augur Nexus | Failed to reroll NPC Current Thread", error);
            ui.notifications.error(error.message || "The Current Thread could not be rerolled.");
        } finally {
            button.disabled = false;
        }
    }

    async #manageActorLink() {
        return manageNpcActorLink(getNpc(this.#npcId), () => this.refresh());
    }

    async #setNpcPlayerVisibility(value) {
        const entity = getNpc(this.#npcId);
        if (!game.user.isGM || !entity) return;
        await CampaignEntityVisibilityManager.setPlayerVisibilityOverride(entity.id, "npc", value);
        this.refresh();
    }

    static async _onCreateNpcJournal() {
        await this.#editJournal({ create: true });
    }

    static async _onOpenNpcJournal() {
        await this.#editJournal({ create: false });
    }

    async #renameNpc() {
        const entity = getNpc(this.#npcId);
        if (!entity) return;
        const name = await promptTextInput({
            title: "Rename Person",
            label: "Name",
            value: NpcEntityModel.getName(entity),
            confirmLabel: "Rename"
        });
        if (!name) return;
        await updateNpc(entity.id, { display: { name } });
        this.refresh();
    }

    #editNpc() {
        const entity = getNpc(this.#npcId);
        if (!canControlPlayerEntity(this.#npcId) || !entity) return;
        NpcDataEditor.show({
            npcId: entity.id,
            onSave: () => this.refresh()
        });
    }

    #changePortrait() {
        const entity = getNpc(this.#npcId);
        if (!canControlPlayerEntity(this.#npcId) || !entity) return;
        new NpcPortraitPicker({
            currentPortraitSrc: NpcEntityModel.getImage(entity),
            raceTemplateId: NpcEntityModel.getRaceTemplateId(entity),
            onSelect: selection => this.#setPortrait(selection?.src || "", selection?.tokenImageSrc || "")
        }).render(true, { focus: true });
    }

    async #setPortrait(path, tokenImageSrc = "") {
        const entity = getNpc(this.#npcId);
        if (!canControlPlayerEntity(this.#npcId) || !entity || !path) return;
        await updateNpc(entity.id, { display: { imageSrc: path, tokenImageSrc } });
        this.refresh();
    }

    #changeCoverImage() {
        if (!game.user.isGM || prepareNexusThemeSurface().mode !== "dark") return;
        const entity = getNpc(this.#npcId);
        if (!canControlPlayerEntity(this.#npcId) || !entity) return;
        SiteCoverPicker.show({
            current: prepareDossierCover(entity).src,
            onSelect: path => this.#setCoverImage(path || "")
        });
    }

    async #setCoverImage(path) {
        if (!game.user.isGM || prepareNexusThemeSurface().mode !== "dark") return;
        const entity = getNpc(this.#npcId);
        if (!canControlPlayerEntity(this.#npcId) || !entity) return;
        await updateNpc(entity.id, { display: { coverImageSrc: path || "" } });
        this.refresh();
    }

    async #editJournal({ create = true } = {}) {
        if (!game.user.isGM) return;
        const page = create
            ? await CampaignEntityJournalStore.getOrCreateJournalPage(this.#npcId)
            : CampaignEntityJournalStore.getJournalPage(this.#npcId);
        if (!page?.parent) {
            ui.notifications.warn("No journal page was found for this person.");
            return;
        }
        page.sheet?.render(true);
    }

    async #deleteNpc() {
        if (await CampaignEntityDeletion.confirm("npc", this.#npcId) === "deleted") await this.close();
    }

    async #enrichJournalContent(page) {
        const content = page?.text?.content || "";
        if (!String(content).trim()) return "";
        try {
            return foundry.applications.ux.TextEditor.implementation.enrichHTML(content, {
                relativeTo: page,
                secrets: page.isOwner
            });
        } catch (_err) {
            return content;
        }
    }
}
