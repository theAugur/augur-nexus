import { createFaction, generateFaction, getFactionGeneratorOptions, getFactionGenerators, openFactionDossier } from "../../../api/factions.js";
import { FactionEntityModel } from "../models/FactionEntityModel.js";
import { FactionProfileViewModel } from "../models/FactionProfileViewModel.js";
import { GeneratorSessionPreference } from "../services/GeneratorSessionPreference.js";
import { FactionDataEditor } from "./FactionDataEditor.js";
import { FactionDetailGeneration } from "../services/FactionDetailGeneration.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class FactionCreateDialog extends HandlebarsApplicationMixin(ApplicationV2) {
    #selectedGeneratorId = null;
    #selectedTypeId = "random";
    #generatorOptions = {};
    #candidate = null;
    #candidateEditor = null;
    #accepting = false;
    #onCreated = null;
    #openDossier = true;
    #existingFaction = null;
    #selection = {};
    #onApply = null;
    #onClosed = null;
    #generationRequest = 0;

    static showDetails(entity, { onApply, onClosed } = {}) {
        const app = new this({ existingFaction: entity, onApply, onClosed });
        app.render(true, { focus: true });
        return app;
    }

    get title() { return this.#existingFaction ? `Generate Details for ${this.#existingFaction.display?.name || "Organization"}` : super.title; }
    get #detailOptions() { return { freeOnly: !!this.#existingFaction && !getFactionGenerators().length }; }

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-faction-create",
        classes: ["augur-nexus", "npc-create-dialog", "faction-create-dialog", "augur-theme-fantasy"],
        tag: "div",
        window: {
            title: "New Organization",
            resizable: false,
            minimizable: false
        },
        position: {
            width: 420,
            height: "auto"
        },
        actions: {
            acceptCandidate: FactionCreateDialog._onAcceptCandidate,
            cancel: FactionCreateDialog._onCancel,
            rerollCandidate: FactionCreateDialog._onRerollCandidate,
            editCandidate: FactionCreateDialog._onEditCandidate
        }
    };

    static PARTS = {
        content: {
            template: "modules/augur-nexus/templates/campaign-entities/faction-create-dialog.hbs",
            templates: [
                "modules/augur-nexus/templates/campaign-entities/quest-world-ties.hbs",
                "modules/augur-nexus/templates/campaign-entities/faction-profile-panel.hbs",
                "modules/augur-nexus/templates/campaign-entities/faction-current-thread.hbs",
                "modules/augur-nexus/templates/campaign-entities/faction-diplomacy.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-portrait.hbs"
            ]
        }
    };

    static show({ onCreated = null, openDossier = true } = {}) {
        const app = new this({ onCreated, openDossier });
        app.render(true, { focus: true });
        return app;
    }

    constructor({ onCreated = null, openDossier = true, existingFaction = null, onApply = null, onClosed = null } = {}, options = {}) {
        super(options);
        this.#existingFaction = existingFaction ? foundry.utils.deepClone(existingFaction) : null;
        this.#onApply = onApply;
        this.#onClosed = onClosed;
        if (existingFaction) {
            this.#selection = Object.fromEntries(FactionDetailGeneration.groups(existingFaction, this.#detailOptions).map(group => [group.id, group.checked]));
            if (this.#detailOptions.freeOnly) this.#candidate = { ideology: FactionDetailGeneration.rollBeliefs() };
        }
        this.#onCreated = typeof onCreated === "function" ? onCreated : null;
        this.#openDossier = openDossier !== false;
    }

    async close(options = {}) {
        if (this.#existingFaction && this.#accepting) return this;
        this.#generationRequest++;
        if (!await this.#finishCandidateEditing()) return this;
        const result = await super.close(options);
        this.#onClosed?.();
        return result;
    }

    async _prepareContext() {
        const generators = getFactionGenerators();
        if (this.#selectedGeneratorId === null) {
            this.#selectedGeneratorId = GeneratorSessionPreference.resolve("faction", generators, { allowManual: !this.#existingFaction });
        }
        this.#generatorOptions = this.#selectedGeneratorId ? await getFactionGeneratorOptions(this.#selectedGeneratorId) : {};
        const types = this.#buildOptions(this.#generatorOptions.types || [], this.#selectedTypeId || this.#generatorOptions.defaults?.typeId || "random");
        const preview = this.#existingFaction ? FactionDetailGeneration.preview(this.#existingFaction, this.#candidate, this.#selection, this.#detailOptions) : this.#candidate;
        const candidateProfile = this.#candidate
            ? FactionProfileViewModel.fromCandidate(preview, { showCurrentThread: !!this.#existingFaction })
            : null;
        if (candidateProfile) candidateProfile.imageSrc = this.#existingFaction
            ? (this.#selection.emblem && !this.#detailOptions.freeOnly && !this.#existingFaction.projections?.actorUuid
                ? await FactionEntityModel.getImageAsync(this.#candidate) || await FactionEntityModel.getImageAsync(this.#existingFaction) : await FactionEntityModel.getImageAsync(this.#existingFaction))
            : await FactionEntityModel.getImageAsync(this.#candidate);
        return {
            existingFaction: !!this.#existingFaction,
            freeDetails: this.#detailOptions.freeOnly,
            replacementGroups: this.#existingFaction ? FactionDetailGeneration.groups(this.#existingFaction, this.#detailOptions).map(group => ({ ...group, checked: !group.disabled && this.#selection[group.id] })) : null,
            applyDisabled: !!this.#existingFaction && !Object.keys(FactionDetailGeneration.values(this.#existingFaction, this.#candidate, this.#selection, this.#detailOptions)).length,
            name: "New Organization",
            generators: [
                ...(!this.#existingFaction ? [{ id: "", label: "Manual Organization", selected: !this.#selectedGeneratorId }] : []),
                ...generators.map(generator => ({ ...generator, selected: generator.id === this.#selectedGeneratorId }))
            ],
            hasGenerators: generators.length > 0,
            hasGeneratorSelected: !!this.#selectedGeneratorId,
            selectedGeneratorId: this.#selectedGeneratorId,
            generatorOptions: {
                types,
                hasTypes: types.length > 0
            },
            candidate: this.#candidate ? {
                profile: candidateProfile,
                data: this.#candidate
            } : null,
            hasCandidate: !!this.#candidate
        };
    }

    _onRender(context, options) {
        super._onRender(context, options);
        this.element?.querySelectorAll('[name^="replaceGroup."]').forEach(input => input.addEventListener("change", event => {
            const id = event.target.name.slice("replaceGroup.".length);
            const group = FactionDetailGeneration.groups(this.#existingFaction, this.#detailOptions).find(group => group.id === id);
            if (group && !group.disabled) this.#selection[id] = event.target.checked;
            this.render({ parts: ["content"] });
        }));
        this.element?.querySelector("form")?.addEventListener("submit", event => {
            FactionCreateDialog._onCreateFaction.call(this, event);
        });
        this.element?.querySelector("[name='generatorId']")?.addEventListener("change", async event => {
            if (!await this.#finishCandidateEditing()) { event.target.value = this.#selectedGeneratorId || ""; return; }
            this.#selectedGeneratorId = event.currentTarget.value || "";
            GeneratorSessionPreference.remember("faction", this.#selectedGeneratorId, getFactionGenerators());
            this.#selectedTypeId = "random";
            this.#candidate = null;
            this.#generationRequest++;
            this.render({ parts: ["content"] });
        });
        this.element?.querySelector("[name='generatorTypeId']")?.addEventListener("change", async event => {
            this.#selectedTypeId = event.currentTarget.value || "random";
            if (this.#candidate) await this.#generateCandidate(this.element?.querySelector?.("form") || this.element);
        });
    }

    static async _onCreateFaction(event) {
        event?.preventDefault?.();
        const form = this.element?.querySelector?.("form") || this.element;
        if (this.#existingFaction) return this.#generateCandidate(form);
        const formData = new FormData(form);
        const generatorId = String(formData.get("generatorId") || "").trim();
        if (this.#candidate) return;
        if (generatorId) {
            await this.#generateCandidate(form);
            return;
        }

        const name = String(formData.get("name") || "New Organization").trim() || "New Organization";
        const type = String(formData.get("type") || "").trim();
        const faction = await createFaction({
            sourceModule: "augur-nexus",
            display: { name, color: "#83c95f" },
            profile: { type }
        });
        await this.#finishCreation(faction);
    }

    static async _onCancel() {
        await this.close();
    }

    static async _onRerollCandidate() {
        const form = this.element?.querySelector?.("form") || this.element;
        await this.#generateCandidate(form);
    }

    static async _onEditCandidate() {
        if (!this.#candidate || this.#existingFaction) return;
        if (this.#candidateEditor?.rendered) return this.#candidateEditor.bringToFront();
        this.#candidateEditor = FactionDataEditor.show({
            candidate: this.#candidate,
            onSave: updated => {
                this.#candidate = updated;
                this.render({ parts: ["content"] });
            }
        });
    }

    static async _onAcceptCandidate() {
        if (!this.#candidate || this.#accepting) return;
        this.#accepting = true;
        try {
            if (this.#existingFaction) {
                const values = FactionDetailGeneration.values(this.#existingFaction, this.#candidate, this.#selection, this.#detailOptions);
                if (!Object.keys(values).length || await this.#onApply?.(values) === false) return;
                this.#accepting = false;
                await this.close();
                return;
            }
            if (!await this.#finishCandidateEditing()) return;
            const faction = await createFaction(this.#candidate);
            await this.#finishCreation(faction);
        } catch (error) { ui.notifications.error(error.message); }
        finally { this.#accepting = false; }
    }

    async #finishCreation(faction) {
        await this.close();
        await this.#onCreated?.(faction);
        if (this.#openDossier) await openFactionDossier(faction.id);
    }

    async #finishCandidateEditing() {
        const editor = this.#candidateEditor;
        if (!editor) return true;
        if (!await editor.flushPendingSaves()) { editor.bringToFront(); return false; }
        await editor.close();
        if (editor.rendered) return false;
        this.#candidateEditor = null;
        return true;
    }

    async #generateCandidate(form) {
        if (this.#accepting || !await this.#finishCandidateEditing()) return;
        if (this.#detailOptions.freeOnly) {
            this.#candidate = { ideology: FactionDetailGeneration.rollBeliefs() };
            this.render({ parts: ["content"] });
            return;
        }
        const request = ++this.#generationRequest;
        const formData = new FormData(form);
        const generatorId = String(formData.get("generatorId") || this.#selectedGeneratorId || "").trim();
        if (!generatorId) return;
        this.#selectedGeneratorId = generatorId;
        GeneratorSessionPreference.remember("faction", generatorId, getFactionGenerators());
        this.#selectedTypeId = String(formData.get("generatorTypeId") || "random").trim() || "random";
        try {
            const candidate = await generateFaction(generatorId, { typeId: this.#selectedTypeId });
            if (request !== this.#generationRequest) return;
            this.#candidate = candidate;
        } catch (error) { ui.notifications.error(error.message); return; }
        this.render({ parts: ["content"] });
    }

    #buildOptions(options = [], selectedId = "random") {
        const rows = options.map(option => ({ ...option, selected: option.id === selectedId }));
        if (!rows.some(option => option.id === "random")) {
            rows.unshift({ id: "random", label: "Any", selected: selectedId === "random" });
        }
        return rows.map(option => ({ ...option, label: option.id === "random" ? "Any" : option.label }));
    }
}
