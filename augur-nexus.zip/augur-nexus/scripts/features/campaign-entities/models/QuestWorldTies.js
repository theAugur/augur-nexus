import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";

export function questWorldTies(nodeId) {
    return ConnectionStore.getConnectionsForNode(nodeId).filter(({ node }) => {
        if (node.entityType !== "quest") return false;
        const quest = game.journal.get(node.entityId)?.getFlag("augur-nexus", "campaignEntity");
        return quest?.type === "quest" && ["available", "ongoing"].includes(quest.status);
    }).map(({ edge, node }) => {
        const display = ConnectionTargetResolver.resolveDisplayNodeSync(node) || node;
        return { id: node.entityId, nodeId: node.id, edgeId: edge.id, name: display.name, imageSrc: display.img,
            role: ConnectionStore.getConnectionRoleForNode(edge, nodeId) };
    });
}
