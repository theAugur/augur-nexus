import { EntityDisclosure } from "./EntityDisclosure.js";
import { questWorldTies } from "./QuestWorldTies.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { FactionEntityModel } from "./FactionEntityModel.js";

export class FactionProfileViewModel {
    static fromEntity(entity = {}, options = {}) {
        return this.fromFactionLike(entity, options);
    }

    static fromCandidate(candidate = {}, options = {}) {
        const profile = this.fromFactionLike(candidate, options);
        return { ...profile, canManageDisclosure: false,
            ideology: profile.ideology.map(entry => ({ ...entry, disclosureEditable: false })),
            currentThread: profile.currentThread.map(entry => ({ ...entry, disclosureEditable: false })) };
    }

    static fromFactionLike(faction = {}, options = {}) {
        faction = { ...faction, type: "faction" };
        const hiddenDefaultFields = new Set(Array.isArray(faction?.dossier?.hiddenDefaultFields) ? faction.dossier.hiddenDefaultFields : []);
        const isVisible = chip => chip.value && !hiddenDefaultFields.has(chip.key);
        const ideology = options.showIdeology === false
            ? []
            : FactionEntityModel.getVisibleIdeology(faction);
        const currentThread = options.showCurrentThread === false ? [] : FactionEntityModel.getVisibleCurrentThread(faction);
        return {
            ...EntityDisclosure.context(faction),
            name: FactionEntityModel.getName(faction),
            subtitle: String(faction.profile?.type || "").trim() || "Organization",
            imageSrc: FactionEntityModel.getImage(faction),
            accent: FactionEntityModel.getAccent(faction),
            profileRows: FactionEntityModel.getProfileRows(faction),
            ideology,
            hasIdeology: ideology.length > 0,
            identityChips: options.showIdentity === false ? [] : [
                { key: "type", label: "Type", value: faction.profile?.type || "" },
                { key: "method", label: "Method", value: faction.profile?.method || "" }
            ].filter(isVisible),
            quests: faction.id ? questWorldTies(ConnectionTargetResolver.getEntityNodeId(faction.id)) : [],
            currentThread,
            hasCurrentThread: currentThread.length > 0,
            canRerollCurrentThread: options.canRerollCurrentThread === true,
            showTabs: options.showTabs === true,
            showCompactToggle: options.showCompactToggle === true,
            compactMode: options.compactMode === true,
            canToggleSections: options.canToggleSections === true,
            compactSectionId: options.compactSectionId,
            compactSectionAction: options.compactSectionAction,
            compactSections: options.compactSections,
            showActions: options.showActions === true,
            linkedActor: options.linkedActor || null,
            showHeaderActions: options.showActions === true || options.showCompactToggle === true,
            showBody: options.showBody !== false,
            showDiplomacy: options.showDiplomacy === true,
            hasChronicle: options.hasChronicle === true,
            tabs: {
                isProfileTab: options.activeTab === "profile",
                isJournalTab: options.activeTab === "journal",
                isConnectionsTab: options.activeTab === "connections",
                isChronicleTab: options.activeTab === "chronicle"
            },
            emptyLabel: options.emptyLabel || "No faction profile details selected."
        };
    }
}
