import { FactionEntityModel } from "./FactionEntityModel.js";

export class FactionProfileViewModel {
    static fromEntity(entity = {}, options = {}) {
        return this.fromFactionLike(entity, options);
    }

    static fromCandidate(candidate = {}, options = {}) {
        return this.fromFactionLike(candidate, options);
    }

    static fromFactionLike(faction = {}, options = {}) {
        return {
            name: FactionEntityModel.getName(faction),
            subtitle: FactionEntityModel.getSubtitle(faction),
            imageSrc: FactionEntityModel.getImage(faction),
            accent: FactionEntityModel.getAccent(faction),
            profileRows: FactionEntityModel.getProfileRows(faction),
            identityChips: [
                { label: "Type", value: faction.profile?.type || "" },
                { label: "Method", value: faction.profile?.method || "" },
                { label: "Drive", value: faction.profile?.drive || "" }
            ].filter(chip => chip.value),
            chips: [
                { label: "Action", value: faction.profile?.action || "" },
                { label: "Theme", value: faction.profile?.theme || "" },
                { label: "Focus", value: faction.profile?.focus || "" }
            ].filter(chip => chip.value),
            showTabs: options.showTabs === true,
            showActions: options.showActions === true,
            showBody: options.showBody !== false,
            tabs: {
                isProfileTab: options.activeTab !== "journal",
                isJournalTab: options.activeTab === "journal"
            },
            emptyLabel: options.emptyLabel || "No faction profile details selected."
        };
    }
}
