import { FactionEntityModel } from "./FactionEntityModel.js";

export class FactionProfileViewModel {
    static fromEntity(entity = {}, options = {}) {
        return this.fromFactionLike(entity, options);
    }

    static fromCandidate(candidate = {}, options = {}) {
        return this.fromFactionLike(candidate, options);
    }

    static fromFactionLike(faction = {}, options = {}) {
        const hiddenDefaultFields = new Set(Array.isArray(faction?.dossier?.hiddenDefaultFields) ? faction.dossier.hiddenDefaultFields : []);
        const isVisible = chip => chip.value && !hiddenDefaultFields.has(chip.key);
        const ideology = options.showIdeology === false
            ? []
            : FactionEntityModel.getIdeology(faction);
        const currentThread = options.showCurrentThread === false ? [] : [
            { key: "drive", label: "Drive", value: faction.profile?.drive || "", icon: "fas fa-bullseye" },
            { key: "action", label: "Action", value: faction.profile?.action || "", icon: "fas fa-bolt" },
            { key: "theme", label: "Theme", value: faction.profile?.theme || "", icon: "fas fa-masks-theater" },
            { key: "focus", label: "Focus", value: faction.profile?.focus || "", icon: "fas fa-magnifying-glass" }
        ].filter(isVisible);
        return {
            name: FactionEntityModel.getName(faction),
            subtitle: String(faction.profile?.type || "").trim() || "Organization",
            imageSrc: FactionEntityModel.getImage(faction),
            accent: FactionEntityModel.getAccent(faction),
            profileRows: FactionEntityModel.getProfileRows(faction),
            ideology,
            hasIdeology: ideology.length > 0,
            identityChips: options.showIdentity === false ? [] : [
                { key: "type", label: "Type", value: faction.profile?.type || "" },
                { key: "method", label: "Method", value: faction.profile?.method || "" }
            ].filter(isVisible),
            currentThread,
            hasCurrentThread: currentThread.length > 0,
            canRerollCurrentThread: options.canRerollCurrentThread === true,
            showTabs: options.showTabs === true,
            showCompactToggle: options.showCompactToggle === true,
            compactMode: options.compactMode === true,
            showActions: options.showActions === true,
            linkedActor: options.linkedActor || null,
            showHeaderActions: options.showActions === true || options.showCompactToggle === true,
            showBody: options.showBody !== false,
            showDiplomacy: options.showDiplomacy === true,
            hasChronicle: options.hasChronicle === true,
            tabs: {
                isProfileTab: options.activeTab === "profile",
                isJournalTab: options.activeTab === "journal",
                isConnectionsTab: options.activeTab === "connections",
                isChronicleTab: options.activeTab === "chronicle"
            },
            emptyLabel: options.emptyLabel || "No faction profile details selected."
        };
    }
}
