import { questWorldTies } from "./QuestWorldTies.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { NpcHeaderModel } from "./NpcHeaderModel.js";
import { NpcEntityModel } from "./NpcEntityModel.js";
import { EntityDisclosure } from "./EntityDisclosure.js";

export class NpcProfileViewModel {
    static fromEntity(entity = {}, options = {}) {
        return this.fromNpcLike(entity, options);
    }

    static fromCandidate(candidate = {}, options = {}) {
        const profile = this.fromNpcLike(candidate, options);
        // Generator previews have no persisted NPC to update through the disclosure menu.
        return { ...profile, canManageDisclosure: false,
            traits: profile.traits.map(entry => ({ ...entry, disclosureEditable: false })),
            ideology: profile.ideology.map(entry => ({ ...entry, disclosureEditable: false })),
            currentThread: profile.currentThread.map(entry => ({ ...entry, disclosureEditable: false })) };
    }

    static fromNpcLike(npc = {}, options = {}) {
        const traits = NpcEntityModel.getVisibleTraits(npc);
        const ideology = NpcEntityModel.getVisibleIdeology(npc);
        const visibleThread = NpcEntityModel.getVisibleCurrentThread(npc);
        const visibleThreadKeys = new Set(visibleThread.map(entry => entry.key));
        const hiddenDefaultFields = new Set(Array.isArray(npc?.dossier?.hiddenDefaultFields) ? npc.dossier.hiddenDefaultFields : []);
        const isVisible = chip => chip.value && !hiddenDefaultFields.has(chip.key)
            && (!["drive", "action", "theme", "focus"].includes(chip.key) || visibleThreadKeys.has(chip.key));
        const showCore = options.showCore !== false;
        const showDefaultFields = showCore && options.showDefaultFields !== false;
        const identityChips = showDefaultFields ? [
            { key: "descriptor", label: "Descriptor", value: npc.flavor?.descriptor || "" },
            { key: "role", label: "Role", value: npc.role?.roleLabel || "" },
            { key: "drive", label: "Drive", value: npc.flavor?.drive || "" }
        ].filter(isVisible) : [];
        const chips = showDefaultFields ? [
            { key: "action", label: "Action", value: npc.flavor?.action || "" },
            { key: "theme", label: "Theme", value: npc.flavor?.theme || "" },
            { key: "focus", label: "Focus", value: npc.flavor?.focus || "" }
        ].filter(isVisible) : [];
        const currentThread = Array.isArray(options.currentThread)
            ? visibleThread.filter(entry => options.currentThread.some(option => option.key === entry.key)) : [];
        const importance = Array.isArray(options.importance) ? options.importance : [];

        return {
            ...NpcHeaderModel.fromEntity(npc, options),
            hidePortrait: options.hidePortrait === true,
            hideEmptyTraits: options.hideEmptyTraits === true,
            traits,
            canManageDisclosure: EntityDisclosure.context(npc).canManageDisclosure,
            traitsDisclosureSummary: EntityDisclosure.summary(npc, "traits"),
            beliefsDisclosureSummary: EntityDisclosure.summary(npc, "beliefs"),
            threadDisclosureSummary: EntityDisclosure.summary(npc, "thread"),
            hasTraits: traits.length > 0,
            ideology,
            hasIdeology: ideology.length > 0,
            profileRows: NpcEntityModel.getProfileRows(npc),
            quests: npc.id ? questWorldTies(ConnectionTargetResolver.getEntityNodeId(npc.id)) : [],
            linkedActor: options.linkedActor || null,
            identityChips,
            chips,
            currentThread,
            hasCurrentThread: currentThread.length > 0,
            importance,
            hasImportance: importance.length > 0,
            canRerollCurrentThread: options.canRerollCurrentThread === true,
            canDrag: options.canDrag === true,
            showTabs: options.showTabs === true,
            showActions: options.showActions === true,
            showCompactToggle: options.showCompactToggle === true,
            showHeaderActions: options.showActions === true || options.showCompactToggle === true,
            compactMode: options.compactMode === true,
            worldTies: options.worldTies,
            compactSectionId: options.compactSectionId || `npc-profile-${npc.id || "preview"}`,
            compactSectionAction: options.compactSectionAction,
            compactSections: { beliefs: true, thread: true, ...options.compactSections },
            canEditTies: options.canEditTies === true,
            canToggleSections: options.canToggleSections === true,
            showBody: options.showBody !== false,
            showCore,
            hasChronicle: options.hasChronicle === true,
            tabs: {
                isProfileTab: options.activeTab === "profile",
                isJournalTab: options.activeTab === "journal",
                isConnectionsTab: options.activeTab === "connections",
                isChronicleTab: options.activeTab === "chronicle"
            },
            emptyTraitsLabel: options.emptyTraitsLabel || "No personality traits selected."
        };
    }
}
