import { NpcEntityModel } from "./NpcEntityModel.js";

export class NpcProfileViewModel {
    static fromEntity(entity = {}, options = {}) {
        return this.fromNpcLike(entity, options);
    }

    static fromCandidate(candidate = {}, options = {}) {
        return this.fromNpcLike(candidate, options);
    }

    static fromNpcLike(npc = {}, options = {}) {
        const traits = NpcEntityModel.getTraits(npc);
        return {
            name: NpcEntityModel.getName(npc),
            subtitle: NpcEntityModel.getSubtitle(npc),
            imageSrc: NpcEntityModel.getImage(npc),
            accent: NpcEntityModel.getAccent(npc),
            traits,
            hasTraits: traits.length > 0,
            profileRows: NpcEntityModel.getProfileRows(npc),
            identityChips: [
                { label: "Descriptor", value: npc.flavor?.descriptor || "" },
                { label: "Role", value: npc.role?.roleLabel || "" },
                { label: "Drive", value: npc.flavor?.drive || "" }
            ].filter(chip => chip.value),
            chips: [
                { label: "Action", value: npc.flavor?.action || "" },
                { label: "Theme", value: npc.flavor?.theme || "" },
                { label: "Focus", value: npc.flavor?.focus || "" }
            ].filter(chip => chip.value),
            showTabs: options.showTabs === true,
            showActions: options.showActions === true,
            showBody: options.showBody !== false,
            tabs: {
                isProfileTab: options.activeTab !== "journal",
                isJournalTab: options.activeTab === "journal"
            },
            emptyTraitsLabel: options.emptyTraitsLabel || "No personality traits selected."
        };
    }
}
