import { NpcEntityModel } from "./NpcEntityModel.js";

export class NpcProfileViewModel {
    static fromEntity(entity = {}, options = {}) {
        return this.fromNpcLike(entity, options);
    }

    static fromCandidate(candidate = {}, options = {}) {
        return this.fromNpcLike(candidate, options);
    }

    static fromNpcLike(npc = {}, options = {}) {
        const traits = NpcEntityModel.getTraits(npc);
        const ideology = NpcEntityModel.getIdeology(npc);
        const hiddenDefaultFields = new Set(Array.isArray(npc?.dossier?.hiddenDefaultFields) ? npc.dossier.hiddenDefaultFields : []);
        const isVisible = chip => chip.value && !hiddenDefaultFields.has(chip.key);
        const showCore = options.showCore !== false;
        const showDefaultFields = showCore && options.showDefaultFields !== false;
        const identityChips = showDefaultFields ? [
            { key: "descriptor", label: "Descriptor", value: npc.flavor?.descriptor || "" },
            { key: "role", label: "Role", value: npc.role?.roleLabel || "" },
            { key: "drive", label: "Drive", value: npc.flavor?.drive || "" }
        ].filter(isVisible) : [];
        const chips = showDefaultFields ? [
            { key: "action", label: "Action", value: npc.flavor?.action || "" },
            { key: "theme", label: "Theme", value: npc.flavor?.theme || "" },
            { key: "focus", label: "Focus", value: npc.flavor?.focus || "" }
        ].filter(isVisible) : [];
        const role = NpcEntityModel.getSubtitle(npc);
        const descriptor = String(npc?.flavor?.descriptor || "").trim();
        const subtitle = options.includeDescriptorInSubtitle === true
            ? [role, descriptor].filter(Boolean).join(" - ")
            : role;
        const currentThread = Array.isArray(options.currentThread) ? options.currentThread : [];
        const importance = Array.isArray(options.importance) ? options.importance : [];

        return {
            name: NpcEntityModel.getName(npc),
            subtitle,
            imageSrc: NpcEntityModel.getImage(npc),
            accent: NpcEntityModel.getAccent(npc),
            traits,
            hasTraits: traits.length > 0,
            ideology,
            hasIdeology: ideology.length > 0,
            profileRows: NpcEntityModel.getProfileRows(npc),
            linkedActor: options.linkedActor || null,
            identityChips,
            chips,
            currentThread,
            hasCurrentThread: currentThread.length > 0,
            importance,
            hasImportance: importance.length > 0,
            canRerollCurrentThread: options.canRerollCurrentThread === true,
            canDrag: options.canDrag === true,
            showTabs: options.showTabs === true,
            showActions: options.showActions === true,
            showCompactToggle: options.showCompactToggle === true,
            showHeaderActions: options.showActions === true || options.showCompactToggle === true,
            compactMode: options.compactMode === true,
            showBody: options.showBody !== false,
            showCore,
            hasChronicle: options.hasChronicle === true,
            tabs: {
                isProfileTab: options.activeTab === "profile",
                isJournalTab: options.activeTab === "journal",
                isConnectionsTab: options.activeTab === "connections",
                isChronicleTab: options.activeTab === "chronicle"
            },
            emptyTraitsLabel: options.emptyTraitsLabel || "No personality traits selected."
        };
    }
}