import { questWorldTies } from "./QuestWorldTies.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { ShipEntityModel } from "./ShipEntityModel.js";

export class ShipProfileViewModel {
    static fromEntity(entity = {}, options = {}) {
        return this.fromShipLike(entity, options);
    }

    static fromCandidate(candidate = {}, options = {}) {
        return this.fromShipLike(candidate, options);
    }

    static fromShipLike(ship = {}, options = {}) {
        const hiddenDefaultFields = new Set(Array.isArray(ship?.dossier?.hiddenDefaultFields) ? ship.dossier.hiddenDefaultFields : []);
        const isVisible = chip => chip.value && !hiddenDefaultFields.has(chip.key);
        return {
            name: ShipEntityModel.getName(ship),
            subtitle: ShipEntityModel.getSubtitle(ship),
            imageSrc: ShipEntityModel.getImage(ship),
            accent: ShipEntityModel.getAccent(ship),
            profileRows: ShipEntityModel.getProfileRows(ship),
            quests: ship.id ? questWorldTies(ConnectionTargetResolver.getEntityNodeId(ship.id)) : [],
            linkedActor: options.linkedActor || null,
            extensionTabs: options.extensionTabs || [],
            identityChips: [
                { key: "model", label: "Model", value: ship.profile?.model || "" },
                { key: "class", label: "Class", value: ship.profile?.class || "" },
                { key: "role", label: "Role", value: ship.profile?.role || "" }
            ].filter(isVisible),
            chips: [
                { key: "action", label: "Action", value: ship.profile?.action || "" },
                { key: "theme", label: "Theme", value: ship.profile?.theme || "" },
                { key: "focus", label: "Focus", value: ship.profile?.focus || "" }
            ].filter(isVisible),
            showTabs: options.showTabs === true,
            showCompactToggle: options.showCompactToggle === true,
            compactMode: options.compactMode === true,
            showActions: options.showActions === true,
            showHeaderActions: options.showActions === true || options.showCompactToggle === true,
            showBody: options.showBody !== false,
            showAssignmentChips: options.showAssignmentChips !== false && options.compactMode !== true,
            tabs: {
                isProfileTab: !options.activeTab || options.activeTab === "profile",
                isJournalTab: options.activeTab === "journal",
                isConnectionsTab: options.activeTab === "connections"
            },
            emptyLabel: options.emptyLabel || "No ship profile details selected."
        };
    }
}
