import { ShipEntityModel } from "./ShipEntityModel.js";

export class ShipProfileViewModel {
    static fromEntity(entity = {}, options = {}) {
        return this.fromShipLike(entity, options);
    }

    static fromCandidate(candidate = {}, options = {}) {
        return this.fromShipLike(candidate, options);
    }

    static fromShipLike(ship = {}, options = {}) {
        return {
            name: ShipEntityModel.getName(ship),
            subtitle: ShipEntityModel.getSubtitle(ship),
            imageSrc: ShipEntityModel.getImage(ship),
            accent: ShipEntityModel.getAccent(ship),
            profileRows: ShipEntityModel.getProfileRows(ship),
            identityChips: [
                { label: "Model", value: ship.profile?.model || "" },
                { label: "Class", value: ship.profile?.class || "" },
                { label: "Role", value: ship.profile?.role || "" }
            ].filter(chip => chip.value),
            chips: [
                { label: "Action", value: ship.profile?.action || "" },
                { label: "Theme", value: ship.profile?.theme || "" },
                { label: "Focus", value: ship.profile?.focus || "" }
            ].filter(chip => chip.value),
            showTabs: options.showTabs === true,
            showActions: options.showActions === true,
            showBody: options.showBody !== false,
            tabs: { isProfileTab: options.activeTab !== "journal", isJournalTab: options.activeTab === "journal" },
            emptyLabel: options.emptyLabel || "No ship profile details selected."
        };
    }
}
