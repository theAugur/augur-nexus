const MODULE_ID = "augur-nexus";

export class LocationParentReference {
    static normalize(parent = null) {
        if (!parent || typeof parent !== "object") return null;
        const kind = String(parent.kind || "").trim();
        if (kind === "location") {
            const locationId = String(parent.locationId || "").trim();
            return locationId ? { kind, locationId } : null;
        }
        if (kind === "scene") {
            const sceneId = String(parent.sceneId || "").trim();
            return sceneId ? { kind, sceneId } : null;
        }
        if (kind === "site") {
            const parentSceneId = String(parent.parentSceneId || "").trim();
            const siteId = String(parent.siteId || "").trim();
            return parentSceneId && siteId ? { kind, parentSceneId, siteId } : null;
        }
        return null;
    }

    static toNodeKey(parent = null) {
        const normalized = this.normalize(parent);
        if (!normalized) return null;
        if (normalized.kind === "location") return `location:${normalized.locationId}`;
        if (normalized.kind === "scene") return `scene:${normalized.sceneId}`;
        return `site:${normalized.parentSceneId}:${normalized.siteId}`;
    }

    static fromNode(node = null) {
        if (!node) return null;
        if (node.type === "location") return this.normalize({ kind: "location", locationId: node.objectId });
        if (node.type === "scene") return this.normalize({ kind: "scene", sceneId: node.sceneId || node.objectId });
        if (node.type === "site") {
            return this.normalize({
                kind: "site",
                parentSceneId: node.parentSceneId,
                siteId: node.siteId
            });
        }
        return null;
    }

    static fromNodeKey(key = "") {
        const value = String(key || "").trim();
        if (!value) return null;
        const [kind, ...parts] = value.split(":");
        if (kind === "location") return this.normalize({ kind, locationId: parts.join(":") });
        if (kind === "scene") return this.normalize({ kind, sceneId: parts.join(":") });
        if (kind === "site" && parts.length >= 2) {
            return this.normalize({
                kind,
                parentSceneId: parts.shift(),
                siteId: parts.join(":")
            });
        }
        return null;
    }

    static forScene(scene = canvas.scene) {
        if (!scene) return null;
        const lineage = scene.getFlag(MODULE_ID, "lineage") || {};
        const site = scene.getFlag(MODULE_ID, "site") || {};
        const parentSceneId = String(lineage.parentSceneId || site.parentSceneId || "").trim();
        const siteId = String(lineage.parentSiteId || site.siteId || "").trim();
        return parentSceneId && siteId
            ? { kind: "site", parentSceneId, siteId }
            : { kind: "scene", sceneId: scene.id };
    }

    static equals(left = null, right = null) {
        return this.toNodeKey(left) === this.toNodeKey(right);
    }
}