// Reading projections keep identity, beliefs and relationships in their existing authorities.
export class NpcReadingViewModel {
    static fromProfile(profile, life = {}) {
        return {
            profile, life, worldTies: profile.worldTies || life,
            character: { ...profile, bodyOnly: true, showBody: true, showCore: true, compactMode: true, hasCurrentThread: false, worldTies: null },
            standing: life.featured?.role || "", responsibilities: life.responsibilities || []
        };
    }
}
