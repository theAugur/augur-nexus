// Disclosure controls presentation; the entity's full content remains authoritative.
export class EntityDisclosure {
    static categories = { npc: ["traits", "beliefs", "thread"], faction: ["beliefs", "thread"], location: ["thread"], ship: ["thread"] };
    static sections(entity) {
        return this.categories[entity?.type || "npc"] || [];
    }
    static defaults(entity) { return Object.fromEntries(this.sections(entity).map(section => [section, { show: [], hide: [] }])); }
    static settingKey(type, section) { return `playerDisclosure_${type}_${section}`; }
    static categoryLabel(type, section) {
        const owner = { npc: "NPC", faction: "Faction", location: "Location", ship: "Ship" }[type];
        const label = { traits: "Personality Traits", beliefs: "Beliefs", thread: type === "ship" ? "Current Assignment" : "Current Thread" }[section];
        return `${owner} ${label}`;
    }
    static globalDefault(entity, section) {
        return globalThis.game?.settings?.get("augur-nexus", this.settingKey(entity?.type || "npc", section)) === "show" ? "show" : "hide";
    }
    static context(entity) {
        return { canManageDisclosure: !!entity?.id && !!globalThis.game?.user?.isGM,
            beliefsDisclosureSummary: this.summary(entity, "beliefs"), threadDisclosureSummary: this.summary(entity, "thread") };
    }
    static beliefKey(selection) { return JSON.stringify([selection.topicId, selection.tenetId]); }
    static threadKey(entry) { return JSON.stringify([entry.key, String(entry.value || "").trim()]); }
    static threadEntries(entity) {
        const type = entity?.type || "npc";
        const definitions = type === "location" ? [
            { key: "state", label: "State", icon: "fas fa-circle-half-stroke" },
            { key: "pressure", label: "Pressure", icon: "fas fa-gauge-high" },
            { key: "opportunity", label: "Opportunity", icon: "fas fa-door-open" },
            { key: "secret", label: "Secret", icon: "fas fa-user-secret" }
        ] : type === "ship" ? [
            { key: "action", label: "Activity" }, { key: "theme", label: "Situation" }, { key: "focus", label: "Objective" }
        ] : type === "faction" ? [
            { key: "drive", label: "Drive", icon: "fas fa-bullseye" },
            { key: "action", label: "Action", icon: "fas fa-bolt" },
            { key: "theme", label: "Theme", icon: "fas fa-masks-theater" },
            { key: "focus", label: "Focus", icon: "fas fa-magnifying-glass" }
        ] : [
            { key: "drive", label: "Wants", icon: "fas fa-bullseye" },
            { key: "action", label: "Approach", icon: "fas fa-bolt" },
            { key: "theme", label: "Tone", icon: "fas fa-masks-theater" },
            { key: "focus", label: "Complication", icon: "fas fa-triangle-exclamation" }
        ];
        const values = type === "npc" ? entity?.flavor : type === "location" ? entity?.currentThread : entity?.profile;
        return definitions.map(entry => ({ ...entry, value: String(values?.[entry.key] || "").trim() }))
            .filter(entry => entry.value);
    }
    static visibleThread(entity, user = globalThis.game?.user) {
        const hiddenFields = new Set(entity?.dossier?.hiddenDefaultFields || []);
        return this.present(entity, "thread", this.threadEntries(entity), user).filter(entry => !hiddenFields.has(entry.key));
    }
    static keys(entity, section) {
        if (section === "thread") return this.threadEntries(entity).map(entry => this.threadKey(entry));
        return section === "traits" ? [...new Set(entity?.personality?.traitIds || [])]
            : (entity?.ideology?.selections || []).map(selection => this.beliefKey(selection));
    }
    static normalize(entity, disclosure) {
        // Absence is the released behavior: existing characters remain revealed.
        if (!disclosure) return undefined;
        return Object.fromEntries(this.sections(entity).map(section => [section, this.normalizeSection(entity, section, disclosure[section])]));
    }
    static normalizeSection(entity, section, value) {
        const keys = this.keys(entity, section);
        // Preserve old reveal lists as explicit choices; missing thread lists predate thread privacy.
        if (Array.isArray(value) || value === undefined) {
            const shown = new Set(value === undefined && section === "thread" ? keys : value || []);
            return { show: keys.filter(key => shown.has(key)), hide: keys.filter(key => !shown.has(key)) };
        }
        const hidden = new Set(Array.isArray(value?.hide) ? value.hide : []);
        const shown = new Set(Array.isArray(value?.show) ? value.show : []);
        return { show: keys.filter(key => shown.has(key) && !hidden.has(key)), hide: keys.filter(key => hidden.has(key)) };
    }
    static override(entity, section, key) {
        const state = this.normalize(entity, entity?.access?.disclosure)?.[section];
        if (!state) return "show";
        return state.hide.includes(key) ? "hide" : state.show.includes(key) ? "show" : "inherit";
    }
    static revealed(entity, section) {
        const state = this.normalize(entity, entity?.access?.disclosure)?.[section];
        const keys = this.keys(entity, section);
        if (!state) return keys;
        const hidden = new Set(state.hide), shown = new Set(state.show);
        const global = this.globalDefault(entity, section) === "show";
        return keys.filter(key => !hidden.has(key) && (shown.has(key) || global));
    }
    static snapshot(entity) {
        return this.normalize(entity, entity?.access?.disclosure)
            ?? Object.fromEntries(this.sections(entity).map(section => [section, { show: this.keys(entity, section), hide: [] }]));
    }
    static forUpdate(current, next, patch) {
        const state = this.snapshot(current);
        for (const section of this.sections(current)) {
            if (patch && Object.hasOwn(patch, section)) state[section] = this.normalizeSection(next, section, patch[section]);
        }
        return this.normalize(next, state);
    }
    static hasHidden(entity, section) { return this.keys(entity, section).length > this.revealed(entity, section).length; }
    static present(entity, section, entries, user = globalThis.game?.user) {
        const revealed = new Set(this.revealed(entity, section));
        return entries.flatMap(entry => {
            const key = section === "traits" ? entry.id : section === "thread" ? this.threadKey(entry) : this.beliefKey(entry);
            const hidden = !revealed.has(key);
            if (!user?.isGM && hidden) return [];
            const override = this.override(entity, section, key);
            const visibilityLabel = `${hidden ? "Hidden from players" : "Visible to players"} (${override === "inherit" ? "global default" : "individual override"})`;
            return [{ ...entry, disclosureKey: key, disclosureHidden: hidden, disclosureVisibilityLabel: visibilityLabel,
                disclosureEditable: !!entity?.id && !!user?.isGM }];
        });
    }
    static summary(entity, section) {
        return `${this.revealed(entity, section).length} of ${this.keys(entity, section).length} revealed`;
    }
    static opinionInfluences(influences, entities, user = globalThis.game?.user) {
        if (user?.isGM) return influences;
        const secret = [], visible = [];
        for (const influence of influences) {
            const section = { personality: "traits", ideology: "beliefs" }[influence.id];
            (section && entities.some(entity => this.sections(entity).includes(section) && this.hasHidden(entity, section)) ? secret : visible).push(influence);
        }
        if (secret.length) visible.push({ id: "unrevealed", label: "Unrevealed influences", value: secret.reduce((sum, entry) => sum + entry.value, 0), details: [] });
        return visible;
    }
}
