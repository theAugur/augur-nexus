import { EntityDisclosure } from "./EntityDisclosure.js";
import { questWorldTies } from "./QuestWorldTies.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { LocationEntityModel } from "./LocationEntityModel.js";

export class LocationProfileViewModel {
    static fromEntity(entity = {}, options = {}) { return this.fromLocationLike(entity, options); }
    static fromCandidate(entity = {}, options = {}) {
        const profile = this.fromLocationLike(entity, options);
        return { ...profile, canManageDisclosure: false,
            currentThread: profile.currentThread.map(entry => ({ ...entry, disclosureEditable: false })) };
    }
    static fromLocationLike(entity = {}, options = {}) {
        entity = { ...entity, type: "location" };
        const currentThread = options.showCurrentThread === false ? [] : LocationEntityModel.getVisibleCurrentThread(entity);
        return {
            ...EntityDisclosure.context(entity),
            name: LocationEntityModel.getName(entity),
            subtitle: LocationEntityModel.getSubtitle(entity),
            imageSrc: LocationEntityModel.getThumbnail(entity),
            accent: LocationEntityModel.getAccent(entity),
            profileRows: LocationEntityModel.getProfileRows(entity),
            quests: entity.id ? questWorldTies(ConnectionTargetResolver.getEntityNodeId(entity.id)) : [],
            currentThread,
            hasCurrentThread: currentThread.length > 0,
            canRerollCurrentThread: options.canRerollCurrentThread === true,
            showTabs: options.showTabs === true,
            showActions: options.showActions === true,
            showBody: options.showBody !== false,
            canToggleSections: options.canToggleSections === true,
            compactSectionId: options.compactSectionId,
            compactSectionAction: options.compactSectionAction,
            compactSections: options.compactSections,
            hasChronicle: options.hasChronicle === true,
            tabs: {
                isProfileTab: options.activeTab === "profile",
                isJournalTab: options.activeTab === "journal",
                isChronicleTab: options.activeTab === "chronicle"
            },
            emptyLabel: options.emptyLabel || "No location profile fields."
        };
    }
}
