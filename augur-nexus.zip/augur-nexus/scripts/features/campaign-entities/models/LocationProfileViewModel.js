import { LocationEntityModel } from "./LocationEntityModel.js";

export class LocationProfileViewModel {
    static fromEntity(entity = {}, options = {}) { return this.fromCandidate(entity, options); }
    static fromCandidate(entity = {}, options = {}) {
        const currentThread = options.showCurrentThread === false ? [] : LocationEntityModel.getCurrentThread(entity);
        return {
            name: LocationEntityModel.getName(entity),
            subtitle: LocationEntityModel.getSubtitle(entity),
            imageSrc: LocationEntityModel.getThumbnail(entity),
            accent: LocationEntityModel.getAccent(entity),
            profileRows: LocationEntityModel.getProfileRows(entity),
            currentThread,
            hasCurrentThread: currentThread.length > 0,
            canRerollCurrentThread: options.canRerollCurrentThread === true,
            showTabs: options.showTabs === true,
            showActions: options.showActions === true,
            showBody: options.showBody !== false,
            hasChronicle: options.hasChronicle === true,
            tabs: {
                isProfileTab: options.activeTab === "profile",
                isJournalTab: options.activeTab === "journal",
                isChronicleTab: options.activeTab === "chronicle"
            },
            emptyLabel: options.emptyLabel || "No location profile fields."
        };
    }
}
