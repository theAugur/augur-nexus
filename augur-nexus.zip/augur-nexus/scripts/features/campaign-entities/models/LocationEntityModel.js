const MODULE_ID = "augur-nexus";

export class LocationEntityModel {
    static ENTITY_TYPE = "location";
    static getFlag(document) { return document?.getFlag?.(MODULE_ID, "campaignEntity") || document?.flags?.[MODULE_ID]?.campaignEntity || null; }
    static isLocationDocument(document) { return this.getFlag(document)?.type === this.ENTITY_TYPE; }
    static fromDocument(document) {
        const entity = this.getFlag(document);
        if (!entity || entity.type !== this.ENTITY_TYPE) return null;
        return { ...entity, uuid: document?.uuid || "", journalEntryId: document?.id || "", journalEntryName: document?.name || entity.display?.name || "Location" };
    }
    static getName(entity) { return String(entity?.display?.name || entity?.journalEntryName || "New Location").trim() || "New Location"; }
    static getSubtitle(entity) { return [entity?.profile?.type, entity?.profile?.kindLabel].filter(Boolean).join(" - ") || "Location"; }
    static getAuthorityType(entity) { return ["resource-site", "service-site"].includes(String(entity?.profile?.kindId || "")) ? "owner" : "ruler"; }
    static getImage(entity) { return String(entity?.display?.imageSrc || "").trim(); }
    static getThumbnail(entity) { return String(entity?.display?.thumbnailSrc || "").trim() || this.getImage(entity); }
    static getCoverImage(entity) { return String(entity?.display?.coverImageSrc || "").trim(); }
    static getAccent(entity) { const value = String(entity?.display?.color || "").trim(); return /^#[0-9a-f]{6}$/i.test(value) ? value : "#d18a42"; }
    static getProfileFields(entity) { return (Array.isArray(entity?.profile?.fields) ? entity.profile.fields : []).filter(field => field?.id && field?.label); }
    static getProfileRows(entity) { return this.getProfileFields(entity).map(field => ({ label: field.label, value: field.value, multiline: field.type === "multiline" })).filter(row => row.value); }
    static getCurrentThread(entity) {
        return [
            { key: "state", label: "State", icon: "fas fa-circle-half-stroke", value: entity?.currentThread?.state },
            { key: "pressure", label: "Pressure", icon: "fas fa-gauge-high", value: entity?.currentThread?.pressure },
            { key: "opportunity", label: "Opportunity", icon: "fas fa-door-open", value: entity?.currentThread?.opportunity },
            { key: "secret", label: "Secret", icon: "fas fa-user-secret", value: entity?.currentThread?.secret }
        ].map(entry => ({ ...entry, value: String(entry.value || "").trim() })).filter(entry => entry.value);
    }
    static getSearchText(entity) { return [this.getName(entity), this.getSubtitle(entity), entity?.profile?.summary, ...this.getCurrentThread(entity).map(field => field.value), ...this.getProfileFields(entity).flatMap(field => [field.label, field.value]), ...(entity?.tags || [])].filter(Boolean).join(" ").toLocaleLowerCase(); }
}
