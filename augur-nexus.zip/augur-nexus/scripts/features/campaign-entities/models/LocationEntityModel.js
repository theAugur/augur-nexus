import { EntityDisclosure } from "./EntityDisclosure.js";
const MODULE_ID = "augur-nexus";

export class LocationEntityModel {
    static ENTITY_TYPE = "location";
    static getFlag(document) { return document?.getFlag?.(MODULE_ID, "campaignEntity") || document?.flags?.[MODULE_ID]?.campaignEntity || null; }
    static isLocationDocument(document) { return this.getFlag(document)?.type === this.ENTITY_TYPE; }
    static fromDocument(document) {
        const entity = this.getFlag(document);
        if (!entity || entity.type !== this.ENTITY_TYPE) return null;
        return { ...entity, uuid: document?.uuid || "", journalEntryId: document?.id || "", journalEntryName: document?.name || entity.display?.name || "Location" };
    }
    static getName(entity) { return String(entity?.display?.name || entity?.journalEntryName || "New Location").trim() || "New Location"; }
    static getSubtitle(entity) {
        const type = String(entity?.profile?.type || "").trim();
        const category = String(entity?.profile?.kindLabel || "").trim();
        const normalizedType = type.toLowerCase().replace(/\s+/g, " ");
        const normalizedCategory = category.toLowerCase().replace(/\s+/g, " ");
        if (category && (normalizedType === normalizedCategory || normalizedType.endsWith(` ${normalizedCategory}`))) return type;
        return [type, category].filter(Boolean).join(" - ") || "Location";
    }
    static getAuthorityType(entity) { return ["resource-site", "service-site"].includes(String(entity?.profile?.kindId || "")) ? "owner" : "ruler"; }
    static getImage(entity) { return String(entity?.display?.imageSrc || "").trim(); }
    static getThumbnail(entity) { return String(entity?.display?.thumbnailSrc || "").trim() || this.getImage(entity); }
    static getCoverImage(entity) { return String(entity?.display?.coverImageSrc || "").trim(); }
    static getAccent(entity) { const value = String(entity?.display?.color || "").trim(); return /^#[0-9a-f]{6}$/i.test(value) ? value : "#d18a42"; }
    static getProfileFields(entity) { return (Array.isArray(entity?.profile?.fields) ? entity.profile.fields : []).filter(field => field?.id && field?.label); }
    static getProfileRows(entity) { return this.getProfileFields(entity).map(field => ({ label: field.label, value: field.value, multiline: field.type === "multiline" })).filter(row => row.value); }
    static getCurrentThread(entity) {
        return EntityDisclosure.threadEntries({ ...entity, type: "location" });
    }
    static getVisibleCurrentThread(entity, user = globalThis.game?.user) { return EntityDisclosure.visibleThread(entity, user); }

    static getSearchText(entity) { return [this.getName(entity), this.getSubtitle(entity), entity?.profile?.summary, ...this.getVisibleCurrentThread(entity).map(field => field.value), ...this.getProfileFields(entity).flatMap(field => [field.label, field.value]), ...(entity?.tags || [])].filter(Boolean).join(" ").toLocaleLowerCase(); }
}
