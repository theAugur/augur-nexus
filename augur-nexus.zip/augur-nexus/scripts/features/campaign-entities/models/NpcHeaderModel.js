import { NpcEntityModel } from "./NpcEntityModel.js";
import { SiteCoverCatalog } from "../../site/services/SiteCoverCatalog.js";

export class NpcHeaderModel {
    static fromEntity(entity = {}, options = {}) {
        const hidden = new Set(Array.isArray(entity.dossier?.hiddenDefaultFields) ? entity.dossier.hiddenDefaultFields : []);
        const role = hidden.has("role") ? "" : NpcEntityModel.getSubtitle(entity);
        const descriptor = hidden.has("descriptor") ? "" : String(entity.flavor?.descriptor || "").trim();
        return {
            name: NpcEntityModel.getName(entity),
            subtitle: options.includeDescriptorInSubtitle === true ? [role, descriptor].filter(Boolean).join(" - ") : role,
            imageSrc: NpcEntityModel.getImage(entity),
            accent: NpcEntityModel.getAccent(entity)
        };
    }

    static coverImage(entity) {
        return NpcEntityModel.getCoverImage(entity)
            || SiteCoverCatalog.getAbstractCover(entity?.id || NpcEntityModel.getName(entity) || "npc");
    }
}
