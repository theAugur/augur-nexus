import { CampaignEntityActorBridge } from "./CampaignEntityActorBridge.js";
import { CampaignEntityJournalStore } from "./CampaignEntityJournalStore.js";
import { FactionGeneratorRegistry } from "./FactionGeneratorRegistry.js";
import { NpcGeneratorRegistry } from "./NpcGeneratorRegistry.js";
import { ShipGeneratorRegistry } from "./ShipGeneratorRegistry.js";
import { FactionCreationGateway } from "./FactionCreationGateway.js";
import { NpcCreationGateway } from "./NpcCreationGateway.js";
import { ShipCreationGateway } from "./ShipCreationGateway.js";

const ENTITY_TYPES = {
    npc: { label: "Person", icon: "fa-solid fa-user" },
    faction: { label: "Organization", icon: "fa-solid fa-shield-halved" },
    ship: { label: "Ship", icon: "fa-solid fa-rocket" }
};

export class CampaignEntityActorImportGateway {
    static async resolve(actor, {
        allowedEntityTypes = ["npc", "faction", "ship"],
        defaultEntityType = "",
        allowActorOnly = false,
        promptWhenLinked = false
    } = {}) {
        if (!actor || actor.documentName !== "Actor") return null;

        const linkedEntity = CampaignEntityActorBridge.getLinkedEntityForActor(actor);
        if (linkedEntity && !promptWhenLinked) {
            if (!allowedEntityTypes.includes(linkedEntity.type)) {
                ui.notifications.warn(`${actor.name} is already linked to a Nexus ${ENTITY_TYPES[linkedEntity.type]?.label || "entity"}, which cannot be used here.`);
                return null;
            }
            return { mode: "entity", entity: linkedEntity, actor };
        }

        if (!game.user?.isGM || !actor.isOwner) {
            ui.notifications.warn(`You do not have permission to import ${actor.name}.`);
            return null;
        }

        const allowed = [...new Set(allowedEntityTypes)]
            .filter(type => ENTITY_TYPES[type])
            .filter(type => this.#isTypeAvailable(type) || linkedEntity?.type === type);
        if (!allowed.length) {
            if (allowActorOnly) return { mode: "actor", actor };
            await this.#openRequiredModuleGateway(defaultEntityType || allowedEntityTypes[0] || "npc");
            return null;
        }

        const suggestedType = linkedEntity
            ? "linked"
            : allowed.includes(defaultEntityType)
            ? defaultEntityType
            : this.#suggestType(actor, allowed);
        const choice = await this.#prompt(actor, { allowed, suggestedType, allowActorOnly, linkedEntity });
        if (!choice) return null;
        if (choice === "linked") return { mode: "entity", entity: linkedEntity, actor };
        if (choice === "actor") return { mode: "actor", actor };

        const entity = await this.#createEntity(choice, actor);
        if (!entity) return null;
        await CampaignEntityActorBridge.linkActor(entity, actor);
        ui.notifications.info(`${actor.name} imported as a Nexus ${ENTITY_TYPES[choice].label}.`);
        return { mode: "entity", entity, actor };
    }

    static #isTypeAvailable(type) {
        if (type === "faction") return FactionGeneratorRegistry.list().length > 0;
        if (type === "ship") return ShipGeneratorRegistry.list().length > 0;
        return NpcGeneratorRegistry.list().length > 0;
    }

    static #suggestType(actor, allowed) {
        const actorType = String(actor.type || "").toLocaleLowerCase();
        const name = String(actor.name || "").toLocaleLowerCase();
        const description = `${actorType} ${name}`;
        if (allowed.includes("ship") && /\b(ship|starship|spacecraft|vehicle|vessel)\b/.test(description)) return "ship";
        if (allowed.includes("faction") && /\b(faction|organization|organisation|party|group|guild|kingdom|company)\b/.test(description)) return "faction";
        return allowed.includes("npc") ? "npc" : allowed[0];
    }

    static async #prompt(actor, { allowed, suggestedType, allowActorOnly, linkedEntity = null }) {
        const safeName = foundry.utils.escapeHTML(actor.name || "this Actor");
        const safeImage = foundry.utils.escapeHTML(actor.img || CONST.DEFAULT_TOKEN);
        const choices = [];
        if (linkedEntity) {
            const definition = ENTITY_TYPES[linkedEntity.type] || { label: "Entity", icon: "fa-solid fa-link" };
            const entityName = foundry.utils.escapeHTML(linkedEntity.display?.name || actor.name || definition.label);
            choices.push(`<label class="nexus-actor-import-choice"><input type="radio" name="entityType" value="linked" checked><i class="${definition.icon}"></i><span><strong>Use Linked ${definition.label}</strong><small>Connect the existing Nexus ${definition.label.toLocaleLowerCase()} ${entityName}.</small></span></label>`);
        }
        choices.push(...allowed.filter(type => type !== linkedEntity?.type).map(type => {
            const definition = ENTITY_TYPES[type];
            return `<label class="nexus-actor-import-choice"><input type="radio" name="entityType" value="${type}" ${type === suggestedType ? "checked" : ""}><i class="${definition.icon}"></i><span><strong>${definition.label}</strong><small>Create and link a Nexus ${definition.label.toLocaleLowerCase()}.</small></span></label>`;
        }));
        if (allowActorOnly) {
            choices.push(`<label class="nexus-actor-import-choice"><input type="radio" name="entityType" value="actor"><i class="fa-solid fa-address-card"></i><span><strong>Actor Only</strong><small>Connect the Foundry Actor without creating a Nexus entity.</small></span></label>`);
        }

        return foundry.applications.api.DialogV2.wait({
            window: { title: "Add Foundry Actor", icon: "fa-solid fa-link" },
            position: { width: 460 },
            content: `<form class="standard-form nexus-actor-import-form"><div class="nexus-actor-import-identity"><img src="${safeImage}" alt=""><span><strong>${safeName}</strong><small>How should Nexus use this Actor?</small></span></div><div class="nexus-actor-import-choices">${choices.join("")}</div></form>`,
            rejectClose: false,
            modal: true,
            buttons: [
                {
                    action: "accept",
                    label: "Accept",
                    icon: "fa-solid fa-check",
                    default: true,
                    callback: (_event, button) => String(button.form?.elements?.entityType?.value || suggestedType)
                },
                { action: "cancel", label: "Cancel", icon: "fa-solid fa-xmark", callback: () => null }
            ]
        });
    }

    static async #createEntity(type, actor) {
        const name = String(actor.name || "Imported Actor").trim() || "Imported Actor";
        const imageSrc = String(actor.img || "").trim();
        if (type === "faction") {
            return CampaignEntityJournalStore.createFaction({
                sourceModule: "augur-nexus",
                display: { name, imageSrc, color: "#83c95f" },
                profile: { type: "Organization" }
            });
        }
        if (type === "ship") {
            return CampaignEntityJournalStore.createShip({
                sourceModule: "augur-nexus",
                display: { name, imageSrc, color: "#55bdec" }
            });
        }
        return CampaignEntityJournalStore.createNpc({
            sourceModule: "augur-nexus",
            display: { name, imageSrc, color: "#55bdec" }
        });
    }

    static #openRequiredModuleGateway(type) {
        if (type === "faction") return FactionCreationGateway.open();
        if (type === "ship") return ShipCreationGateway.open();
        return NpcCreationGateway.open();
    }
}
