import { CampaignEntityJournalStore } from "./CampaignEntityJournalStore.js";
import { hasPremiumAccess, requestPremiumAccess } from "../../access/PremiumAccess.js";

const ENTITY_TYPES = {
    npc: { label: "Person", icon: "fa-solid fa-user" },
    faction: { label: "Organization", icon: "fa-solid fa-shield-halved" },
    ship: { label: "Ship", icon: "fa-solid fa-rocket" }
};

export class CampaignEntityActorImportGateway {
    static isTypeAvailable(type) {
        return Object.hasOwn(ENTITY_TYPES, type);
    }

    static async prompt(actor, { allowed, suggestedType, allowActorOnly, linkedEntity = null }) {
        const safeName = foundry.utils.escapeHTML(actor.name || "this Actor");
        const safeImage = foundry.utils.escapeHTML(actor.img || CONST.DEFAULT_TOKEN);
        const premium = hasPremiumAccess();
        const defaultChoice = linkedEntity ? "linked" : !premium && allowActorOnly ? "actor" : suggestedType;
        const choices = [];
        if (linkedEntity) {
            const definition = ENTITY_TYPES[linkedEntity.type] || { label: "Entity", icon: "fa-solid fa-link" };
            const entityName = foundry.utils.escapeHTML(linkedEntity.display?.name || actor.name || definition.label);
            choices.push(`<label class="nexus-actor-import-choice"><input type="radio" name="entityType" value="linked" checked><i class="${definition.icon}"></i><span><strong>Use Linked ${definition.label}</strong><small>Connect the existing Nexus ${definition.label.toLocaleLowerCase()} ${entityName}.</small></span></label>`);
        }
        choices.push(...allowed.filter(type => type !== linkedEntity?.type).map(type => {
            const definition = ENTITY_TYPES[type];
            if (!premium) return `<button type="button" class="nexus-actor-import-choice is-premium-locked" data-premium-creation="${type}" aria-disabled="true" aria-label="${definition.label}: premium module required. Learn more."><i class="fa-solid fa-lock" aria-hidden="true"></i><i class="${definition.icon}" aria-hidden="true"></i><span><strong>${definition.label}</strong><small>Create and link a Nexus ${definition.label.toLocaleLowerCase()}. Premium module required.</small></span></button>`;
            return `<label class="nexus-actor-import-choice"><input type="radio" name="entityType" value="${type}" ${type === defaultChoice ? "checked" : ""}><i class="${definition.icon}"></i><span><strong>${definition.label}</strong><small>Create and link a Nexus ${definition.label.toLocaleLowerCase()}.</small></span></label>`;
        }));
        if (allowActorOnly) {
            choices.push(`<label class="nexus-actor-import-choice"><input type="radio" name="entityType" value="actor" ${defaultChoice === "actor" ? "checked" : ""}><i class="fa-solid fa-address-card"></i><span><strong>Actor Only</strong><small>Connect the Foundry Actor without creating a Nexus entity.</small></span></label>`);
        }

        const selectedChoice = form => String(form?.elements?.entityType?.value || defaultChoice);
        const lockedChoice = choice => this.isTypeAvailable(choice) && !hasPremiumAccess();
        let explaining = false;
        const explain = async choice => {
            if (explaining) return;
            explaining = true;
            try { await requestPremiumAccess(choice); }
            finally { explaining = false; }
        };

        const result = await foundry.applications.api.DialogV2.wait({
            window: { title: "Add Foundry Actor", icon: "fa-solid fa-link" },
            position: { width: 460 },
            content: `<form class="standard-form nexus-actor-import-form"><div class="nexus-actor-import-identity"><img src="${safeImage}" alt=""><span><strong>${safeName}</strong><small>How should Nexus use this Actor?</small></span></div><div class="nexus-actor-import-choices">${choices.join("")}</div></form>`,
            rejectClose: false,
            modal: true,
            render: (_event, dialog) => {
                const root = dialog.element;
                root.querySelectorAll("[data-premium-creation]").forEach(button => {
                    button.addEventListener("click", event => {
                        event.preventDefault(); event.stopPropagation();
                        void explain(button.dataset.premiumCreation);
                    });
                });
                // Intercept before DialogV2 submits, so a revoked choice leaves the parent dialog open.
                const guard = event => {
                    const accept = event.target.closest?.('button[data-action="accept"]');
                    if (event.type !== "submit" && !accept) return;
                    const choice = selectedChoice(accept?.form || root.querySelector("form"));
                    if (!lockedChoice(choice)) return;
                    event.preventDefault(); event.stopImmediatePropagation();
                    void explain(choice);
                };
                root.addEventListener("click", guard, { capture: true });
                root.addEventListener("submit", guard, { capture: true });
            },
            buttons: [
                {
                    action: "accept",
                    label: "Accept",
                    icon: "fa-solid fa-check",
                    default: true,
                    callback: (_event, button) => {
                        const choice = selectedChoice(button.form);
                        return lockedChoice(choice) ? "cancel" : choice;
                    }
                },
                { action: "cancel", label: "Cancel", icon: "fa-solid fa-xmark", callback: () => null }
            ]
        });
        // DialogV2 substitutes the button action when its callback returns null.
        return result === "cancel" ? null : result;
    }

    static async createEntity(type, actor) {
        if (!this.isTypeAvailable(type)) throw new Error("Unsupported Actor import type.");
        if (!await requestPremiumAccess(type)) return null;
        const name = String(actor.name || "Imported Actor").trim() || "Imported Actor";
        const imageSrc = String(actor.img || "").trim();
        if (type === "faction") {
            return CampaignEntityJournalStore.createFaction({
                sourceModule: "augur-nexus",
                display: { name, imageSrc, color: "#83c95f" },
                profile: { type: "Organization" }
            });
        }
        if (type === "ship") {
            return CampaignEntityJournalStore.createShip({
                sourceModule: "augur-nexus",
                display: { name, imageSrc, color: "#55bdec" }
            });
        }
        return CampaignEntityJournalStore.createNpc({
            sourceModule: "augur-nexus",
            display: { name, imageSrc, color: "#55bdec" }
        });
    }

}
