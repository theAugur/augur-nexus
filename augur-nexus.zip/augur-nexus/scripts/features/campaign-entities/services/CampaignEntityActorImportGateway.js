import { CampaignEntityJournalStore } from "./CampaignEntityJournalStore.js";
import { FactionGeneratorRegistry } from "./FactionGeneratorRegistry.js";
import { NpcGeneratorRegistry } from "./NpcGeneratorRegistry.js";
import { ShipGeneratorRegistry } from "./ShipGeneratorRegistry.js";
import { FactionCreationGateway } from "./FactionCreationGateway.js";
import { NpcCreationGateway } from "./NpcCreationGateway.js";
import { ShipCreationGateway } from "./ShipCreationGateway.js";

const ENTITY_TYPES = {
    npc: { label: "Person", icon: "fa-solid fa-user" },
    faction: { label: "Organization", icon: "fa-solid fa-shield-halved" },
    ship: { label: "Ship", icon: "fa-solid fa-rocket" }
};

export class CampaignEntityActorImportGateway {
    static isTypeAvailable(type) {
        if (type === "faction") return FactionGeneratorRegistry.list().length > 0;
        if (type === "ship") return ShipGeneratorRegistry.list().length > 0;
        return NpcGeneratorRegistry.list().length > 0;
    }

    static async prompt(actor, { allowed, suggestedType, allowActorOnly, linkedEntity = null }) {
        const safeName = foundry.utils.escapeHTML(actor.name || "this Actor");
        const safeImage = foundry.utils.escapeHTML(actor.img || CONST.DEFAULT_TOKEN);
        const choices = [];
        if (linkedEntity) {
            const definition = ENTITY_TYPES[linkedEntity.type] || { label: "Entity", icon: "fa-solid fa-link" };
            const entityName = foundry.utils.escapeHTML(linkedEntity.display?.name || actor.name || definition.label);
            choices.push(`<label class="nexus-actor-import-choice"><input type="radio" name="entityType" value="linked" checked><i class="${definition.icon}"></i><span><strong>Use Linked ${definition.label}</strong><small>Connect the existing Nexus ${definition.label.toLocaleLowerCase()} ${entityName}.</small></span></label>`);
        }
        choices.push(...allowed.filter(type => type !== linkedEntity?.type).map(type => {
            const definition = ENTITY_TYPES[type];
            return `<label class="nexus-actor-import-choice"><input type="radio" name="entityType" value="${type}" ${type === suggestedType ? "checked" : ""}><i class="${definition.icon}"></i><span><strong>${definition.label}</strong><small>Create and link a Nexus ${definition.label.toLocaleLowerCase()}.</small></span></label>`;
        }));
        if (allowActorOnly) {
            choices.push(`<label class="nexus-actor-import-choice"><input type="radio" name="entityType" value="actor" ${suggestedType === "actor" ? "checked" : ""}><i class="fa-solid fa-address-card"></i><span><strong>Actor Only</strong><small>Connect the Foundry Actor without creating a Nexus entity.</small></span></label>`);
        }

        const result = await foundry.applications.api.DialogV2.wait({
            window: { title: "Add Foundry Actor", icon: "fa-solid fa-link" },
            position: { width: 460 },
            content: `<form class="standard-form nexus-actor-import-form"><div class="nexus-actor-import-identity"><img src="${safeImage}" alt=""><span><strong>${safeName}</strong><small>How should Nexus use this Actor?</small></span></div><div class="nexus-actor-import-choices">${choices.join("")}</div></form>`,
            rejectClose: false,
            modal: true,
            buttons: [
                {
                    action: "accept",
                    label: "Accept",
                    icon: "fa-solid fa-check",
                    default: true,
                    callback: (_event, button) => String(button.form?.elements?.entityType?.value || suggestedType)
                },
                { action: "cancel", label: "Cancel", icon: "fa-solid fa-xmark", callback: () => null }
            ]
        });
        // DialogV2 substitutes the button action when its callback returns null.
        return result === "cancel" ? null : result;
    }

    static async createEntity(type, actor) {
        const name = String(actor.name || "Imported Actor").trim() || "Imported Actor";
        const imageSrc = String(actor.img || "").trim();
        if (type === "faction") {
            return CampaignEntityJournalStore.createFaction({
                sourceModule: "augur-nexus",
                display: { name, imageSrc, color: "#83c95f" },
                profile: { type: "Organization" }
            });
        }
        if (type === "ship") {
            return CampaignEntityJournalStore.createShip({
                sourceModule: "augur-nexus",
                display: { name, imageSrc, color: "#55bdec" }
            });
        }
        return CampaignEntityJournalStore.createNpc({
            sourceModule: "augur-nexus",
            display: { name, imageSrc, color: "#55bdec" }
        });
    }

    static openRequiredModuleGateway(type) {
        if (type === "faction") return FactionCreationGateway.open();
        if (type === "ship") return ShipCreationGateway.open();
        return NpcCreationGateway.open();
    }
}
