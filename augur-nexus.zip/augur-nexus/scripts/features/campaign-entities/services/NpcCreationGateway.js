import { getNpcGenerators } from "../../../api/npcs.js";
import { CampaignEntityCreation } from "./CampaignEntityCreation.js";

export class NpcCreationGateway {
    static async open(options = {}) {
        if (!getNpcGenerators().length) {
            const action = await foundry.applications.api.DialogV2.wait({
                window: { title: "Generate Person", icon: "fas fa-dice" },
                position: { width: 420 },
                content: `<p><a href="https://foundryvtt.com/packages/augur-fantasy" target="_blank" rel="noopener noreferrer">Augur: Fantasy</a> and <a href="https://foundryvtt.com/packages/augur-scifi" target="_blank" rel="noopener noreferrer">Augur: Sci-Fi</a> add NPC generation with names, portraits, personalities, beliefs and other character details.</p>
                    <p>You can also create a blank person and edit their details yourself. Personality and belief generation is included in Nexus.</p>`,
                buttons: [
                    { action: "close", label: "Close", icon: "fas fa-xmark" },
                    { action: "createBlank", label: "Create Blank Person", icon: "fas fa-user-plus", default: true }
                ],
                rejectClose: false
            });
            if (action === "createBlank") return CampaignEntityCreation.open("npc", { ...options, generate: false });
            return null;
        }
        const { NpcCreateDialog } = await import("../applications/NpcCreateDialog.js");
        return NpcCreateDialog.show(options);
    }
}
