import { getNpcGenerators } from "../../../api/npcs.js";
import { CampaignEntityCreation } from "./CampaignEntityCreation.js";
import { requestPremiumAccess, showGeneratorRequirement } from "../../access/PremiumAccess.js";

export class NpcCreationGateway {
    static async open(options = {}) {
        if (!await requestPremiumAccess("npc")) return null;
        if (!getNpcGenerators().length) return showGeneratorRequirement("npc", {
            moduleIds: ["augur-fantasy", "augur-scifi"],
            createBlank: () => CampaignEntityCreation.open("npc", { ...options, generate: false })
        });
        const { NpcCreateDialog } = await import("../applications/NpcCreateDialog.js");
        return NpcCreateDialog.show(options);
    }
}
