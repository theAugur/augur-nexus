const clone = value => foundry.utils.deepClone(value);
const equal = (left, right) => JSON.stringify(left) === JSON.stringify(right);
const get = (object, path) => path.split(".").reduce((value, key) => value?.[key], object);
function set(object, path, value) {
    const keys = path.split(".");
    const key = keys.pop();
    const parent = keys.reduce((target, part) => target[part] ??= {}, object);
    parent[key] = clone(value);
}

/** Owns unsaved input and serializes this editor's writes without replacing its focused form. */
export class EntityEditorAutosave {
    #baseline;
    #pending = new Map();
    #running = null;
    #read;
    #write;
    #changed;
    #conflicted = false;
    #label;
    draft;
    error = "";

    constructor(entity, { read, write, changed = () => {}, label = "Person" }) {
        this.draft = clone(entity);
        this.#baseline = clone(entity);
        this.#read = read;
        this.#write = write;
        this.#changed = changed;
        this.#label = label;
    }

    get dirty() { return this.#pending.size > 0; }
    get saving() { return !!this.#running; }

    set(path, value) {
        if (equal(get(this.draft, path), value)) return;
        set(this.draft, path, value);
        this.#pending.set(path, clone(value));
        this.#changed();
    }

    async flush() {
        if (this.#running) return this.#running;
        // Defer draining until the promise is assigned, including synchronous candidate callbacks.
        this.#running = Promise.resolve().then(() => this.#drain());
        this.#changed();
        try { return await this.#running; }
        finally { this.#running = null; this.#changed(); }
    }

    async retry() {
        // Only an explicit retry authorizes applying retained input over a conflicting edit.
        if (this.#conflicted) this.#baseline = clone(this.#read());
        return this.flush();
    }

    async #drain() {
        this.error = "";
        this.#conflicted = false;
        while (this.#pending.size) {
            const snapshot = new Map(this.#pending);
            try {
                const current = this.#read();
                if (!current) throw new Error(`This ${this.#label} is no longer available.`);
                const patch = {};
                for (const [path, value] of snapshot) {
                    const live = get(current, path);
                    if (!equal(live, get(this.#baseline, path)) && !equal(live, value)) {
                        this.#conflicted = true;
                        throw new Error(`These fields changed elsewhere. Your input is retained. Retry Save applies your edits to the latest ${this.#label}.`);
                    }
                    set(patch, path, value);
                }
                const updated = await this.#write(patch, current);
                this.#baseline = clone(updated);
                for (const [path, value] of snapshot) {
                    if (equal(this.#pending.get(path), value)) this.#pending.delete(path);
                }
            } catch (error) {
                this.error = error?.message || `Could not save ${this.#label} changes.`;
                return false;
            }
        }
        return true;
    }
}
