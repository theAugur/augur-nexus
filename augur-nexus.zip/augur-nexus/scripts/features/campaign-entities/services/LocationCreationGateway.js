import { LocationGeneratorRegistry } from "./LocationGeneratorRegistry.js";

const SCIFI_MODULE_URL = "https://foundryvtt.com/packages/augur-scifi";
const PATREON_URL = "https://www.patreon.com/TheAugur";

export class LocationCreationGateway {
    static async open(options = {}) {
        if (LocationGeneratorRegistry.list().length > 0) {
            const { LocationCreateDialog } = await import("../applications/LocationCreateDialog.js");
            return LocationCreateDialog.show(options);
        }
        return this.#showModuleRequiredDialog();
    }

    static async #showModuleRequiredDialog() {
        const safePatreonUrl = foundry.utils.escapeHTML(PATREON_URL);

        return foundry.applications.api.DialogV2.wait({
            window: {
                title: "Module Required",
                icon: "fa-solid fa-circle-info"
            },
            position: {
                width: 440
            },
            content: `
                <p>Creating <strong>locations</strong> in Nexus is powered by Augur content modules.</p>
                <p><strong>Augur: Sci-Fi</strong> adds sci-fi settlements. <strong>Augur: Fantasy</strong> adds fantasy locations and regional settlements.</p>
                <p class="notes">You can follow development and releases on <a href="${safePatreonUrl}" target="_blank" rel="noopener noreferrer">Patreon</a>.</p>
            `,
            buttons: [
                {
                    action: "close",
                    label: "Close",
                    icon: "fa-solid fa-xmark"
                },
                {
                    action: "viewModule",
                    label: "View Module",
                    icon: "fa-solid fa-up-right-from-square",
                    default: true,
                    callback: () => {
                        window.open(SCIFI_MODULE_URL, "_blank", "noopener,noreferrer");
                    }
                }
            ]
        });
    }
}
