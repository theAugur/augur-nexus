import { LocationGeneratorRegistry } from "./LocationGeneratorRegistry.js";
import { CampaignEntityCreation } from "./CampaignEntityCreation.js";
import { requestPremiumAccess, showGeneratorRequirement } from "../../access/PremiumAccess.js";

export class LocationCreationGateway {
    static async open(options = {}) {
        if (!await requestPremiumAccess("location")) return null;
        if (!LocationGeneratorRegistry.list().length) return showGeneratorRequirement("location", {
            moduleIds: ["augur-fantasy", "augur-scifi"],
            createBlank: () => CampaignEntityCreation.open("location", { ...options, generate: false })
        });
        const { LocationCreateDialog } = await import("../applications/LocationCreateDialog.js");
        return LocationCreateDialog.show(options);
    }
}
