import { LocationGeneratorRegistry } from "./LocationGeneratorRegistry.js";

const PATREON_URL = "https://www.patreon.com/TheAugur";

export class LocationCreationGateway {
    static async open(options = {}) {
        if (LocationGeneratorRegistry.list().length > 0) {
            const { LocationCreateDialog } = await import("../applications/LocationCreateDialog.js");
            return LocationCreateDialog.show(options);
        }
        return this.#showModuleRequiredDialog();
    }

    static async #showModuleRequiredDialog() {
        const safePatreonUrl = foundry.utils.escapeHTML(PATREON_URL);

        return foundry.applications.api.DialogV2.wait({
            window: {
                title: "Module Required",
                icon: "fa-solid fa-circle-info"
            },
            position: {
                width: 440
            },
            content: `
                <p>Creating <strong>locations</strong> in Nexus is powered by Augur content modules.</p>
                <p><strong>Augur: Fantasy</strong> and <strong>Augur: Sci-Fi</strong> are available now, with generators and artwork for their respective settings. Install and activate a module that provides locations to get started.</p>
                <p class="notes">Explore the available modules on <a href="${safePatreonUrl}" target="_blank" rel="noopener noreferrer">Patreon</a>.</p>
            `,
            buttons: [
                {
                    action: "close",
                    label: "Close",
                    icon: "fa-solid fa-xmark"
                },
                {
                    action: "viewModules",
                    label: "View Modules",
                    icon: "fa-solid fa-up-right-from-square",
                    default: true,
                    callback: () => {
                        window.open(PATREON_URL, "_blank", "noopener,noreferrer");
                    }
                }
            ]
        });
    }
}
