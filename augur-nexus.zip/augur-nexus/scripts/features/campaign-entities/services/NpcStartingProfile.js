import { PersonalityTraitRegistry } from "./PersonalityTraitRegistry.js";
import { IdeologyCatalog } from "./IdeologyCatalog.js";

export const DEFAULT_PERSON_PORTRAIT = "modules/augur-nexus/assets/portraits/default.png";

const TRAIT_COUNT = 3;
const BELIEF_COUNT = 3;
const pick = list => list[Math.floor(Math.random() * list.length)];

// A manual Person starts with Nexus-owned personality and beliefs so opinions work immediately.
// Role, names, portraits and current threads stay with generator providers.
export class NpcStartingProfile {
    static build({ affiliation = null } = {}) {
        return {
            display: { imageSrc: DEFAULT_PERSON_PORTRAIT, tokenImageSrc: DEFAULT_PERSON_PORTRAIT },
            personality: { traitIds: this.rollTraits() },
            ideology: this.rollBeliefs({ affiliation })
        };
    }

    static isPlaceholderImage(src = "") {
        const value = String(src || "").trim();
        return !value || value === DEFAULT_PERSON_PORTRAIT;
    }

    static rollTraits() {
        return PersonalityTraitRegistry.pickRandomTraits(TRAIT_COUNT);
    }

    // Members share one or two of their organization's beliefs, the rest are their own.
    static rollBeliefs({ affiliation = null } = {}) {
        const topics = IdeologyCatalog.getTopics({ perspective: IdeologyCatalog.PERSONAL_PERSPECTIVE });
        const inherited = IdeologyCatalog.normalize(affiliation?.ideology || {}).selections;
        const selections = [];
        const keep = inherited.length > 1 && Math.random() < 0.5 ? 2 : Math.min(1, inherited.length);
        const pool = [...inherited];
        while (selections.length < keep && pool.length) selections.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
        while (selections.length < BELIEF_COUNT) {
            const used = new Set(selections.map(selection => selection.topicId));
            const topic = pick(topics.filter(entry => !used.has(entry.id) && entry.tenets.length));
            if (!topic) break;
            selections.push({ topicId: topic.id, tenetId: pick(topic.tenets).id });
        }
        return { schemaVersion: IdeologyCatalog.SCHEMA_VERSION, selections };
    }
}
