export class LocationGeneratorRegistry {
    static #generators = new Map();

    static register(definition = {}) {
        const id = String(definition.id || "").trim();
        if (!id || typeof definition.generate !== "function") throw new Error("Location generators require an id and generate function.");
        const row = { id, moduleId: String(definition.moduleId || ""), genreId: String(definition.genreId || "").trim() === "scifi" ? "scifi" : "fantasy", label: String(definition.label || id), description: String(definition.description || ""), icon: String(definition.icon || "fas fa-map-location-dot"), getOptions: definition.getOptions, getProfileOptions: definition.getProfileOptions, rerollCurrentThread: definition.rerollCurrentThread, composeCandidate: definition.composeCandidate, reconcileCandidate: definition.reconcileCandidate, renderCandidatePreview: definition.renderCandidatePreview, generate: definition.generate };
        this.#generators.set(id, row);
        Hooks.callAll("augurNexusLocationGeneratorsChanged", { generator: this.#public(row) });
        return this.#public(row);
    }

    static list() { return [...this.#generators.values()].sort((a, b) => a.label.localeCompare(b.label)).map(this.#public); }
    static get(id) { return this.#generators.get(String(id || "")) || null; }
    static async getOptions(id) { const generator = this.get(id); const raw = generator?.getOptions ? await generator.getOptions() : {}; return { types: (raw.types || []).map(option => ({ id: String(option.id || ""), label: String(option.label || option.id || "") })).filter(option => option.id), defaults: { typeId: String(raw.defaults?.typeId || "random") } }; }
    static async getProfileOptions(id, context = {}) { const generator = this.get(id); return generator?.getProfileOptions ? generator.getProfileOptions(context) : {}; }
    static canRerollCurrentThread(id) { return typeof this.get(id)?.rerollCurrentThread === "function"; }
    static async rerollCurrentThread(id, context = {}) { const generator = this.get(id); return generator?.rerollCurrentThread ? generator.rerollCurrentThread(context) : null; }
    static async composeCandidate(id, candidate, options = {}) {
        const generator = this.get(id);
        if (!generator?.composeCandidate || !candidate) return { members: [] };
        const composition = await generator.composeCandidate(candidate, options);
        return { members: Array.isArray(composition?.members) ? composition.members : [] };
    }
    static async reconcileCandidate(id, candidate, composition = {}) {
        const generator = this.get(id);
        if (!generator?.reconcileCandidate || !candidate) return composition;
        const reconciled = await generator.reconcileCandidate(candidate, composition);
        return { members: Array.isArray(reconciled?.members) ? reconciled.members : [] };
    }

    static async renderCandidatePreview(id, candidate, composition = {}) {
        const generator = this.get(id);
        if (!generator?.renderCandidatePreview || !candidate) return "";
        return String(await generator.renderCandidatePreview(candidate, composition) || "");
    }
    static async generate(id, options = {}) { const generator = this.get(id); if (!generator) throw new Error(`Unknown location generator: ${id}`); return generator.generate(options); }
    static #public(row) { return { id: row.id, moduleId: row.moduleId, genreId: row.genreId, label: row.label, description: row.description, icon: row.icon, hasOptions: !!row.getOptions, hasProfileOptions: !!row.getProfileOptions, canRerollCurrentThread: !!row.rerollCurrentThread }; }
}
