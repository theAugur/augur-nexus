export class GeneratorSessionPreference {
    static #selections = new Map();
    static #preferredSource = { moduleId: "", genreId: "" };

    static resolve(entityType, generators = [], { allowManual = false } = {}) {
        const type = String(entityType || "").trim();
        const rows = Array.isArray(generators) ? generators : [];
        const remembered = this.#selections.get(type);

        if (remembered?.generatorId === "" && allowManual) return "";
        if (remembered?.generatorId) {
            const exact = rows.find(generator => generator.id === remembered.generatorId);
            if (exact) return exact.id;
            this.#selections.delete(type);
        }

        const { moduleId, genreId } = this.#preferredSource;
        const sameSource = rows.find(generator => (
            moduleId
            && generator.moduleId === moduleId
            && (!genreId || generator.genreId === genreId)
        ));
        if (sameSource) return sameSource.id;

        const sameGenre = rows.find(generator => genreId && generator.genreId === genreId);
        return sameGenre?.id || rows[0]?.id || "";
    }

    static remember(entityType, generatorId, generators = []) {
        const type = String(entityType || "").trim();
        if (!type) return;

        const id = String(generatorId || "").trim();
        if (!id) {
            this.#selections.set(type, { generatorId: "", moduleId: "", genreId: "" });
            return;
        }

        const rows = Array.isArray(generators) ? generators : [];
        const generator = rows.find(row => row.id === id);
        if (!generator) return;

        const selection = {
            generatorId: id,
            moduleId: String(generator.moduleId || "").trim(),
            genreId: this.#normalizeGenre(generator.genreId)
        };
        this.#selections.set(type, selection);
        if (selection.moduleId || selection.genreId) {
            this.#preferredSource = {
                moduleId: selection.moduleId,
                genreId: selection.genreId
            };
        }
    }

    static rememberGenre(genreId, { entityType = "" } = {}) {
        const normalized = this.#normalizeGenre(genreId);
        if (!normalized) return;
        this.#preferredSource = { moduleId: "", genreId: normalized };

        const type = String(entityType || "").trim();
        if (type) this.#selections.delete(type);
    }

    static getPreferredGenre(fallback = "fantasy") {
        return this.#preferredSource.genreId || this.#normalizeGenre(fallback) || "fantasy";
    }

    static #normalizeGenre(value) {
        const genreId = String(value || "").trim();
        return genreId === "fantasy" || genreId === "scifi" ? genreId : "";
    }
}
