// Feature modules own the identity of Locations whose maps they manage.
export class LocationScenePolicyRegistry {
    static #policies = new Map();

    static register({ moduleId, matches, reason }) {
        if (!moduleId || typeof matches !== "function" || !reason) throw new Error("Location Scene policies require an owner, matcher, and explanation.");
        this.#policies.set(moduleId, { moduleId, matches, reason });
    }

    static get(location) {
        if (!location) return null;
        for (const policy of this.#policies.values()) {
            if (policy.matches(location)) return policy;
        }
        return null;
    }

    static assertCanManage(location) {
        const policy = this.get(location);
        if (policy) throw new Error(policy.reason);
    }
}
