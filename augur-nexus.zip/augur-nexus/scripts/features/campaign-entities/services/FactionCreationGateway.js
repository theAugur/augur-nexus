import { FactionGeneratorRegistry } from "./FactionGeneratorRegistry.js";
import { CampaignEntityCreation } from "./CampaignEntityCreation.js";
import { requestPremiumAccess, showGeneratorRequirement } from "../../access/PremiumAccess.js";

export class FactionCreationGateway {
    static async open(options = {}) {
        if (!await requestPremiumAccess("faction")) return null;
        if (!FactionGeneratorRegistry.list().length) return showGeneratorRequirement("faction", {
            moduleIds: ["augur-fantasy", "augur-scifi"],
            createBlank: () => CampaignEntityCreation.open("faction", { ...options, generate: false })
        });
        const { FactionCreateDialog } = await import("../applications/FactionCreateDialog.js");
        return FactionCreateDialog.show(options);
    }
}
