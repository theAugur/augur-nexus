import { FactionGeneratorRegistry } from "./FactionGeneratorRegistry.js";

const SCIFI_MODULE_URL = "https://foundryvtt.com/packages/augur-scifi";
const PATREON_URL = "https://www.patreon.com/TheAugur";

export class FactionCreationGateway {
    static async open(options = {}) {
        if (FactionGeneratorRegistry.list().length > 0) {
            const { FactionCreateDialog } = await import("../applications/FactionCreateDialog.js");
            return FactionCreateDialog.show(options);
        }
        return this.#showModuleRequiredDialog();
    }

    static async #showModuleRequiredDialog() {
        const safePatreonUrl = foundry.utils.escapeHTML(PATREON_URL);

        return foundry.applications.api.DialogV2.wait({
            window: {
                title: "Module Required",
                icon: "fa-solid fa-circle-info"
            },
            position: {
                width: 440
            },
            content: `
                <p>Creating <strong>organizations</strong> in Nexus is powered by Augur content modules.</p>
                <p><strong>Augur: Sci-Fi</strong> adds sci-fi themed entities now. An <strong>Augur: Fantasy</strong> module is in the works.</p>
                <p class="notes">You can follow development and releases on <a href="${safePatreonUrl}" target="_blank" rel="noopener noreferrer">Patreon</a>.</p>
            `,
            buttons: [
                {
                    action: "close",
                    label: "Close",
                    icon: "fa-solid fa-xmark"
                },
                {
                    action: "viewModule",
                    label: "View Module",
                    icon: "fa-solid fa-up-right-from-square",
                    default: true,
                    callback: () => {
                        window.open(SCIFI_MODULE_URL, "_blank", "noopener,noreferrer");
                    }
                }
            ]
        });
    }
}
