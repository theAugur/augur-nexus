import { FactionGeneratorRegistry } from "./FactionGeneratorRegistry.js";
import { CampaignEntityCreation } from "./CampaignEntityCreation.js";

export class FactionCreationGateway {
    static async open(options = {}) {
        if (FactionGeneratorRegistry.list().length > 0) {
            const { FactionCreateDialog } = await import("../applications/FactionCreateDialog.js");
            return FactionCreateDialog.show(options);
        }
        return this.#showModuleRequiredDialog(options);
    }

    static async #showModuleRequiredDialog(options) {
        const action = await foundry.applications.api.DialogV2.wait({
            window: {
                title: "Generate Organization",
                icon: "fa-solid fa-circle-info"
            },
            position: {
                width: 440
            },
            content: `
                <p><a href="https://foundryvtt.com/packages/augur-fantasy" target="_blank" rel="noopener noreferrer">Augur: Fantasy</a> and <a href="https://foundryvtt.com/packages/augur-scifi" target="_blank" rel="noopener noreferrer">Augur: Sci-Fi</a> add organization generation with names and other details for their respective settings.</p>
                <p>You can also create a blank organization and edit its details yourself.</p>
            `,
            buttons: [
                {
                    action: "close",
                    label: "Close",
                    icon: "fa-solid fa-xmark"
                },
                {
                    action: "createBlank",
                    label: "Create Blank Organization",
                    icon: "fa-solid fa-plus",
                    default: true
                }
            ],
            rejectClose: false
        });
        if (action === "createBlank") return CampaignEntityCreation.open("faction", { ...options, generate: false });
        return null;
    }
}
