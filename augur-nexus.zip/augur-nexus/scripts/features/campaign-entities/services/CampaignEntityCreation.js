import { CampaignEntityJournalStore } from "./CampaignEntityJournalStore.js";
import { LocationEntityStore } from "./LocationEntityStore.js";
import { NpcStartingProfile } from "./NpcStartingProfile.js";
import { openActionMenu } from "../../../api/ui.js";

const TYPES = {
    npc: { name: "Person", className: "Npc" },
    faction: { name: "Organization", className: "Faction" },
    location: { name: "Location", className: "Location" },
    ship: { name: "Ship", className: "Ship" }
};

// Manual records use the same stores and editors as generated campaign content.
export class CampaignEntityCreation {
    static async create(type, { parent = null, generationContext = {} } = {}) {
        if (!game.user.isGM) throw new Error("Only a GM can create campaign entries.");
        const definition = TYPES[type];
        if (!definition) throw new Error("Unsupported campaign entry type.");
        const starting = type === "npc" ? NpcStartingProfile.build({ affiliation: generationContext?.affiliation }) : {};
        const data = { ...starting, display: { ...starting.display, name: `New ${definition.name}` }, access: { playerVisibility: "inherit" } };
        if (type === "location" && parent) data.hierarchy = { parent };
        const store = type === "location" ? LocationEntityStore : CampaignEntityJournalStore;
        return store[`create${definition.className}`](data, { ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE } });
    }

    static async open(type, { generate = false, ...options } = {}) {
        if (!game.user.isGM) throw new Error("Only a GM can create campaign entries.");
        const definition = TYPES[type];
        if (!definition) throw new Error("Unsupported campaign entry type.");
        if (generate) {
            const name = `${definition.className}CreationGateway`;
            const gateway = await import(`./${name}.js`);
            return gateway[name].open(options);
        }
        const entity = await this.create(type, options);
        if (type === "npc" && options.connectToScene && options.connectToSceneId) {
            try {
                const { ConnectionTargetResolver } = await import("../../connections/services/ConnectionTargetResolver.js");
                const { ConnectionStore } = await import("../../connections/services/ConnectionStore.js");
                const scene = ConnectionTargetResolver.fromSceneReference({ sceneId: options.connectToSceneId });
                const target = ConnectionTargetResolver.fromCampaignEntity(entity);
                if (scene && target) await ConnectionStore.addConnection(scene, target, {
                    sourceView: { category: "npc", role: "Present" },
                    targetView: { category: "place", role: "Located At" }
                });
            } catch (error) {
                ui.notifications.warn(`The Person was created, but could not be connected to the current scene: ${error.message}`);
            }
        }
        // Run relationship callbacks once, on creation, never on subsequent editor saves.
        try { await options.onCreated?.(entity); }
        catch (error) { ui.notifications.error(`${entity.display.name} was created, but its connection could not be completed: ${error.message}`); }
        const name = `${definition.className}DataEditor`;
        const editor = await import(`../applications/${name}.js`);
        await editor[name].show({ [`${type}Id`]: entity.id });
        return entity;
    }

    static items(type, { generateFirst = true, ...options } = {}, label = TYPES[type]?.name) {
        if (!game.user.isGM) return [];
        return (generateFirst ? [true, false] : [false, true]).map(generate => ({
            id: `${generate ? "generate" : "new"}-${type}`,
            label: `${generate ? "Generate" : "New"} ${label}`,
            icon: generate ? "fas fa-dice" : "fas fa-plus",
            onSelect: () => this.open(type, { ...options, generate }).catch(error => ui.notifications.error(error.message))
        }));
    }

    static menu(type, anchor, options = {}, label) {
        return openActionMenu({ anchor, items: this.items(type, options, label) });
    }
}
