import { LocationScenePolicyRegistry } from "./LocationScenePolicyRegistry.js";
import { SiteScenePicker } from "../../site/applications/SiteScenePicker.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";
import { LocationEntityStore } from "./LocationEntityStore.js";
import { LocationSceneService } from "./LocationSceneService.js";
import { openActionMenu } from "../../../api/ui.js";
import { getSiteSceneType } from "../../site/registry/SiteSceneTypeRegistry.js";
import { showGeneratorRequirement } from "../../access/PremiumAccess.js";

const DUNGEON_SCENE_TYPE = "instant-dungeons-generator";

export class LocationSceneWorkflow {
    static getControlModel(locationId) {
        const scene = LocationSceneService.getPrimaryScene(locationId);
        return {
            hasScene: !!scene,
            canManage: LocationSceneService.canManage(locationId),
            canOpen: !!scene && NexusPlayerSceneAccess.canUserViewScene(scene),
            label: game.user?.isGM ? "Open Scene" : "View Scene",
            icon: "fas fa-map",
            title: scene ? `Open ${scene.name}` : ""
        };
    }

    static openMenu(locationId, anchor, { onChanged = null } = {}) {
        const items = this.getMenuItems(locationId, { onChanged, managementOnly: true, anchor });
        if (!items.length) return null;
        return openActionMenu({ anchor, className: "location-dossier-scene-menu", items });
    }

    static getMenuItems(locationId, { onChanged = null, onOpened = null, managementOnly = false, anchor = null } = {}) {
        if (!game.user?.isGM) return [];
        const scene = LocationSceneService.getPrimaryScene(locationId);
        const canManage = LocationSceneService.canManage(locationId);
        if (!scene) {
            if (!canManage) return [];
            return [
                {
                    id: "create-location-scene",
                    label: "Create Empty Scene",
                    status: "Creates and opens an empty map",
                    icon: "fas fa-map-location-dot",
                    onSelect: () => this.create(locationId, { onChanged })
                },
                {
                    id: "create-location-dungeon-scene",
                    label: "Create Instant Dungeon Scene",
                    icon: "fas fa-dungeon",
                    iconBadge: this.#hasDungeonGenerator() ? "" : "fas fa-lock",
                    className: this.#hasDungeonGenerator() ? "" : "unavailable",
                    description: this.#hasDungeonGenerator() ? "Generate dungeons, buildings, or villages" : "Requires Instant Dungeons",
                    onSelect: () => this.createInstantDungeon(locationId, { onChanged })
                },
                {
                    id: "link-location-scene",
                    label: "Link Existing Scene",
                    icon: "fas fa-link",
                    onSelect: () => this.selectExisting(locationId, { onChanged })
                }
            ];
        }

        return [
            ...(!managementOnly ? [{
                id: "open-location-scene",
                label: "Open Scene",
                status: scene.name,
                description: "Bring players to this scene",
                icon: "fas fa-map",
                onSelect: async () => {
                    const opened = await this.open(locationId);
                    if (opened) await onOpened?.();
                    return opened;
                }
            }, {
                id: "view-location-scene",
                label: "View Scene",
                description: "Only changes your view",
                icon: "fas fa-eye",
                onSelect: async () => {
                    const viewed = await LocationSceneService.view(locationId);
                    if (viewed) await onOpened?.();
                    return viewed;
                }
            }] : []),
            ...this.getPlayerAccessMenuItems(locationId, { onChanged, anchor }),
            ...(canManage ? [{
                id: "replace-location-scene",
                label: "Replace Linked Scene",
                status: "Current Scene is kept",
                icon: "fas fa-link",
                onSelect: () => this.selectExisting(locationId, { replace: true, onChanged })
            },
            {
                id: "detach-location-scene",
                label: "Detach Scene",
                status: "Scene is kept",
                icon: "fas fa-link-slash",
                onSelect: () => this.detach(locationId, { onChanged })
            }] : [])
        ];
    }

    static getPlayerAccessMenuItems(locationId, { onChanged = null, position = null, anchor = null } = {}) {
        const scene = LocationSceneService.getPrimaryScene(locationId);
        if (!game.user?.isGM || !scene || !LocationSceneService.canManage(locationId)) return [];
        return [{
            id: "player-location-scene-access",
            label: `Player Scene Open: ${NexusPlayerSceneAccess.getSceneViewLabel(scene)}`,
            icon: "fas fa-door-open",
            onSelect: () => this.openPlayerAccessMenu(locationId, anchor, { onChanged, position })
        }];
    }

    static openPlayerAccessMenu(locationId, anchor, { onChanged = null, position = null } = {}) {
        const scene = LocationSceneService.getPrimaryScene(locationId);
        if (!game.user?.isGM || !scene || !LocationSceneService.canManage(locationId)) return null;
        const current = NexusPlayerSceneAccess.getSceneViewOverride(scene);
        return openActionMenu({
            anchor, position, className: "location-player-scene-access-menu",
            items: [["inherit", "Global", "fas fa-layer-group"], ["allow", "Allowed", "fas fa-eye"], ["block", "Blocked", "fas fa-eye-slash"]].map(([value, label, icon]) => ({
                id: value, label: current === value ? `${label} (Current)` : label, icon,
                onSelect: async () => {
                    // Resolve again so a replaced or detached link never edits a stale Scene.
                    const linkedScene = LocationSceneService.getPrimaryScene(locationId);
                    if (!game.user?.isGM || linkedScene?.id !== scene.id || !LocationSceneService.canManage(locationId)) return;
                    await NexusPlayerSceneAccess.setSceneViewOverride(linkedScene, value);
                    await onChanged?.();
                }
            }))
        });
    }

    static async open(locationId) {
        const scene = LocationSceneService.getPrimaryScene(locationId);
        if (!scene) {
            ui.notifications.warn("This Location does not have a Scene.");
            return false;
        }
        if (!NexusPlayerSceneAccess.canUserViewScene(scene)) {
            ui.notifications.warn("This Scene is not currently available to view.");
            return false;
        }
        try {
            return await LocationSceneService.open(locationId);
        } catch (error) {
            this.#reportError(error, "The Location Scene could not be opened.");
            return false;
        }
    }

    static #hasDungeonGenerator() {
        const type = getSiteSceneType(DUNGEON_SCENE_TYPE);
        return game.modules?.get("instant-dungeons")?.active === true
            && type?.id === DUNGEON_SCENE_TYPE && type.available !== false && typeof type.resolveScene === "function";
    }

    static async createInstantDungeon(locationId, { onChanged = null } = {}) {
        if (!game.user?.isGM) return false;
        if (!this.#allowManagement(locationId)) return false;
        if (!this.#hasDungeonGenerator()) {
            await showGeneratorRequirement("locationScene", { label: "Creating an Instant Dungeon Scene", moduleIds: ["instant-dungeons"] });
            return false;
        }
        try {
            await LocationSceneService.createFromSceneType(locationId, DUNGEON_SCENE_TYPE);
            await onChanged?.();
            return true;
        } catch (error) {
            await onChanged?.();
            this.#reportError(error, "The Instant Dungeon Scene could not be created.");
            return false;
        }
    }

    static async create(locationId, { onChanged = null } = {}) {
        if (!game.user?.isGM) return false;
        try {
            await LocationSceneService.create(locationId);
            await onChanged?.();
            return true;
        } catch (error) {
            this.#reportError(error, "The Location Scene could not be created.");
            return false;
        }
    }

    static selectExisting(locationId, { replace = false, onChanged = null } = {}) {
        if (!game.user?.isGM) return null;
        if (!this.#allowManagement(locationId)) return null;
        const location = LocationEntityStore.getLocation(locationId);
        if (!location) return null;

        const parent = location.hierarchy?.parent || null;
        const containingSceneId = parent?.kind === "scene"
            ? parent.sceneId
            : parent?.kind === "site" ? parent.parentSceneId : null;
        const currentScene = LocationSceneService.getPrimaryScene(locationId);

        const picker = new SiteScenePicker(currentScene?.id || null, async (sceneId, { descendantCount = 0 } = {}) => {
            const scene = game.scenes.get(sceneId);
            if (descendantCount > 0) {
                const countLabel = `${descendantCount} ${descendantCount === 1 ? "descendant" : "descendants"}`;
                const confirmed = await foundry.applications.api.DialogV2.confirm({
                    window: { title: "Adopt Scene Branch" },
                    content: `<p>Use <strong>${foundry.utils.escapeHTML(scene?.name || "this Scene")}</strong> as the map for <strong>${foundry.utils.escapeHTML(location.display?.name || "this Location")}</strong>?</p><p>This Scene currently has ${countLabel}. The entire branch will appear beneath the Location.</p><p class="notification warning">Detaching preserves the Scene branch. Deleting the Location may delete its owned Scene branch.</p>`,
                    modal: true,
                    rejectClose: false,
                    yes: { label: "Adopt Branch" },
                    no: { label: "Cancel" }
                });
                if (!confirmed) return false;
            }

            try {
                if (replace && currentScene) await LocationSceneService.replace(locationId, sceneId);
                else await LocationSceneService.link(locationId, sceneId);
                await onChanged?.();
                return true;
            } catch (error) {
                this.#reportError(error, "The selected Scene could not be linked.");
                return false;
            }
        }, {
            mode: "location",
            locationId,
            excludedSceneIds: containingSceneId ? [containingSceneId] : []
        });
        picker.render(true);
        return picker;
    }

    static async detach(locationId, { onChanged = null } = {}) {
        if (!game.user?.isGM) return false;
        if (!this.#allowManagement(locationId)) return false;
        const location = LocationEntityStore.getLocation(locationId);
        const scene = LocationSceneService.getPrimaryScene(locationId);
        if (!location || !scene) return false;

        const confirmed = await foundry.applications.api.DialogV2.confirm({
            window: { title: "Detach Location Scene" },
            content: `<p>Detach <strong>${foundry.utils.escapeHTML(scene.name)}</strong> from <strong>${foundry.utils.escapeHTML(location.display?.name || "this Location")}</strong>?</p><p>The Scene and its descendants will be kept.</p>`,
            modal: true,
            rejectClose: false,
            yes: { label: "Detach Scene" },
            no: { label: "Cancel" }
        });
        if (!confirmed) return false;

        try {
            await LocationSceneService.detach(locationId);
            await onChanged?.();
            return true;
        } catch (error) {
            this.#reportError(error, "The Location Scene could not be detached.");
            return false;
        }
    }

    static #allowManagement(locationId) {
        const policy = LocationScenePolicyRegistry.get(LocationEntityStore.getLocation(locationId));
        if (!policy) return true;
        ui.notifications.warn(policy.reason);
        return false;
    }

    static #reportError(error, fallback) {
        console.error("Augur Nexus | Location Scene workflow failed", error);
        ui.notifications.error(error?.message || fallback);
    }
}
