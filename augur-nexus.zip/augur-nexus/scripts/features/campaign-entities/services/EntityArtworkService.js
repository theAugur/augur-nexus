import { canControlPlayerEntity, resolveControlledDocument } from "../../player-context/PlayerAccessService.js";
import { CampaignEntityJournalStore } from "./CampaignEntityJournalStore.js";
import { NpcEntityModel } from "../models/NpcEntityModel.js";

function imagePath(value) {
    const path = String(value || "").trim();
    return path && !/^(?:javascript|data|vbscript):/i.test(path) ? path : "";
}

export class EntityArtworkService {
    static async inspect(reference) {
        const document = resolveControlledDocument(reference);
        const entity = document?.getFlag("augur-nexus", "campaignEntity");
        if (!entity || !["npc", "ship"].includes(entity.type)) throw new Error("This Person or Ship is no longer available.");
        const canEdit = canControlPlayerEntity(document.uuid);
        if (!canEdit) throw new Error("You no longer have permission to change this entity’s artwork.");
        const actorUuid = entity.projections?.actorUuid || "";
        // Read the canonical link directly; inspecting artwork must never repair or replace links.
        const linked = actorUuid ? await fromUuid(actorUuid) : null;
        const actor = linked?.documentName === "Actor" && linked.testUserPermission(game.user, "OBSERVER") ? linked : null;
        return { document, entity, actor, actorUuid, canEdit, canCopy: !!actor?.testUserPermission(game.user, "OWNER"),
            entityImage: imagePath(entity.display?.imageSrc), actorImage: imagePath(actor?.img),
            entityTokenImage: imagePath(entity.type === "npc" ? NpcEntityModel.getTokenImage(entity) : entity.display?.imageSrc),
            tokenImage: imagePath(actor?.prototypeToken?.texture?.src),
            syncActorPortrait: entity.type === "npc" && entity.projections?.syncActorPortrait !== false,
            syncActorToken: entity.type === "npc" && entity.projections?.syncActorToken === true };
    }

    static async setLink(reference, { key, enabled, expected } = {}) {
        if (!["syncActorPortrait", "syncActorToken"].includes(key) || typeof enabled !== "boolean") throw new Error("Invalid artwork link setting.");
        const state = await this.inspect(reference);
        if (state.entity.type !== "npc" || !state.canCopy) throw new Error("Ownership of the linked Actor is required to change artwork linking.");
        if (!expected || expected.actorUuid !== state.actorUuid || expected.entityImage !== state.entityImage || expected.actorImage !== state.actorImage || expected.entityTokenImage !== state.entityTokenImage) {
            throw new Error("The link or artwork changed. Review the refreshed portraits and try again.");
        }
        await CampaignEntityJournalStore.updateNpc(state.document.uuid, { projections: { [key]: enabled } }, { expectedRevision: state.document._stats?.modifiedTime || 0 });
        return enabled ? "Artwork linked to this Person." : "Artwork unlinked. The Actor keeps its current image.";
    }

    static async copy(reference, { source, includeToken = false, expected } = {}) {
        if (!["nexus", "actor"].includes(source)) throw new Error("Choose the portrait to use.");
        const state = await this.inspect(reference);
        if (!state.canCopy) throw new Error("You need ownership of the linked Actor to copy its artwork.");
        includeToken = includeToken || state.syncActorToken;
        if (!expected || expected.actorUuid !== state.actorUuid || expected.entityImage !== state.entityImage || expected.actorImage !== state.actorImage || (source === "nexus" && includeToken && expected.entityTokenImage !== state.entityTokenImage)) {
            throw new Error("The link or artwork changed. Review the refreshed portraits and try again.");
        }
        const image = source === "nexus" ? state.entityImage : state.actorImage;
        if (!image) throw new Error("That portrait is empty or unavailable. Choose an image first.");
        const tokenImage = source === "nexus" ? state.entityTokenImage : state.entity.type === "npc" ? imagePath(NpcEntityModel.getTokenImage({ ...state.entity, display: { ...state.entity.display, imageSrc: image } })) : image;
        if (includeToken && !tokenImage) throw new Error("The token artwork is unavailable. Choose a valid image first.");
        if (source === "actor") {
            const update = state.entity.type === "npc" ? "updateNpc" : "updateShip";
            await CampaignEntityJournalStore[update](state.document.uuid, { display: { imageSrc: image } }, { expectedRevision: state.document._stats?.modifiedTime || 0 });
        }
        const actorPatch = {};
        if (source === "nexus") actorPatch.img = image;
        if (includeToken) actorPatch["prototypeToken.texture.src"] = tokenImage;
        if (Object.keys(actorPatch).length) {
            try {
                // A delegated Nexus save may yield to a GM. Recheck before touching the Actor.
                const current = await this.inspect(reference);
                if (!current.canCopy || current.actorUuid !== state.actorUuid) throw new Error("The Actor link or permissions changed.");
                const tokenAlreadySynced = source === "actor" && state.syncActorToken && current.tokenImage === tokenImage;
                if ((source === "nexus" && current.entityImage !== state.entityImage) || current.actorImage !== state.actorImage || (includeToken && current.tokenImage !== state.tokenImage && !tokenAlreadySynced)) throw new Error("The Actor artwork changed. Review it before copying again.");
                if (source === "nexus" && includeToken && current.entityTokenImage !== state.entityTokenImage) throw new Error("The Nexus token artwork changed. Review it before copying again.");
                if (tokenAlreadySynced) delete actorPatch["prototypeToken.texture.src"];
                if (Object.keys(actorPatch).length) await current.actor.update(actorPatch);
            } catch (error) {
                if (source === "actor") throw new Error(`Nexus portrait updated, but the default token was not changed: ${error.message}`);
                throw error;
            }
        }
        return includeToken ? "Portraits matched. The Actor’s default token artwork was also updated." : "Portraits matched. Token artwork was left unchanged.";
    }
}
