import { NpcEntityModel } from "../models/NpcEntityModel.js";

// The Person owns artwork; the linked Actor receives a one-way projection.
export class NpcActorArtworkSync {
    static async apply(document, previous, user = game.user) {
        const entity = document.getFlag("augur-nexus", "campaignEntity");
        const projection = entity?.projections;
        if (entity?.type !== "npc" || !projection?.actorUuid) return;
        const relinked = previous?.projections?.actorUuid !== projection.actorUuid;
        const portrait = NpcEntityModel.getImage(entity);
        const token = NpcEntityModel.getTokenImage(entity);
        const syncPortrait = projection.syncActorPortrait !== false && (relinked
            || previous?.projections?.syncActorPortrait === false
            || NpcEntityModel.getImage(previous) !== portrait);
        const syncToken = projection.syncActorToken === true && (relinked
            || previous?.projections?.syncActorToken !== true
            || NpcEntityModel.getTokenImage(previous) !== token);
        if (!syncPortrait && !syncToken) return;
        const revision = document._stats?.modifiedTime;
        const actor = await fromUuid(projection.actorUuid);
        if (!actor || actor.documentName !== "Actor") throw new Error("The linked Actor is unavailable.");
        if (!actor.testUserPermission(user, "OWNER")) throw new Error("Ownership of the linked Actor is required to update its artwork.");
        if (document.getFlag("augur-nexus", "campaignEntity").projections?.actorUuid !== actor.uuid) throw new Error("The Actor link changed while saving.");
        if (document._stats?.modifiedTime !== revision) throw new Error("The Person artwork changed while saving. Review it before matching the portraits again.");
        const patch = {};
        for (const [enabled, path, image, current] of [
            [syncPortrait, "img", portrait, actor.img],
            [syncToken, "prototypeToken.texture.src", token, actor.prototypeToken?.texture?.src]
        ]) {
            if (!enabled || !image || image === current) continue;
            if (/^(?:javascript|data|vbscript):/i.test(image)) throw new Error("The artwork path is unavailable.");
            patch[path] = image;
        }
        if (Object.keys(patch).length) await actor.update(patch);
    }
}
