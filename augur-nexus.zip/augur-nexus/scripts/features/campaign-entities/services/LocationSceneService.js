import { LocationScenePolicyRegistry } from "./LocationScenePolicyRegistry.js";
import { LocationEntityStore } from "./LocationEntityStore.js";
import { NexusLineageManager } from "../../nexus/services/NexusLineageManager.js";
import { LegacySciFiCompatibility } from "../../../support/compatibility/LegacySciFiCompatibility.js";
import { NexusSceneTransition } from "../../nexus/services/NexusSceneTransition.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";
import { getSiteSceneType, normalizeResolvedSiteScene } from "../../site/registry/SiteSceneTypeRegistry.js";
import { SiteRecordManager } from "../../site/services/SiteRecordManager.js";

const MODULE_ID = "augur-nexus";

export class LocationSceneService {
    static #generatedCreates = new Map();

    static registerHooks() {
        Hooks.on("deleteScene", scene => {
            this.#clearDeletedScene(scene).catch(err => {
                console.error("Augur Nexus | Failed to clear a deleted Location scene.", err);
            });
        });
        Hooks.on("augurNexusCampaignEntitiesChanged", () => {
            if (!canvas.scene?.id || !this.getLocationForScene(canvas.scene.id)) return;
            this.#refreshActiveSceneControls([canvas.scene.id]);
        });
    }

    static getPrimaryScene(locationId) {
        const sceneId = LocationEntityStore.getLocation(locationId)?.scenes?.primarySceneId;
        return sceneId ? game.scenes.get(sceneId) || null : null;
    }

    static getLocationForScene(sceneId, { excludeLocationId = null } = {}) {
        const normalizedSceneId = String(sceneId || "").trim();
        if (!normalizedSceneId) return null;
        return LocationEntityStore.getLocations().find(location =>
            location.id !== excludeLocationId
            && location.scenes?.primarySceneId === normalizedSceneId
        ) || null;
    }

    static getReturnNavigation(sceneOrId) {
        const sceneId = typeof sceneOrId === "string" ? sceneOrId : sceneOrId?.id;
        const location = this.getLocationForScene(sceneId);
        if (!location) return null;

        const parent = this.#resolveNearestParentScene(location, { ownedSceneId: sceneId });
        if (!parent) return null;
        return {
            parentSceneId: parent.scene.id,
            sceneId: parent.scene.id,
            parentSiteId: parent.siteId || null,
            locationId: parent.locationId,
            transitionStyle: "focus-placeable",
            transitionContext: {}
        };
    }

    static canManage(locationId) {
        return !LocationScenePolicyRegistry.get(LocationEntityStore.getLocation(locationId));
    }

    static async create(locationId) {
        const location = LocationEntityStore.getLocation(locationId);
        if (!location) throw new Error("Location could not be found.");
        LocationScenePolicyRegistry.assertCanManage(location);
        if (location.scenes?.primarySceneId) throw new Error("This Location already has a Scene.");

        const scene = await Scene.create({
            name: location.display?.name || "Location Map",
            navigation: false
        });
        try {
            await this.link(location.id, scene.id);
        } catch (err) {
            await scene.delete();
            throw err;
        }
        await scene.view();
        return scene;
    }

    static async createFromSceneType(locationId, sceneTypeId) {
        if (!game.user?.isGM) throw new Error("Only the GM can create Location Scenes.");
        const pending = this.#generatedCreates.get(locationId);
        if (pending) return pending;

        const task = this.#createFromSceneType(locationId, sceneTypeId);
        this.#generatedCreates.set(locationId, task);
        try {
            return await task;
        } finally {
            if (this.#generatedCreates.get(locationId) === task) this.#generatedCreates.delete(locationId);
        }
    }

    static async #createFromSceneType(locationId, sceneTypeId) {
        const location = LocationEntityStore.getLocation(locationId);
        if (!location) throw new Error("Location could not be found.");
        LocationScenePolicyRegistry.assertCanManage(location);
        if (location.scenes?.primarySceneId) throw new Error("This Location already has a Scene.");
        const sceneType = getSiteSceneType(sceneTypeId);
        if (!sceneType || sceneType.id !== sceneTypeId || !sceneType.available
            || typeof sceneType.resolveScene !== "function"
            || (sceneType.requiresModuleId && !game.modules.get(sceneType.requiresModuleId)?.active)) {
            throw new Error("This Scene generator is not currently available.");
        }

        const context = {
            existingScene: null,
            name: location.display?.name,
            ownerContext: { kind: "location", entityId: location.id },
            pageFlags: {}
        };
        const existingSceneIds = new Set(game.scenes.keys());
        const resolved = normalizeResolvedSiteScene(await sceneType.resolveScene(context));
        if (!resolved?.scene) throw new Error(`Scene type '${sceneType.id}' did not return a Scene.`);
        const scene = resolved.scene;
        try {
            await this.link(location.id, scene.id);
        } catch (error) {
            if (!existingSceneIds.has(scene.id)) await scene.delete();
            throw error;
        }
        // Once linked, a failed view or generator leaves the owned map available for retry.
        await scene.view();
        await resolved.afterEnter?.(scene, context);
        return scene;
    }

    static async link(locationId, sceneId) {
        return this.#assign(locationId, sceneId, { replace: false });
    }

    static async replace(locationId, sceneId) {
        return this.#assign(locationId, sceneId, { replace: true });
    }

    static async linkManaged(locationId, sceneId, { sourceModule = "" } = {}) {
        const moduleId = String(sourceModule || "").trim();
        if (!moduleId || moduleId === MODULE_ID || !game.modules.get(moduleId)?.active) {
            throw new Error("Managed Location Scenes require an active owning module.");
        }
        const linked = await this.#assign(locationId, sceneId, { replace: false, sourceModule: moduleId });
        return LocationEntityStore.updateLocation(linked.id, {
            moduleData: {
                [MODULE_ID]: {
                    ...(linked.moduleData?.[MODULE_ID] || {}),
                    managedScene: { sourceModule: moduleId, sceneId: String(sceneId || "").trim() }
                }
            }
        }, { moduleId: MODULE_ID });
    }

    static async #assign(locationId, sceneId, { replace = false, sourceModule = "" } = {}) {
        const location = LocationEntityStore.getLocation(locationId);
        if (!location) throw new Error("Location could not be found.");
        if (!sourceModule) LocationScenePolicyRegistry.assertCanManage(location);
        const previousSceneId = location.scenes?.primarySceneId || null;
        if (location.scenes?.primarySceneId && !replace) {
            throw new Error("Detach the current Location Scene before linking another one.");
        }

        const scene = game.scenes.get(String(sceneId || "").trim());
        if (!scene) throw new Error("Scene could not be found.");
        const isManagedScene = !!sourceModule;
        if (isManagedScene) {
            if (location.sourceModule !== sourceModule) {
                throw new Error("The Location and managed Scene must have the same owning module.");
            }
            if (!scene.flags?.[sourceModule]) {
                throw new Error("The Scene is not identified as content owned by that module.");
            }
        }
        if (scene.id === NexusLineageManager.getRootScene()?.id || scene.getFlag(MODULE_ID, NexusLineageManager.ROOT_FLAG) === true) {
            throw new Error("The designated Nexus root Scene cannot belong to a Location.");
        }
        if (!isManagedScene && (NexusLineageManager.getParentScene(scene) || scene.getFlag(MODULE_ID, "navigation")?.parentSceneId)) {
            throw new Error("Only a root Scene with no parent can belong to a Location.");
        }
        if (!isManagedScene && LegacySciFiCompatibility.getSceneKind(scene)) {
            throw new Error("Legacy Sci-Fi Scenes cannot belong to a Location.");
        }

        const parent = location.hierarchy?.parent || null;
        const containingSceneId = parent?.kind === "scene"
            ? parent.sceneId
            : parent?.kind === "site" ? parent.parentSceneId : null;
        if (containingSceneId === scene.id) {
            throw new Error("A Location cannot own the Scene that currently contains it.");
        }

        const owner = this.getLocationForScene(scene.id, { excludeLocationId: location.id });
        if (owner) throw new Error(`This Scene already belongs to ${owner.display?.name || "another Location"}.`);
        if (this.#isSiteScene(scene)) throw new Error("A Scene already owned by a Site cannot also belong to a Location.");

        const [{ PlaceHierarchyModel }, { PlaceTypeRegistry }] = await Promise.all([
            import("../../places/models/PlaceHierarchyModel.js"),
            import("../../places/services/PlaceTypeRegistry.js")
        ]);
        const sceneBranch = PlaceHierarchyModel.getBranch(
            PlaceTypeRegistry.getNodes({ isGM: true, includeHidden: true }),
            `scene:${scene.id}`
        );
        if (sceneBranch.some(node => node.key === `location:${location.id}`)) {
            throw new Error("A Location cannot own a Scene branch that already contains it.");
        }

        const patch = { scenes: { primarySceneId: scene.id } };
        if (!isManagedScene && location.moduleData?.[MODULE_ID]?.managedScene) {
            patch.moduleData = {
                [MODULE_ID]: { ...(location.moduleData[MODULE_ID] || {}), managedScene: null }
            };
        }
        const linked = await LocationEntityStore.updateLocation(location.id, patch, { moduleId: MODULE_ID });
        this.#refreshActiveSceneControls([previousSceneId, scene.id]);
        return linked;
    }

    static async detach(locationId) {
        const location = LocationEntityStore.getLocation(locationId);
        if (!location) throw new Error("Location could not be found.");
        LocationScenePolicyRegistry.assertCanManage(location);
        return this.#detach(location);
    }

    static async detachManaged(locationId, { sourceModule = "" } = {}) {
        const location = LocationEntityStore.getLocation(locationId);
        const policy = LocationScenePolicyRegistry.get(location);
        if (!game.user?.isGM || !location || !game.modules.get(sourceModule)?.active
            || location.sourceModule !== sourceModule || policy?.moduleId !== sourceModule) {
            throw new Error("Only the owning module can release this managed Location Scene.");
        }
        return this.#detach(location);
    }

    static async #detach(location) {
        if (!location.scenes?.primarySceneId) return location;
        const previousSceneId = location.scenes.primarySceneId;
        const detached = await LocationEntityStore.updateLocation(location.id, {
            scenes: { primarySceneId: null },
            moduleData: {
                [MODULE_ID]: { ...(location.moduleData?.[MODULE_ID] || {}), managedScene: null }
            }
        }, { moduleId: MODULE_ID });
        this.#refreshActiveSceneControls([previousSceneId]);
        return detached;
    }

    static async view(locationId) {
        if (!game.user?.isGM) return false;
        return this.open(locationId, { audience: "self", transitionStyle: "none" });
    }

    static async open(locationId, { audience = undefined, transitionStyle = undefined } = {}) {
        if (audience === "self" && !game.user?.isGM) return false;
        const scene = this.getPrimaryScene(locationId);
        if (!scene) {
            ui.notifications.warn("This Location does not have a Scene.");
            return false;
        }
        if (!NexusPlayerSceneAccess.canUserViewScene(scene)) {
            ui.notifications.warn("This Scene is not currently available to view.");
            return false;
        }
        await NexusSceneTransition.transitionToScene(scene, { audience, transitionStyle });
        return true;
    }

    static #isSiteScene(scene) {
        const lineage = scene.getFlag(MODULE_ID, "lineage") || {};
        const site = scene.getFlag(MODULE_ID, "site") || {};
        return scene.getFlag(MODULE_ID, "siteScene") === true
            || !!lineage.parentSiteId
            || (!!lineage.parentSceneId && !!site.siteId)
            || (!!site.parentSceneId && !!site.siteId);
    }

    static #resolveNearestParentScene(location, { ownedSceneId = null } = {}) {
        const visited = new Set();
        let cursor = location;

        while (cursor && !visited.has(cursor.id)) {
            visited.add(cursor.id);
            const parent = cursor.hierarchy?.parent || null;
            if (parent?.kind === "scene") {
                const scene = game.scenes.get(parent.sceneId) || null;
                return scene && scene.id !== ownedSceneId ? { scene, locationId: cursor.id } : null;
            }
            if (parent?.kind === "site") {
                const containingScene = game.scenes.get(parent.parentSceneId) || null;
                if (!containingScene) return null;
                const site = SiteRecordManager.resolveSite({ parentScene: containingScene, siteId: parent.siteId });
                const linkedScene = game.scenes.get(site?.siteSceneId || site?.linkedSceneId) || null;
                // The Site reference identifies a record on its containing map, not that map itself.
                if (linkedScene && linkedScene.id !== ownedSceneId && linkedScene.id !== containingScene.id) {
                    return { scene: linkedScene, locationId: cursor.id };
                }
                return containingScene.id !== ownedSceneId
                    ? { scene: containingScene, siteId: parent.siteId, locationId: cursor.id }
                    : null;
            }
            if (parent?.kind !== "location") return null;

            const parentLocation = LocationEntityStore.getLocation(parent.locationId);
            if (!parentLocation) return null;
            const parentLocationScene = game.scenes.get(parentLocation.scenes?.primarySceneId) || null;
            if (parentLocationScene && parentLocationScene.id !== ownedSceneId) return { scene: parentLocationScene, locationId: cursor.id };
            cursor = parentLocation;
        }

        return null;
    }

    static #refreshActiveSceneControls(sceneIds = []) {
        if (!canvas.scene?.id || !(sceneIds || []).filter(Boolean).includes(canvas.scene.id)) return;
        if (!ui.controls?.render) return;
        void Promise.resolve(ui.controls.render({ reset: true })).catch(error => {
            console.warn("Augur Nexus | Failed to refresh Scene controls after a Location Scene change.", error);
        });
    }

    static async #clearDeletedScene(scene) {
        if (!scene?.id) return;
        const owners = LocationEntityStore.getLocations()
            .filter(location => location.scenes?.primarySceneId === scene.id);
        for (const location of owners) {
            await LocationEntityStore.updateLocation(location.id, {
                scenes: { primarySceneId: null }
            });
        }
    }
}
