import { LocationViewRegistry } from "./LocationViewRegistry.js";
import { LOCATION_DOSSIER_VIEW_IDS } from "./LocationDossierViewIds.js";

export class CoreLocationViewRegistration {
    static register() {
        LocationViewRegistry.register({
            id: LOCATION_DOSSIER_VIEW_IDS.settlement,
            moduleId: "augur-nexus",
            label: "Open Settlement Dossier",
            description: "Open the full Nexus settlement and place dossier.",
            icon: "fas fa-city",
            priority: 50,
            isPrimary: entity => entity?.dossier?.viewId === LOCATION_DOSSIER_VIEW_IDS.settlement,
            isAvailable: entity => entity?.type === "location"
                && entity?.dossier?.viewId === LOCATION_DOSSIER_VIEW_IDS.settlement,
            open: async entity => {
                const { SettlementDossier } = await import("../applications/SettlementDossier.js");
                return SettlementDossier.show({ locationId: entity.id });
            }
        });
    }
}
