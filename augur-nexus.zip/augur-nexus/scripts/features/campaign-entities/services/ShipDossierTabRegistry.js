export class ShipDossierTabRegistry {
    static #providers = new Map();

    static register({ id, moduleId, label, matches, build } = {}) {
        if (!id || !moduleId || !label || typeof matches !== "function" || typeof build !== "function") {
            throw new Error("Ship dossier tabs require id, moduleId, label, matches and build.");
        }
        this.#providers.set(id, { id, moduleId, label, matches, build });
    }

    static async buildTabs({ actor, entity, user = game.user } = {}) {
        if (!actor || !user || (!user.isGM && !actor.testUserPermission(user, CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER))) return [];
        const tabs = [];
        for (const provider of this.#providers.values()) {
            if (!game.modules.get(provider.moduleId)?.active) continue;
            try {
                if (!provider.matches({ actor, entity })) continue;
                const model = await provider.build({ actor, entity });
                if (!model) continue;
                tabs.push({
                    id: `extension:${provider.id}`,
                    label: provider.label,
                    openActorLabel: String(model.openActorLabel || "Open Actor Sheet"),
                    rows: (model.rows || []).map(row => ({
                        label: String(row.label || ""),
                        value: String(row.value ?? "—"),
                        sectionStart: row.sectionStart === true
                    }))
                });
            } catch (error) {
                console.warn(`Augur: Nexus | Could not build ship dossier tab ${provider.id}.`, error);
            }
        }
        return tabs;
    }
}
