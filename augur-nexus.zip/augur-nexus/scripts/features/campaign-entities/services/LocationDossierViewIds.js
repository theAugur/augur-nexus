export const LOCATION_DOSSIER_VIEW_IDS = Object.freeze({
    settlement: "augur-nexus:settlement-dossier"
});
