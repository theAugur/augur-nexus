import { EntityDisclosure } from "../models/EntityDisclosure.js";
import { CampaignEntityJournalStore } from "./CampaignEntityJournalStore.js";
import { LocationEntityStore } from "./LocationEntityStore.js";
import { openActionMenu } from "../../../api/ui.js";
import { openHelp } from "../../../api/help.js";

const bound = new WeakSet();

export function bindEntityDisclosureControls(root, getId, { type = "npc", handleClick = false } = {}) {
    for (const entry of root?.querySelectorAll("[data-entity-disclosure-section]") || []) {
        if (bound.has(entry)) continue;
        bound.add(entry);
        const open = event => {
            event.preventDefault(); event.stopPropagation();
            openEntityDisclosureMenu(getId(), entry, type);
        };
        entry.addEventListener("contextmenu", open);
        // Embedded location panels can be hosted by applications without our action table.
        if (handleClick) entry.addEventListener("click", open);
        entry.addEventListener("keydown", event => {
            const activateEntry = entry.hasAttribute("data-entity-disclosure-key") && ["Enter", " "].includes(event.key);
            if (!activateEntry && event.key !== "ContextMenu" && !(event.shiftKey && event.key === "F10")) return;
            event.preventDefault(); event.stopPropagation();
            openEntityDisclosureMenu(getId(), entry, type);
        });
    }
}

export function openEntityDisclosureMenu(id, anchor, type = "npc") {
    const section = anchor.dataset.entityDisclosureSection;
    if (!EntityDisclosure.sections({ type }).includes(section)) return;
    const sectionLabel = section === "thread" ? (type === "ship" ? "assignment entries" : "thread entries") : section;
    const store = type === "location" ? LocationEntityStore : CampaignEntityJournalStore;
    const suffix = { npc: "Npc", faction: "Faction", location: "Location", ship: "Ship" }[type];
    const entity = store[`get${suffix}`](id);
    if (!entity || !EntityDisclosure.context(entity).canManageDisclosure) return;
    const key = anchor.dataset.entityDisclosureKey;
    const setVisibility = async (visibility, all = false) => {
        try {
            const live = store[`get${suffix}`](id);
            if (!live || !EntityDisclosure.context(live).canManageDisclosure) return;
            const keys = EntityDisclosure.keys(live, section);
            if (!all && !keys.includes(key)) return;
            const disclosure = EntityDisclosure.snapshot(live);
            const targets = new Set(all ? keys : [key]);
            const state = disclosure[section];
            for (const value of ["show", "hide"]) {
                state[value] = state[value].filter(target => !targets.has(target));
                if (visibility === value) state[value].push(...targets);
            }
            await store[`update${suffix}`](id, { access: { disclosure: { [section]: state } } });
        } catch (error) { ui.notifications.error(error.message || "Player visibility could not be updated."); }
    };
    const current = EntityDisclosure.override(entity, section, key);
    const global = EntityDisclosure.globalDefault(entity, section);
    const category = EntityDisclosure.categoryLabel(type, section);
    const changeGlobal = async () => {
        if (!game.user.isGM) return;
        const value = EntityDisclosure.globalDefault({ type }, section);
        const result = await foundry.applications.api.DialogV2.wait({
            window: { title: `${category} — Global Visibility` },
            position: { width: 440 }, modal: true, rejectClose: false,
            content: `<p>Set the default player visibility for <strong>${category}</strong> across this world.</p>
                <p>Only entries set to Global follow this default. Individual Yes and No choices stay unchanged.</p>`,
            buttons: [
                { action: "hide", label: `Hidden${value === "hide" ? " (Current)" : ""}`, icon: "fas fa-eye-slash", callback: () => "hide" },
                { action: "show", label: `Visible${value === "show" ? " (Current)" : ""}`, icon: "fas fa-eye", callback: () => "show" },
                { action: "cancel", label: "Cancel", callback: () => null }
            ]
        });
        if (!game.user.isGM || !["show", "hide"].includes(result)) return;
        try {
            await game.settings.set("augur-nexus", EntityDisclosure.settingKey(type, section), result);
        } catch (error) { ui.notifications.error(error.message || "The global visibility default could not be updated."); }
    };
    return openActionMenu({ anchor, items: [
        ...(key ? [
            { id: "inherit", label: `Global (${global === "show" ? "Visible" : "Hidden"})${current === "inherit" ? " — Current" : ""}`, icon: "fas fa-layer-group", onSelect: () => setVisibility("inherit") },
            { id: "show", label: `Yes — Visible to players${current === "show" ? " (Current)" : ""}`, icon: "fas fa-eye", onSelect: () => setVisibility("show") },
            { id: "hide", label: `No — Hidden from players${current === "hide" ? " (Current)" : ""}`, icon: "fas fa-eye-slash", onSelect: () => setVisibility("hide") },
            { type: "separator" }
        ] : []),
        { id: "hide-all", label: `Hide all ${sectionLabel} from players`, icon: "fas fa-eye-slash", onSelect: () => setVisibility("hide", true) },
        { id: "reveal-all", label: `Reveal all ${sectionLabel} to players`, icon: "fas fa-eye", onSelect: () => setVisibility("show", true) },
        { id: "reset-all", label: `Reset all ${sectionLabel} to Global`, icon: "fas fa-layer-group", onSelect: () => setVisibility("inherit", true) },
        { type: "separator" },
        ...(game.user.isGM ? [{ id: "change-global", label: "Change global default…", status: category, icon: "fas fa-sliders", onSelect: changeGlobal }] : []),
        { id: "visibility-info", label: "What's This?", icon: "fas fa-circle-question", onSelect: () => openHelp("augur-nexus:dossier-details") }
    ] });
}
