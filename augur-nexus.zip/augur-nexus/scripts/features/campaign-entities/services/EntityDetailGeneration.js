import { AUGUR_PATREON_URL as PATREON } from "../../access/PremiumAccess.js";
import { NpcGeneratorRegistry } from "./NpcGeneratorRegistry.js";
import { FactionGeneratorRegistry } from "./FactionGeneratorRegistry.js";
import { ShipGeneratorRegistry } from "./ShipGeneratorRegistry.js";
import { DEFAULT_PERSON_PORTRAIT } from "./NpcStartingProfile.js";

const TEMPLATE = "modules/augur-nexus/templates/campaign-entities/entity-detail-generation.hbs";
const INFO_TEMPLATE = "modules/augur-nexus/templates/campaign-entities/generators-info.hbs";
const KEPT = ["Connections", "Journal", "Custom fields", "Player visibility"];

// Only descriptive fields may cross this boundary. Access, connections and custom fields never do;
// names and artwork only replace untouched defaults so authored or Actor-linked identity survives.
const TYPES = {
    npc: {
        registry: NpcGeneratorRegistry, noun: "Person", plural: "people",
        summary: "a complete person: name, portrait, role, personality, beliefs, and current thread",
        replaced: ["Personality", "Beliefs", "Role", "Descriptor", "Current thread"],
        paths: ["personality.traitIds", "ideology.selections", "role.roleId", "role.roleLabel", "flavor.descriptor",
            "flavor.drive", "flavor.action", "flavor.theme", "flavor.focus"],
        // Race and appearance describe the portrait, so they only change together with it.
        defaultImages: ["", DEFAULT_PERSON_PORTRAIT], imagePaths: ["display.imageSrc", "display.tokenImageSrc", "identity.ancestryId", "identity.ancestryLabel", "identity.gender"],
        groups: options => [["speciesId", "Race", options.species], ["roleId", "Role", options.roles], ["gender", "Appearance", options.genders]]
    },
    faction: {
        registry: FactionGeneratorRegistry, noun: "Organization", plural: "organizations",
        summary: "a complete organization: beliefs, methods, drives, and current thread",
        replaced: ["Beliefs", "Method", "Drive", "Current thread"],
        paths: ["ideology.selections", "profile.method", "profile.drive", "profile.action", "profile.theme", "profile.focus"],
        defaultImages: [""], imagePaths: ["display.imageSrc"],
        groups: options => [["typeId", "Organization type", options.types]]
    },
    ship: {
        registry: ShipGeneratorRegistry, noun: "Ship", plural: "ships",
        summary: "a ship's role and current assignment",
        replaced: ["Role", "Current assignment"],
        paths: ["profile.role", "profile.action", "profile.theme", "profile.focus"],
        defaultImages: [""], imagePaths: ["display.imageSrc"],
        groups: options => [["templateId", "Ship type", options.templates]]
    }
};
const valueAt = (entity, path) => path.split(".").reduce((value, key) => value?.[key], entity);
const empty = value => value == null || value === "" || (Array.isArray(value) && !value.length);

export class EntityDetailGeneration {
    static npcGroups(entity, { freeOnly = false } = {}) {
        const linked = !!entity?.projections?.actorUuid;
        return [
            { id: "name", label: "Name", paths: ["display.name"], checked: entity?.display?.name === "New Person", identity: true },
            { id: "portrait", label: "Portrait", paths: TYPES.npc.imagePaths, checked: TYPES.npc.defaultImages.includes(entity?.display?.imageSrc || ""), identity: true },
            { id: "personality", label: "Personality", paths: ["personality.traitIds"] },
            { id: "beliefs", label: "Beliefs", paths: ["ideology.selections"] },
            { id: "role", label: "Role", paths: ["role.roleId", "role.roleLabel"] },
            { id: "descriptor", label: "Descriptor", paths: ["flavor.descriptor"] },
            { id: "thread", label: "Current thread", paths: ["flavor.drive", "flavor.action", "flavor.theme", "flavor.focus"] }
        ].map(group => {
            const requiresModule = freeOnly && !["personality", "beliefs"].includes(group.id);
            const actorControlled = linked && !!group.identity;
            const disabled = requiresModule || actorControlled;
            return { ...group, checked: !disabled && group.checked !== false, disabled, requiresModule,
                lockIcon: actorControlled ? "fa-link" : "fa-lock",
                reason: actorControlled ? "Linked Actor controls name and portrait" : requiresModule ? "Add Augur: Fantasy or Augur: Sci-Fi to generate these details. You can also edit them manually." : "" };
        });
    }

    static npcSelectedValues(entity, candidate, selection, options = {}) {
        const values = {};
        for (const group of this.npcGroups(entity, options)) {
            if (group.disabled || !selection[group.id]) continue;
            if (group.id === "portrait" && empty(candidate?.display?.imageSrc)) continue;
            for (const path of group.paths) {
                const value = valueAt(candidate, path);
                if (!empty(value)) values[path] = foundry.utils.deepClone(value);
            }
        }
        return values;
    }

    static npcSelectedPreview(entity, candidate, selection, options = {}) {
        // Keep saved identity visible as context; only selected generated values replace it.
        const preview = { display: { name: entity?.display?.name || "New Person", imageSrc: entity?.display?.imageSrc || "" } };
        for (const [path, value] of Object.entries(this.npcSelectedValues(entity, candidate, selection, options))) {
            foundry.utils.setProperty(preview, path, value);
        }
        return preview;
    }

    static preview(type, entity, candidate) {
        const preview = foundry.utils.deepClone(entity);
        for (const [path, value] of Object.entries(this.values(type, entity, candidate))) {
            foundry.utils.setProperty(preview, path, foundry.utils.deepClone(value));
        }
        return preview;
    }

    static warning(type, entity, candidate = null) {
        const definition = TYPES[type];
        const values = this.values(type, entity, candidate || { display: { name: "x", imageSrc: "x" } });
        const art = type === "npc" ? "Portrait and appearance" : "Image";
        const linked = !!entity?.projections?.actorUuid;
        const fields = definition.replaced.map((label, index) => ({ label, paths: type === "npc"
            ? [["personality.traitIds"], ["ideology.selections"], ["role.roleId", "role.roleLabel"], ["flavor.descriptor"], ["flavor.drive", "flavor.action", "flavor.theme", "flavor.focus"]][index] : definition.paths }));
        return {
            replaced: [...(values["display.name"] ? ["Name"] : []), ...(values["display.imageSrc"] ? [art] : []), ...fields.filter(field => !candidate || field.paths.some(path => path in values)).map(field => field.label)].join(", "),
            kept: [...(values["display.name"] ? [] : [linked ? "Actor name" : "Name"]), ...(values["display.imageSrc"] ? [] : [linked ? "Actor portrait and appearance" : art]), ...fields.filter(field => candidate && !field.paths.some(path => path in values)).map(field => field.label), ...KEPT, "Actor links"].join(", ")
        };
    }
    static available(type) { return !!TYPES[type]?.registry.list().length; }

    // Every generated detail replaces the current one; the warning panel states this before generating.
    static values(type, entity, candidate) {
        const definition = TYPES[type];
        if (!definition) return {};
        const values = {};
        for (const path of definition.paths) {
            const value = valueAt(candidate, path);
            if (!empty(value)) values[path] = value;
        }
        if (entity?.projections?.actorUuid) return values;
        const name = valueAt(candidate, "display.name");
        if (name && valueAt(entity, "display.name") === `New ${definition.noun}`) values["display.name"] = name;
        if (!empty(valueAt(candidate, "display.imageSrc")) && definition.defaultImages.includes(String(valueAt(entity, "display.imageSrc") || ""))) {
            for (const path of definition.imagePaths) {
                const value = valueAt(candidate, path);
                if (!empty(value)) values[path] = value;
            }
        }
        return values;
    }

    static async choose(type, entity) {
        if (!game.user.isGM || !TYPES[type]) return null;
        const definition = TYPES[type];
        const providers = definition.registry.list();
        if (!providers.length) {
            await this.showInfo(type);
            return null;
        }
        const groups = [];
        for (const [index, provider] of providers.entries()) {
            const options = await definition.registry.getOptions(provider.id);
            const fields = definition.groups(options).filter(([, , rows]) => rows?.length).map(([key, label, rows]) => ({
                key, label, options: rows.map(row => ({ id: row.id, label: row.label, selected: row.id === options.defaults?.[key] }))
            }));
            groups.push({ providerId: provider.id, hidden: index > 0, fields, requires: options });
        }
        // Mirror values(): the warning must list exactly what this entry will lose.
        const identity = this.values(type, entity, { display: { name: "x", imageSrc: "x" } });
        const art = type === "npc" ? "Portrait and appearance" : "Image";
        const linked = !!entity?.projections?.actorUuid;
        const content = await foundry.applications.handlebars.renderTemplate(TEMPLATE, {
            name: entity?.display?.name || `this ${definition.noun.toLowerCase()}`,
            multipleProviders: providers.length > 1,
            providers: providers.map((provider, index) => ({ id: provider.id, label: provider.label, selected: index === 0 })),
            groups,
            replaced: [...(identity["display.name"] ? ["Name"] : []), ...(identity["display.imageSrc"] ? [art] : []), ...definition.replaced],
            kept: [...(identity["display.name"] ? [] : [linked ? "Actor name" : "Name"]), ...(identity["display.imageSrc"] ? [] : [linked ? `Actor ${art.toLowerCase()}` : art]), ...KEPT]
        });
        const chosen = await foundry.applications.api.DialogV2.wait({
            classes: ["augur-nexus", "augur-theme-fantasy", "nexus-detail-generation-dialog"],
            window: { title: `Generate ${definition.noun} Details`, icon: "fas fa-dice" },
            position: { width: 460 },
            modal: true,
            rejectClose: false,
            content,
            buttons: [
                { action: "cancel", label: "Cancel", callback: () => null },
                { action: "generate", label: "Generate Details", icon: "fas fa-dice", default: true, callback: (_event, button) => {
                    const form = button.form;
                    const providerId = form.elements.provider?.value || providers[0].id;
                    const group = form.querySelector(`[data-provider-options="${CSS.escape(providerId)}"]`);
                    const values = Object.fromEntries([...(group?.querySelectorAll("select") || [])].map(select => [select.name, select.value]));
                    return { providerId, values };
                } }
            ],
            render: (_event, dialog) => {
                const select = dialog.element.querySelector("[data-detail-provider]");
                select?.addEventListener("change", () => {
                    for (const group of dialog.element.querySelectorAll("[data-provider-options]")) group.hidden = group.dataset.providerOptions !== select.value;
                });
            }
        });
        if (!chosen?.providerId) return null;
        const requires = groups.find(group => group.providerId === chosen.providerId)?.requires || {};
        if ((requires.requiresSpecies && !requires.species?.length) || (requires.requiresRole && !requires.roles?.length)) {
            throw new Error("No eligible race or role is available. Update World Templates before generating details.");
        }
        const candidate = await definition.registry.generate(chosen.providerId, chosen.values);
        const values = this.values(type, entity, candidate);
        if (!Object.keys(values).length) ui.notifications.info("The generator returned no new details.");
        return values;
    }

    static async showInfo(type) {
        const definition = TYPES[type] || TYPES.npc;
        const content = await foundry.applications.handlebars.renderTemplate(INFO_TEMPLATE, { summary: definition.summary, plural: definition.plural });
        return foundry.applications.api.DialogV2.wait({
            classes: ["augur-nexus", "augur-theme-fantasy", "nexus-detail-generation-dialog"],
            window: { title: "Generators", icon: "fas fa-dice" },
            position: { width: 440 },
            rejectClose: false,
            content,
            buttons: [
                { action: "close", label: "Close" },
                { action: "explore", label: "Explore Modules", icon: "fas fa-up-right-from-square", default: true,
                    callback: () => window.open(PATREON, "_blank", "noopener,noreferrer") }
            ]
        });
    }
}
