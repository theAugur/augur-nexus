// Module-supplied defaults are presentation only; explicit ship covers remain authoritative.
export class ShipDossierPresentationRegistry {
    static #backgrounds = new Map();

    static register({ moduleId, backgroundSrc } = {}) {
        moduleId = String(moduleId || "").trim();
        backgroundSrc = String(backgroundSrc || "").trim();
        if (!moduleId || !backgroundSrc) throw new Error("Ship dossier backgrounds require moduleId and backgroundSrc.");
        this.#backgrounds.set(moduleId, backgroundSrc);
    }

    static getBackground(entity = {}) {
        const active = [...this.#backgrounds].filter(([moduleId]) => game.modules.get(moduleId)?.active);
        return active.find(([moduleId]) => moduleId === entity.sourceModule)?.[1]
            || active[0]?.[1] || "";
    }
}
