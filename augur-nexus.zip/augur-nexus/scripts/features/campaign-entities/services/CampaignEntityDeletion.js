import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { CampaignEntityIndex } from "./CampaignEntityIndex.js";
import { NexusMarkerService } from "../../markers/services/NexusMarkerService.js";
import { FactionHierarchyService } from "../../connections/services/FactionHierarchyService.js";
import { RegionPopulationProjectionCleanup } from "../../region-population/services/RegionPopulationProjectionCleanup.js";

const LABELS = { npc: "Person", faction: "Organization", ship: "Ship" };
const MODULE = "augur-nexus";

export class CampaignEntityDeletion {
    static pending = new Map();
    static #running = new Map();
    static #nativePlans = new Map();
    static #registered = false;

    static requireGM() { if (!game.user?.isGM) throw new Error("Only a GM can permanently delete campaign objects."); }

    static resolve(type, id) {
        return (game.journal?.contents || []).find(document => {
            const entity = document.getFlag(MODULE, "campaignEntity");
            return entity?.type === type && [entity.id, document.id, document.uuid].includes(id);
        }) || null;
    }

    static pendingFor(type, id) {
        return [...this.pending.values()].find(plan => plan.type === type
            && [plan.id, plan.journalId, `JournalEntry.${plan.journalId}`].includes(id));
    }

    static preview(type, id, document = this.resolve(type, id)) {
        this.requireGM();
        if (!LABELS[type] || !document) return null;
        const entity = foundry.utils.deepClone(document.getFlag(MODULE, "campaignEntity"));
        const nodeId = ConnectionTargetResolver.getEntityNodeId(entity.id);
        const graph = ConnectionStore.getGraph();
        const connections = ConnectionStore.getIncidentEdgesForDeletion(nodeId)
            .map(edge => {
                const otherId = edge.sourceNodeId === nodeId ? edge.targetNodeId : edge.sourceNodeId;
                const stored = ConnectionStore.getNode(otherId) || graph.nodes?.[otherId];
                const other = stored && (ConnectionTargetResolver.resolveDisplayNodeSync(stored) || stored);
                const view = ConnectionStore.getConnectionView(edge, nodeId);
                return { id: edge.id, name: other?.name || otherId, role: view?.role || "Connection", edge: foundry.utils.deepClone(edge) };
            }).sort((a, b) => a.id.localeCompare(b.id));
        const markers = [];
        for (const scene of game.scenes?.contents || []) for (const tile of scene.tiles?.contents || []) {
            const record = NexusMarkerService.getMarkerRecord(tile);
            const target = record?.target;
            if (target?.kind === "campaign-entity" && target.entityId === entity.id && target.entityType === type)
                markers.push({ sceneId: scene.id, documentId: tile.id, markerId: record.markerId,
                    name: scene.name || scene.id, label: record.presentation?.name || document.name });
        }
        markers.sort((a, b) => `${a.sceneId}:${a.documentId}`.localeCompare(`${b.sceneId}:${b.documentId}`));
        const assignments = connections.flatMap(({ edge, name }) => {
            const consequences = [];
            if (edge.factionMembership?.tier === "leader") consequences.push(type === "faction"
                ? `${name} remains a person; their leadership assignment to this organization is removed.`
                : `${name} will no longer have this person as its leader.`);
            if (edge.factionSeat) consequences.push(`The seat-of-power assignment involving ${name} is removed.`);
            if (edge.factionHierarchy) consequences.push(`The organization hierarchy link with ${name} is removed; that organization remains.`);
            if (edge.locationLeadership) consequences.push(`${name} will no longer have this person as its ruler.`);
            if (edge.shipCaptain) consequences.push(type === "ship"
                ? `${name} remains a person; their command assignment to this ship is removed.`
                : `${name} will no longer have this person as its captain.`);
            return consequences;
        });
        const plan = { type, id: entity.id, label: LABELS[type], name: entity.display?.name || document.name,
            journalId: document.id, entity, nodeId, connections, markers, assignments };
        plan.fingerprint = JSON.stringify([document.id, entity, connections, markers]);
        return plan;
    }

    static async confirm(type, id, options = {}) {
        this.requireGM();
        const pending = this.pendingFor(type, id);
        const plan = pending ? this.previewCleanup(pending) : this.preview(type, id);
        if (!plan) return false;
        const { EntityDeletionDialog } = await import("../applications/EntityDeletionDialog.js");
        return EntityDeletionDialog.show(plan, options);
    }

    static previewCleanup(plan) {
        return { ...this.preview(plan.type, plan.id, {
            id: plan.journalId, name: plan.name, getFlag: () => plan.entity
        }), retainJournal: plan.retainJournal };
    }

    static async execute(plan, { deleteJournal = true } = {}) {
        this.requireGM();
        if (!plan || !LABELS[plan.type]) return false;
        if (this.#running.has(plan.id)) return this.#running.get(plan.id);
        const operation = this.#execute(plan, { deleteJournal });
        this.#running.set(plan.id, operation);
        try { return await operation; } finally { this.#running.delete(plan.id); }
    }

    static async #execute(plan, { deleteJournal }) {
        const pending = this.pending.get(plan.id);
        if (pending) {
            const remaining = this.previewCleanup(pending);
            if (remaining.fingerprint !== plan.fingerprint) throw new Error("Deletion impact changed. Review the updated summary and confirm again.");
            return this.cleanup(remaining);
        }
        const document = this.resolve(plan.type, plan.id);
        if (!document) return false;
        const current = this.preview(plan.type, plan.id, document);
        if (current.fingerprint !== plan.fingerprint) throw new Error("Deletion impact changed. Review the updated summary and confirm again.");
        if (deleteJournal) {
            const deleted = await document.delete({ [MODULE]: { entityDeletion: true } });
            if (!deleted) throw new Error("The object was not deleted. Its connections have been preserved.");
        }
        current.retainJournal = !deleteJournal;
        this.pending.set(plan.id, current);
        return this.cleanup(current);
    }

    static async cleanup(plan) {
        this.requireGM();
        const failures = [];
        for (const marker of plan.markers) {
            const scene = game.scenes.get(marker.sceneId), tile = scene?.tiles?.get(marker.documentId);
            if (!tile) continue;
            const target = NexusMarkerService.getMarkerRecord(tile)?.target;
            if (target?.kind !== "campaign-entity" || target.entityId !== plan.id || target.entityType !== plan.type) continue;
            try {
                if (!await NexusMarkerService.deleteMarker(tile, { notify: false, removeOwnerRef: !!plan.retainJournal, scene })
                    || scene.tiles.get(marker.documentId))
                    throw new Error("Marker could not be removed");
            }
            catch (error) { failures.push(`marker in ${marker.name}: ${error.message}`); }
        }
        if (plan.retainJournal && !failures.length) {
            try { await NexusMarkerService.deleteMarkersForTarget({ kind: "campaign-entity", entityType: plan.type, entityId: plan.id }); }
            catch (error) { failures.push(`marker references: ${error.message}`); }
        }
        try { await ConnectionStore.removeNode(plan.nodeId); } catch (error) { failures.push(`connections: ${error.message}`); }
        if (plan.type === "faction") {
            try { await FactionHierarchyService.removeForDeletedFaction(plan.nodeId); } catch (error) { failures.push(`organization hierarchy: ${error.message}`); }
        }
        try { await RegionPopulationProjectionCleanup.reconcileManagedDeletion({ entities: [{ id: plan.id, entityType: plan.type }] }); }
        catch (error) { failures.push(`population references: ${error.message}`); }
        try { CampaignEntityIndex.remove(plan.id); } catch (error) { failures.push(`entity index: ${error.message}`); }
        Hooks.callAll("augurNexusCampaignEntitiesChanged", { reason: `delete${{ npc: "Npc", faction: "Faction", ship: "Ship" }[plan.type]}`,
            entity: plan.entity, document: null, deletionCleanupHandled: true });
        if (failures.length) {
            this.pending.set(plan.id, plan);
            throw new Error(`Object deletion cleanup is incomplete: ${failures.join("; ")}. Retry cleanup to finish.`);
        }
        this.pending.delete(plan.id);
        return true;
    }

    static registerHooks() {
        if (this.#registered) return;
        this.#registered = true;
        Hooks.on("preDeleteJournalEntry", (document, options) => {
            const entity = document.getFlag(MODULE, "campaignEntity");
            if (!LABELS[entity?.type]) return;
            if (!game.user?.isGM) return false;
            if (options?.[MODULE]?.entityDeletion || options?.[MODULE]?.managedCascade) return;
            this.#nativePlans.set(document.id, this.preview(entity.type, entity.id, document));
        });
        Hooks.on("deleteJournalEntry", (document, options, userId) => {
            const entity = document.getFlag(MODULE, "campaignEntity");
            const snapshot = this.#nativePlans.get(document.id);
            this.#nativePlans.delete(document.id);
            if (!LABELS[entity?.type] || !game.user?.isGM || options?.[MODULE]?.entityDeletion || options?.[MODULE]?.managedCascade) return;
            if (game.user.id !== (game.users?.activeGM?.id || userId)) return;
            const plan = snapshot || this.preview(entity.type, entity.id, document);
            this.pending.set(plan.id, plan);
            void this.cleanup(plan).catch(async error => {
                ui.notifications.error(error.message);
                await this.confirm(plan.type, plan.id);
            });
        });
    }
}
