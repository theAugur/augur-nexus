import { ShipGeneratorRegistry } from "./ShipGeneratorRegistry.js";

const PATREON_URL = "https://www.patreon.com/TheAugur";

export class ShipCreationGateway {
    static async open(options = {}) {
        if (ShipGeneratorRegistry.list().length > 0) {
            const { ShipCreateDialog } = await import("../applications/ShipCreateDialog.js");
            return ShipCreateDialog.show(options);
        }
        return this.#showModuleRequiredDialog();
    }

    static async #showModuleRequiredDialog() {
        const safePatreonUrl = foundry.utils.escapeHTML(PATREON_URL);

        return foundry.applications.api.DialogV2.wait({
            window: {
                title: "Module Required",
                icon: "fa-solid fa-circle-info"
            },
            position: {
                width: 440
            },
            content: `
                <p>Creating <strong>ships</strong> in Nexus is powered by Augur content modules.</p>
                <p><strong>Augur: Sci-Fi</strong> provides ship generation and artwork. <strong>Augur: Fantasy</strong> is also available for fantasy people, organizations, and locations.</p>
                <p class="notes">Explore the available modules on <a href="${safePatreonUrl}" target="_blank" rel="noopener noreferrer">Patreon</a>.</p>
            `,
            buttons: [
                {
                    action: "close",
                    label: "Close",
                    icon: "fa-solid fa-xmark"
                },
                {
                    action: "viewModules",
                    label: "View Modules",
                    icon: "fa-solid fa-up-right-from-square",
                    default: true,
                    callback: () => {
                        window.open(PATREON_URL, "_blank", "noopener,noreferrer");
                    }
                }
            ]
        });
    }
}
