import { ShipGeneratorRegistry } from "./ShipGeneratorRegistry.js";
import { CampaignEntityCreation } from "./CampaignEntityCreation.js";
import { requestPremiumAccess, showGeneratorRequirement } from "../../access/PremiumAccess.js";

export class ShipCreationGateway {
    static async open(options = {}) {
        if (!await requestPremiumAccess("ship")) return null;
        if (!ShipGeneratorRegistry.list().length) return showGeneratorRequirement("ship", {
            moduleIds: ["augur-scifi"],
            createBlank: () => CampaignEntityCreation.open("ship", { ...options, generate: false })
        });
        const { ShipCreateDialog } = await import("../applications/ShipCreateDialog.js");
        return ShipCreateDialog.show(options);
    }
}
