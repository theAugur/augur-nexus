import { IdeologyCatalog } from "./IdeologyCatalog.js";
import { FactionEmblemProviderRegistry } from "./FactionEmblemProviderRegistry.js";

const at = (entity, path) => path.split(".").reduce((value, key) => value?.[key], entity);

export class FactionDetailGeneration {
    static rollBeliefs() {
        const topics = IdeologyCatalog.getTopics().filter(topic => topic.tenets.length);
        const selections = [];
        while (selections.length < 3 && topics.length) {
            const topic = topics.splice(Math.floor(Math.random() * topics.length), 1)[0];
            selections.push({ topicId: topic.id, tenetId: topic.tenets[Math.floor(Math.random() * topic.tenets.length)].id });
        }
        return { schemaVersion: IdeologyCatalog.SCHEMA_VERSION, selections };
    }

    static groups(entity, { freeOnly = false } = {}) {
        return [
            { id: "name", label: "Name", paths: ["display.name"], checked: entity?.display?.name === "New Organization", identity: true },
            { id: "emblem", label: "Emblem", paths: ["display.imageSrc"], checked: false, identity: true },
            { id: "beliefs", label: "Beliefs", paths: ["ideology.selections"] },
            { id: "type", label: "Type", paths: ["profile.type"] },
            { id: "method", label: "Method", paths: ["profile.method"] },
            { id: "drive", label: "Drive", paths: ["profile.drive"] },
            { id: "thread", label: "Current thread", paths: ["profile.action", "profile.theme", "profile.focus"] }
        ].map(group => {
            const linked = group.identity && !!entity?.projections?.actorUuid;
            const disabled = linked || (freeOnly && group.id !== "beliefs");
            return { ...group, disabled, checked: !disabled && group.checked !== false,
                lockIcon: linked ? "fa-link" : "fa-lock",
                reason: linked ? "Linked Actor controls name and emblem" : disabled ? "Augur: Fantasy and Augur: Sci-Fi add generation options for these details. You can also edit them manually." : "" };
        });
    }

    static values(entity, candidate, selection, options = {}) {
        const values = {};
        for (const group of this.groups(entity, options)) {
            if (group.disabled || !selection[group.id]) continue;
            for (const path of group.paths) {
                const value = at(candidate, path);
                if (value != null && value !== "") values[path] = foundry.utils.deepClone(value);
            }
            if (group.id === "emblem" && (candidate?.display?.imageSrc || FactionEmblemProviderRegistry.getPresentation(candidate))) {
                values["display.imageSrc"] = candidate.display?.imageSrc || "";
                Object.assign(values, FactionEmblemProviderRegistry.getReplacementValues(entity, candidate));
            }
        }
        return values;
    }

    static preview(entity, candidate, selection, options = {}) {
        const preview = { display: foundry.utils.deepClone(entity.display || {}) };
        for (const [path, value] of Object.entries(this.values(entity, candidate, selection, options))) foundry.utils.setProperty(preview, path, value);
        return preview;
    }
}
