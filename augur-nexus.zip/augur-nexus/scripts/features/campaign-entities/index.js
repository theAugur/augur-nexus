import { CampaignEntityIndex } from "./services/CampaignEntityIndex.js";
import { CampaignEntityActorBridge } from "./services/CampaignEntityActorBridge.js";
import { CampaignEntityPlacementSync } from "./services/CampaignEntityPlacementSync.js";
import { CampaignEntityDossierRefresh } from "./services/CampaignEntityDossierRefresh.js";
import { LocationSceneService } from "./services/LocationSceneService.js";
import { CoreLocationViewRegistration } from "./services/CoreLocationViewRegistration.js";

export function registerCampaignEntitiesFeature() {
    CoreLocationViewRegistration.register();
    CampaignEntityDossierRefresh.registerHooks();
    CampaignEntityActorBridge.registerHooks();
    CampaignEntityPlacementSync.registerHooks();
    LocationSceneService.registerHooks();

    Hooks.once("ready", async () => {
        try {
            await CampaignEntityIndex.initialize();
            Hooks.callAll("augurNexusCampaignEntitiesReady");
        } catch (err) {
            console.error("Augur Nexus | Failed to initialize campaign entities.", err);
        }
    });
}
