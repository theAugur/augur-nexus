import { CampaignEntityActorBridge } from "../services/CampaignEntityActorBridge.js";
import { renderDossierControls } from "./DossierHeaderControls.js";

export async function prepareNpcDossierFooter(entity) {
    const actor = await CampaignEntityActorBridge.getLinkedActor(entity);
    return {
        controlsHtml: game.user.isGM ? await renderDossierControls({ entity, showEdit: false, options: false }) : "",
        linkedActor: actor ? { name: actor.name || "Actor", uuid: actor.uuid || "", type: actor.type || "Actor" } : null,
        canOpenActor: !!actor
    };
}

export async function openNpcLinkedActor(entity) {
    if (!entity) return;
    const actor = await CampaignEntityActorBridge.getLinkedActor(entity);
    if (!actor) {
        ui.notifications.warn("No linked Actor was found for this person.");
        return;
    }
    actor.sheet?.render(true);
}

export async function manageNpcActorLink(entity, onChanged) {
    if (!game.user.isGM || !entity) return;
    const result = await CampaignEntityActorBridge.manageActorLink(entity);
    if (result?.action && result.action !== "cancel" && result.action !== "open") await onChanged?.();
    return result;
}
