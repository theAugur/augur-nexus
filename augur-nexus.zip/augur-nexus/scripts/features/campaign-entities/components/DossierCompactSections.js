let nextDossierId = 0;
const rememberedSections = new Map();

// Presentation-only state stays in this client session, independent of entity records.
export class DossierCompactSections {
    id = `dossier-compact-${++nextDossierId}`;
    #sections = new Map();
    #defaults;
    #sessionKey;
    #action;
    constructor({ sections = ["beliefs", "thread"], sessionKey = "", action = "toggleDossierCompactSection" } = {}) {
        this.#defaults = Object.fromEntries(sections.map(section => [section, true]));
        this.#sessionKey = sessionKey;
        this.#action = action;
        this.restore(rememberedSections.get(sessionKey));
    }
    context(entityId) {
        return { canToggleSections: true, compactSectionId: this.id, compactSectionAction: this.#action,
            compactSections: { ...this.#defaults, ...this.#sections.get(entityId) } };
    }
    async toggle(entityId, section, render, root) {
        if (!(section in this.#defaults)) return;
        const state = this.context(entityId).compactSections;
        state[section] = !state[section]; this.#sections.set(entityId, state);
        if (this.#sessionKey) rememberedSections.set(this.#sessionKey, this.snapshot());
        await render();
        root()?.querySelector(`[data-action="${this.#action}"][data-section="${section}"]`)?.focus();
    }
    snapshot() { return [...this.#sections].map(([id, sections]) => [id, { ...sections }]); }
    restore(state = []) { this.#sections = new Map(state.map(([id, sections]) => [id, { ...sections }])); }
}
