import { CampaignEntityVisibilityManager } from "../services/CampaignEntityVisibilityManager.js";
import { PlayerNpcVisibilityDialog } from "../../nexus/applications/PlayerNpcVisibilityDialog.js";
import { openHelp } from "../../../api/help.js";
import { openActionMenu } from "../../../api/ui.js";

export function entityDossierVisibility(entity) {
    const visible = CampaignEntityVisibilityManager.isVisibleToPlayers(entity);
    const inherited = CampaignEntityVisibilityManager.getPlayerVisibilityOverride(entity) === "inherit";
    return { label: `${visible ? "Visible to players" : "Hidden from players"}${inherited ? " (Global)" : ""}`, icon: visible ? "fas fa-eye" : "fas fa-eye-slash" };
}

export async function renderDossierControls({ entity, canEdit = game.user.isGM, showEdit = canEdit, compact = false, compactAction = "", popout = false, compactWithPopout = false, options = true, sceneControl = null, visibility = entity && entityDossierVisibility(entity) } = {}) {
    return foundry.applications.handlebars.renderTemplate("modules/augur-nexus/templates/campaign-entities/dossier-controls.hbs", {
        canEdit: showEdit, compact, compactAction: popout && !compactWithPopout ? "" : compactAction, popout, options: canEdit && options, visibility: game.user.isGM ? visibility : null, scene: sceneControl?.canOpen ? sceneControl : null
    });
}

const bound = new WeakSet();
export function bindDossierControls(root, handlers) {
    for (const button of root?.querySelectorAll?.("[data-dossier-control]") || []) {
        if (bound.has(button)) continue;
        const callback = handlers[button.dataset.dossierControl];
        if (!callback) continue;
        bound.add(button);
        button.addEventListener("click", event => {
            event.preventDefault(); event.stopPropagation();
            Promise.resolve().then(() => callback(button)).catch(error => ui.notifications.error(error.message || "The dossier action could not be completed."));
        });
    }
}

export function openEntityDossierVisibility(entity, anchor, onChanged) {
    if (!game.user.isGM || !entity) return;
    const current = CampaignEntityVisibilityManager.getPlayerVisibilityOverride(entity);
    const set = async value => { await CampaignEntityVisibilityManager.setPlayerVisibilityOverride(entity.id, entity.type, value); await onChanged?.(); };
    return openActionMenu({ anchor, className: "nexus-scene-player-access-menu", items: [
        ...[["inherit", "Global", "fas fa-layer-group"], ["show", "Yes", "fas fa-eye"], ["hide", "No", "fas fa-eye-slash"]].map(([id, label, icon]) => ({ id, label: `${label}${current === id ? " (Current)" : ""}`, icon, onSelect: () => set(id) })),
        { id: "change-global", label: "Change Global Setting...", icon: "fas fa-sliders", onSelect: () => PlayerNpcVisibilityDialog.show(entity.type) },
        { id: "player-visibility-info", label: "What's this?", icon: "fas fa-circle-info", onSelect: () => openHelp("augur-nexus:object-visibility") }
    ] });
}
