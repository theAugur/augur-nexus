import { CampaignEntityVisibilityManager } from "../services/CampaignEntityVisibilityManager.js";
import { CampaignEntityDisclosureManager } from "../services/CampaignEntityDisclosureManager.js";
import { DossierTabPreference } from "../../nexus/services/DossierTabPreference.js";

// Hosts supply workflows; command identity, order and permissions remain shared.
export function buildDossierActionItems({ entity, actions, extras = [], hasCover = false, dark = false, parentItem = null }) {
    const type = entity.type;
    const label = { npc: "Person", faction: "Organization", location: "Location" }[type];
    const item = (id, text, icon, action) => ({ id, label: text, icon, onSelect: actions[action] });
    const initial = type === "npc" ? [
        item("edit-npc", "Edit Person", "fas fa-sliders", "edit"),
        item("artwork", "Portraits & artwork", "fas fa-images", "artwork"),
        item("linked-actor", entity.projections?.actorUuid ? "Linked Actor" : "Link Actor", "fas fa-user-circle", "linkedActor")
    ] : type === "faction" ? [
        item("edit-faction", "Edit Organization", "fas fa-sliders", "edit"),
        ...(parentItem && game.user.isGM ? [parentItem] : []),
        item("linked-actor", entity.projections?.actorUuid ? "Linked Actor" : "Link Actor", "fas fa-user-circle", "linkedActor")
    ] : [
        item("rename", "Rename", "fas fa-pen", "rename"),
        item("edit", "Edit Location", "fas fa-sliders", "edit"),
        item("change-icon", "Change Icon", "fas fa-map-location-dot", "changeIcon"),
        item("open-journal", "Edit Journal", "fas fa-book-open", "journal")
    ];
    const items = [...initial, ...extras,
        item("default-dossier-tab", `Default Tab: ${DossierTabPreference.getTabLabel(DossierTabPreference.getDefaultTab(entity))}`, "fas fa-table-columns", "defaultTab"),
        ...(game.user.isGM && dark ? [item("change-cover", "Change Cover Image", "fas fa-image", "changeCover"), ...(hasCover ? [item("clear-cover", "Use World Cover", "fas fa-rotate-left", "clearCover")] : [])] : []),
        item(`player-${type}-visibility`, `Visible To Players: ${CampaignEntityVisibilityManager.getPlayerVisibilityLabel(entity)}`, CampaignEntityVisibilityManager.getPlayerVisibilityIcon(entity), "visibility"),
        ...(type === "location" ? [item("player-location-disclosure", `Player Details: ${CampaignEntityDisclosureManager.getPlayerDisclosureLabel(entity, { includeEffective: true })}`, CampaignEntityDisclosureManager.getPlayerDisclosureIcon(entity), "disclosure")] : []),
        { ...item("delete", `Delete ${label}`, "fas fa-skull-crossbones", "delete"), status: "Permanent", danger: true, className: "permanent-danger" }
    ];
    const playerActions = { npc: ["edit-npc", "artwork", "default-dossier-tab", "change-cover"], faction: ["edit-faction", "default-dossier-tab", "change-cover", "clear-cover"], location: ["rename", "edit", "change-icon", "default-dossier-tab", "change-cover", "clear-cover"] };
    return items.filter(entry => game.user.isGM || playerActions[type].includes(entry.id));
}
