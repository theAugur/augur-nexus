import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { DossierCompactSections } from "./DossierCompactSections.js";

// Each dossier owns presentation preferences; records and relationship projections remain authoritative.
export class NpcCompactProfile extends DossierCompactSections {
    constructor() { super({ action: "toggleNpcCompactSection" }); }
    context(entityId, life = {}) {
        const worldTies = { ...life };
        const groups = ["affiliations", "ships", "people", "places", "other"];
        for (const group of groups) worldTies[group] = [...(life[group] || [])].map(card => ({ ...card }));
        for (const card of [...(life.importance || []), ...(life.responsibilities || [])]) {
            const node = ConnectionStore.getNode(card.nodeId);
            const edge = card.edgeId ? ConnectionStore.getConnectionEdge?.(card.edgeId) : null;
            if (edge && ConnectionStore.canUserSeeConnection?.(edge) === false) continue;
            if (!node || node.missing || !ConnectionTargetResolver.canUserSeeNode(node)) continue;
            const group = groups.find(key => worldTies[key].some(entry => entry.nodeId === card.nodeId))
                || (node.kind === "nexus-entity" ? ({ faction: "affiliations", ship: "ships", npc: "people", location: "places" })[node.entityType]
                    : ["nexus-site", "nexus-scene"].includes(node.kind) ? "places" : "other") || "other";
            const index = worldTies[group].findIndex(entry => entry.nodeId === card.nodeId);
            const existing = worldTies[group][index] || {};
            const merged = { ...card, ...existing, role: group === "places" ? [...new Set([card.role, existing.role].filter(Boolean))].join(" · ") : card.role || existing.role, categoryIcon: card.icon || existing.categoryIcon || "fas fa-link" };
            if (index >= 0) worldTies[group][index] = merged;
            else worldTies[group].push(merged);
        }
        Object.assign(worldTies, {
            hasAffiliations: worldTies.affiliations.length > 0, hasShips: worldTies.ships.length > 0,
            hasPeople: worldTies.people.length > 0, hasPlaces: worldTies.places.length > 0, hasOther: worldTies.other.length > 0,
            worldTieCount: groups.reduce((sum, key) => sum + worldTies[key].length, 0)
        });
        worldTies.hasWorldTieEntities = worldTies.worldTieCount > 0;
        return { worldTies, ...super.context(entityId) };
    }
}
