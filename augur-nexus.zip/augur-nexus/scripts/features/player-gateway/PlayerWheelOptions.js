import { requirePremiumAccess } from "../access/PremiumAccess.js";
const MODULE_ID = "augur-nexus";

export const PLAYER_WHEEL_OPTIONS = Object.freeze({
    sheet: "Character sheet", dossier: "Nexus character dossier", contacts: "Contacts", quests: "Quests", holdings: "Holdings",
    organization: "Assigned organization", ship: "Assigned ship", mainQuest: "Main quest", hotkeys: "Hotkey ring"
});

export const PLAYER_WHEEL_OPTION_GROUPS = Object.freeze([
    { label: "Character", keys: ["sheet", "dossier", "hotkeys"] },
    { label: "Campaign", keys: ["contacts", "holdings", "quests", "workspace"] },
    { label: "Assigned shortcuts", keys: ["ship", "organization", "mainQuest"] }
]);

export function groupPlayerWheelOptions(rows) {
    const byKey = new Map(rows.map(row => [row.key, row]));
    return PLAYER_WHEEL_OPTION_GROUPS.map(group => ({ label: group.label, rows: group.keys.map(key => byKey.get(key)).filter(Boolean) }))
        .filter(group => group.rows.length);
}

export function getPlayerWheelOptions() {
    const saved = game.settings.get(MODULE_ID, "playerGatewayOptions") || {};
    return Object.fromEntries(Object.keys(PLAYER_WHEEL_OPTIONS).map(key => [key, saved[key] !== false]));
}

export async function setPlayerWheelOption(key, enabled) {
    requirePremiumAccess("playerWheel");
    if (!game.user.isGM) throw new Error("Only the GM can configure the Player Wheel.");
    if (!Object.hasOwn(PLAYER_WHEEL_OPTIONS, key)) throw new Error("Unknown Player Wheel option.");
    await game.settings.set(MODULE_ID, "playerGatewayOptions", { ...getPlayerWheelOptions(), [key]: !!enabled });
}
