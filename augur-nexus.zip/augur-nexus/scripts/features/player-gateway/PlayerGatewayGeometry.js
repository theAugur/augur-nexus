export const PLAYER_GATEWAY_GEOMETRY = Object.freeze({
    size: 292, compactSize: 236, collapsedSize: 72, portraitSize: 60, buttonSize: 38, pinSize: 38,
    center: 146, pinRadius: 124, hotkeyOrbitMargin: 12, innerRadius: 78, minimumInnerRadius: 60, clearance: 4, badgeSize: 16, badgeOverflow: 2, collapsedInset: 6,
    character: { left: 116, top: 116, width: 60, height: 60, portraitOffset: 0 },
    actionAngles: [-90, -54, -18, 18, 54, 90, 202, 236],
    characterAngles: { sheet: 130, story: 165 }
});

const geometryCache = new Map();

export function gatewayOrbitPosition(angle, center = PLAYER_GATEWAY_GEOMETRY.center, radius = PLAYER_GATEWAY_GEOMETRY.innerRadius, size = PLAYER_GATEWAY_GEOMETRY.buttonSize) {
    const radians = angle * Math.PI / 180;
    return { left: Math.round(center + radius * Math.cos(radians) - size / 2),
        top: Math.round(center + radius * Math.sin(radians) - size / 2) };
}

export function gatewayPinPosition(slot, geometry = PLAYER_GATEWAY_GEOMETRY) {
    return gatewayOrbitPosition(-90 + slot * 36, geometry.center, geometry.pinRadius, PLAYER_GATEWAY_GEOMETRY.pinSize);
}

function point(angle, radius, size) {
    const position = gatewayOrbitPosition(angle, 0, radius, size);
    return { x: position.left + size / 2, y: position.top + size / 2, radius: size / 2 };
}
function separated(a, b) { return Math.hypot(a.x - b.x, a.y - b.y) >= a.radius + b.radius + PLAYER_GATEWAY_GEOMETRY.clearance; }
function fitInner(angles) {
    const g = PLAYER_GATEWAY_GEOMETRY, portrait = { x: 0, y: 0, radius: g.portraitSize / 2 };
    for (let radius = g.minimumInnerRadius; radius <= g.innerRadius; radius++) {
        const buttons = angles.map(angle => point(angle, radius, g.buttonSize));
        if (buttons.every((button, index) => separated(button, portrait) && buttons.slice(index + 1).every(other => separated(button, other)))) return radius;
    }
    return g.innerRadius;
}
function fitPins(angles, innerRadius) {
    const g = PLAYER_GATEWAY_GEOMETRY, buttons = angles.map(angle => point(angle, innerRadius, g.buttonSize));
    const minimum = Math.ceil((g.pinSize + g.clearance) / (2 * Math.sin(Math.PI / 10)));
    for (let radius = minimum; radius <= g.pinRadius; radius++) {
        const pins = Array.from({ length: 10 }, (_, slot) => point(-90 + slot * 36, radius, g.pinSize));
        const badgeOffset = g.pinSize / 2 + g.badgeOverflow - g.badgeSize / 2;
        const badges = pins.map(pin => ({ x: pin.x + badgeOffset, y: pin.y + badgeOffset, radius: g.badgeSize / 2 }));
        if (pins.every((pin, index) => buttons.every(button => separated(pin, button) && separated(badges[index], button))
            && pins.slice(index + 1).every((other, offset) => separated(pin, other)
                && separated(badges[index], other) && separated(pin, badges[index + 1 + offset])
                && separated(badges[index], badges[index + 1 + offset])))) return radius;
    }
    return g.pinRadius;
}

export function gatewayGeometry({ collapsed = false, hotkeysExpanded = true, angles } = {}) {
    const g = PLAYER_GATEWAY_GEOMETRY;
    const key = JSON.stringify([collapsed, hotkeysExpanded, angles]);
    if (geometryCache.has(key)) return geometryCache.get(key);
    // Without a visible-button projection, use the existing conservative bounds.
    const innerRadius = angles ? fitInner(angles) : g.innerRadius;
    const pinRadius = (angles ? fitPins(angles, innerRadius) : g.pinRadius) + g.hotkeyOrbitMargin;
    const size = collapsed ? g.collapsedSize : hotkeysExpanded ? 2 * (pinRadius + g.pinSize / 2 + 3) : 2 * (innerRadius + g.buttonSize / 2 + 21);
    const geometry = Object.freeze({ size, center: size / 2, portrait: size / 2 - g.portraitSize / 2, innerRadius, pinRadius });
    if (geometryCache.size >= 128) geometryCache.clear();
    geometryCache.set(key, geometry);
    return geometry;
}

// The frameless application's placement and its CSS use the same dimensions.
export function gatewayGeometryStyle(options = {}) {
    const g = PLAYER_GATEWAY_GEOMETRY, layout = gatewayGeometry(options);
    const values = { size: layout.size, "collapsed-size": g.collapsedSize, "portrait-size": g.portraitSize,
        "badge-size": g.badgeSize, "badge-overflow": g.badgeOverflow, "button-size": g.buttonSize, "pin-size": g.pinSize, "collapsed-inset": g.collapsedInset,
        "character-left": layout.portrait, "character-top": layout.portrait, "character-width": g.portraitSize,
        "character-height": g.portraitSize, "portrait-offset": 0,
        "orbit-left": layout.center - layout.innerRadius, "orbit-top": layout.center - layout.innerRadius, "orbit-size": layout.innerRadius * 2,
        "pin-orbit-offset": layout.center - layout.pinRadius, "pin-orbit-size": layout.pinRadius * 2,
        "hotkeys-left": layout.center - g.buttonSize / 2, "hotkeys-top": layout.center - layout.innerRadius - g.buttonSize / 2,
        "preview-left": layout.center - 35, "preview-top": layout.center + 33, "preview-width": 70 };
    return Object.entries(values).map(([name, value]) => `--pg-${name}:${value}px`).join(";");
}
