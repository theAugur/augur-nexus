import { getPlayerSetupData } from "../../api/player-context.js";
import { openPlayerSetup } from "../../api/player-gateway.js";

const dossiers = new Set();
const report = error => ui.notifications.error(error.message || "Player action unavailable.");

export function registerGatewayDossiers() {
    // Render hooks expose entity identity without coupling the gateway to dossier implementation classes.
    for (const [className, field] of [["NpcDossier", "npc"], ["ShipDossier", "ship"], ["FactionDossier", "faction"], ["LocationDossier", "location"]]) {
        Hooks.on(`render${className}`, (app, _element, context) => {
            app.playerGatewayEntityId = context?.[field]?.id || "";
            dossiers.add(app);
        });
        Hooks.on(`close${className}`, app => dossiers.delete(app));
        Hooks.on(`getHeaderControls${className}`, (app, controls) => {
            if (!game.user.isGM) return;
            app.options.actions.augurAssignPlayer = () => {
                const entry = getPlayerSetupData().entities.find(entity => entity.id === app.playerGatewayEntityId);
                void openPlayerSetup({ entityUuid: entry?.uuid || "" }).catch(report);
            };
            controls.push({ action: "augurAssignPlayer", icon: "fas fa-user-plus", label: "Assign to player…" });
        });
    }
    Hooks.on("augurNexusPlayerContextChanged", () => {
        for (const app of dossiers) if (app.rendered) app.render({ parts: ["content"] });
    });
}
