import { clampFloatingPosition, startFloatingMove, moveFloatingControl, endFloatingMove } from "../../support/ui/FloatingControlMovement.js";
import { getPlayerContext, openPlayerCharacterSheet } from "../../api/player-context.js";
import { openGatewayEntity, openPlayerPanel, openPlayerWorkspace, openPlayerWheelSettings, canUseWorkspace } from "../../api/player-gateway.js";
import { openQuests, openQuest, getMainQuest } from "../../api/quests.js";
import { getGatewayPins, getGatewayLayoutId, requireGatewayLayout, updateGatewayPin, resolveGatewayDrop, PIN_LIMIT } from "./PlayerGatewayPins.js";
import { activatePlayerShortcut } from "../../api/player-shortcuts.js";
import { canCreateGatewayMacro, createGatewayDropMacro } from "./PlayerGatewayHotbar.js";
import { prepareNexusThemeSurface } from "../../api/appearance.js";

import { gatewayPortraitHint, gatewayInnerLayout, openGatewayPortrait } from "./PlayerGatewayNavigation.js";
import { getEffectivePlayerWheelOptions } from "./PlayerWheelPreferences.js";
import { PLAYER_GATEWAY_GEOMETRY, gatewayGeometry, gatewayGeometryStyle } from "./PlayerGatewayGeometry.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const MODULE_ID = "augur-nexus";
const icons = { npc: "fa-user", faction: "fa-flag", ship: "fa-shuttle-space", location: "fa-location-dot", macro: "fa-bolt", document: "fa-book-open" };

export class PlayerGatewayApplication extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
        id: "nexus-player-home", tag: "div", classes: ["nexus-player-wheel"],
        window: { frame: false, positioned: true, minimizable: false, resizable: false }, position: { width: PLAYER_GATEWAY_GEOMETRY.size, height: PLAYER_GATEWAY_GEOMETRY.size },
        actions: Object.fromEntries(["sheet", "story", "workspace", "section", "toggleWheel", "toggleHotkeys", "openEntity", "openMainQuest", "openPin", "unpin", "movePin"].map(key => [key, { handler: PlayerGatewayApplication.action, buttons: [0, 2] }]))
    };
    static PARTS = { body: { template: "modules/augur-nexus/templates/player-gateway/home.hbs" } };
    constructor({ userId = game.user.id, onClose, ...options } = {}) {
        super(options); this.userId = userId; this.onClose = onClose;
        this.collapsed = userId === game.user.id && !!game.settings.get(MODULE_ID, "playerGatewayCollapsed");
        this.hotkeysExpanded = game.settings.get(MODULE_ID, "playerGatewayHotkeysExpanded") !== false;
    }

    async _prepareContext() {
        const context = getPlayerContext(this.userId);
        const layoutId = getGatewayLayoutId(this.userId);
        const main = await getMainQuest({ userId: this.userId });
        context.mainQuest = main && { id: main.id, name: main.title, image: main.image || main.goals?.[0]?.target?.image || main.giver?.image || "" };
        const options = getEffectivePlayerWheelOptions(this.userId);
        const showHotkeys = options.hotkeys && this.hotkeysExpanded;
        const layout = gatewayInnerLayout(context, { options, workspaceAllowed: options.workspace && canUseWorkspace(), collapsed: this.collapsed, hotkeysExpanded: this.hotkeysExpanded });
        this.orbitAngles = layout.angles;
        const geometry = layout.geometry;
        const pins = getGatewayPins(this.userId, geometry);
        return { ...context, workspaceAllowed: options.workspace && canUseWorkspace(), layoutId, primaries: layout.primaries, wheelActions: layout.actions, characterActions: layout.characterActions, innerPositions: { ...layout.positions, ...Object.fromEntries(pins.map(pin => [`pin-${pin.slot}`, pin])) },
            footprintSize: geometry.size, hotkeysEnabled: options.hotkeys, hotkeysExpanded: this.hotkeysExpanded, showHotkeys, geometryStyle: gatewayGeometryStyle({ collapsed: this.collapsed, hotkeysExpanded: showHotkeys, angles: layout.angles }),
            characterHint: `${this.collapsed ? "Expand wheel" : "Collapse to portrait"} · Right-click: Wheel settings | Drag to move · arrow keys when focused`, isGM: game.user.isGM, collapsed: this.collapsed,
            name: context.character?.name || context.actor?.name || context.userName,
            portrait: context.character?.image || context.actor?.image || "icons/svg/mystery-man.svg",
            pins: pins.map(pin => ({ ...pin, available: !!pin.entry,
                label: pin.entry?.name || (pin.uuid ? "Unavailable shortcut" : "Add a shortcut"),
                hint: pin.entry ? (pin.native ? pin.entry.hint : gatewayPortraitHint(pin.entry.name, { hasActor: !!pin.entry.actorUuid, preview: context.preview })) : "Unavailable shortcut",
                icon: icons[pin.entry?.type] || "fa-thumbtack", previous: pin.slot - 1, next: pin.slot + 1,
                canPrevious: pin.slot > 0, canNext: pin.slot < PIN_LIMIT - 1 })) };
    }
    refresh() {
        const workspace = this.element?.querySelector?.('[data-action="workspace"]');
        if (workspace) { workspace.disabled = !canUseWorkspace(); workspace.title = workspace.disabled ? "Campaign Nexus disabled by the GM" : "Campaign Nexus � browse campaign entries available to you"; }
        // Appearance can change during a drag; retint without replacing its live controls.
        if (this.element) this.element.dataset.nexusTheme = prepareNexusThemeSurface().id;
        if (this.layoutId !== getGatewayLayoutId(this.userId)) {
            this.dropRequests?.clear(); this.stopReadingDrag?.(); this.dropData = null; this.dropUuid = null;
        }
        if (this.drag || this.dropData) { this.refreshPending = true; return; }
        if (this.rendered) void this.render({ force: false }).catch(error => console.error("Nexus | Wheel refresh", error));
    }
    _onRender(context, options) {
        super._onRender(context, options);
        this.layoutId = context.layoutId;
        const shift = ((context.footprintSize ?? 0) - (this.renderedFootprintSize ?? context.footprintSize ?? 0)) / 2;
        const target = clampFloatingPosition(this.position.left - shift, this.position.top - shift, context.footprintSize || this.geometry.size, context.footprintSize || this.geometry.size, window.innerWidth, window.innerHeight);
        const canAnimateResize = !shift || this.footprintSize !== context.footprintSize && target.left === this.position.left - shift && target.top === this.position.top - shift;
        if (canAnimateResize && !this.collapsed && !this.previousCollapsed && this.innerPositions && !this.drag && !window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches) {
            for (const [key, position] of Object.entries(context.innerPositions)) {
                const previous = this.innerPositions[key];
                if (!previous || (previous.left === position.left && previous.top === position.top)) continue;
                this.element.querySelector('[data-inner-key="' + key + '"]')?.animate([
                    { transform: 'translate(' + (previous.left - position.left + shift) + 'px, ' + (previous.top - position.top + shift) + 'px)' },
                    { transform: "translate(0, 0)" }
                ], { duration: 180, easing: "ease-out" });
            }
        }
        this.innerPositions = context.innerPositions; this.renderedFootprintSize = context.footprintSize; this.previousCollapsed = this.collapsed;
        // Theme selection is paused; use Whispering stone even with a saved tech preference.
        this.element.dataset.theme = "arcane";
        this.element.dataset.nexusTheme = prepareNexusThemeSurface().id;
        this.element.classList.toggle("is-collapsed", this.collapsed);
        this.interactions?.abort(); this.interactions = new AbortController();
        const signal = this.interactions.signal;
        this.element.addEventListener("contextmenu", event => {
            if (event.target.closest('[data-action="toggleWheel"]')) event.preventDefault();
        }, { signal });
        this.element.addEventListener("dragstart", event => {
            const pin = event.target.closest('[data-action="openPin"]');
            if (!pin) return;
            if (context.preview || pin.disabled || context.layoutId !== getGatewayLayoutId(this.userId)) { event.preventDefault(); return; }
            event.dataTransfer.setData("text/plain", JSON.stringify({ type: "AugurPlayerShortcut", uuid: pin.dataset.uuid, userId: this.userId, layoutId: context.layoutId, slot: Number(pin.dataset.slot) }));
            event.dataTransfer.effectAllowed = "copyMove";
        }, { signal });
        window.addEventListener("dragstart", event => {
            if (context.preview || this.collapsed || !context.showHotkeys) return;
            this.stopReadingDrag?.();
            // Core DragDrop stops bubbling after writing its payload. Read after existing handlers
            // on the event path, while dragstart still permits access to DataTransfer.
            const path = event.composedPath();
            const read = () => {
                if (event.defaultPrevented) return;
                const data = this.readDrop(event);
                if (!data) return;
                this.dropData = data;
                this.dropUuid = resolveGatewayDrop(data, getPlayerContext().entries) || canCreateGatewayMacro(data);
            };
            for (const target of path) target.addEventListener("dragstart", read, { once: true, signal });
            this.stopReadingDrag = () => { for (const target of path) target.removeEventListener("dragstart", read); this.stopReadingDrag = null; };
        }, { capture: true, signal });
        window.addEventListener("dragend", () => this.clearDrop(), { signal });
        window.addEventListener("drop", () => this.clearDrop(), { signal });
        // A frameless application has no native drag handle. These listeners handle movement and drops only.
        this.element.addEventListener("pointerdown", event => this.startMove(event), { signal });
        this.element.addEventListener("pointermove", event => this.move(event), { signal });
        this.element.addEventListener("pointerup", event => this.endMove(event), { signal });
        this.element.addEventListener("pointercancel", event => this.endMove(event, true), { signal });
        this.element.addEventListener("lostpointercapture", event => { if (this.drag) this.endMove(event, true); }, { signal });
        // Pointer release produces a click too. Consume it after movement, before ApplicationV2 actions.
        this.element.addEventListener("click", event => {
            if (this.suppressPortraitClick && event.target.closest('[data-action="toggleWheel"]') && event.detail !== 0) {
                event.preventDefault(); event.stopImmediatePropagation(); this.suppressPortraitClick = false;
            }
        }, { capture: true, signal });
        this.element.addEventListener("keydown", event => {
            if (event.key === "Escape") { this.element.querySelectorAll("details[open]").forEach(menu => menu.open = false); event.stopPropagation(); return; }
            if (event.target.dataset.action !== "toggleWheel") return;
            const delta = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[event.key];
            if (!delta) return;
            event.preventDefault(); event.stopPropagation();
            const step = event.shiftKey ? 30 : 10;
            this.place(this.position.left + delta[0] * step, this.position.top + delta[1] * step);
            void this.rememberPosition();
        }, { signal });
        this.element.addEventListener("dragover", event => {
            if (context.preview || this.collapsed || !context.showHotkeys) return;
            event.preventDefault(); event.stopPropagation();
            const target = event.target.closest("[data-pin-slot]");
            const accepted = !!target && !!this.dropUuid;
            event.dataTransfer.dropEffect = accepted ? (this.dropData?.type === "AugurPlayerShortcut" ? "move" : "copy") : "none";
            this.element.querySelectorAll(".pg-pin.is-drop-target").forEach(pin => pin.classList.remove("is-drop-target"));
            if (accepted) target.classList.add("is-drop-target");
        }, { signal });
        this.element.addEventListener("dragleave", event => {
            const pin = event.target.closest("[data-pin-slot]");
            if (pin && !pin.contains(event.relatedTarget)) pin.classList.remove("is-drop-target");
        }, { signal });
        this.element.addEventListener("drop", async event => {
            event.preventDefault(); event.stopPropagation();
            if (context.preview || this.collapsed || !context.showHotkeys) return;
            try {
                const data = this.readDrop(event);
                const target = event.target.closest("[data-pin-slot]");
                if (!target) throw new Error("Drop onto an outer shortcut slot.");
                await this.pinDrop(data, Number(target.dataset.pinSlot));
            } catch (error) { ui.notifications.warn(error.message); }
            finally { this.clearDrop(); }
        }, { signal });
        window.addEventListener("resize", () => { this.place(this.position.left, this.position.top); void this.rememberPosition(); }, { signal });
        if (!this.placed) {
            this.placed = true;
            const saved = game.settings.get(MODULE_ID, "playerGatewayPosition") || {};
            this.place(saved.left ?? 75, saved.top ?? this.defaultTop());
        } else this.resizeForGeometry();
    }
    get geometry() {
        return gatewayGeometry({ collapsed: this.collapsed, hotkeysExpanded: getEffectivePlayerWheelOptions(this.userId).hotkeys && this.hotkeysExpanded, angles: this.orbitAngles });
    }
    resizeForGeometry() {
        const size = this.geometry.size, previous = this.footprintSize ?? this.position.width ?? PLAYER_GATEWAY_GEOMETRY.size;
        if (previous === size) return;
        this.place(this.position.left + (previous - size) / 2, this.position.top + (previous - size) / 2);
        void this.rememberPosition();
    }
    defaultTop() {
        const players = document.querySelector("#players")?.getBoundingClientRect();
        const size = this.geometry.size;
        return Math.max(8, Math.min(window.innerHeight - size - 8, (players?.top ?? window.innerHeight - 110) - size - 12));
    }
    async pinDrop(data, slot) {
        if (this.userId !== game.user.id) throw new Error("Shortcuts cannot be changed from a player preview.");
        if (!Number.isInteger(slot) || slot < 0 || slot >= PIN_LIMIT) throw new Error("Choose a valid shortcut slot.");
        const layoutId = this.layoutId;
        requireGatewayLayout(layoutId, this.userId);
        const entries = getPlayerContext().entries;
        let uuid = resolveGatewayDrop(data, entries);
        this.dropRequests ??= new Map();
        const requestKey = `${layoutId}:${slot}`;
        const ticket = Symbol(); this.dropRequests.set(requestKey, ticket);
        try {
            const expectedUuid = getGatewayPins(this.userId)[slot].uuid;
            if (data?.type !== "AugurPlayerShortcut" && !entries.some(entry => entry.uuid === uuid)) {
                uuid = await createGatewayDropMacro(data, { userId: this.userId });
            }
            if (this.dropRequests.get(requestKey) !== ticket) return;
            requireGatewayLayout(layoutId, this.userId);
            if (!uuid) throw new Error("Drop an accessible Nexus entry or hotbar action onto a slot.");
            const change = data.type === "AugurPlayerShortcut"
                ? { slot: data.slot, toSlot: slot, expectedUuid: uuid }
                : { uuid, slot, expectedUuid };
            await updateGatewayPin({ ...change, layoutId });
        } finally {
            if (this.dropRequests.get(requestKey) === ticket) this.dropRequests.delete(requestKey);
        }
    }
    readDrop(event) {
        try { return JSON.parse(event.dataTransfer.getData("text/plain") || event.dataTransfer.getData("application/json") || "null"); }
        catch { return null; }
    }
    clearDrop() {
        this.stopReadingDrag?.();
        this.dropData = null; this.dropUuid = null;
        this.element.querySelectorAll(".pg-pin.is-drop-target").forEach(pin => pin.classList.remove("is-drop-target"));
        if (this.refreshPending) { this.refreshPending = false; this.refresh(); }
    }
    place(left, top) {
        const width = this.geometry.size, height = width;
        this.footprintSize = width;
        this.setPosition(clampFloatingPosition(left, top, width, height, window.innerWidth, window.innerHeight));
    }
    startMove(event) { startFloatingMove(this, event, "toggleWheel"); }
    move(event) { moveFloatingControl(this, event); }
    endMove(event, cancelled = false) {
        if (!endFloatingMove(this, event, cancelled)) return;
        if (this.refreshPending) {
            this.refreshPending = false;
            // Wait for the release click to be consumed before replacing its target.
            this.refreshTimer = setTimeout(() => this.refresh(), 0);
        }
    }
    async toggleCollapsed() {
        this.collapsed = !this.collapsed;
        // Keep old bounds until _onRender applies the new portrait offset and centered bounds together.
        await this.render({ force: true });
        if (this.userId === game.user.id) await game.settings.set(MODULE_ID, "playerGatewayCollapsed", this.collapsed);
        await this.rememberPosition();
        this.element.querySelector('[data-action="toggleWheel"]')?.focus({ preventScroll: true });
    }
    async toggleHotkeys() {
        if (!getEffectivePlayerWheelOptions(this.userId).hotkeys) return;
        this.hotkeysExpanded = !this.hotkeysExpanded;
        await this.render({ force: true });
        if (this.userId === game.user.id) await game.settings.set(MODULE_ID, "playerGatewayHotkeysExpanded", this.hotkeysExpanded);
        await this.rememberPosition();
        this.element.querySelector('[data-action="toggleHotkeys"]')?.focus({ preventScroll: true });
    }
    async rememberPosition() {
        if (this.userId === game.user.id) await game.settings.set(MODULE_ID, "playerGatewayPosition", { left: this.position.left, top: this.position.top });
    }
    async close(options = {}) {
        this.dropRequests?.clear();
        this.stopReadingDrag?.(); this.interactions?.abort(); clearTimeout(this.refreshTimer); this.drag = null; this.dropData = null; await this.rememberPosition();
        // The floating wheel has no window-collapse animation to wait for.
        const result = await super.close({ ...options, animate: false });
        this.onClose?.();
        return result;
    }
    static async action(event, button) {
        event.preventDefault(); event.stopPropagation();
        const action = button.dataset.action;
        if (event.button === 2 && !["openEntity", "openPin", "toggleWheel"].includes(action)) return;
        this.element.querySelectorAll("details[open]").forEach(menu => menu.open = false);
        try {
            const preview = this.userId !== game.user.id;
            if (["unpin", "movePin"].includes(action) && preview) return;
            if (["openPin", "unpin", "movePin"].includes(action)) requireGatewayLayout(this.layoutId, this.userId);
            if (action === "toggleWheel") {
                if (event.button === 2) await openPlayerWheelSettings({ userId: this.userId });
                else await this.toggleCollapsed();
            }
            else if (action === "toggleHotkeys") await this.toggleHotkeys();
            else if (action === "openMainQuest") {
                const quest = await getMainQuest({ userId: this.userId });
                if (quest && !preview) await openQuest(quest.id);
            }
            else if (action === "openEntity") await openGatewayPortrait({ uuid: button.dataset.uuid, dossier: event.button === 2, userId: this.userId });
            else if (action === "openPin") {
                const pin = getGatewayPins(this.userId).find(pin => pin.slot === Number(button.dataset.slot) && pin.uuid === button.dataset.uuid);
                if (!pin?.entry) throw new Error("This shortcut is no longer available to you.");
                if (pin.native) await activatePlayerShortcut(pin.uuid, { userId: this.userId, alternate: event.button === 2 });
                else await openGatewayPortrait({ uuid: pin.uuid, dossier: event.button === 2, userId: this.userId });
            }
            else if (action === "sheet") { if (!preview) await openPlayerCharacterSheet(); }
            else if (action === "workspace") await openPlayerWorkspace();
            else if (action === "story") {
                const character = getPlayerContext(this.userId).character;
                if (character) await openGatewayEntity(character.uuid, { userId: this.userId });
                else await openPlayerPanel({ userId: this.userId, section: "profile" });
            } else if (action === "section") {
                if (button.dataset.section === "quests") await openQuests();
                else await openPlayerPanel({ userId: this.userId, section: button.dataset.section });
            }
            else if (action === "unpin") await updateGatewayPin({ uuid: button.dataset.uuid, slot: Number(button.dataset.slot), remove: true, layoutId: this.layoutId });
            else if (action === "movePin") await updateGatewayPin({ slot: Number(button.dataset.slot), toSlot: Number(button.dataset.to), expectedUuid: button.dataset.uuid, layoutId: this.layoutId });
        } catch (error) { ui.notifications.warn(error.message || "That destination is unavailable."); }
    }
}

