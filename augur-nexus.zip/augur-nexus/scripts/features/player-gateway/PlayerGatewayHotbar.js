import { describePlayerShortcut } from "../../api/player-shortcuts.js";

// V13 hotbarDrop is synchronous, but systems commonly create and assign a Macro asynchronously.
// Route only our virtual slot assignments; real slots always retain Foundry's original behavior.
const users = new Map();
const FIRST_SLOT = -100000;
let installed = false;
const TIMEOUT = 15000;

function installAssignmentBridge() {
    if (installed) return;
    const prototype = getDocumentClass("User").prototype;
    const original = prototype.assignHotbarMacro;
    prototype.assignHotbarMacro = function (macro, slot, ...args) {
        const state = users.get(this.id), number = Number(slot);
        if (!state || !Number.isInteger(number) || number > FIRST_SLOT || number <= state.nextSlot) {
            return original.call(this, macro, slot, ...args);
        }
        // The issued range absorbs late assignments without retaining completed requests.
        state.pending.get(number)?.(macro);
        return Promise.resolve(this);
    };
    installed = true;
}

function canAccessCompendiumDrop(data, user = game.user) {
    const parsed = foundry.utils.parseUuid(data.uuid);
    if (!parsed?.id || !parsed.collection || (data.type && data.type !== parsed.type)) return false;
    return !!parsed.collection.testUserPermission(user, parsed.type === "Macro" ? "LIMITED" : "OBSERVER");
}

function canUseDropDocument(doc, user = game.user) {
    const journal = doc?.documentName === "JournalEntryPage" ? doc.parent : doc;
    if (journal?.getFlag?.("augur-nexus", "campaignEntity")) return false;
    return !!doc?.testUserPermission?.(user, doc.documentName === "Macro" ? "LIMITED" : "OBSERVER");
}

export function canCreateGatewayMacro(data) {
    if (!data || typeof data !== "object" || Array.isArray(data) || !Object.keys(data).length) return false;
    if (data.type !== undefined && typeof data.type !== "string") return false;
    if (data.type === "AugurPlayerShortcut" || data.type === "AugurNexusEntity" || data.kind === "nexus-entity" || data.entityId) return false;
    if (!data.uuid) return true; // Systems also supply non-document payloads, such as skills.
    try {
        if (typeof data.uuid !== "string") return false;
        // A synchronous compendium lookup may be only an index row, not a permission-bearing Document.
        if (data.uuid.startsWith("Compendium.")) return canAccessCompendiumDrop(data);
        return canUseDropDocument(fromUuidSync(data.uuid));
    } catch { return false; }
}

/** Let the installed system/modules build their normal hotbar Macro, without touching any real slot. */
export async function createGatewayDropMacro(data, { userId = game.user.id } = {}) {
    if (userId !== game.user.id) throw new Error("Shortcuts cannot be created from a player preview.");
    if (!canCreateGatewayMacro(data)) throw new Error("This drop is not available to you.");
    // Existing world macros already are the hotbar action. Never import commands from the payload.
    if (data.type === "Macro" && describePlayerShortcut(data.uuid)?.documentName === "Macro") return data.uuid;
    if (!ui.hotbar) throw new Error("The hotbar is not ready yet.");
    const user = game.user;
    const payload = foundry.utils.deepClone(data);
    if (payload.uuid?.startsWith("Compendium.")) {
        const doc = await fromUuid(payload.uuid);
        if (game.user !== user || !canAccessCompendiumDrop(payload, user) || !canUseDropDocument(doc, user)
            || (payload.type && doc.documentName !== payload.type)) throw new Error("This drop is not available to you.");
    }
    // Copy from the hotbar; never move the original slot.
    delete payload.slot;
    installAssignmentBridge();
    if (!users.has(user.id)) users.set(user.id, { nextSlot: FIRST_SLOT, pending: new Map() });
    const state = users.get(user.id), slot = state.nextSlot--;
    let settle;
    const result = new Promise((resolve, reject) => { settle = { resolve, reject }; });
    const finish = (macro, error) => {
        if (!settle) return;
        clearTimeout(timer);
        const pending = settle; settle = null;
        state.pending.delete(slot);
        if (error) pending.reject(error);
        else if (game.user !== user || macro?.documentName !== "Macro" || !describePlayerShortcut(macro.uuid)) {
            pending.reject(new Error("The hotbar did not provide an accessible macro."));
        } else pending.resolve(macro.uuid);
    };
    const timer = setTimeout(() => finish(null, new Error("This drop handler did not return a macro. Drop it on the hotbar, then drag that macro to the wheel.")), TIMEOUT);
    state.pending.set(slot, macro => finish(macro));
    void (async () => {
        const handled = Hooks.call("hotbarDrop", ui.hotbar, payload, slot) === false;
        if (!handled && settle) {
            // These are the same factory methods called by V13 Hotbar's native drop handler.
            const cls = getDocumentClass(payload.type);
            const doc = await cls?.fromDropData(payload);
            if (!doc) throw new Error("This system did not create an action for that drop. Try dragging its hotbar macro instead.");
            let macro;
            if (payload.type === "Macro") macro = game.macros.has(doc.id) ? doc : await cls.create(doc.toObject());
            else if (payload.type === "RollTable") macro = await ui.hotbar._createRollTableRollMacro(doc);
            else macro = await ui.hotbar._createDocumentSheetToggle(doc);
            finish(macro);
        }
    })().catch(error => finish(null, error));
    return result;
}
