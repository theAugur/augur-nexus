import { getPlayerContext } from "../../api/player-context.js";
import { describePlayerShortcut } from "../../api/player-shortcuts.js";

const MODULE_ID = "augur-nexus";
const KEY = "playerGatewayLayouts";
export const PIN_LIMIT = 10;
let writes = Promise.resolve();

export function normalizePins(value) {
    const seen = new Set();
    return Array.from({ length: PIN_LIMIT }, (_, slot) => {
        const uuid = Array.isArray(value) ? value[slot] : null;
        if (typeof uuid !== "string" || !/^(?:Actor|Item|JournalEntry|Macro|RollTable|Scene)\.[A-Za-z0-9]+(?:\.(?:Item|Token|Actor|JournalEntryPage)\.[A-Za-z0-9]+)*$/.test(uuid) || seen.has(uuid)) return null;
        seen.add(uuid); return uuid;
    });
}

// These are personal layouts for an assigned Actor, independent of its Nexus Person link.
export function getGatewayLayoutId(userId = game.user.id) {
    const actorId = game.users.get(userId)?.character?.id;
    return actorId ? `characters.${actorId}` : "unassigned";
}

export function requireGatewayLayout(layoutId, userId = game.user.id) {
    if (layoutId !== getGatewayLayoutId(userId)) throw new Error("Your character changed. Try that shortcut action again on the current wheel.");
}

export function getGatewayPins(userId = game.user.id) {
    const context = getPlayerContext(userId);
    const user = game.users.get(userId);
    return normalizePins(user?.getFlag(MODULE_ID, `${KEY}.${getGatewayLayoutId(userId)}`)).map((uuid, slot) => {
        const campaignEntry = context.entries.find(entry => entry.uuid === uuid);
        const entry = campaignEntry || (uuid && describePlayerShortcut(uuid, { userId })) || null;
        const angle = (-90 + slot * 360 / PIN_LIMIT) * Math.PI / 180;
        return { slot, slotNumber: slot + 1, uuid, entry, native: !!entry && !campaignEntry,
            left: Math.round(180 + 164 * Math.cos(angle)), top: Math.round(180 + 164 * Math.sin(angle)),
            menuLeft: slot < PIN_LIMIT / 2, menuUp: slot >= 3 && slot <= 7 };
    });
}

export function updateGatewayPin({ uuid, remove = false, slot, toSlot, expectedUuid, layoutId = getGatewayLayoutId() } = {}) {
    const user = game.user;
    const work = writes.then(async () => {
        if (game.user !== user) throw new Error("The active user changed. Try that shortcut action again.");
        requireGatewayLayout(layoutId, user.id);
        const key = `${KEY}.${layoutId}`;
        const pins = normalizePins(user.getFlag(MODULE_ID, key));
        if (slot !== undefined && (!Number.isInteger(slot) || slot < 0 || slot >= PIN_LIMIT)) throw new Error("Choose a valid pin position.");
        if (toSlot !== undefined) {
            if (!Number.isInteger(slot) || !Number.isInteger(toSlot) || slot < 0 || slot >= PIN_LIMIT || toSlot < 0 || toSlot >= PIN_LIMIT) throw new Error("Choose a valid pin position.");
            if (expectedUuid !== undefined && pins[slot] !== expectedUuid) throw new Error("That shortcut moved. Drag it again.");
            [pins[slot], pins[toSlot]] = [pins[toSlot], pins[slot]];
        } else if (remove) {
            const index = slot ?? pins.indexOf(uuid);
            if (index >= 0) {
                if (uuid !== undefined && pins[index] !== uuid) throw new Error("That shortcut changed. Try removing it again.");
                pins[index] = null;
            }
        } else {
            if (expectedUuid !== undefined && pins[slot] !== expectedUuid) throw new Error("That shortcut changed while its macro was being created. Drop it again.");
            const entry = getPlayerContext().entries.find(entry => entry.uuid === uuid) || describePlayerShortcut(uuid);
            if (!entry || entry.primary) throw new Error("Pin an available campaign entry, macro, or document.");
            if (normalizePins([uuid])[0] !== uuid) throw new Error("This document cannot be pinned.");
            const previous = pins.indexOf(uuid);
            if (previous >= 0 && (slot === undefined || previous === slot)) return;
            const index = slot ?? pins.indexOf(null);
            if (index < 0) throw new Error("All shortcut slots are used. Drop onto a slot to replace it, or unpin something first.");
            if (previous >= 0) [pins[previous], pins[index]] = [pins[index], pins[previous]];
            else pins[index] = uuid;
        }
        // Update only this layout, so writes for another character cannot replace it.
        await user.setFlag(MODULE_ID, key, pins);
        Hooks.callAll("augurNexusPlayerContextChanged");
    });
    writes = work.catch(() => {});
    return work;
}

export function resolveGatewayDrop(data, entries) {
    if (!data || typeof data !== "object") return null;
    if (data.type === "AugurPlayerShortcut" && (data.userId !== game.user.id || data.layoutId !== getGatewayLayoutId())) return null;
    const matches = entries.filter(entry => !entry.primary && (
        (data.uuid && entry.uuid === data.uuid)
        || ((data.type === "AugurNexusEntity" || data.kind === "nexus-entity") && data.entityId === entry.id)
        || (data.type === "Actor" && data.uuid && entry.actorUuid === data.uuid)
    ));
    if (matches.length) return matches.length === 1 ? matches[0].uuid : null;
    if (data.type === "AugurNexusEntity" || data.kind === "nexus-entity" || data.entityId) return null;
    const entry = describePlayerShortcut(data.uuid);
    return entry && (data.type === entry.documentName || data.type === "AugurPlayerShortcut") ? entry.uuid : null;
}
