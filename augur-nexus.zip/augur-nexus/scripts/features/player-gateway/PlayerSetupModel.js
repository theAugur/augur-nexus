const TYPES = { npc: "Person", faction: "Group", ship: "Ship", location: "Place" };

// Resolve only existing world records. Drag labels and portraits are never authoritative.
export function resolveSetupDrop(data, target, setup) {
    if (!data || typeof data !== "object") return null;
    if (target === "actor" || target === "shipActor") {
        if (data.type !== "Actor") return null;
        return setup.actors.find(actor => actor.uuid === data.uuid) || null;
    }
    const matches = setup.entities.filter(entity => {
        if (target === "person" && entity.type !== "npc") return false;
        if (target === "ship" && entity.type !== "ship") return false;
        if (data.type === "JournalEntry") return entity.uuid === data.uuid;
        if (data.type === "AugurNexusEntity" || data.kind === "nexus-entity") return entity.id === data.entityId;
        if (target === "assignments" && data.type === "Actor") return !!data.uuid && entity.actorUuid === data.uuid;
        return false;
    });
    return matches.length === 1 ? matches[0] : null;
}

export function setupEntityCard(entity, grant = {}) {
    return { ...entity, ...grant, name: entity?.name || "Missing entity", image: entity?.image || "icons/svg/mystery-man.svg",
        typeLabel: TYPES[entity?.type] || "Unavailable", accessLabel: grant.mode === "manage" ? "Full control" : "View only",
        missing: !entity };
}

export async function openSetupEntity(entity) {
    if (!entity) throw new Error("This campaign entity is no longer available.");
    switch (entity.type) {
        case "npc": return (await import("../../api/npcs.js")).openNpcDossier(entity.id);
        case "ship": return (await import("../../api/ships.js")).openShipDossier(entity.id);
        case "faction": return (await import("../../api/factions.js")).openFactionDossier(entity.id);
        case "location": return (await import("../../api/locations.js")).openLocationDossier(entity.id);
    }
}
