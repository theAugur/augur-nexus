import { getPlayerSetupData, linkPlayerCharacter, assignPlayerEntity, unlinkPlayerPerson, clearPlayerIdentity, getPlayerAssignmentActions, assignPlayerShip, clearPlayerShip, unlinkPlayerShip, assignPlayerShipActor } from "../../api/player-context.js";
import { openActionMenu, closeActionMenu } from "../../api/ui.js";
import { createPlayerIdentityPerson } from "./PlayerSetupCreation.js";
import { createPlayerIdentityShip } from "./PlayerSetupShip.js";
import { resolveSetupDrop, setupEntityCard, openSetupEntity } from "./PlayerSetupModel.js";
const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class PlayerSetupApplication extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
        id: "nexus-player-setup", tag: "form", classes: ["augur-nexus", "augur-theme-fantasy", "nexus-player-setup"],
        window: { title: "Player Identity - Setup", resizable: true }, position: { width: 620, height: 740 },
        form: { closeOnSubmit: false },
        actions: Object.fromEntries(["createPerson", "createShip", "clearShip", "toggleSection", "preview", "options", "open", "clearIdentity", "addSuggested"].map(key => [key, PlayerSetupApplication.action]))
    };
    static PARTS = { body: { template: "modules/augur-nexus/templates/player-gateway/setup.hbs" } };
    constructor({ userId = "", entityUuid = "", ...options } = {}) {
        super(options); this.userId = userId; this.entityUuid = entityUuid; this.message = ""; this.busy = false;
        this.sections = new Map();
    }
    _onChangeForm(config, event) {
        const field = event.target;
        if (field.name === "userId") {
            if (this.busy) { field.value = this.userId; return; }
            this.userId = field.value; this.message = "";
            void this.render({ force: true });
        }
        super._onChangeForm(config, event);
    }
    async _prepareContext() {
        const data = getPlayerSetupData();
        this.userId ||= data.users[0]?.id || "";
        const user = data.users.find(row => row.id === this.userId);
        const actor = data.actors.find(row => row.id === user?.actorId);
        const person = data.entities.find(row => row.uuid === user?.personUuid);
        const ship = data.entities.find(row => row.uuid === user?.shipUuid && row.type === "ship");
        const shipActor = data.actors.find(row => row.uuid === user?.shipActorUuid);
        const collapsed = this.sections.get(this.userId) || {};
        const assigned = (user?.grants || []).filter(grant => grant.uuid !== person?.uuid && grant.uuid !== ship?.uuid).map(grant => setupEntityCard(data.entities.find(row => row.uuid === grant.uuid), grant));
        if (user?.isGM) assigned.forEach(entry => { entry.accessLabel = "GM access"; });
        const suggested = data.entities.find(row => row.uuid === this.entityUuid && row.uuid !== person?.uuid && row.uuid !== ship?.uuid && !assigned.some(grant => grant.uuid === row.uuid));
        return { users: data.users.map(row => ({ ...row, selected: row.id === this.userId })),
            isOwnHome: this.userId === game.user.id, selectedIsGM: !!user?.isGM,
            actor, person, assigned, assignmentCount: assigned.length, suggested,
            ship, shipActor, characterCollapsed: collapsed.character ?? false, shipCollapsed: collapsed.ship ?? !(ship || shipActor),
            canClearShip: !!(user?.shipUuid || user?.shipActorUuid) && !this.busy, savedShipUuid: user?.shipUuid || "", savedShipActorUuid: user?.shipActorUuid || "",
            characterSummary: [actor?.name, person?.name].filter(Boolean).filter((name, i, names) => names.indexOf(name) === i).join(" / ") || "Not assigned",
            shipSummary: [shipActor?.name, ship?.name].filter(Boolean).filter((name, i, names) => names.indexOf(name) === i).join(" / ") || "Not assigned",
            canClearIdentity: !!user?.actorId && !this.busy, savedActorId: user?.actorId || "",
            canCreatePerson: !!actor && !person && !user?.identityError && !this.busy, message: this.message || user?.identityError, busy: this.busy, hasUser: !!user };
    }
    _onRender(context, options) {
        super._onRender(context, options);
        if (this.menuAnchor) closeActionMenu();
        if (!this.placed) {
            this.placed = true;
            const width = Math.min(620, window.innerWidth - 30), height = Math.min(740, window.innerHeight - 40);
            this.setPosition({ width, height, left: (window.innerWidth - width) / 2, top: (window.innerHeight - height) / 2 });
        }
        this.dropEvents?.abort(); this.dropEvents = new AbortController();
        const optionsForDrop = { signal: this.dropEvents.signal };
        this.element.addEventListener("dragover", event => {
            const zone = event.target.closest("[data-drop-target]");
            if (!zone || this.busy || !this.userId) return;
            event.preventDefault(); event.stopPropagation();
            event.dataTransfer.dropEffect = "copy";
            zone.classList.add("accepting-drop");
        }, optionsForDrop);
        this.element.addEventListener("dragleave", event => {
            const zone = event.target.closest("[data-drop-target]");
            if (zone && !zone.contains(event.relatedTarget)) zone.classList.remove("accepting-drop");
        }, optionsForDrop);
        this.element.addEventListener("drop", event => {
            const zone = event.target.closest("[data-drop-target]");
            if (!zone) return;
            event.preventDefault(); event.stopPropagation(); zone.classList.remove("accepting-drop");
            let data;
            try { data = JSON.parse(event.dataTransfer.getData("text/plain") || event.dataTransfer.getData("application/json")); }
            catch { this.message = "Drop an Actor or a Nexus campaign entity from its directory."; void this.render({ force: true }); return; }
            void this.run(() => this.applyDrop(data, zone.dataset.dropTarget));
        }, optionsForDrop);
    }
    async close(options) {
        if (this.menuAnchor) closeActionMenu();
        this.dropEvents?.abort(); return super.close(options);
    }
    async applyDrop(data, target) {
        const setup = getPlayerSetupData();
        const record = resolveSetupDrop(data, target, setup);
        if (!record) throw new Error(["actor", "shipActor"].includes(target) ? "Drop a world Actor from the Actors directory." : target === "person" ? "Drop a Nexus Person from the Nexus directory." : target === "ship" ? "Drop a Nexus Ship from the Nexus directory." : "Drop an existing Person, Group, Ship, or Place. Actors must already be linked to a Nexus entity.");
        if (target === "shipActor") {
            await assignPlayerShipActor(this.userId, record.id);
            await this.shipAssignedCallback()();
            return;
        }
        if (target === "ship") {
            await assignPlayerShip(this.userId, record.uuid);
            await this.shipAssignedCallback()();
            return;
        }
        if (target === "actor" || target === "person") {
            if (!game.user.isGM) throw new Error("Only the GM can assign player identities.");
            const user = setup.users.find(row => row.id === this.userId);
            if (!user) throw new Error("The selected player no longer exists.");
            if (record.identityError) throw new Error(record.identityError);
            const actorId = target === "actor" ? record.id : user.actorId || setup.actors.find(row => row.uuid === record.actorUuid)?.id;
            if (!actorId) throw new Error("Drop a character Actor first, then add this Person.");
            await linkPlayerCharacter(this.userId, actorId, target === "person" ? record.uuid : "");
            this.message = target === "actor" ? "Character Actor assigned. Ownership and identity are saved." : "Person assigned. Identity saved.";
        } else {
            const user = setup.users.find(row => row.id === this.userId);
            if (record.uuid === user?.personUuid) { this.message = "This is the player’s character. They already have full control through their saved identity."; return; }
            const existing = setup.users.find(row => row.id === this.userId)?.grants.find(grant => grant.uuid === record.uuid);
            if (existing) { this.message = `${record.name} is already assigned. Use its options to change access.`; return; }
            await assignPlayerEntity(this.userId, { uuid: record.uuid, mode: "manage" });
            this.message = user?.isGM ? `${record.name} added to the wheel.` : `${record.name} assigned with full control.`;
        }
    }
    showMenu(anchor, items) {
        openActionMenu({ anchor, items, onClose: () => { anchor.setAttribute("aria-expanded", "false"); this.menuAnchor = null; } });
        this.menuAnchor = anchor; anchor.setAttribute("aria-expanded", "true");
    }
    shipAssignedCallback() {
        const userId = this.userId;
        return async () => {
            this.sections.set(userId, { ...this.sections.get(userId), ship: false });
            if (this.userId === userId) {
                const user = getPlayerSetupData().users.find(row => row.id === userId);
                this.message = user?.shipUuid ? "Ship assigned with full control and selected for the wheel." : "Ship Actor assigned. Ownership saved; add or create a Nexus Ship whenever you are ready.";
            }
            if (this.rendered) await this.render({ force: false });
        };
    }
    entryMenu(anchor, uuid, kind) {
        if (this.menuAnchor === anchor) { closeActionMenu(); return; }
        const data = getPlayerSetupData();
        const entity = data.entities.find(row => row.uuid === uuid);
        const item = (id, label, icon, work, extra = {}) => ({ id, label, icon, ...extra, onSelect: () => this.run(work) });
        const items = kind === "assignment" ? [] : [item("open", kind === "actor" ? "Open Actor sheet" : "Open dossier", "fas fa-book-open", () => this.openRecord(uuid, kind), { unavailable: kind !== "actor" && !entity })];
        const userId = this.userId;
        const user = data.users.find(row => row.id === userId);
        if (game.user.isGM && kind === "person" && user?.personUuid === uuid && user.actorId) {
            items.push(item("unlinkPerson", "Unlink Person from Actor", "fas fa-unlink", async () => {
                await unlinkPlayerPerson(userId, user.actorId, uuid);
                this.message = "Person unlinked. The character Actor remains assigned; both documents and Actor permissions are kept.";
            }));
        }
        if (game.user.isGM && kind === "ship" && user?.shipUuid === uuid) {
            items.push(item("unlinkShip", "Unlink Nexus Ship", "fas fa-unlink", async () => {
                await unlinkPlayerShip(userId, uuid, entity?.actorUuid || "");
                this.message = "Nexus Ship unlinked. The Ship Actor remains assigned; the Ship keeps its Additional access grant.";
            }));
        }
        if (kind === "assignment") items.push(...getPlayerAssignmentActions(this.userId, uuid).map(action => ({
            ...action, onSelect: () => this.run(action.onSelect)
        })));
        this.showMenu(anchor, items);
    }
    async openRecord(uuid, kind) {
        if (kind === "actor") {
            const actor = game.actors.contents.find(row => row.uuid === uuid);
            if (!actor) throw new Error("This Actor is no longer available.");
            return actor.sheet.render(true);
        }
        return openSetupEntity(getPlayerSetupData().entities.find(row => row.uuid === uuid));
    }
    async run(work) {
        if (this.busy || !this.userId || !game.user.isGM) return;
        this.busy = true; this.message = "";
        this.element?.querySelector("[name=userId]")?.setAttribute("disabled", "");
        try { await work(); }
        catch (error) { this.message = error.message || "Setup could not be saved."; ui.notifications.warn(this.message); }
        finally { this.busy = false; }
        await this.render({ force: true });
    }
    static async action(event, button) {
        event.preventDefault(); event.stopPropagation();
        if (this.busy || !this.userId) return;
        const { action, uuid, kind } = button.dataset;
        if (action === "toggleSection") {
            const section = button.dataset.section;
            if (!["character", "ship"].includes(section)) return;
            const context = await this._prepareContext();
            this.sections.set(this.userId, { ...this.sections.get(this.userId), [section]: !context[`${section}Collapsed`] });
            await this.render({ force: false });
            return;
        }
        if (action === "options") { this.entryMenu(button, uuid, kind); return; }
        await this.run(async () => {
            switch (action) {
                case "createShip":
                    await createPlayerIdentityShip(this.userId, { onAssigned: this.shipAssignedCallback() });
                    break;
                case "clearShip":
                    await clearPlayerShip(this.userId, uuid, button.dataset.actorUuid);
                    this.message = "Ship setup cleared. The Actor, Nexus Ship, their link and existing permissions are kept.";
                    break;
                case "createPerson": {
                    const userId = this.userId;
                    await createPlayerIdentityPerson(userId, { onAssigned: async () => {
                        if (this.userId === userId) this.message = "Person created and assigned. Identity saved.";
                        if (this.rendered) await this.render({ force: false });
                    } });
                    break;
                }
                case "clearIdentity":
                    await clearPlayerIdentity(this.userId, button.dataset.actorId);
                    this.message = "Identity cleared. The Actor and Person are kept, along with their existing Actor permissions.";
                    break;
                case "open": await this.openRecord(uuid, kind); break;
                case "addSuggested": await this.applyDrop({ type: "JournalEntry", uuid: this.entityUuid }, "assignments"); break;
                case "preview": { const { openPlayerHome } = await import("../../api/player-gateway.js"); await openPlayerHome({ userId: this.userId }); break; }
            }
        });
    }
}
