import { getPlayerSetupData, linkPlayerCharacter } from "../../api/player-context.js";
import { openNpcCreator } from "../../api/npcs.js";

export async function createPlayerIdentityPerson(userId, { onAssigned } = {}) {
    if (!game.user.isGM) throw new Error("Only the GM can create a player's Person.");
    const user = getPlayerSetupData().users.find(row => row.id === userId);
    if (!user) throw new Error("The selected player no longer exists.");
    if (!user.actorId) throw new Error("Drop a character Actor before creating their Person.");
    if (user.identityError) throw new Error(user.identityError);
    if (user.personUuid) throw new Error("This character already has a Nexus Person.");
    const actorId = user.actorId;
    // The normal Person gateway supplies the module-required message and creation workflow.
    return openNpcCreator({ onCreated: async entity => {
        try {
            await linkPlayerCharacter(userId, actorId, entity.uuid, { expectedActorId: actorId, expectedPersonUuid: "" });
            await onAssigned?.();
        } catch (error) {
            // The Person exists already; do not offer to create a duplicate after assignment fails.
            ui.notifications.warn(`${entity.display?.name || "The Person"} was created, but could not be assigned: ${error.message} Review Player Identity - Setup.`);
        }
    } });
}
