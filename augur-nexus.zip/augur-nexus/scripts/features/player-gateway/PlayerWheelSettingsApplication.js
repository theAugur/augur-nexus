import { hidePlayerWheel, isPlayerWheelOpen } from "../../api/player-gateway.js";
import { prepareNexusThemeSurface } from "../../api/appearance.js";
import { attachHelpButton } from "../../api/help.js";
import { resolveWheelPreferenceUser, preparePlayerWheelPreferences, setPlayerWheelPreference, resetPlayerWheelPreferences } from "./PlayerWheelPreferences.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class PlayerWheelSettingsApplication extends HandlebarsApplicationMixin(ApplicationV2) {
    #hooks = [];
    static DEFAULT_OPTIONS = {
        tag: "form", classes: ["augur-nexus", "augur-theme-fantasy", "nexus-player-setup", "nexus-player-wheel-settings"],
        window: { title: "Player Wheel Settings", resizable: true }, position: { width: 410, height: 510 },
        form: { closeOnSubmit: false },
        actions: { hideWheel() { return this.save(() => hidePlayerWheel({ userId: this.userId })); }, resetWheelPreferences() { return this.save(() => resetPlayerWheelPreferences(this.userId)); } }
    };
    static PARTS = { body: { template: "modules/augur-nexus/templates/player-gateway/wheel-settings.hbs",
        templates: ["modules/augur-nexus/templates/player-gateway/wheel-preferences.hbs", "modules/augur-nexus/templates/player-gateway/wheel-shortcut-groups.hbs"] } };
    constructor({ userId = game.user.id, ...options } = {}) {
        resolveWheelPreferenceUser(userId);
        super(options); this.userId = userId; this.busy = false; this.message = "";
    }
    async _prepareContext() {
        const appearance = prepareNexusThemeSurface();
        return { appearance: { ...appearance, style: appearance.id === "parchment" ? appearance.style : "" },
            preferences: preparePlayerWheelPreferences(this.userId, { busy: this.busy }), message: this.message,
            canHideWheel: !!game.user.isGM, hideWheelDisabled: this.busy || !isPlayerWheelOpen(this.userId),
            hideWheelLabel: this.userId === game.user.id ? "Hide this wheel" : "Close preview" };
    }
    _onChangeForm(config, event) {
        if (event.target.name?.startsWith("wheelPreference.")) {
            if (this.busy) return void this.render({ force: false });
            return this.save(() => setPlayerWheelPreference(this.userId, event.target.name.slice(16), event.target.checked));
        }
        return super._onChangeForm(config, event);
    }
    async save(work) {
        if (this.busy) return;
        this.busy = true; this.message = "";
        try { await work(); }
        catch (error) { this.message = error.message || "Wheel settings could not be saved."; ui.notifications.warn(this.message); }
        finally { this.busy = false; }
        if (this.rendered) await this.render({ force: false });
    }
    _onRender(context, options) {
        super._onRender(context, options);
        attachHelpButton(this, "augur-nexus:player-wheel");
        if (this.#hooks.length) return;
        const refresh = () => { if (this.rendered && !this.busy) void this.render({ force: false }); };
        for (const name of ["updateUser", "updateSetting", "augurNexusAppearanceChanged", "augurNexusPlayerWheelPresentationChanged"]) this.#hooks.push([name, Hooks.on(name, refresh)]);
    }
    async close(options) {
        for (const [name, id] of this.#hooks) Hooks.off(name, id);
        this.#hooks = [];
        return super.close(options);
    }
}
