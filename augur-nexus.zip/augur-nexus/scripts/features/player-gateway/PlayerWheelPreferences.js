import { requirePremiumAccess } from "../access/PremiumAccess.js";
import { PLAYER_WHEEL_OPTIONS, getPlayerWheelOptions, groupPlayerWheelOptions } from "./PlayerWheelOptions.js";
import { isPlayerWheelEnabled, isPlayerWheelEnabledFor } from "./PlayerGatewayAvailability.js";
import { isPlayerWorkspaceAllowed } from "../../api/player-gateway.js";

const MODULE_ID = "augur-nexus";
const KEY = "playerWheelPreferences";
const labels = { ...PLAYER_WHEEL_OPTIONS, workspace: "Campaign Nexus" };

export function resolveWheelPreferenceUser(userId = game.user.id) {
    if (!game.user.isGM && userId !== game.user.id) throw new Error("You can only configure your own Player Wheel.");
    const user = game.users.get(userId);
    if (!user) throw new Error("This user no longer exists.");
    return user;
}

function allowedOptions(user) {
    return { ...getPlayerWheelOptions(), workspace: !!user.isGM || isPlayerWorkspaceAllowed() };
}

export function getPlayerWheelPreferences(userId = game.user.id) {
    const user = resolveWheelPreferenceUser(userId), saved = user.getFlag(MODULE_ID, KEY) || {};
    return Object.fromEntries(Object.keys(labels).filter(key => typeof saved[key] === "boolean").map(key => [key, saved[key]]));
}

export function getEffectivePlayerWheelOptions(userId = game.user.id) {
    const user = resolveWheelPreferenceUser(userId), allowed = allowedOptions(user), saved = getPlayerWheelPreferences(userId);
    const enabled = isPlayerWheelEnabledFor(userId);
    return Object.fromEntries(Object.keys(labels).map(key => [key, enabled && allowed[key] && saved[key] !== false]));
}

export function preparePlayerWheelPreferences(userId, { busy = false, showEnable = false } = {}) {
    const user = resolveWheelPreferenceUser(userId), allowed = allowedOptions(user), saved = getPlayerWheelPreferences(userId);
    const globalEnabled = isPlayerWheelEnabled(), canEdit = user.canUserModify(game.user, "update");
    const rows = Object.entries(labels).map(([key, label]) => {
            const available = globalEnabled && allowed[key];
            return { key, label, name: `wheelPreference.${key}`, checked: available && saved[key] !== false, disabled: busy || !canEdit || !available,
                reason: !globalEnabled ? "The Player Wheel is disabled for everyone by the GM." : !allowed[key]
                    ? key === "workspace" ? "Campaign Nexus is disabled by the GM." : "Unavailable in the GM's Available Wheel Shortcuts." : "" };
        });
    return { userId, userName: user.name, canEnable: !!game.user.isGM && showEnable,
        userEnabled: game.settings.get(MODULE_ID, "playerGatewayUserEnabled")?.[userId] !== false,
        enableDisabled: busy, resetDisabled: busy || !canEdit || !Object.keys(saved).length,
        rows, groups: groupPlayerWheelOptions(rows) };
}

function requireUpdate(user, patch) {
    if (!user.canUserModify(game.user, "update", patch)) throw new Error("You cannot update this user's Player Wheel.");
}

export async function setPlayerWheelPreference(userId, key, shown) {
    requirePremiumAccess("playerWheel");
    const user = resolveWheelPreferenceUser(userId);
    if (!Object.hasOwn(labels, key)) throw new Error("Unknown Player Wheel shortcut.");
    if (!isPlayerWheelEnabled() || !allowedOptions(user)[key]) throw new Error("That shortcut is disabled by the GM.");
    const patch = { [`flags.${MODULE_ID}.${KEY}.${key}`]: !!shown };
    requireUpdate(user, patch);
    await user.update(patch);
}

export async function resetPlayerWheelPreferences(userId) {
    requirePremiumAccess("playerWheel");
    const user = resolveWheelPreferenceUser(userId);
    requireUpdate(user, { [`flags.${MODULE_ID}.-=${KEY}`]: null });
    await user.unsetFlag(MODULE_ID, KEY);
}
