import { getPlayerContext, openPlayerEntity } from "../../api/player-context.js";
import { openGatewayEntity } from "../../api/player-gateway.js";

export function gatewayPortraitHint(name, { hasActor = false, hasDossier = true, preview = false } = {}) {
    if (preview) return `${name} - Player preview`;
    if (hasActor && hasDossier) return `${name}\nLeft-click: Actor sheet · Right-click: Nexus dossier`;
    return `${name}\n${hasActor ? "Open Actor sheet" : "Open Nexus dossier"}`;
}

export async function openGatewayPortrait({ uuid = "", dossier = false, userId = game.user.id } = {}) {
    const context = getPlayerContext(userId);
    const preview = context.preview || userId !== game.user.id;
    const entry = context.entries.find(row => row.uuid === uuid);
    if (!entry) throw new Error("This entry is no longer available to you.");
    if (!preview && !dossier && entry.actorUuid) return openPlayerEntity(uuid, { actor: true });
    return openGatewayEntity(uuid, { userId });
}

export function gatewayInnerLayout(context) {
    const primaries = [
        context.primaryShip && { ...context.primaryShip, key: "ship", typeLabel: "Primary ship" },
        context.mainQuest && { ...context.mainQuest, key: "quest", typeLabel: "Main quest", isQuest: true },
        context.primaryFaction && { ...context.primaryFaction, key: "faction", typeLabel: "Primary faction" }
    ].filter(Boolean);
    const positions = { contacts: { left: 72, top: 176 }, quests: { left: 280, top: 176 }, holdings: { left: 176, top: 280 } };
    const slots = primaries.length === 1 ? [[174, 70]] : primaries.length === 2 ? [[128, 82], [220, 82]] : [[100, 100], [174, 70], [248, 100]];
    primaries.forEach((entry, index) => {
        const [left, top] = slots[index];
        positions[entry.key] = { left, top };
        Object.assign(entry, { left, top, hint: entry.isQuest ? `${entry.name} - Main quest` : gatewayPortraitHint(`${entry.name} - ${entry.typeLabel}`, { hasActor: !!entry.actorUuid, preview: context.preview }) });
    });
    return { primaries, positions };
}
