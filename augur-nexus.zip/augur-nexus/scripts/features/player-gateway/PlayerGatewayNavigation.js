import { getPlayerContext, openPlayerEntity } from "../../api/player-context.js";
import { getPlayerWheelOptions } from "./PlayerWheelOptions.js";
import { gatewayOrbitPosition, gatewayGeometry } from "./PlayerGatewayGeometry.js";
import { openGatewayEntity } from "../../api/player-gateway.js";
import { PLAYER_GATEWAY_GEOMETRY } from "./PlayerGatewayGeometry.js";

export function gatewayPortraitHint(name, { hasActor = false, hasDossier = true, preview = false } = {}) {
    if (preview) return `${name} - Player preview`;
    if (hasActor && hasDossier) return `${name}\nLeft-click: Actor sheet · Right-click: Nexus dossier`;
    return `${name}\n${hasActor ? "Open Actor sheet" : "Open Nexus dossier"}`;
}

export async function openGatewayPortrait({ uuid = "", dossier = false, userId = game.user.id } = {}) {
    const context = getPlayerContext(userId);
    const preview = context.preview || userId !== game.user.id;
    const entry = context.entries.find(row => row.uuid === uuid);
    if (!entry) throw new Error("This entry is no longer available to you.");
    if (!preview && !dossier && entry.actorUuid) return openPlayerEntity(uuid, { actor: true });
    return openGatewayEntity(uuid, { userId });
}

export function gatewayInnerLayout(context, { options = getPlayerWheelOptions(), workspaceAllowed = true, collapsed = false, hotkeysExpanded = true } = {}) {
    const primaries = [
        options.ship && context.primaryShip && { ...context.primaryShip, key: "ship", typeLabel: "Assigned ship" },
        options.mainQuest && context.mainQuest && { ...context.mainQuest, key: "quest", typeLabel: "Main quest", isQuest: true },
        options.organization && context.primaryFaction && { ...context.primaryFaction, key: "faction", typeLabel: "Assigned organization" }
    ].filter(Boolean);
    const actions = [
        workspaceAllowed && { key: "workspace", action: "workspace", icon: "fa-books", hint: "Campaign Nexus � browse campaign entries available to you" },
        options.contacts && { key: "contacts", action: "section", section: "contacts", icon: "fa-users", hint: "Contacts and groups" },
        options.quests && { key: "quests", action: "section", section: "quests", icon: "fa-scroll", hint: "Quests and pursuits", disabled: context.preview },
        options.holdings && { key: "holdings", action: "section", section: "holdings", icon: "fa-landmark", hint: "Your holdings" },
        ...primaries.map(entry => ({ ...entry, icon: entry.isQuest ? "fa-scroll" : entry.key === "ship" ? "fa-shuttle-space" : "fa-flag", action: entry.isQuest ? "openMainQuest" : "openEntity", disabled: entry.isQuest && context.preview,
            hint: entry.isQuest ? `${entry.name} - Main quest` : gatewayPortraitHint(`${entry.name} - ${entry.typeLabel}`, { hasActor: !!entry.actorUuid, preview: context.preview }) }))
    ].filter(Boolean);
    const characterActions = [
        options.sheet && (context.actor || context.character?.actorUuid) && { key: "sheet", action: "sheet", icon: "fa-address-card", hint: "Character sheet", disabled: context.preview },
        options.dossier && (context.character || context.actor) && { key: "story", action: "story", icon: "fa-book-open", hint: "Character dossier in Nexus" }
    ].filter(Boolean);
    const actionAngles = actions.map((_entry, index) => PLAYER_GATEWAY_GEOMETRY.actionAngles[index + (options.hotkeys ? 1 : 0)]);
    const angles = [...(options.hotkeys ? [-90] : []), ...actionAngles, ...characterActions.map(entry => PLAYER_GATEWAY_GEOMETRY.characterAngles[entry.key])];
    const geometry = gatewayGeometry({ angles, collapsed, hotkeysExpanded: options.hotkeys && hotkeysExpanded });
    const center = geometry.center;
    const positions = {};
    actions.forEach((entry, index) => Object.assign(entry, positions[entry.key] = gatewayOrbitPosition(actionAngles[index], center, geometry.innerRadius)));
    characterActions.forEach(entry => Object.assign(entry, positions[entry.key] = gatewayOrbitPosition(PLAYER_GATEWAY_GEOMETRY.characterAngles[entry.key], center, geometry.innerRadius)));
    if (options.hotkeys) positions.hotkeys = gatewayOrbitPosition(-90, center, geometry.innerRadius);
    return { geometry, angles, primaries: actions.filter(entry => ["ship", "quest", "faction"].includes(entry.key)), positions, actions, characterActions };
}
