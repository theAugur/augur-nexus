import { hasPremiumAccess, requirePremiumAccess } from "../access/PremiumAccess.js";

const MODULE_ID = "augur-nexus";

export function isPlayerWheelEnabled() {
    return hasPremiumAccess() && game.settings.get(MODULE_ID, "playerGatewayEnabled") !== false;
}

export async function setPlayerWheelEnabled(enabled) {
    if (!game.user.isGM) throw new Error("Only the GM can enable or disable the Player Wheel.");
    requirePremiumAccess("playerWheel");
    await game.settings.set(MODULE_ID, "playerGatewayEnabled", !!enabled);
}

export function requirePlayerWheelEnabled() {
    requirePremiumAccess("playerWheel");
    if (!isPlayerWheelEnabled()) throw new Error("The Player Wheel is disabled for everyone by the GM.");
}


export function isPlayerWheelEnabledFor(userId = game.user.id) {
    return isPlayerWheelEnabled() && game.settings.get(MODULE_ID, "playerGatewayUserEnabled")?.[userId] !== false;
}

export function requirePlayerWheelAvailable(userId = game.user.id) {
    requirePlayerWheelEnabled();
    if (!isPlayerWheelEnabledFor(userId)) throw new Error("The Player Wheel is disabled for this player by the GM.");
}

export async function setPlayerWheelUserEnabled(userId, enabled) {
    if (!game.user.isGM) throw new Error("Only the GM can enable or disable a player's wheel.");
    requirePremiumAccess("playerSetup");
    if (!game.users.get(userId)) throw new Error("This user no longer exists.");
    const saved = game.settings.get(MODULE_ID, "playerGatewayUserEnabled") || {};
    const next = Object.fromEntries(Object.entries(saved).filter(([id, value]) => id !== userId && value === false));
    if (!enabled) next[userId] = false;
    await game.settings.set(MODULE_ID, "playerGatewayUserEnabled", next);
}
