const MODULE_ID = "augur-nexus";

export function isPlayerWheelEnabled() {
    return game.settings.get(MODULE_ID, "playerGatewayEnabled") !== false;
}

export async function setPlayerWheelEnabled(enabled) {
    if (!game.user.isGM) throw new Error("Only the GM can enable or disable the Player Wheel.");
    await game.settings.set(MODULE_ID, "playerGatewayEnabled", !!enabled);
}

export function requirePlayerWheelEnabled() {
    if (!isPlayerWheelEnabled()) throw new Error("The Player Wheel is disabled for everyone by the GM.");
}
