import { getPlayerContext, selectPrimaryPlayerShip, selectPrimaryPlayerFaction, selectPlayerAsset, openPlayerEntity } from "../../api/player-context.js";
import { openGatewayEntity } from "../../api/player-gateway.js";
import { openActionMenu, closeActionMenu } from "../../api/ui.js";
import { getGatewayPins, updateGatewayPin, PIN_LIMIT } from "./PlayerGatewayPins.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const MODULE_ID = "augur-nexus";
const titles = { contacts: "Player Wheel - Contacts", holdings: "Player Wheel - Holdings", profile: "Player Wheel - Profile" };

export class PlayerGatewayPanel extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
        id: "nexus-player-panel", tag: "form", classes: ["augur-nexus", "augur-theme-fantasy", "nexus-player-panel"],
        window: { title: "Player Wheel", resizable: true }, position: { width: 410, height: 540 }, form: { closeOnSubmit: false },
        actions: Object.fromEntries(["open", "options", "clearAsset", "filter"].map(key => [key, { handler: PlayerGatewayPanel.action, buttons: [0, 2] }]))
    };
    static PARTS = { body: { template: "modules/augur-nexus/templates/player-gateway/panel.hbs" } };
    constructor({ userId = game.user.id, section = "holdings", entityUuid = "", onClose, ...options } = {}) {
        super(options); this.onClose = onClose; this.userId = userId; this.section = section; this.entityUuid = entityUuid; 
        this.filter = "all"; this.message = "";
    }
    get title() { return titles[this.section] || "Player Wheel"; }
    refresh() {
        if (!this.rendered) return;
        void this.render({ force: false }).catch(error => console.error("Nexus | Player panel refresh", error));
    }
    async _prepareContext() {
        const context = getPlayerContext(this.userId);
        const selected = context.entries.find(entry => entry.uuid === this.entityUuid);
        const pinIds = getGatewayPins(this.userId).map(pin => pin.uuid);
        const types = this.section === "contacts" ? ["npc", "faction"] : ["ship", "location"];
        const entries = context.entries.filter(entry => !entry.primary && types.includes(entry.type) && (this.filter === "all" || this.filter === entry.type))
            .map(entry => ({ ...entry, isPrimaryShip: context.primaryShip?.uuid === entry.uuid, isPrimaryFaction: context.primaryFaction?.uuid === entry.uuid, pinned: pinIds.includes(entry.uuid) }));
        return { ...context, selected, entries, hasEntityRequest: !!this.entityUuid, heading: context.character?.name || context.actor?.name || context.userName, isContacts: this.section === "contacts", isProfile: this.section === "profile", isList: ["contacts", "holdings"].includes(this.section),
            filters: [{ id: "all", label: "All" }, { id: "npc", label: "People" }, { id: "faction", label: "Groups" }].map(row => ({ ...row, active: row.id === this.filter })),
            pinCount: pinIds.filter(Boolean).length, pinLimit: PIN_LIMIT, message: this.message || context.error };
    }
    _onRender(context, options) {
        super._onRender(context, options);
        if (this.menuAnchor) closeActionMenu();
        this.element.dataset.theme = game.settings.get(MODULE_ID, "playerGatewayTheme");
        if (!this.placed) {
            this.placed = true;
            const width = Math.min(410, window.innerWidth - 30);
            const height = Math.min(window.innerHeight - 40, context.isList ? 540 : 460);
            this.setPosition({ width, height, left: Math.max(15, (window.innerWidth - width) / 2), top: Math.max(20, (window.innerHeight - height) / 2) });
        }
        this.dragEvents?.abort(); this.dragEvents = new AbortController();
        this.element.addEventListener("dragstart", event => {
            const row = event.target.closest("[data-entry-uuid]");
            if (!row || context.preview) { event.preventDefault(); return; }
            event.dataTransfer.setData("text/plain", JSON.stringify({ type: "JournalEntry", uuid: row.dataset.entryUuid }));
            event.dataTransfer.effectAllowed = "copy";
        }, { signal: this.dragEvents.signal });
    }
    async close(options) {
        if (this.menuAnchor) closeActionMenu();
        this.dragEvents?.abort();
        const result = await super.close(options);
        if (!this.rendered) this.onClose?.();
        return result;
    }
    openEntryMenu(anchor, uuid) {
        if (this.menuAnchor === anchor) { closeActionMenu(); return; }
        const context = getPlayerContext(this.userId);
        const entry = context.entries.find(entry => entry.uuid === uuid);
        if (!entry) return;
        const item = (id, label, icon, unavailable = false) => ({ id, label, icon, unavailable, onSelect: () => this.performAction(id, { uuid }) });
        const items = context.preview || this.userId !== game.user.id
            ? [{ id: "preview", label: "Preview only", icon: "fas fa-eye", unavailable: true }]
            : [item("pin", getGatewayPins(this.userId).some(pin => pin.uuid === uuid) ? "Unpin from wheel" : "Pin to wheel", "fas fa-thumbtack")];
        if (!context.preview && this.userId === game.user.id) {
            if (entry.actorUuid) items.push(item("actor", "Open Actor sheet", "fas fa-user"));
            if (entry.type === "ship") {
                const primary = context.primaryShip?.uuid === uuid;
                items.push(item(primary ? "clearPrimaryShip" : "primaryShip", primary ? "Clear primary ship" : "Set as primary ship", "fas fa-shuttle-space"));
            }
            if (entry.type === "faction" && entry.canEdit) {
                const primary = context.primaryFaction?.uuid === uuid;
                items.push(item(primary ? "clearPrimaryFaction" : "primaryFaction", primary ? "Clear primary faction" : "Set as primary faction", "fas fa-flag"));
            }
            if (["ship", "location"].includes(entry.type)) {
                const using = context.currentAsset?.uuid === uuid;
                items.push(item("useAsset", using ? "Current asset" : "Use this asset", "fas fa-check", using));
            }
        }
        openActionMenu({ anchor, items, onClose: () => {
            anchor.setAttribute("aria-expanded", "false");
            this.menuAnchor = null;
        } });
        this.menuAnchor = anchor;
        anchor.setAttribute("aria-expanded", "true");
    }
    static async action(event, button) {
        event.preventDefault(); event.stopPropagation();
        if (button.dataset.action === "options" || (event.button === 2 && button.dataset.uuid)) {
            const anchor = button.closest(".pg-entry")?.querySelector(".pg-entry-menu") || button;
            this.openEntryMenu(anchor, button.dataset.uuid);
            return;
        }
        if (event.button === 2) return;
        await this.performAction(button.dataset.action, button.dataset);
    }
    async performAction(action, { uuid, filter } = {}) {
        if (this.busy) return;
        this.busy = true;
        this.message = "";
        try {
            if (this.userId !== game.user.id && !["open", "filter"].includes(action)) return;
            if (action === "open") await openGatewayEntity(uuid, { userId: this.userId });
            else if (action === "pin") await updateGatewayPin({ uuid, remove: getGatewayPins().some(pin => pin.uuid === uuid) });
            else if (action === "actor") await openPlayerEntity(uuid, { actor: true });
            else if (action === "useAsset" || action === "clearAsset") await selectPlayerAsset(action === "clearAsset" ? "" : uuid);
            else if (action === "filter") this.filter = filter;
            else if (action === "primaryShip" || action === "clearPrimaryShip") await selectPrimaryPlayerShip(action === "clearPrimaryShip" ? "" : uuid);
            else if (action === "primaryFaction" || action === "clearPrimaryFaction") await selectPrimaryPlayerFaction(action === "clearPrimaryFaction" ? "" : uuid);
        } catch (error) { this.message = error.message; }
        finally { this.busy = false; }
        await this.render({ force: true });
    }
}
