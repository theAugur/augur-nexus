import { getPlayerSetupData, assignPlayerShip } from "../../api/player-context.js";
import { openShipCreator, setShipPlayerVisibility } from "../../api/ships.js";

export async function createPlayerIdentityShip(userId, { onAssigned } = {}) {
    if (!game.user.isGM) throw new Error("Only the GM can create a player's Ship.");
    const setup = getPlayerSetupData();
    const user = setup.users.find(row => row.id === userId);
    if (!user) throw new Error("The selected player no longer exists.");
    const expectedActorUuid = user.shipActorUuid || "";
    const actor = expectedActorUuid ? setup.actors.find(row => row.uuid === expectedActorUuid) : null;
    if (expectedActorUuid && !actor) throw new Error("The selected Actor no longer exists.");
    if (actor && setup.entities.some(row => row.actorUuid === actor.uuid)) throw new Error("That Actor already has a linked campaign entity.");
    if (user.shipUuid) throw new Error("Unlink the current Nexus Ship before creating another.");
    const expectedShipUuid = "";
    // Capture both saved assignments so a delayed creator cannot replace newer Setup choices.
    return openShipCreator({ onCreated: async entity => {
        try {
            await assignPlayerShip(userId, entity.uuid, { expectedActorUuid, expectedShipUuid });
            await setShipPlayerVisibility(entity.uuid, "show");
            await onAssigned?.();
        } catch (error) {
            ui.notifications.warn(`${entity.display?.name || "The Ship"} was created, but setup could not be completed: ${error.message} Review Player Identity - Setup.`);
        }
    } });
}
