import { hasPremiumAccess } from "../access/PremiumAccess.js";
import { openPlayerHome, openPlayerSetup, refreshPlayerHomes, refreshPlayerWorkspaceAccess, isOwnGmWheelHidden } from "../../api/player-gateway.js";
import { isPlayerWheelEnabled, isPlayerWheelEnabledFor } from "./PlayerGatewayAvailability.js";
import { registerGatewayDossiers } from "./PlayerGatewayDossiers.js";

const MODULE_ID = "augur-nexus";
const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const report = error => ui.notifications.error(error.message || "Player Wheel could not be opened.");
class HomeMenu extends HandlebarsApplicationMixin(ApplicationV2) {
    render() { return openPlayerHome().catch(report); }
}
class SetupMenu extends HandlebarsApplicationMixin(ApplicationV2) {
    render() { return openPlayerSetup().catch(report); }
}

export function registerPlayerGatewayFeature() {
    const enabled = hasPremiumAccess();
    for (const [key, data] of Object.entries({
        playerGatewayEnabled: { name: "Enable Player Wheel", hint: "Allow the Player Wheel for all players and GMs. Disabling it closes wheels. Player Setup remains available.", scope: "world", config: enabled, restricted: true, type: Boolean, default: true, onChange: () => {
            void refreshPlayerHomes({ show: true }).catch(report);
            if (ui.controls) void ui.controls.render({ reset: true }).catch(report);
            Hooks.callAll("augurNexusAppearanceChanged");
        } },
        allowPlayerWorkspace: { name: "Allow Player Campaign Nexus Access", hint: "Allow players to use Campaign Nexus. Disabling closes their open Campaign Nexus windows; standalone dossiers remain available. GMs keep access.", scope: "world", config: true, restricted: true, type: Boolean, default: true, onChange: () => { void refreshPlayerWorkspaceAccess().catch(report); } },
        playerGatewayUserEnabled: { scope: "world", config: false, restricted: true, type: Object, default: {}, onChange: () => { void refreshPlayerHomes({ show: true }).catch(report); } },
        playerGatewayOptions: { scope: "world", config: false, restricted: true, type: Object, default: {}, onChange: () => { void refreshPlayerHomes().catch(report); } },
        gmPlayerWheelHidden: { scope: "client", config: false, type: Boolean, default: false },
        playerGatewayHotkeysExpanded: { scope: "client", config: false, type: Boolean, default: true },
        playerGatewayPosition: { scope: "client", config: false, type: Object, default: {} },
        playerGatewayCollapsed: { scope: "client", config: false, type: Boolean, default: false },
        playerGatewayTheme: { name: "Player Wheel: appearance", scope: "world", config: false, type: String, choices: { arcane: "Whispering stone", tech: "Personal interface" }, default: "arcane" }
    })) game.settings.register(MODULE_ID, key, { ...data, onChange: key === "playerGatewayTheme" ? refreshPlayerHomes : data.onChange });
    if (!enabled) return;
    game.settings.registerMenu(MODULE_ID, "playerHome", { name: "Player Wheel", label: "Open Player Wheel", hint: "Your character and assigned campaign entities.", icon: "fas fa-compass", type: HomeMenu, restricted: false });
    game.settings.registerMenu(MODULE_ID, "playerSetup", { name: "Player Setup", label: "Configure players", hint: "Link characters, assign campaign entities, and preview player access.", icon: "fas fa-users-gear", type: SetupMenu, restricted: true });
    game.keybindings.register(MODULE_ID, "openPlayerHome", { name: "Open Player Wheel", editable: [], onDown: () => { if (!isPlayerWheelEnabledFor()) return false; void openPlayerHome().catch(report); return true; } });
    Hooks.on("updateUser", () => { void refreshPlayerHomes().catch(report); });
    Hooks.on("augurNexusPlayerContextChanged", refreshPlayerHomes);
    Hooks.on("augurNexusAppearanceChanged", refreshPlayerHomes);
    Hooks.on("augurNexusQuestsChanged", refreshPlayerHomes);
    for (const type of ["Item", "Macro", "JournalEntryPage", "RollTable", "Token", "Scene"]) {
        Hooks.on(`update${type}`, refreshPlayerHomes);
        Hooks.on(`delete${type}`, refreshPlayerHomes);
    }
    Hooks.once("ready", () => {
        if (isPlayerWheelEnabledFor() && !isOwnGmWheelHidden() && (!game.user.isGM || game.user.character)) void openPlayerHome({ automatic: true }).catch(report);
    });
    registerGatewayDossiers();
}
