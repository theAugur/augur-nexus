import { openPlayerHome, openPlayerSetup, refreshPlayerHomes } from "../../api/player-gateway.js";
import { registerGatewayDossiers } from "./PlayerGatewayDossiers.js";

const MODULE_ID = "augur-nexus";
const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const report = error => ui.notifications.error(error.message || "Player Wheel could not be opened.");
class HomeMenu extends HandlebarsApplicationMixin(ApplicationV2) {
    render() { return openPlayerHome().catch(report); }
}
class SetupMenu extends HandlebarsApplicationMixin(ApplicationV2) {
    render() { return openPlayerSetup().catch(report); }
}

export function registerPlayerGatewayFeature() {
    const enabled = !!(game.modules.get("augur-fantasy")?.active || game.modules.get("augur-scifi")?.active);
    for (const [key, data] of Object.entries({
        playerGatewayVisible: { scope: "client", config: false, type: Boolean, default: true },
        playerGatewayPosition: { scope: "client", config: false, type: Object, default: {} },
        playerGatewayCollapsed: { scope: "client", config: false, type: Boolean, default: false },
        playerGatewayTheme: { name: "Player Wheel: appearance", scope: "world", config: enabled, type: String, choices: { arcane: "Whispering stone", tech: "Personal interface" }, default: "arcane" }
    })) game.settings.register(MODULE_ID, key, { ...data, onChange: key === "playerGatewayTheme" ? refreshPlayerHomes : undefined });
    if (!enabled) return;
    game.settings.registerMenu(MODULE_ID, "playerHome", { name: "Player Wheel", label: "Open Player Wheel", hint: "Your character and assigned campaign entities.", icon: "fas fa-compass", type: HomeMenu, restricted: false });
    game.settings.registerMenu(MODULE_ID, "playerSetup", { name: "Player Identity - Setup", label: "Configure players", hint: "Link characters, assign campaign entities, and preview player access.", icon: "fas fa-users-gear", type: SetupMenu, restricted: true });
    game.keybindings.register(MODULE_ID, "openPlayerHome", { name: "Open Player Wheel", editable: [], onDown: () => { void openPlayerHome().catch(report); return true; } });
    Hooks.on("getSceneControlButtons", controls => {
        // A personal campaign home remains relevant across scene types; this is deliberately scene-independent.
        if (!controls.tokens?.tools) return;
        controls.tokens.tools.augurPlayerHome = { name: "augurPlayerHome", title: "Player Wheel", icon: "fas fa-compass", order: 90, button: true, onChange: () => void openPlayerHome().catch(report) };
        if (game.user.isGM) controls.tokens.tools.augurPlayerSetup = { name: "augurPlayerSetup", title: "Player Identity - Setup", icon: "fas fa-users-gear", order: 91, button: true, onChange: () => void openPlayerSetup().catch(report) };
    });
    Hooks.on("augurNexusPlayerContextChanged", refreshPlayerHomes);
    Hooks.on("augurNexusAppearanceChanged", refreshPlayerHomes);
    Hooks.on("augurNexusQuestsChanged", refreshPlayerHomes);
    for (const type of ["Item", "Macro", "JournalEntryPage", "RollTable", "Token", "Scene"]) {
        Hooks.on(`update${type}`, refreshPlayerHomes);
        Hooks.on(`delete${type}`, refreshPlayerHomes);
    }
    Hooks.once("ready", () => {
        if ((!game.user.isGM || game.user.character) && game.settings.get(MODULE_ID, "playerGatewayVisible")) void openPlayerHome().catch(report);
    });
    registerGatewayDossiers();
}
