export function classifyDnd5eActor(actor) {
    if (actor.type === "character") return { kind: "person", personImportEligible: true, suggestedEntityType: "npc" };
    if (actor.type === "vehicle") return { kind: "vehicle", suggestedEntityType: "ship" };
    if (["group", "encounter"].includes(actor.type)) return { kind: "group", suggestedEntityType: "faction" };
    if (actor.type !== "npc") return { kind: "other" };
    const type = actor.system?.details?.type;
    const creatureType = String(typeof type === "string" ? type : type?.value || "").trim().toLowerCase();
    if (!creatureType) return { kind: "unknown" };
    return creatureType === "humanoid"
        ? { kind: "person", personImportEligible: true, suggestedEntityType: "npc" }
        : { kind: "creature" };
}
