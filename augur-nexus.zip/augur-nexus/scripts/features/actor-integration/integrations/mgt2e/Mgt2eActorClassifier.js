export function classifyMgt2eActor(actor) {
    if (["traveller", "npc"].includes(actor.type)) {
        return { kind: "person", personImportEligible: true, suggestedEntityType: "npc" };
    }
    if (actor.type === "spacecraft") return { kind: "vehicle", suggestedEntityType: "ship" };
    if (["creature", "swarm"].includes(actor.type)) return { kind: "creature" };
    // Ground vehicles and robots do not imply a Nexus Ship or Person.
    if (["robot", "vehicle", "world", "package"].includes(actor.type)) return { kind: "other" };
    return { kind: "unknown" };
}
