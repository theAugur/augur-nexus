export function classifyPf2eActor(actor) {
    if (actor.type === "character") return { kind: "person", personImportEligible: true, suggestedEntityType: "npc" };
    if (actor.type === "vehicle") return { kind: "vehicle", suggestedEntityType: "ship" };
    if (["party", "army"].includes(actor.type)) return { kind: "group", suggestedEntityType: "faction" };
    if (actor.type !== "npc") return { kind: "other" };
    const traits = actor.system?.traits?.value;
    if (!Array.isArray(traits) || !traits.length) return { kind: "unknown" };
    return traits.includes("humanoid")
        ? { kind: "person", personImportEligible: true, suggestedEntityType: "npc" }
        : { kind: "creature" };
}
