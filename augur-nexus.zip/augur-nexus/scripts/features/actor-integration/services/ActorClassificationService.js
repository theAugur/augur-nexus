import { classifyDnd5eActor } from "../integrations/dnd5e/Dnd5eActorClassifier.js";
import { classifyPf2eActor } from "../integrations/pf2e/Pf2eActorClassifier.js";
import { classifyMgt2eActor } from "../integrations/mgt2e/Mgt2eActorClassifier.js";

const classifiers = { dnd5e: classifyDnd5eActor, pf2e: classifyPf2eActor, mgt2e: classifyMgt2eActor };

/** Read-only interpretation; eligibility is a suggestion, never permission to create. */
export class ActorClassificationService {
    static classify(actor, systemId = game.system?.id) {
        const classification = classifiers[systemId]?.(actor || {}) || { kind: "unknown" };
        return { personImportEligible: false, suggestedEntityType: "", ...classification };
    }
}
