import { ActorClassificationService } from "./ActorClassificationService.js";
import { CampaignEntityActorBridge } from "../../campaign-entities/services/CampaignEntityActorBridge.js";
import { CampaignEntityActorImportGateway } from "../../campaign-entities/services/CampaignEntityActorImportGateway.js";
import { CampaignEntityJournalStore } from "../../campaign-entities/services/CampaignEntityJournalStore.js";
import { CampaignEntityVisibilityManager } from "../../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";

export class ActorResolutionService {
    static #pending = new Map();
    static #unlinkedImports = new Map();

    static async resolve(reference, options = {}) {
        const actor = await this.#actor(reference);
        if (!actor) return this.#reject("Drop an accessible world Actor from the Actors directory.");
        const policy = {
            allowedEntityTypes: ["npc", "faction", "ship"], defaultEntityType: "",
            allowActorOnly: false, promptWhenLinked: false, convertActors: true,
            reuseLinkedActors: options.convertActors !== false && game.user.isGM, importPolicy: "explicit", ...options
        };
        const key = JSON.stringify(policy);
        const pending = this.#pending.get(actor.uuid);
        if (pending) {
            if (pending.key === key) return pending.promise;
            await pending.promise;
            return this.resolve(reference, { ...policy, promptWhenLinked: false });
        }
        const promise = this.#resolve(actor, policy);
        this.#pending.set(actor.uuid, { key, promise });
        try { return await promise; }
        finally { if (this.#pending.get(actor.uuid)?.promise === promise) this.#pending.delete(actor.uuid); }
    }

    static async #actor(reference) {
        const uuid = typeof reference === "string" ? reference
            : reference?.uuid || (reference?.id || reference?._id ? `Actor.${reference.id || reference._id}` : "");
        if (!/^Actor\.[A-Za-z0-9]+$/.test(uuid)) return null;
        const actor = await fromUuid(uuid).catch(() => null);
        return actor?.documentName === "Actor" && !actor.pack && !actor.inCompendium && !actor.isToken
            && (game.user.isGM || actor.testUserPermission(game.user, "OBSERVER")) ? actor : null;
    }

    static #visible(entity) {
        if (game.user.isGM) return true;
        const document = CampaignEntityJournalStore.resolveCampaignEntityDocument(entity.id);
        return !!document?.testUserPermission(game.user, "OBSERVER")
            && (CampaignEntityVisibilityManager.canUserSee(entity, game.user) || canControlPlayerEntity(document, game.user));
    }

    static #linkedResult(actor, entity, policy) {
        if (policy.allowedEntityTypes.includes(entity.type) && this.#visible(entity)) return { mode: "entity", entity, actor };
        if (policy.allowActorOnly) return { mode: "actor", actor };
        return this.#reject("This Actor's linked Nexus entity cannot be used here.");
    }

    static async #resolve(actor, policy) {
        const raw = () => ({ mode: "actor", actor });
        if (policy.convertActors === false && !policy.reuseLinkedActors) return raw();
        const linked = CampaignEntityActorBridge.getLinkedEntityForActor(actor);
        if (linked && policy.reuseLinkedActors) {
            if (!policy.promptWhenLinked || !game.user.isGM || !this.#visible(linked)
                || !policy.allowedEntityTypes.includes(linked.type)) return this.#linkedResult(actor, linked, policy);
        }
        if (policy.convertActors === false || !game.user.isGM) return raw();
        if (!actor.isOwner) return policy.allowActorOnly ? raw() : this.#reject("You do not have permission to import this Actor.");
        const classification = ActorClassificationService.classify(actor);
        if (policy.importPolicy === "person" && !classification.personImportEligible) return policy.allowActorOnly ? raw() : this.#reject("This Actor is not eligible for Person import here.");
        const allowed = [...new Set(policy.allowedEntityTypes)]
            .filter(type => policy.importPolicy !== "person" || type === "npc")
            .filter(type => ["npc", "faction", "ship"].includes(type))
            .filter(type => CampaignEntityActorImportGateway.isTypeAvailable(type) || linked?.type === type);
        if (!allowed.length) {
            if (policy.allowActorOnly) return raw();
            await CampaignEntityActorImportGateway.openRequiredModuleGateway(policy.defaultEntityType || policy.allowedEntityTypes[0]);
            return { mode: "cancelled" };
        }
        const suggestedType = linked ? "linked" : policy.importPolicy === "person" && policy.allowActorOnly ? "actor"
            : allowed.includes(classification.suggestedEntityType) ? classification.suggestedEntityType
            : allowed.includes(policy.defaultEntityType) ? policy.defaultEntityType : allowed[0];
        const choice = await CampaignEntityActorImportGateway.prompt(actor, { allowed, suggestedType, allowActorOnly: policy.allowActorOnly, linkedEntity: linked });
        if (!choice) return { mode: "cancelled" };
        // The prompt may stay open while ownership, visibility, or links change elsewhere.
        actor = await this.#actor(actor.uuid);
        if (!actor) return this.#reject("That Actor is no longer accessible.");
        if (choice === "actor" && policy.allowActorOnly) return { mode: "actor", actor };
        const currentLink = CampaignEntityActorBridge.getLinkedEntityForActor(actor);
        if (choice === "linked") return currentLink ? this.#linkedResult(actor, currentLink, policy) : this.#reject("The Actor link changed. Drop it again.");
        if (!allowed.includes(choice) || !game.user.isGM || !actor.isOwner) return this.#reject("You do not have permission to import this Actor.");
        if (policy.importPolicy === "person" && !ActorClassificationService.classify(actor).personImportEligible) return { mode: "actor", actor };
        if (currentLink && currentLink.id !== linked?.id) return this.#linkedResult(actor, currentLink, policy);
        const previousImport = this.#unlinkedImports.get(actor.uuid);
        if (previousImport && previousImport.type !== choice) return this.#reject("A previous import needs its Actor link completed. Retry with the same entity type.");
        const entity = previousImport || await CampaignEntityActorImportGateway.createEntity(choice, actor);
        this.#unlinkedImports.set(actor.uuid, entity);
        const linkedActor = await CampaignEntityActorBridge.linkActor(entity, actor);
        if (!linkedActor) throw new Error("The Nexus entity was created, but its Actor link could not be completed. Retry the import to finish linking it.");
        this.#unlinkedImports.delete(actor.uuid);
        ui.notifications.info(`${actor.name} imported and linked to Nexus.`);
        return { mode: "entity", entity, actor };
    }

    static #reject(message) { ui.notifications.warn(message); return { mode: "rejected", message }; }
}
