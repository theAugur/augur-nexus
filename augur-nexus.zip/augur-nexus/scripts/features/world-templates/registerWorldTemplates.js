import { TEMPLATE_SCOPE, TEMPLATE_FLAG } from "./models/RaceTemplate.js";
import { EntityPlacementTab } from "../site/applications/tabs/EntityPlacementTab.js";

export function registerWorldTemplates() {
    const changed = detail => Hooks.callAll("augurNexusWorldTemplatesChanged", detail);
    Hooks.on("augurNexusWorldTemplatesChanged", detail => {
        EntityPlacementTab.onWorldTemplatesChanged(detail).catch(error => console.error("Augur: Nexus | Could not refresh template choices", error));
    });
    game.settings.register(TEMPLATE_SCOPE, "hiddenWorldTemplates", {
        scope: "world", config: false, type: Array, default: [], onChange: () => changed({ reason: "visibility" })
    });
    for (const hook of ["createJournalEntry", "updateJournalEntry", "deleteJournalEntry"]) {
        Hooks.on(hook, document => {
            const template = document.getFlag(TEMPLATE_SCOPE, TEMPLATE_FLAG);
            if (template) changed({ reason: hook, deletedId: hook === "deleteJournalEntry" ? template.id : "" });
        });
    }
}
