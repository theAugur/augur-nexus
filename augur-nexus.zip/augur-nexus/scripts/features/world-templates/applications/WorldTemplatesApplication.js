import { raceLabel, racePoolKeys } from "../models/RaceTemplate.js";
import { ToolWindowLifecycle } from "../../../support/toolbar/ToolWindowLifecycle.js";
import { WorldTemplateCatalog as Catalog } from "../services/WorldTemplateCatalog.js";
import { RaceSources } from "../services/RaceSources.js";
import { TemplateTransfer } from "../services/TemplateTransfer.js";
import { normalizeTemplate } from "../models/TemplateDefinition.js";
import { ROLE_POOL_KEYS } from "../models/RoleTemplate.js";
import { PersonalityTraitRegistry } from "../../campaign-entities/services/PersonalityTraitRegistry.js";

const { ApplicationV2, HandlebarsApplicationMixin, DialogV2 } = foundry.applications.api;
const FilePicker = foundry.applications.apps.FilePicker.implementation;

export class WorldTemplatesApplication extends HandlebarsApplicationMixin(ApplicationV2) {
    static #instance = null;
    #draft = null;
    #type = "race";
    #raceTab = "people";
    #previewRace = "";
    #previewGenre = "fantasy";
    #racePreviewProvider = "";
    #builtin = false;
    #saveQueue = Promise.resolve(true);
    #pendingSaves = 0;
    #saveError = false;
    #search = "";
    #sample = null;
    #previewError = "";
    #portraits = new Map();
    #busy = false;
    #changeHook = null;
    #expandedNamePool = null;
    #expandedPortraitSources = new Set();

    static DEFAULT_OPTIONS = {
        id: "augur-world-templates", classes: ["augur-nexus", "augur-theme-fantasy", "world-templates"],
        tag: "div", window: { title: "Nexus Templates", icon: "fas fa-books", resizable: true },
        position: { width: 980, height: 740 },
        actions: Object.fromEntries(["select", "new", "copy", "hide", "retrySave", "delete", "addImage", "addFolder",
            "removeImage", "removeFolder", "clearImages", "setIcon", "addTrait", "removeTrait", "raceTab", "togglePortraits", "token", "refresh", "preview", "export", "import", "toggleNames"].map(action => [action, WorldTemplatesApplication._onAction]))
    };
    static PARTS = {
        main: { template: "modules/augur-nexus/templates/world-templates/library.hbs", forms: { ".wt-form": { closeOnSubmit: false, handler: WorldTemplatesApplication._onSubmit } }, scrollable: [".wt-list", ".wt-editor"] }
    };

    static async open() {
        Catalog.requireGM();
        return ToolWindowLifecycle.open("world-templates", () => this.#instance ||= new this());
    }

    constructor(options = {}) {
        super(options);
        this.#changeHook = Hooks.on("augurNexusWorldTemplatesChanged", () => { if (this.rendered && !this.#pendingSaves) this.render(); });
    }

    async close(options = {}) {
        if (!await this.#flushSaves()) return this;
        Hooks.off("augurNexusWorldTemplatesChanged", this.#changeHook);
        WorldTemplatesApplication.#instance = null;
        const result = await super.close(options);
        ToolWindowLifecycle.released(this);
        return result;
    }

    async _prepareContext() {
        const isRole = this.#type === "role";
        const races = await Catalog.list(this.#type, { includeHidden: true });
        if (!this.#draft && races.length) this.#select(races[0]);
        const query = this.#search.trim().toLocaleLowerCase();
        const entries = races.filter(race => race.label.toLocaleLowerCase().includes(query)).map(race => ({
            ...race, selected: race.id === this.#draft?.id, sourceLabel: race.builtin ? game.modules.get(race.moduleId)?.title || "Module" : "Custom",
            image: isRole ? "icons/svg/book.svg" : race.icon.thumb || race.icon.imageSrc || racePoolKeys(race).map(key => race.portraits[key].images[0]).filter(Boolean)
                .map(image => image.thumb || image.imageSrc)[0] || "icons/svg/mystery-man.svg"
        }));
        const civilization = !isRole && this.#draft ? await Catalog.civilizationEditor(this.#draft) : null;
        if (!civilization) this.#raceTab = "people";
        const namePools = [], portraitPools = [];
        if (this.#draft) {
            for (const key of isRole ? ROLE_POOL_KEYS : this.#raceTab === "civilization" ? ["settlement"] : [...racePoolKeys(this.#draft), "surname"]) {
                const pool = (isRole ? this.#draft.pools : this.#draft.names)[key];
                const table = pool.tableUuid ? await fromUuid(pool.tableUuid).catch(() => null) : null;
                const names = pool.text.split(isRole ? /\r?\n/ : /[,\n]/).map(name => name.trim()).filter(Boolean);
                namePools.push({ key, field: `${isRole ? "pools" : "names"}.${key}`, label: isRole ? key[0].toUpperCase() + key.slice(1) : key === "surname" ? "Surnames (optional)" : key === "neutral" ? "First names" : `${key === "female" ? "Female" : "Male"} first names`,
                    expanded: this.#expandedNamePool === key, names, count: names.length,
                    isSettlement: key === "settlement", isDefault: pool.mode === "default",
                    summary: pool.mode === "table" ? table?.name || "No table available" : names.slice(0, 4).join(" · ") + (names.length > 4 ? " …" : "") || (isRole ? "No entries yet" : "No names yet"),
                    ...pool, isTable: pool.mode === "table", tableName: table?.name || pool.tableUuid || "Drop a RollTable here",
                    tables: game.tables.contents.map(table => ({ uuid: table.uuid, name: table.name, selected: table.uuid === pool.tableUuid })) });
                if (key === "settlement") {
                    namePools.at(-1).label = "Settlement names";
                    if (pool.mode === "default") namePools.at(-1).summary = "Uses settlement style names";
                }
            }
            for (const key of isRole ? [] : racePoolKeys(this.#draft)) {
                const pool = this.#draft.portraits[key];
                if (!this.#portraits.has(key)) {
                    const folders = await Promise.all(pool.folders.map(async folder => {
                        try { return { ...folder, images: await RaceSources.portraits({ folders: [folder] }) }; }
                        catch (error) { return { ...folder, images: [], error: error.message }; }
                    }));
                    this.#portraits.set(key, folders);
                }
                const folders = this.#portraits.get(key);
                const sources = [
                    ...(pool.images.length ? [{ sourceKey: `${key}:images`, label: "Individual images", images: pool.images, isFolder: false }] : []),
                    ...folders.map((folder, index) => ({ ...folder, sourceKey: `${key}:folder:${index}`, index,
                        label: folder.path.split(/[\\/]/).filter(Boolean).at(-1) || folder.path, isFolder: true }))
                ].map(source => ({ ...source, pool: key, count: source.images.length,
                    expanded: this.#expandedPortraitSources.has(source.sourceKey),
                    images: source.images.map((image, index) => ({ ...image, index,
                        isIcon: image.imageSrc === this.#draft.icon.imageSrc,
                        label: image.label || image.imageSrc.split("/").pop(), previewSrc: image.thumb || image.imageSrc })) }));
                portraitPools.push({ key, label: key === "neutral" ? "Portraits" : `${key === "female" ? "Female" : "Male"} portraits`,
                    count: new Set(sources.flatMap(source => source.images.map(image => image.imageSrc))).size, sources });
            }
        }
        const traits = isRole ? await PersonalityTraitRegistry.load() : [];
        const raceProviders = Catalog.racePreviewOptions();
        if (!raceProviders.some(row => row.id === this.#racePreviewProvider)) this.#racePreviewProvider = raceProviders.find(row => this.#draft?.id.startsWith(`${row.id}:`))?.id || raceProviders[0]?.id || "";
        const availableRaces = isRole ? await Catalog.listRaces() : [];
        if (!availableRaces.some(race => race.id === this.#previewRace)) this.#previewRace = availableRaces[0]?.id || "";
        if (isRole && this.#draft?.genre !== "both") this.#previewGenre = this.#draft?.genre || "fantasy";
        const previewIssues = await this.#previewIssues();
        return { entries, hasEntries: entries.length > 0, search: this.#search, hasDraft: !!this.#draft,
            previewDisabled: this.#busy || previewIssues.length > 0, previewHelp: previewIssues.join(" ") || this.#previewError,
            isRole, civilization, civilizationTab: !isRole && this.#raceTab === "civilization", peopleTab: this.#raceTab === "people",
            chooseRacePreviewProvider: raceProviders.length > 1, racePreviewProviders: raceProviders.map(row => ({ ...row, selected: row.id === this.#racePreviewProvider })),
            typeLabel: isRole ? "role" : "race", typePlural: isRole ? "roles" : "races",
            genreOptions: ["fantasy", "scifi", "both"].map(id => ({ id, label: id === "scifi" ? "Sci-fi" : id === "both" ? "Both" : "Fantasy", selected: id === this.#draft?.genre })),
            previewGenres: ["fantasy", "scifi"].filter(id => this.#draft?.genre === "both" || this.#draft?.genre === id).map(id => ({ id, label: id === "scifi" ? "Sci-fi" : "Fantasy", selected: id === this.#previewGenre })),
            previewFantasy: isRole && this.#previewGenre === "fantasy",
            previewRaces: availableRaces.map(race => ({ id: race.id, label: race.label, selected: race.id === this.#previewRace })),
            traits: traits.filter(trait => !this.#draft?.traitWeights?.some(row => row.id === trait.id)),
            traitRows: (this.#draft?.traitWeights || []).map((row, index) => ({ ...row, index, label: traits.find(trait => trait.id === row.id)?.label || traits.find(trait => trait.id === row.id)?.name || row.id,
                weights: [1, 2, 3].map(value => ({ value, label: ["Normal", "Favored", "Strongly favored"][value - 1], selected: value === row.weight })) })),
            preferredTags: this.#draft?.portrait?.preferredTags.join(", ") || "", excludedTags: this.#draft?.portrait?.excludedTags.join(", ") || "",
            draft: this.#draft, label: raceLabel(this.#draft), builtin: this.#builtin, saveError: this.#saveError, saveStatus: this.#saveStatus(),
            canEdit: !this.#builtin && !this.#busy,
            isBinary: this.#draft?.genderMode === "binary", hidden: this.#draft ? !Catalog.isVisible(this.#draft.id) : false,
            namePools, portraitPools, sample: this.#sample, busy: this.#busy };
    }

    async _onChangeForm(config, event) {
        super._onChangeForm(config, event);
        const { name, value } = event.target;
        if (name === "templateType") {
            if (!await this.#flushSaves()) return;
            this.#type = value === "role" ? "role" : "race"; this.#search = ""; this.#select(null); return this.render();
        }
        if (name === "previewRace" || name === "previewGenre") {
            if (name === "previewRace") this.#previewRace = value; else this.#previewGenre = value;
            this.#sample = null; return this.render();
        }
        if (name === "racePreviewProvider") { this.#racePreviewProvider = value; this.#sample = null; return this.render(); }
        if (name === "search") { this.#search = value; return this.render(); }
        if (this.#builtin || !this.#draft || this.#busy) return;
        if (name.startsWith("civilization.")) {
            const field = name.slice("civilization.".length);
            const group = event.target.closest("[data-civilization-field]");
            const input = group?.dataset.multiple === "true"
                ? [...group.querySelectorAll("input:checked")].map(element => element.value)
                : event.target.type === "checkbox" ? event.target.checked : value;
            await Catalog.updateCivilization(this.#draft, group.dataset.moduleId, field, input);
            await this.#persist();
            return this.render();
        }
        if (/^traitWeights\.\d+\.weight$/.test(name) || /^portrait\.(preferredTags|excludedTags)$/.test(name)) {
            foundry.utils.setProperty(this.#draft, name, name.startsWith("portrait.") ? value.split(",").map(tag => tag.trim()).filter(Boolean) : Number(value));
            this.#sample = null; await this.#persist(); return;
        }
        if (name === "name" || name === "genderMode" || name === "genre" || /^(names|pools)\.(neutral|male|female|surname|settlement|descriptor|drive|action|theme|focus)\.(mode|text|tableUuid)$/.test(name)) {
            if (name.split(".").reduce((value, key) => value?.[key], this.#draft) === value) return;
            foundry.utils.setProperty(this.#draft, name, value);
            this.#sample = null;
            const saved = this.#persist();
            if (name === "name") {
                for (const label of this.element.querySelectorAll("[data-current-label]")) label.textContent = raceLabel(this.#draft);
            }
            await saved;
            if (name.startsWith("names.")) await this.#updatePreviewHelp();
            if (name !== "name" && !name.endsWith(".text")) this.render();
        }
    }

    _attachPartListeners(partId, element, options) {
        super._attachPartListeners(partId, element, options);
        // Foundry forms emit change on blur; persist text input without replacing the focused editor.
        element.addEventListener("input", event => {
            if (event.target.name === "name" || /^(names|pools)\..*\.text$/.test(event.target.name) || event.target.name?.startsWith("portrait.")) void this._onChangeForm({}, event);
        });
        element.addEventListener("dragover", event => { if (event.target.closest("[data-name-pool]")) event.preventDefault(); });
        element.addEventListener("drop", async event => {
            const target = event.target.closest("[data-name-pool]");
            if (!target || this.#builtin || this.#busy) return;
            event.preventDefault();
            try {
                const data = JSON.parse(event.dataTransfer.getData("text/plain"));
                const table = data.uuid ? await fromUuid(data.uuid) : null;
                RaceSources.tableRows(table);
                const pools = this.#type === "role" ? this.#draft.pools : this.#draft.names;
                pools[target.dataset.namePool] = { ...pools[target.dataset.namePool], mode: "table", tableUuid: table.uuid };
                this.#sample = null;
                await this.#persist();
                this.render();
            } catch (error) { ui.notifications.warn(error.message || "Drop a RollTable containing plain-text names."); }
        });
    }

    static async _onSubmit(event) {
        event.preventDefault();
        await this.#flushSaves();
    }

    static async _onAction(event, target) {
        if (this.#busy) return;
        try { await this.#act(target.dataset.action, target.dataset); }
        catch (error) { console.error("Augur: Nexus | World Templates", error); ui.notifications.error(error.message); }
    }

    async #act(action, data) {
        Catalog.requireGM();
        if (action === "raceTab") {
            if (!await this.#flushSaves()) return;
            this.#raceTab = data.tab === "civilization" ? "civilization" : "people";
        } else if (action === "toggleNames") {
            this.#expandedNamePool = this.#expandedNamePool === data.pool ? null : data.pool;
        } else if (action === "togglePortraits") {
            if (!this.#expandedPortraitSources.delete(data.source)) this.#expandedPortraitSources.add(data.source);
        } else if (action === "select") {
            if (data.id === this.#draft?.id || !await this.#flushSaves()) return;
            this.#select(await Catalog.get(data.id));
        } else if (action === "new" || action === "copy") {
            if (!await this.#flushSaves()) return;
            this.#select(Catalog.createDraft(action === "copy" ? this.#draft : { type: this.#type }));
            await this.#persist();
        } else if (action === "hide") {
            const id = data.id || this.#draft?.id;
            if (id) await Catalog.setHidden(id, Catalog.isVisible(id));
        } else if (action === "retrySave") {
            await this.#persist();
        } else if (action === "delete") {
            if (this.#builtin || !this.#draft) return;
            if (!await DialogV2.confirm({ window: { title: "Delete template?" }, content: "<p>Delete this custom template? Existing NPCs, name tables and image files will be kept.</p>" })) return;
            await this.#saveQueue;
            await Catalog.delete(this.#draft.id); this.#select(null);
        } else if (action === "refresh") this.#portraits.clear();
        else if (action === "preview") {
            this.#previewError = "";
            if ((await this.#previewIssues()).length) { this.render(); return; }
            this.#busy = true;
            this.#sample = null;
            this.render();
            try { this.#sample = await Catalog.preview(this.#draft, { genre: this.#previewGenre, raceId: this.#previewRace, moduleId: this.#racePreviewProvider }); }
            catch (error) { this.#previewError = error.message || "Could not generate an example. Check the race’s sources and try again."; }
            finally { this.#busy = false; this.render(); }
            return;
        } else if (action === "addImage" || action === "addFolder" || action === "token") {
            if (this.#builtin) return;
            const id = this.#draft.id;
            const picker = new FilePicker({ type: action === "addFolder" ? "folder" : "image", callback: async (path, app) => {
                if (!path || this.#draft?.id !== id) return;
                const pool = this.#draft.portraits[data.pool];
                if (action === "addFolder") pool.folders.push({ source: app.activeSource || "data", path, bucket: app.sources?.s3?.bucket || "" });
                else if (action === "token") pool.images[Number(data.index)].tokenImageSrc = path;
                else if (!pool.images.some(image => image.imageSrc === path)) pool.images.push({ imageSrc: path, tokenImageSrc: "", label: "", tags: [] });
                if (action !== "token" && !this.#draft.icon.imageSrc) {
                    let portrait = pool.images[0];
                    if (!portrait && action === "addFolder") {
                        try { [portrait] = await RaceSources.portraits({ folders: [pool.folders.at(-1)] }); }
                        catch { /* Keep the source editable; the folder preview explains unavailable paths. */ }
                    }
                    if (this.#draft?.id !== id) return;
                    if (portrait && !this.#draft.icon.imageSrc) this.#draft.icon = { imageSrc: portrait.imageSrc, thumb: portrait.thumb || "" };
                }
                this.#portraits.delete(data.pool); this.#sample = null;
                await this.#persist(); this.render();
            } });
            picker.render({ force: true }); return;
        } else if (action === "addTrait" || action === "removeTrait") {
            if (this.#builtin || this.#type !== "role") return;
            if (action === "removeTrait") this.#draft.traitWeights.splice(Number(data.index), 1);
            else {
                const id = this.element.querySelector('[name="newTrait"]').value;
                if (!id || this.#draft.traitWeights.some(row => row.id === id)) return;
                this.#draft.traitWeights.push({ id, weight: 1 });
            }
            this.#sample = null; await this.#persist();
        } else if (action === "setIcon") {
            if (this.#builtin) return;
            this.#draft.icon = { imageSrc: data.image, thumb: data.thumb || "" };
            await this.#persist();
        } else if (action === "clearImages") {
            if (this.#builtin) return;
            this.#draft.portraits[data.pool].images = [];
            this.#sample = null;
            await this.#persist();
        } else if (action === "removeImage" || action === "removeFolder") {
            if (this.#builtin) return;
            this.#draft.portraits[data.pool][action === "removeImage" ? "images" : "folders"].splice(Number(data.index), 1);
            if (action === "removeFolder") {
                for (const key of this.#expandedPortraitSources) if (key.startsWith(`${data.pool}:folder:`)) this.#expandedPortraitSources.delete(key);
            }
            this.#portraits.delete(data.pool); this.#sample = null;
            await this.#persist();
        } else if (action === "export") {
            if (!await this.#flushSaves()) return;
            const collection = await TemplateTransfer.export(Catalog.customRaces());
            const blob = new Blob([JSON.stringify(collection, null, 2)], { type: "application/json" });
            const url = URL.createObjectURL(blob), anchor = document.createElement("a");
            anchor.href = url; anchor.download = "world-templates.json"; anchor.click();
            setTimeout(() => URL.revokeObjectURL(url), 1000); return;
        } else if (action === "import") {
            if (!await this.#flushSaves()) return;
            const input = document.createElement("input"); input.type = "file"; input.accept = ".json,application/json";
            input.addEventListener("change", async () => {
                try {
                    if (!input.files[0]) return;
                    const plan = TemplateTransfer.inspect(JSON.parse(await input.files[0].text()));
                    if (plan.templates.some(template => template.type !== "race")) throw new Error("This release imports race templates only. Choose a collection containing only races.");
                    if ((plan.overwriteCount || plan.tableOverwriteCount) && !await DialogV2.confirm({ window: { title: "Import Nexus Templates?" },
                        content: `<p>This will overwrite ${plan.overwriteCount} custom templates and ${plan.tableOverwriteCount} name tables already in this world. Continue?</p>` })) return;
                    if (!await this.#flushSaves()) return;
                    this.#busy = true;
                    const count = await TemplateTransfer.import(plan);
                    this.#select(null);
                    ui.notifications.info(`Imported ${count} templates.`);
                } catch (error) { ui.notifications.error(error.message); }
                finally { this.#busy = false; this.render(); }
            }, { once: true });
            input.click(); return;
        }
        this.render();
    }

    #select(race) {
        this.#previewError = "";
        this.#racePreviewProvider = "";
        this.#draft = race ? normalizeTemplate(race) : null;
        this.#builtin = race?.builtin === true;
        this.#expandedNamePool = null;
        this.#expandedPortraitSources.clear();
        this.#saveError = false; this.#sample = null; this.#portraits.clear();
    }

    async #previewIssues() {
        if (!this.#draft || this.#type === "role") return [];
        const issues = [];
        if (!Catalog.racePreviewOptions().length) issues.push("Activate an NPC generator module to generate an example.");
        for (const key of [...racePoolKeys(this.#draft), "surname"]) {
            const label = key === "surname" ? "Surnames" : key === "neutral" ? "First names" : `${key === "female" ? "Female" : "Male"} first names`;
            try {
                if (!(await RaceSources.names(this.#draft.names[key])).length && key !== "surname") issues.push(`${label}: add at least one name or choose a name table.`);
            } catch (error) { issues.push(`${label}: ${error.message}`); }
            if (key === "surname") continue;
            const portraitLabel = key === "neutral" ? "Portraits" : `${key === "female" ? "Female" : "Male"} portraits`;
            const folders = this.#portraits.get(key);
            try {
                const failed = folders?.find(folder => folder.error);
                if (failed) throw new Error(failed.error);
                const images = folders ? [...this.#draft.portraits[key].images, ...folders.flatMap(folder => folder.images)] : await RaceSources.portraits(this.#draft.portraits[key]);
                if (!images.length) issues.push(`${portraitLabel}: add an image or a folder containing portraits.`);
            } catch (error) { issues.push(`${portraitLabel}: ${error.message} Check the folder and use Refresh portraits.`); }
        }
        return issues;
    }

    async #updatePreviewHelp() {
        this.#previewError = "";
        const issues = await this.#previewIssues();
        const button = this.element?.querySelector('[data-action="preview"]');
        if (button) button.disabled = this.#busy || issues.length > 0;
        const help = this.element?.querySelector("[data-preview-help]");
        if (help) { help.textContent = issues.join(" "); help.hidden = !issues.length; }
    }

    #saveStatus() {
        return this.#pendingSaves ? "Saving…" : this.#saveError ? "Changes could not be saved." : "Changes saved automatically";
    }

    #persist() {
        if (!this.#draft || this.#builtin) return Promise.resolve(true);
        const snapshot = structuredClone(this.#draft);
        this.#pendingSaves++;
        this.#updateSaveStatus();
        // Serialize this editor's writes so rapid input cannot save an older value last.
        this.#saveQueue = this.#saveQueue.then(async () => {
            try {
                await Catalog.save(snapshot);
                this.#saveError = false;
                return true;
            } catch (error) {
                this.#saveError = true;
                ui.notifications.error(`Could not save template: ${error.message}`);
                return false;
            } finally {
                this.#pendingSaves--;
                this.#updateSaveStatus();
            }
        });
        return this.#saveQueue;
    }

    #updateSaveStatus() {
        const status = this.element?.querySelector("[data-save-status]");
        if (status) status.textContent = this.#saveStatus();
        const retry = this.element?.querySelector('[data-action="retrySave"]');
        if (retry) retry.hidden = !this.#saveError || !!this.#pendingSaves;
    }

    async #flushSaves() {
        while (this.#pendingSaves) await this.#saveQueue;
        return !this.#saveError || await this.#persist();
    }
}
