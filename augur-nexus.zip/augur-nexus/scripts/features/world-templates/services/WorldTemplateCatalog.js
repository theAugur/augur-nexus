import { normalizeRace, raceLabel, TEMPLATE_SCOPE, TEMPLATE_FLAG } from "../models/RaceTemplate.js";
import { normalizeRole } from "../models/RoleTemplate.js";
import { normalizeTemplate } from "../models/TemplateDefinition.js";

const providers = new Map();
const roleProviders = new Map();

export class WorldTemplateCatalog {
    static registerRoles({ moduleId, genre, getRoles, preview }) {
        if (!moduleId || typeof getRoles !== "function") throw new Error("Role providers require moduleId and getRoles.");
        roleProviders.set(moduleId, { genre, getRoles, preview });
    }

    static customTemplates(type) {
        return game.journal.contents.flatMap(doc => {
            const data = doc.getFlag(TEMPLATE_SCOPE, TEMPLATE_FLAG);
            return data && ["race", "role"].includes(data.type) && (!type || data.type === type)
                ? [{ ...normalizeTemplate({ ...data, name: doc.name }), builtin: false }] : [];
        });
    }

    static async listRoles({ includeHidden = false, genre } = {}) {
        const roles = this.customTemplates("role");
        for (const [moduleId, provider] of roleProviders) {
            if (!game.modules.get(moduleId)?.active) continue;
            for (const input of await provider.getRoles()) {
                if (!input.id?.startsWith(`${moduleId}:`)) throw new Error("Role IDs must be module-qualified.");
                roles.push({ ...normalizeRole(input), builtin: true, moduleId });
            }
        }
        return roles.map(role => ({ ...role, label: raceLabel(role), hidden: !this.isVisible(role.id) }))
            .filter(role => (includeHidden || !role.hidden) && (!genre || role.genre === genre || role.genre === "both"))
            .sort((a, b) => a.label.localeCompare(b.label));
    }

    static async getRole(id, { moduleId, ...options } = {}) {
        const roles = await this.listRoles(options);
        return roles.find(role => role.id === id || (moduleId && role.moduleId === moduleId && role.legacyId === id)) || null;
    }

    static async list(type, options) { return type === "role" ? this.listRoles(options) : this.listRaces(options); }
    static async get(id) { return (await this.listRaces({ includeHidden: true })).find(row => row.id === id) || this.getRole(id, { includeHidden: true }); }
    static registerRaces({ moduleId, label, getRaces, preview, civilization }) {
        if (!moduleId || typeof getRaces !== "function") throw new Error("Race providers require a module ID and getRaces function.");
        providers.set(moduleId, { label, getRaces, preview, civilization });
    }

    static racePreviewOptions() {
        return [...providers].filter(([moduleId, provider]) => game.modules.get(moduleId)?.active && provider.preview)
            .map(([id, provider]) => ({ id, label: provider.label || game.modules.get(id)?.title || id }));
    }

    static async civilizationEditor(race) {
        if (race?.type !== "race") return null;
        for (const [moduleId, provider] of providers) {
            if (game.modules.get(moduleId)?.active && provider.civilization) {
                return { moduleId, ...await provider.civilization.getEditor(race) };
            }
        }
        return null;
    }

    static async updateCivilization(race, moduleId, field, value) {
        this.requireGM();
        const provider = providers.get(moduleId);
        if (!game.modules.get(moduleId)?.active || !provider?.civilization) throw new Error("Civilization editor is unavailable.");
        await provider.civilization.update(race, field, value);
    }

    static document(id) {
        return game.journal.contents.find(doc => doc.getFlag(TEMPLATE_SCOPE, TEMPLATE_FLAG)?.id === id) || null;
    }

    static customRaces() {
        return this.customTemplates("race");
    }

    static isVisible(id) {
        return !(game.settings.get(TEMPLATE_SCOPE, "hiddenWorldTemplates") || []).includes(id);
    }

    static async listRaces({ includeHidden = false } = {}) {
        const builtins = [];
        for (const [moduleId, provider] of providers) {
            if (!game.modules.get(moduleId)?.active) continue;
            for (const race of await provider.getRaces()) {
                if (!race.id?.startsWith(`${moduleId}:`)) throw new Error(`Race IDs from ${moduleId} must be module-qualified.`);
                builtins.push({ ...normalizeRace(race), builtin: true, moduleId });
            }
        }
        return [...builtins, ...this.customRaces()]
            .map(race => ({ ...race, label: raceLabel(race), hidden: !this.isVisible(race.id) }))
            .filter(race => includeHidden || !race.hidden)
            .sort((a, b) => a.label.localeCompare(b.label));
    }

    static async getRace(id, { includeHidden = false } = {}) {
        return (await this.listRaces({ includeHidden })).find(race => race.id === id) || null;
    }

    static async save(input) {
        this.requireGM();
        const race = normalizeTemplate(input);
        if (!race.id.startsWith("custom:")) throw new Error("Module templates are read-only. Create a copy to edit them.");
        const { name, ...data } = race;
        const document = this.document(race.id);
        if (document && document.getFlag(TEMPLATE_SCOPE, TEMPLATE_FLAG)?.type !== race.type) throw new Error("Cannot replace a different template type.");
        if (document) {
            const flags = structuredClone(document.flags);
            flags[TEMPLATE_SCOPE] = { ...flags[TEMPLATE_SCOPE], [TEMPLATE_FLAG]: data };
            // Imports replace the definition, including removed fields, while preserving unrelated flags.
            await document.update({ name: name.trim() || "Unnamed", flags }, { recursive: false });
        }
        else await JournalEntry.create({ name: name.trim() || "Unnamed", ownership: { default: 0 }, flags: { [TEMPLATE_SCOPE]: { [TEMPLATE_FLAG]: data } } });
        return race.id;
    }

    static createDraft(source = {}) {
        return normalizeTemplate({ ...source, id: `custom:${foundry.utils.randomID(24)}`, name: source.id ? `${raceLabel(source)} copy` : "" });
    }

    static async delete(id) {
        this.requireGM();
        if (!id.startsWith("custom:")) throw new Error("Module templates cannot be deleted.");
        await this.document(id)?.delete();
    }

    static async setHidden(id, hidden) {
        this.requireGM();
        const ids = new Set(game.settings.get(TEMPLATE_SCOPE, "hiddenWorldTemplates") || []);
        if (hidden) ids.add(id); else ids.delete(id);
        await game.settings.set(TEMPLATE_SCOPE, "hiddenWorldTemplates", [...ids]);
    }

    static async preview(race, options = {}) {
        if (race.type === "role") {
            for (const [moduleId, provider] of roleProviders) {
                if (game.modules.get(moduleId)?.active && provider.preview && (race.genre === "both" || race.genre === provider.genre)
                    && (!options.genre || provider.genre === options.genre)) return provider.preview(normalizeRole(race), options);
            }
            throw new Error("Activate a compatible NPC generator to preview this role.");
        }
        const choices = this.racePreviewOptions();
        const selected = options.moduleId ? choices.find(row => row.id === options.moduleId)
            : choices.find(row => race.id.startsWith(`${row.id}:`)) || choices[0];
        if (selected) return providers.get(selected.id).preview(normalizeRace(race));
        throw new Error("Activate an NPC race generator to preview this template.");
    }

    static requireGM() { if (!game.user?.isGM) throw new Error("Only GMs can manage World Templates."); }
}
