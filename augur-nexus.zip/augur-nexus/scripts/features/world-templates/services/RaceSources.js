import { racePoolKeys, raceLabel } from "../models/RaceTemplate.js";

export class RaceSources {
    static tableRows(table) {
        if (table?.documentName !== "RollTable") throw new Error("Choose a Foundry RollTable for this name pool.");
        return Array.from(table.results || []).map(row => {
            if (row.type !== CONST.TABLE_RESULT_TYPES.TEXT) throw new Error(`“${table.name}” must contain only plain-text name results.`);
            const text = String(row.name || row.description || "").trim();
            if (/<[^>]*>/.test(text)) throw new Error(`“${table.name}” contains formatted text. Use plain names.`);
            return { text, weight: Math.max(0, Number(row.weight ?? 1)) };
        }).filter(row => row.text && Number.isFinite(row.weight) && row.weight > 0);
    }

    static async names(pool = {}) {
        if (pool.mode === "table") {
            if (!pool.tableUuid) throw new Error("Choose a name table or switch this pool to pasted names.");
            const table = await fromUuid(pool.tableUuid);
            if (!table) throw new Error(`Name table is unavailable: ${pool.tableUuid}`);
            return this.tableRows(table);
        }
        return String(pool.text || "").split(/[,\r\n]+/).map(text => ({ text: text.trim(), weight: 1 })).filter(row => row.text);
    }

    static async portraits(pool = {}) {
        const images = [...(pool.images || [])];
        for (const folder of pool.folders || []) {
            let result;
            try {
                result = await foundry.applications.apps.FilePicker.implementation.browse(folder.source || "data", folder.path,
                    { ...(folder.bucket ? { bucket: folder.bucket } : {}), extensions: [".png", ".jpg", ".jpeg", ".webp", ".gif", ".avif"] });
            } catch (error) {
                throw new Error(`Portrait folder is unavailable: ${folder.path}`, { cause: error });
            }
            for (const imageSrc of result.files || []) {
                if (/\.(png|jpe?g|webp|gif|avif)(?:[?#].*)?$/i.test(imageSrc)) images.push({ imageSrc, tokenImageSrc: "", label: imageSrc.split("/").pop() });
            }
        }
        const unique = new Map();
        for (const image of images) if (!unique.has(image.imageSrc)) unique.set(image.imageSrc, image);
        return [...unique.values()];
    }

    static async resolve(race) {
        const names = {}, portraits = {}, errors = {};
        for (const key of racePoolKeys(race)) {
            try { [names[key], portraits[key]] = await Promise.all([this.names(race.names[key]), this.portraits(race.portraits[key])]); }
            catch (error) { errors[key] = error.message; }
        }
        names.surname = await this.names(race.names.surname);
        return { race, names, portraits, errors };
    }

    static pickName(rows, random = Math.random) {
        let cursor = random() * rows.reduce((sum, row) => sum + row.weight, 0);
        for (const row of rows) { cursor -= row.weight; if (cursor < 0) return row.text; }
        return rows.at(-1)?.text || "";
    }

    static async sample(race, { gender = "random", random = Math.random, excludedPortraits = [], selectPortrait = null } = {}) {
        const sources = await this.resolve(race);
        const resolvedGender = ["male", "female"].includes(gender) ? gender : random() < .5 ? "female" : "male";
        const key = race.genderMode === "binary" ? resolvedGender : "neutral";
        if (sources.errors?.[key]) throw new Error(sources.errors[key]);
        if (!sources.names[key]?.length) throw new Error(`${raceLabel(race)} has no ${key === "neutral" ? "first" : key + " first"} names.`);
        const pool = sources.portraits[key] || [];
        if (!pool.length) throw new Error(`${raceLabel(race)} has no ${key === "neutral" ? "" : key + " "}portraits.`);
        const unused = pool.filter(image => !excludedPortraits.includes(image.imageSrc));
        const available = unused.length ? unused : pool;
        const portrait = selectPortrait ? selectPortrait(available, random) : available[Math.floor(random() * available.length)];
        return {
            name: [this.pickName(sources.names[key], random), this.pickName(sources.names.surname, random)].filter(Boolean).join(" "),
            gender: resolvedGender, portrait
        };
    }
}
