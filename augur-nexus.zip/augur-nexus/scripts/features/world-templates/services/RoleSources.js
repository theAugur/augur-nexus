import { RaceSources } from "./RaceSources.js";

export class RoleSources {
    static async rows(pool) {
        if (pool.mode === "table") return RaceSources.names(pool);
        return pool.text.split(/\r?\n/).map(text => ({ text: text.trim(), weight: 1 })).filter(row => row.text);
    }

    static async sample(role, { random = Math.random } = {}) {
        const properties = { roleId: role.legacyId || role.id, roleLabel: role.name.trim() || "Unnamed" };
        for (const [key, pool] of Object.entries(role.pools)) {
            properties[key] = RaceSources.pickName(await this.rows(pool), random);
        }
        return properties;
    }
}
