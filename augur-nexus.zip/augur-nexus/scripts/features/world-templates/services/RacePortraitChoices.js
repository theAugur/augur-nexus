import { WorldTemplateCatalog } from "./WorldTemplateCatalog.js";
import { RaceSources } from "./RaceSources.js";
import { racePoolKeys, raceLabel } from "../models/RaceTemplate.js";

/** Existing NPCs may still browse their own hidden race. No source reference controls their saved image. */
export async function addWorldRacePortraits(portraits, sourceRaceId = "") {
    const races = await WorldTemplateCatalog.listRaces({ includeHidden: true });
    const allowed = races.filter(race => !race.hidden || race.id === sourceRaceId);
    const result = portraits.filter(portrait => {
        const id = `${portrait.moduleId}:race:${portrait.speciesId}`;
        return !races.some(race => race.id === id && race.hidden && race.id !== sourceRaceId);
    });
    for (const race of allowed.filter(race => !race.builtin)) {
        const seen = new Set();
        for (const key of racePoolKeys(race)) {
            let images;
            try { images = await RaceSources.portraits(race.portraits[key]); }
            catch (error) { ui.notifications.warn(error.message); images = race.portraits[key].images; }
            for (const image of images) {
                if (seen.has(image.imageSrc)) continue;
                seen.add(image.imageSrc);
                result.push({ ...image, id: `${race.id}:${image.imageSrc}`, speciesId: race.id, speciesLabel: raceLabel(race),
                    label: image.label || raceLabel(race), meta: raceLabel(race), tokenImageSrc: image.tokenImageSrc || image.imageSrc });
            }
        }
    }
    return result;
}
