import { TEMPLATE_SCOPE } from "../models/RaceTemplate.js";
import { WorldTemplateCatalog } from "./WorldTemplateCatalog.js";
import { normalizeTemplate, templatePools } from "../models/TemplateDefinition.js";
import { RaceSources } from "./RaceSources.js";

export class TemplateTransfer {
    static async export(races = WorldTemplateCatalog.customTemplates()) {
        WorldTemplateCatalog.requireGM();
        const tables = new Map();
        const templates = races.map(normalizeTemplate);
        for (const race of templates) {
            for (const pool of templatePools(race)) {
                if (pool.mode !== "table" || !pool.tableUuid) continue;
                const table = await fromUuid(pool.tableUuid);
                if (!table) throw new Error(`Cannot export missing text table: ${pool.tableUuid}`);
                const id = table.getFlag(TEMPLATE_SCOPE, "worldTemplateTableId") || table.uuid;
                if (!tables.has(id)) tables.set(id, { id, uuid: id, name: table.name, rows: RaceSources.tableRows(table) });
                pool.tableUuid = id;
            }
        }
        return { format: "augur-world-templates", version: 1, templates, tables: [...tables.values()] };
    }

    static inspect(data) {
        if (data?.format !== "augur-world-templates" || data.version !== 1 || !Array.isArray(data.templates) || !Array.isArray(data.tables)) {
            throw new Error("This file is not a supported World Templates collection.");
        }
        const ids = new Set();
        const templates = data.templates.map(entry => {
            if (!["race", "role"].includes(entry?.type) || entry.schemaVersion !== 1 || !/^custom:[A-Za-z0-9]+$/.test(entry.id || "") || ids.has(entry.id)) {
                throw new Error("The collection contains an unsupported, duplicate, or protected template ID.");
            }
            const existing = WorldTemplateCatalog.document(entry.id);
            if (existing && existing.getFlag(TEMPLATE_SCOPE, "worldTemplate")?.type !== entry.type) throw new Error("Cannot overwrite a different template type.");
            ids.add(entry.id);
            return normalizeTemplate(entry);
        });
        const tableIds = new Set(), tableUuids = new Set();
        const tables = data.tables.map(table => {
            if (!table?.id || !table.uuid || !Array.isArray(table.rows) || tableIds.has(table.id) || tableUuids.has(table.uuid)) {
                throw new Error("The collection contains an invalid or duplicate text table.");
            }
            tableIds.add(table.id); tableUuids.add(table.uuid);
            const rows = table.rows.map(row => {
                if (typeof row.text !== "string" || /<[^>]*>/.test(row.text) || !Number.isSafeInteger(row.weight) || row.weight <= 0) {
                    throw new Error("Imported text tables must contain weighted plain-text entries.");
                }
                return { text: row.text, weight: row.weight };
            });
            return { id: String(table.id), uuid: String(table.uuid), name: String(table.name || "Names"), rows };
        });
        for (const template of templates) {
            for (const pool of templatePools(template)) {
                if (pool.mode === "table" && pool.tableUuid && !tableUuids.has(pool.tableUuid)) throw new Error("A referenced text table is missing from this collection.");
            }
        }
        return { templates, tables, overwriteCount: templates.filter(template => WorldTemplateCatalog.document(template.id)).length,
            tableOverwriteCount: tables.filter(table => this.findTable(table.id)).length };
    }

    static findTable(id) {
        return game.tables.contents.find(candidate => candidate.getFlag(TEMPLATE_SCOPE, "worldTemplateTableId") === id || candidate.uuid === id);
    }

    static async import(plan) {
        WorldTemplateCatalog.requireGM();
        const uuids = new Map();
        for (const table of plan.tables) {
            let document = this.findTable(table.id);
            let cursor = 1;
            const results = table.rows.map(row => {
                const start = cursor;
                cursor += Math.max(1, Math.round(row.weight));
                return { type: CONST.TABLE_RESULT_TYPES.TEXT, name: row.text, description: row.text, weight: row.weight, range: [start, cursor - 1], drawn: false };
            });
            const fields = { name: table.name, formula: `1d${Math.max(1, cursor - 1)}`, replacement: true, displayRoll: false,
                flags: { [TEMPLATE_SCOPE]: { worldTemplateTableId: table.id } } };
            if (document) {
                await document.deleteEmbeddedDocuments("TableResult", document.results.map(result => result.id));
                await document.update(fields);
                await document.createEmbeddedDocuments("TableResult", results);
            } else document = await RollTable.create({ ...fields, results, ownership: { default: 0 } });
            uuids.set(table.uuid, document.uuid);
        }
        for (const template of plan.templates) {
            const race = normalizeTemplate(template);
            for (const pool of templatePools(race)) {
                if (pool.mode === "table" && pool.tableUuid) pool.tableUuid = uuids.get(pool.tableUuid);
            }
            await WorldTemplateCatalog.save(race);
        }
        return plan.templates.length;
    }
}
