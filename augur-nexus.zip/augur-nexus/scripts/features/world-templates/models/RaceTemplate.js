export const TEMPLATE_SCOPE = "augur-nexus";
export const TEMPLATE_FLAG = "worldTemplate";
export const POOL_KEYS = ["neutral", "female", "male"];

export function normalizeRace(input = {}) {
    const names = {};
    const portraits = {};
    for (const key of [...POOL_KEYS, "surname", "settlement"]) {
        const pool = input.names?.[key] || {};
        names[key] = {
            mode: pool.mode === "table" ? "table" : key === "settlement" && pool.mode !== "text" ? "default" : "text",
            text: String(pool.text || ""),
            tableUuid: String(pool.tableUuid || "").trim()
        };
    }
    for (const key of POOL_KEYS) {
        const pool = input.portraits?.[key] || {};
        portraits[key] = {
            images: (Array.isArray(pool.images) ? pool.images : []).map(image => ({
                id: String(image.id || ""),
                gender: String(image.gender || ""),
                imageSrc: String(image.imageSrc || "").trim(),
                tokenImageSrc: String(image.tokenImageSrc || "").trim(),
                thumb: String(image.thumb || "").trim(),
                label: String(image.label || ""),
                tags: Array.isArray(image.tags) ? image.tags.map(String) : []
            })).filter(image => image.imageSrc),
            folders: (Array.isArray(pool.folders) ? pool.folders : []).map(folder => ({
                source: String(folder.source || "data"), path: String(folder.path || "").trim(),
                bucket: String(folder.bucket || "")
            })).filter(folder => folder.path)
        };
    }
    return {
        schemaVersion: 1, type: "race", id: String(input.id || ""), name: String(input.name || ""),
        icon: { imageSrc: String(input.icon?.imageSrc || ""), thumb: String(input.icon?.thumb || "") },
        genderMode: input.genderMode === "binary" ? "binary" : "any", names, portraits,
        moduleData: structuredClone(input.moduleData || {})
    };
}

export function raceLabel(race) { return String(race?.name || "").trim() || "Unnamed"; }
export function racePoolKeys(race) { return race.genderMode === "binary" ? ["female", "male"] : ["neutral"]; }
