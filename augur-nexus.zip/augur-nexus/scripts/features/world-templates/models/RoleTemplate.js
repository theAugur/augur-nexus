export const ROLE_POOL_KEYS = ["descriptor", "drive", "action", "theme", "focus"];

export function normalizeRole(input = {}) {
    const pools = Object.fromEntries(ROLE_POOL_KEYS.map(key => {
        const pool = input.pools?.[key] || {};
        return [key, { mode: pool.mode === "table" ? "table" : "text", text: String(pool.text || ""), tableUuid: String(pool.tableUuid || "") }];
    }));
    const tags = values => [...new Set((Array.isArray(values) ? values : []).map(value => String(value).trim()).filter(Boolean))];
    return { schemaVersion: 1, type: "role", id: String(input.id || ""), name: String(input.name || ""),
        genre: ["fantasy", "scifi", "both"].includes(input.genre) ? input.genre : "fantasy", pools,
        legacyId: String(input.id || "").startsWith("custom:") ? "" : String(input.legacyId || ""),
        traitWeights: (input.traitWeights || []).map(row => ({ id: String(row.id || ""), weight: Math.min(3, Math.max(1, Number(row.weight) || 1)) })).filter(row => row.id),
        portrait: { preferredTags: tags(input.portrait?.preferredTags), excludedTags: tags(input.portrait?.excludedTags) },
        tags: tags(input.tags) };
}
