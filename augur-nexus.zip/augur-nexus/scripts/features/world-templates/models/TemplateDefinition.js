import { normalizeRace } from "./RaceTemplate.js";
import { normalizeRole } from "./RoleTemplate.js";

export function normalizeTemplate(input = {}) {
    if (input.type === "role") return normalizeRole(input);
    if (input.type && input.type !== "race") throw new Error("Unsupported template type.");
    return normalizeRace(input);
}

export function templatePools(template) { return Object.values(template.type === "role" ? template.pools : template.names); }
