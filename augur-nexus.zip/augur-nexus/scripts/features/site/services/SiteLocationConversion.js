import { LOCATION_DOSSIER_VIEW_IDS } from "../../campaign-entities/services/LocationDossierViewIds.js";
import { SiteRecordManager } from "./SiteRecordManager.js";
import { SiteLocationJournalTransfer } from "./SiteLocationJournalTransfer.js";
import { SiteLocationConversionRefresh } from "./SiteLocationConversionRefresh.js";
import { SitePlayerVisibility } from "./SitePlayerVisibility.js";
import { resolveSiteIconSrc } from "./SiteIconDefaults.js";
import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { LocationSceneService } from "../../campaign-entities/services/LocationSceneService.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { ConnectionGraphLayoutStore } from "../../connections/services/ConnectionGraphLayoutStore.js";
import { JournalAssociationService } from "../../connections/services/JournalAssociationService.js";
import { NexusLineageManager } from "../../nexus/services/NexusLineageManager.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";
import { DevelopedRegionProviderRegistry } from "../../region-dossier/DevelopedRegionProviderRegistry.js";
import { requestPremiumAccess, requirePremiumAccess } from "../../access/PremiumAccess.js";

const MODULE = "augur-nexus";
const ORDINARY = new Set(["empty", "existing", "from-image", "instant-dungeons-generator"]);
const copy = value => foundry.utils.deepClone(value);
const contents = collection => collection?.contents || [...(collection?.values?.() || [])];
const equal = (a,b) => JSON.stringify(a) === JSON.stringify(b);

/** An explicit ownership transfer; ordinary Site/Location deletion must never be used here. */
export class SiteLocationConversion {
    static #pending = new Set();

    static source({ sceneId = null, parentSceneId = null, siteId = null, record = null, scene = null } = {}) {
        scene ||= sceneId ? game.scenes.get(sceneId) : null;
        if (!record && siteId && parentSceneId) record = SiteRecordManager.getSceneRecord(game.scenes.get(parentSceneId), siteId);
        if (!record && scene) record = SiteRecordManager.findSiteRecordForLinkedScene(scene);
        const parent = record ? game.scenes.get(record.parentSceneId) : null;
        if (record) {
            record = parent && SiteRecordManager.getSceneRecord(parent, record.siteId);
            if (!record) throw new Error("The original Site record could not be resolved safely.");
            scene = game.scenes.get(record.linkedSceneId || record.siteSceneId) || null;
        }
        if (!record && !scene) throw new Error("This place could not be found.");
        const flags = scene?.flags || {};
        const type = record?.siteSceneType || flags[MODULE]?.rootSceneCreation?.sceneType || "empty";
        if (!ORDINARY.has(type) || Object.keys(flags["augur-scifi"] || {}).length
            || Object.keys(flags.hexlands || {}).length || Object.keys(flags["augur-fantasy"]?.region || {}).length) {
            throw new Error("Only ordinary Sites and Scenes can be converted; Sci-Fi places and generated regions are excluded.");
        }
        if (scene && (scene.id === NexusLineageManager.getRootScene()?.id || DevelopedRegionProviderRegistry.find({scene,record,user:game.user}))) {
            throw new Error("The Nexus root and developed regions cannot be converted.");
        }
        if (scene && LocationSceneService.getLocationForScene(scene.id)) throw new Error("This Scene already belongs to a Location.");
        if (scene) {
            const owners = contents(game.scenes).flatMap(parent => SiteRecordManager.getSceneRecordList(parent))
                .filter(site => (site.linkedSceneId || site.siteSceneId) === scene.id);
            if (owners.length > 1 || (!record && flags[MODULE]?.site?.siteId)) throw new Error("This Scene has ambiguous Site ownership.");
        }
        const target = record ? ConnectionTargetResolver.fromSiteRecord(record) : ConnectionTargetResolver.fromSceneReference({sceneId:scene.id});
        const graph = ConnectionStore.getGraph();
        const hasEdges = id => Object.values(graph.edges || {}).some(edge => edge.sourceNodeId === id || edge.targetNodeId === id);
        const sceneTarget = scene && ConnectionTargetResolver.fromSceneReference({sceneId:scene.id});
        const ambiguousGraph = record && hasEdges(target.id) && hasEdges(sceneTarget?.id);
        return {record,parent,scene,target,ambiguousGraph,graphTarget:record && sceneTarget && hasEdges(sceneTarget.id) ? sceneTarget : target,
            name:record?.siteName || scene.name, icon:record ? resolveSiteIconSrc(record.siteIconSrc) : target.img || "",
            subtitle:record ? SiteRecordManager.getDossierSubtitle(record,{fallback:""}) : scene.flags?.[MODULE]?.placePreview?.subtitle || "",
            coverImageSrc:record ? record.coverImageSrc || "" : scene.flags?.[MODULE]?.placePreview?.coverImageSrc || ""};
    }

    static menuItem(context, {onConverted=null} = {}) {
        if (!game.user.isGM) return null;
        try { this.source(context); } catch { return null; }
        return {id:"convert-to-location",label:"Convert to Location",icon:"fas fa-map-location-dot",onSelect:()=>this.request(context,{onConverted})};
    }

    static async request(context,{onConverted=null}={}) {
        if (!game.user.isGM || !await requestPremiumAccess("location")) return null;
        try {
            const plan = await this.preflight(context);
            const esc = foundry.utils.escapeHTML;
            const journalMessage = plan.journalMode === "reused" ? "Its dedicated Journal is reused." : plan.journalMode === "transferred" ? "Its notes move into a dedicated Location Journal." : "A dedicated Location Journal is created.";
            const confirmed = await foundry.applications.api.DialogV2.confirm({window:{title:"Convert to Location"},modal:true,rejectClose:false,
                content:`<p>Convert <strong>${esc(plan.name)}</strong> into a Location?</p><p>Keeps the existing Scene and transfers its notes, connections, and place in the hierarchy. ${journalMessage} Player visibility is preserved. The Site entry is replaced by the Location. No Scene is deleted.</p>`,
                yes:{label:"Convert to Location"},no:{label:"Cancel"}});
            if (!confirmed) return null;
            const entity = await this.convert(context);
            await onConverted?.(entity);
            return entity;
        } catch(error) { console.error("Augur Nexus | Site conversion failed",error);ui.notifications.warn(error.message || "This place could not be converted.");return null; }
    }

    static async preflight(context) {
        if (!game.user.isGM) throw new Error("Only the GM can convert a place.");
        requirePremiumAccess("location");
        const source = this.source(context);
        const {record,parent,scene,target} = source;
        // Opening a generator Site creates its map; conversion must not retire that pending work.
        if (!scene && record?.siteSceneType === "instant-dungeons-generator") {
            throw new Error("Open this Site first to generate its scene, then come back to convert it to a Location.");
        }
        if (source.ambiguousGraph) throw new Error("The Site and its Scene have separate connections. Resolve these two identities before converting.");
        if (record && !scene && contents(game.scenes).some(child => child.flags?.[MODULE]?.lineage?.parentSiteId === record.siteId && child.flags[MODULE].lineage.parentSceneId === parent.id)) {
            throw new Error("This Site has Scene children but no linked Scene. Link its Scene before converting.");
        }
        const page = await JournalAssociationService.getJournalPage(target);
        if (record?.journalPageId && !page) throw new Error("The Site notes page is missing.");
        for (const worldScene of contents(game.scenes)) for (const note of contents(worldScene.notes)) {
            const flags = note.flags?.[MODULE];
            if (record && flags?.site && flags.siteId === record.siteId && worldScene.id === parent.id) throw new Error("This Site uses a legacy Note marker. Convert its marker before converting the Site.");
        }
        for (const macro of contents(game.macros)) if (record && String(macro.command || "").includes(record.siteId)) {
            throw new Error("A Macro directly references this Site. Update that Macro before converting.");
        }
        const journalRef={...record,journalEntryId:page?.parent?.id || record?.journalEntryId || null,journalPageId:page?.id || record?.journalPageId || null};
        return {...source,page,journalMode:SiteLocationJournalTransfer.describe(journalRef,{sourceTarget:target})};
    }

    static async convert(context) {
        const plan = await this.preflight(context);
        if (this.#pending.has(plan.target.id)) throw new Error("This place is already being converted.");
        this.#pending.add(plan.target.id);
        const undo=[];let journal;
        const writeFlags = async (document,next) => {
            const before=copy(document.flags?.[MODULE] || {});
            undo.push(()=>document.update({[`flags.==${MODULE}`]:before}));
            await document.update({[`flags.==${MODULE}`]:next});
        };
        const write = async (document,patch) => {
            const before=Object.fromEntries(Object.keys(patch).map(path=>[path,copy(path.split(".").reduce((value,key)=>value?.[key],document))]));
            undo.push(()=>document.update(before));await document.update(patch);
        };
        try {
            await ConnectionGraphLayoutStore.flush();
            const {record,parent,scene,target,graphTarget,page}=plan;
            const sourceLayouts=copy(scene?.flags?.[MODULE]?.connectionGraphLayouts || page?.flags?.[MODULE]?.connectionGraphLayouts || record?.graphLayouts || {});
            const lineage=scene?.flags?.[MODULE]?.lineage || {};
            const hierarchy=record ? {kind:"scene",sceneId:parent.id} : lineage.parentSceneId
                ? lineage.parentSiteId ? {kind:"site",parentSceneId:lineage.parentSceneId,siteId:lineage.parentSiteId} : {kind:"scene",sceneId:lineage.parentSceneId} : null;
            const visible=record ? SitePlayerVisibility.isVisible({scene:parent,record,siteId:record.siteId,linkedScene:scene})
                : NexusPlayerSceneAccess.isNexusVisibilityVisible(NexusPlayerSceneAccess.getSceneNexusVisibilityOverride(scene));
            const journalRef={...record,journalEntryId:page?.parent?.id || record?.journalEntryId || null,journalPageId:page?.id || record?.journalPageId || null};
            journal=await SiteLocationJournalTransfer.prepare(journalRef,{display:{name:plan.name,imageSrc:plan.icon,thumbnailSrc:plan.icon,coverImageSrc:plan.coverImageSrc,color:record?.siteColor || "#d18a42"},
                profile:{kindId:"location",kindLabel:plan.subtitle,type:""},dossier:{viewId:LOCATION_DOSSIER_VIEW_IDS.settlement},hierarchy:{parent:hierarchy},access:{playerVisibility:visible?"show":"hide"}}, {sourceTarget:target});
            const entity=journal.entity, destination=ConnectionTargetResolver.fromCampaignEntity(entity,journal.document);
            const ids=new Map([[target.id,destination.id],[graphTarget.id,destination.id]]);
            const markerTarget={kind:"campaign-entity",entityType:"location",entityId:entity.id,journalEntryId:journal.document.id,uuid:journal.document.uuid};
            const matches=value=>record ? value?.kind==="nexus-site" && value.siteId===record.siteId && value.parentSceneId===parent.id
                : value?.kind==="nexus-scene" && value.sceneId===scene.id;
            const remap=value=>{
                if(typeof value==="string") return ids.get(value) || (journal.oldPageUuid && value===journal.oldPageUuid ? journal.newPageUuid : value);
                if(Array.isArray(value))return value.map(remap);
                if(!value || typeof value!=="object")return value;
                if(matches(value))return {...markerTarget};
                return Object.fromEntries(Object.entries(value).map(([key,entry])=>[ids.get(key)||key,remap(entry)]));
            };
            const remapLayouts=layouts=>Object.fromEntries(Object.entries(layouts||{}).map(([context,cards])=>{
                let nextContext=context;
                if(/^c[0-9a-f_]+$/.test(context))try{
                    const [boundaryId,density]=JSON.parse(context.slice(1).split("_").map(code=>String.fromCodePoint(parseInt(code,16))).join(""));
                    nextContext=ConnectionGraphLayoutStore.contextKey({boundaryId:ids.get(boundaryId)||boundaryId,density});
                }catch{}
                return [nextContext,Object.fromEntries(Object.entries(cards||{}).map(([id,point])=>{
                    let decoded=id;try{decoded=decodeURIComponent(id);}catch{}
                    return [encodeURIComponent(ids.get(decoded)||decoded).replace(/\./g,"%2E"),point];
                }))];
            }));
            await ConnectionStore.runBatch(async()=>{
                const graphBefore=ConnectionStore.getGraph();
                const oldNode=graphBefore.nodes?.[graphTarget.id];
                await ConnectionStore.replaceTarget(graphTarget,destination);
                if(graphTarget.id!==target.id){const graph=ConnectionStore.getGraph();delete graph.nodes[target.id];await ConnectionStore.setGraph(graph,{reason:"retireConvertedSite"});}
                if(oldNode){const graph=ConnectionStore.getGraph();for(const key of ["groupOrder","hiddenCategoryIds"])if(oldNode[key])graph.nodes[destination.id][key]=copy(oldNode[key]);await ConnectionStore.setGraph(graph,{reason:"convertSite"});}
                if(scene){
                    const flags=copy(scene.flags?.[MODULE]||{});
                    delete flags.site;delete flags.siteScene;delete flags.navigation;delete flags.lineage;delete flags.connectionGraphLayouts;
                    if(flags.placePreview){delete flags.placePreview.journalEntryId;delete flags.placePreview.journalPageId;}
                    await writeFlags(scene,flags);
                    await LocationSceneService.link(entity.id,scene.id);
                }
                for(const child of LocationEntityStore.getLocations())if(record && child.id!==entity.id && child.hierarchy?.parent?.kind==="site" && child.hierarchy.parent.siteId===record.siteId && child.hierarchy.parent.parentSceneId===parent.id){
                    const prior=copy(child.hierarchy);undo.push(()=>LocationEntityStore.updateLocation(child.id,{hierarchy:prior}));
                    await LocationEntityStore.updateLocation(child.id,{hierarchy:{parent:{kind:"location",locationId:entity.id}}});
                }
                const refs=[];
                for(const worldScene of contents(game.scenes)){
                    const docs=[worldScene,...contents(worldScene.tiles),...contents(worldScene.notes),...contents(worldScene.drawings)];
                    for(const document of docs){
                        const flags=copy(document.flags?.[MODULE]||{});let next=remap(flags);
                        if(flags.marker && matches(flags.marker.target)){
                            next.marker.markerKind=flags.marker.markerKind==="site-placement"?"entity-placement":flags.marker.markerKind;
                            next.marker.behavior={...flags.marker.behavior,opens:"entity-dossier",canConvertToToken:false,createsSceneConnection:true};
                            refs.push({markerId:next.marker.markerId,sceneId:worldScene.id,documentName:document.documentName,documentId:document.id,labelId:next.marker.label?.id||"",markerKind:next.marker.markerKind,target:markerTarget});
                        }
                        if(record && flags.site && flags.siteId===record.siteId && worldScene.id===parent.id && document.documentName==="Tile"){
                            const markerId=foundry.utils.randomID();
                            next={marker:{markerId,markerKind:"entity-placement",target:markerTarget,parentSceneId:worldScene.id,placeableDocumentName:"Tile",
                                presentation:{name:plan.name,iconSrc:plan.icon||document.texture?.src||"",iconTint:record.siteColor||"#ffffff",labelColor:record.siteLabelColor||record.siteColor||"#ffffff",showLabel:record.showLabel!==false,labelFontSize:record.labelFontSize,labelFontFamily:record.labelFontFamily},
                                behavior:{opens:"entity-dossier",canOrbit:true,canConvertToToken:false,createsSceneConnection:true},
                                placement:{iconSize:document.height,iconAspectRatio:document.width/document.height,rotation:document.rotation||0,snapToGrid:false},label:{id:record.labelId||"",role:"name"}}};
                            refs.push({markerId,sceneId:worldScene.id,documentName:"Tile",documentId:document.id,labelId:record.labelId||"",markerKind:"entity-placement",target:markerTarget});
                            const label=worldScene.drawings?.get(record.labelId);
                            if(label)await writeFlags(label,{...copy(label.flags?.[MODULE]||{}),markerLabel:true,markerId,ownerTileId:document.id,target:markerTarget,labelRole:"name"});
                        }
                        if(record && scene && document===worldScene && worldScene.id!==scene.id){
                            for(const key of ["lineage","navigation"]){
                                const reference=next[key];
                                if(reference?.parentSiteId===record.siteId && reference.parentSceneId===parent.id){
                                    next[key]={...reference,parentSceneId:scene.id,parentSiteId:null};
                                    if(key==="navigation")Object.assign(next[key],{sceneId:scene.id,transitionStyle:"scene-default",transitionContext:{}});
                                }
                            }
                        }
                        if(next.connectionGraphLayouts)next.connectionGraphLayouts=remapLayouts(next.connectionGraphLayouts);
                        if(!equal(flags,next))await writeFlags(document,next);
                        if(document.documentName==="Note" && journal.oldPageId && document.entryId===journal.oldEntryId && document.pageId===journal.oldPageId && journal.oldPageUuid!==journal.newPageUuid)await write(document,{entryId:journal.newEntryId,pageId:journal.newPageId});
                    }
                }
                for(const document of [...contents(game.journal),...contents(game.journal).flatMap(entry=>contents(entry.pages)),...contents(game.users)]){
                    const flags=copy(document.flags?.[MODULE]||{}),next=remap(flags);
                    if(next.connectionGraphLayouts)next.connectionGraphLayouts=remapLayouts(next.connectionGraphLayouts);
                    if(!equal(flags,next))await writeFlags(document,next);
                }
                if(refs.length)await LocationEntityStore.updateLocation(entity.id,{markerRefs:refs},{syncMarkers:false});
                if(Object.keys(sourceLayouts).length){
                    const flags=copy(journal.document.flags?.[MODULE]||{});flags.connectionGraphLayouts=remapLayouts(sourceLayouts);await writeFlags(journal.document,flags);
                }
                if(journal.oldPageUuid && journal.oldPageUuid!==journal.newPageUuid)for(const entry of contents(game.journal))for(const otherPage of contents(entry.pages)){
                    const text=otherPage.text?.content;
                    if(otherPage.uuid!==journal.oldPageUuid && typeof text==="string" && text.includes(journal.oldPageUuid))await write(otherPage,{"text.content":text.replaceAll(journal.oldPageUuid,journal.newPageUuid)});
                }
                if(journal.oldPageUuid && journal.oldPageUuid!==journal.newPageUuid)for(const macro of contents(game.macros))if(typeof macro.command==="string" && macro.command.includes(journal.oldPageUuid))await write(macro,{command:macro.command.replaceAll(journal.oldPageUuid,journal.newPageUuid)});
                await journal.commit();
                if(record){const flags=copy(parent.flags?.[MODULE]||{});if(!flags.sites?.records?.[record.siteId])throw new Error("The Site changed during conversion.");delete flags.sites.records[record.siteId];await writeFlags(parent,flags);}
            },{reason:"convertSiteToLocation"});
            await SiteLocationConversionRefresh.notify({sourceIds:[...new Set([...ids.keys(), ...(scene ? [`nexus-scene:${scene.id}`] : [])])],destinationId:entity.id});
            Hooks.callAll("augurNexusLineageChanged");Hooks.callAll("augurNexusCampaignEntitiesChanged",{reason:"convertSiteToLocation",entity});
            return LocationEntityStore.getLocation(entity.id)||entity;
        }catch(error){
            const failures=[];for(const rollback of undo.reverse())try{await rollback();}catch(failure){failures.push(failure);}
            try{await journal?.rollback();}catch(failure){failures.push(failure);}
            if(failures.length)throw new AggregateError([error,...failures],"Conversion failed and could not be fully restored. Reload and inspect the affected documents.");
            throw error;
        }finally{this.#pending.delete(plan.target.id);}
    }
}
