import { ConnectionGraphLayoutStore } from "../../connections/services/ConnectionGraphLayoutStore.js";

const MODULE_ID = "augur-nexus";
const SCENE_ID_FIELDS = new Set(["sceneId", "parentSceneId", "linkedSceneId", "siteSceneId", "primarySceneId", "sourceSceneId", "targetSceneId", "returnSceneId", "containingSceneId", "selectedSceneId", "activeSceneId", "viewedSceneId", "currentSceneId", "lastSceneId"]);
const TEXT_FIELDS = new Set(["name", "label", "title", "text", "content", "description", "summary", "command"]);
const contents = collection => collection?.contents || [...(collection?.values?.() || [])];
const copy = value => foundry.utils.deepClone(value);
const equal = (first, second) => JSON.stringify(first) === JSON.stringify(second);

export class SiteSceneReferenceTransfer {
    static prepare({ oldScene, newScene, record = null, idMap = {} } = {}) {
        if (!game.user?.isGM) throw new Error("Only the GM can transfer Scene references.");
        if (!oldScene?.id || !newScene?.id || oldScene.id === newScene.id) throw new Error("Two distinct Scenes are required to transfer references.");
        const ids = new Map(typeof idMap?.entries === "function" ? idMap.entries() : Object.entries(idMap));
        const oldNode = `nexus-scene:${oldScene.id}`, newNode = `nexus-scene:${newScene.id}`;
        const oldUuid = `Scene.${oldScene.id}`, newUuid = `Scene.${newScene.id}`;
        const remapUuid = value => {
            if (value === oldUuid) return newUuid;
            const prefix = `${oldUuid}.`;
            if (!value.startsWith(prefix)) return value;
            const [type, id, ...tail] = value.slice(prefix.length).split(".");
            return ids.has(id) ? `${newUuid}.${type}.${ids.get(id)}${tail.length ? `.${tail.join(".")}` : ""}` : value;
        };
        const remapKey = key => {
            if (key === oldNode) return newNode;
            try { if (decodeURIComponent(key) === oldNode) return encodeURIComponent(newNode).replace(/\./g, "%2E"); } catch { /* Preserve malformed legacy keys. */ }
            if (/^c[0-9a-f_]+$/.test(key)) try {
                const [boundaryId, density] = JSON.parse(key.slice(1).split("_").map(code => String.fromCodePoint(parseInt(code, 16))).join(""));
                if (boundaryId === oldNode) return ConnectionGraphLayoutStore.contextKey({ boundaryId: newNode, density });
            } catch { /* Not a graph-layout context. */ }
            return key;
        };
        const mapValue = (value, field = "", localIds = false) => {
            if (typeof value === "string") return value === oldNode ? newNode : remapUuid(value);
            if (Array.isArray(value)) return value.map(entry => mapValue(entry, field, localIds));
            if (!value || typeof value !== "object") return value;
            // A Site's identity is the parent Scene plus Site ID, independent of its linked map.
            if (value.kind === "nexus-site") {
                const target = copy(value);
                for (const key of ["linkedSceneId", "siteSceneId"]) if (target[key] === oldScene.id) target[key] = newScene.id;
                return target;
            }
            const placedOnOld = value.sceneId === oldScene.id;
            const sceneDocument = value.documentName === "Scene" || value.documentType === "Scene";
            return Object.fromEntries(Object.entries(value).map(([key, entry]) => {
                if (TEXT_FIELDS.has(key) && typeof entry === "string") return [key, entry];
                if (SCENE_ID_FIELDS.has(key) && entry === oldScene.id) {
                    if (key === "parentSceneId" && value.siteId) return [key, entry];
                    return [key, newScene.id];
                }
                if (placedOnOld && ["documentId", "labelId"].includes(key)) return [key, ids.get(entry) || entry];
                if (localIds && (key === "ownerTileId" || field === "label" && key === "id")) return [key, ids.get(entry) || entry];
                if (sceneDocument && ["id", "documentId"].includes(key) && entry === oldScene.id) return [key, newScene.id];
                return [remapKey(key), mapValue(entry, key, localIds)];
            }));
        };
        // Core moves source markers; labels in other Scenes keep their own scene-local owner IDs.
        const remap = value => mapValue(value, "", true);
        const remapExternal = value => mapValue(value);
        const remapLinks = text => text.replace(/@UUID\[([^\]]+)\]/g, (match, uuid) => {
            const next = remapUuid(uuid);
            return next === uuid ? match : `@UUID[${next}]`;
        });
        const documents = [];
        for (const scene of contents(game.scenes)) {
            if (scene.id === oldScene.id || scene.id === newScene.id) continue;
            documents.push(scene);
            for (const key of ["tiles", "notes", "drawings", "tokens", "walls", "lights", "sounds", "templates", "regions"]) documents.push(...contents(scene[key]));
        }
        for (const entry of contents(game.journal)) documents.push(entry, ...contents(entry.pages));
        documents.push(...contents(game.users));
        const staged = [...new Set(documents)].flatMap(document => {
            const flags = copy(document.flags?.[MODULE_ID] || {}), next = remapExternal(flags);
            const text = document.documentName === "JournalEntryPage" ? document.text?.content : undefined;
            const nextText = typeof text === "string" ? remapLinks(text) : text;
            if (equal(flags, next) && text === nextText) return [];
            return [{ document, flags, text, changeFlags: !equal(flags, next), changeText: text !== nextText }];
        });
        const attempted = [];
        let applied = false, rolledBack = false;
        const rollback = async () => {
            if (rolledBack) return;
            const failures = [];
            for (const snapshot of [...attempted].reverse()) try {
                await snapshot.document.update({ ...(snapshot.changeFlags ? { [`flags.==${MODULE_ID}`]: snapshot.flags } : {}), ...(snapshot.changeText ? { "text.content": snapshot.text } : {}) });
            } catch (error) { failures.push(error); }
            if (failures.length) throw new AggregateError(failures, "Some Scene references could not be restored.");
            rolledBack = true;
        };
        return {
            remap,
            async apply() {
                if (!game.user?.isGM) throw new Error("Only the GM can transfer Scene references.");
                if (rolledBack) throw new Error("This Scene reference transfer has been rolled back.");
                if (applied) return;
                try {
                    for (const snapshot of staged) {
                        attempted.push(snapshot);
                        const flags = snapshot.document.flags?.[MODULE_ID] || {};
                        const text = snapshot.document.text?.content;
                        await snapshot.document.update({ ...(snapshot.changeFlags ? { [`flags.==${MODULE_ID}`]: remapExternal(flags) } : {}), ...(snapshot.changeText ? { "text.content": remapLinks(text) } : {}) });
                    }
                    applied = true;
                } catch (error) {
                    try { await rollback(); } catch (failure) { throw new AggregateError([error, failure], "Scene reference transfer failed and could not be fully restored."); }
                    throw error;
                }
            },
            rollback
        };
    }
}
