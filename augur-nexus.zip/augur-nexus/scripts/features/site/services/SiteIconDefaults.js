export const DEFAULT_SITE_ICON_SRC = "modules/augur-nexus/assets/site_icons/scifi/site.png";

export function resolveSiteIconSrc(...sources) {
    return sources.map(source => String(source || "").trim()).find(Boolean) || DEFAULT_SITE_ICON_SRC;
}

