export const DEFAULT_SITE_ICON_SRC = "modules/augur-nexus/assets/site_icons/scifi/site.png";

