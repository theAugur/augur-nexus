import { SiteSceneIdentityTransfer } from "./SiteSceneIdentityTransfer.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { SiteRecordManager } from "./SiteRecordManager.js";
import { SiteSceneCopyService } from "./SiteSceneCopyService.js";
import { SiteJournalManager } from "./SiteJournalManager.js";
import { NexusLineageManager } from "../../nexus/services/NexusLineageManager.js";
import { NexusSceneNavigationManager } from "../../nexus/services/NexusSceneNavigationManager.js";
import { NexusSceneFolderManager } from "../../nexus/services/NexusSceneFolderManager.js";
import { ConnectionGraphLayoutStore } from "../../connections/services/ConnectionGraphLayoutStore.js";

const MODULE = "augur-nexus";
const clone = value => foundry.utils.deepClone(value);
const scenes = () => game.scenes?.contents || [];

/** Shared adoption rules: another Site's map is a copy source, never a transferable owner. */
export class SiteSceneLinkService {
    static #pending = new Set();

    static inspectSource(scene, { parentSceneId = null } = {}) {
        SiteSceneCopyService.assertCanCopy(scene);
        const owners = scenes().flatMap(parent => SiteRecordManager.getSceneRecordList(parent))
            .filter(record => (record.linkedSceneId || record.siteSceneId) === scene.id);
        if (owners.length > 1) throw new Error("This Scene has ambiguous Site ownership.");
        const owner = owners[0] || null;
        if (!owner && (scene.flags?.[MODULE]?.siteScene || scene.flags?.[MODULE]?.site?.siteId)) {
            throw new Error("The Scene's Site owner could not be resolved safely.");
        }
        const flags = scene.flags?.[MODULE] || {};
        const sceneNodeId = `nexus-scene:${scene.id}`;
        const directIdentity = ["rootSceneCreation", "placePreview", "connectionDossier", "connectionGraphLayouts", "alwaysShowInNexus", "hideFromNexus", "lineage", "navigation", "siteJournalId", "sites", "markerRefs", "playerAccess"].some(key => flags[key] !== undefined)
            || !!ConnectionStore.getGraph().nodes?.[sceneNodeId]
            || ["tiles", "notes", "drawings"].some(key => scene[key]?.contents?.some(doc => doc.flags?.[MODULE]?.marker || doc.flags?.[MODULE]?.site));
        if (!owner && !directIdentity) {
            const navigation = scene.flags?.[MODULE]?.navigation;
            const lineage = scene.flags?.[MODULE]?.lineage;
            if (navigation?.parentSceneId || lineage?.parentSceneId || lineage?.parentSiteId) throw new Error("Already nested in another Nexus branch.");
            if (parentSceneId) {
                const validation = NexusLineageManager.validateSceneParent(scene, { parentSceneId });
                if (!validation.valid) throw new Error(validation.message || "This Scene cannot be linked here.");
            }
        }
        return { scene, owner, directIdentity, copyRequired: !!owner || directIdentity, actionLabel: owner || directIdentity ? "Copy & link" : "Link scene", ownerName: owner?.siteName || (directIdentity ? scene.name : "") };
    }

    static inspectReplacement(context) { return SiteSceneIdentityTransfer.inspect(context); }

    static inspectLinkSource(scene, options) {
        const source = this.inspectSource(scene, options);
        // Copying Site maps remains internal while its release integrity work is pending.
        if (source.copyRequired) throw new Error(`${source.ownerName || "This Scene"} is already used by a Site. Choose an unclaimed Scene.`);
        return source;
    }

    static hasChildren(record, scene) { return SiteSceneIdentityTransfer.hasChildren(record, scene); }

    static replace(context, sceneId) { return SiteSceneIdentityTransfer.replace(context, sceneId, { inspectSource: (scene, options) => this.inspectSource(scene, options) }); }

    static async link(record, sourceSceneId, { replace = false, autoSort = true } = {}) {
        if (replace) return this.replace({ record }, sourceSceneId);
        if (!game.user?.isGM) throw new Error("Only a GM can link Site Scenes.");
        await ConnectionGraphLayoutStore.flush();
        const parent = game.scenes.get(record.parentSceneId);
        const current = SiteRecordManager.getSceneRecord(parent, record.siteId);
        if (!current) throw new Error("The Site no longer exists.");
        const key = `${parent.id}:${current.siteId}`;
        if (this.#pending.has(key)) throw new Error("This Site is already changing its linked Scene.");
        const oldScene = game.scenes.get(current.linkedSceneId || current.siteSceneId);
        if (oldScene && oldScene.id !== sourceSceneId) throw new Error("Use Replace Linked Scene to change an existing Site map.");
        if (oldScene?.id === sourceSceneId) throw new Error("This Scene is already linked to this Site.");
        const source = this.inspectLinkSource(game.scenes.get(sourceSceneId), { parentSceneId: parent.id });
        this.#pending.add(key);
        let linked, copied = false;
        const snapshots = [];
        const capture = document => { if (document) snapshots.push({ document, flags: clone(document.flags?.[MODULE] || {}), folder: document.documentName === "Scene" ? document.folder?.id || document.folder || null : undefined }); };
        capture(parent); capture(oldScene);
        const page = SiteJournalManager.findSitePage(current.journalEntryId, current.siteId);
        capture(page);
        try {
            linked = source.copyRequired ? await SiteSceneCopyService.copy(source.scene) : source.scene;
            if (!linked?.id) throw new Error("The Scene could not be created or linked.");
            copied = source.copyRequired;
            capture(linked);
            const marker = parent.tiles?.contents?.find(tile => tile.flags?.[MODULE]?.marker?.target?.siteId === current.siteId);
            await NexusSceneNavigationManager.setSceneNavigation(linked, { parentSceneId: parent.id, parentSiteId: current.siteId,
                transitionStyle: "focus-note", transitionContext: { placeableId: marker?.id || current.placeableId, documentName: "Tile", moduleId: MODULE, flagKey: "marker.target.siteId", flagValue: current.siteId } });
            await NexusSceneFolderManager.placeExistingSceneInParentFolder(parent, linked, { autoSort });
            const next = await SiteRecordManager.persistLinkedScene(current, linked.id, linked.name);
            await linked.update({ [`flags.${MODULE}.siteScene`]: true, [`flags.${MODULE}.site`]: next });
            Hooks.callAll("augurNexusLineageChanged");
            return { record: next, scene: linked, copied };
        } catch (error) {
            const failures = [];
            for (const snapshot of snapshots.reverse()) {
                if (copied && snapshot.document === linked) continue;
                try { await snapshot.document.update({ [`flags.==${MODULE}`]: snapshot.flags, ...(snapshot.folder !== undefined ? { folder: snapshot.folder } : {}) }); }
                catch (failure) { failures.push(failure); }
            }
            try { await SiteRecordManager.syncRecordToVisuals(parent, current); } catch (failure) { failures.push(failure); }
            if (copied) try { await linked.delete({ [MODULE]: { managedCascade: true } }); } catch (failure) { failures.push(failure); }
            Hooks.callAll("augurNexusLineageChanged");
            if (failures.length) throw new AggregateError([error, ...failures], "Scene linking failed; some rollback writes also failed.");
            throw error;
        } finally { this.#pending.delete(key); }
    }
}
