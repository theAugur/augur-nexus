import { SiteLocationConversion } from "./SiteLocationConversion.js";
import { SiteSceneLinkService } from "./SiteSceneLinkService.js";
import { SiteScenePicker } from "../applications/SiteScenePicker.js";
import { openActionMenu } from "../../../api/ui.js";

export class SiteAdvancedMenu {
    static menuItem(context, { anchor, position, onConverted = null, onChanged = null } = {}) {
        if (!game.user?.isGM) return null;
        const conversion = SiteLocationConversion.menuItem(context, { onConverted });
        return { id: "site-advanced", label: "Advanced…", icon: "fas fa-sliders", onSelect: () => {
            let conversionReason = "";
            if (!conversion) try { SiteLocationConversion.source(context); } catch (error) { conversionReason = error.message; }
            // Site Scene replacement remains internal while its release integrity work is pending.
            openActionMenu({ anchor, position, className: "site-advanced-menu", items: [
                conversion || { id: "convert-to-location", label: "Convert to Location", icon: "fas fa-map-location-dot", unavailable: true, description: conversionReason || "This place cannot be converted.", title: conversionReason }
            ] });
        } };
    }

    static replace(context, { onChanged = null } = {}) {
        try {
            const plan = SiteSceneLinkService.inspectReplacement(context);
            return new SiteScenePicker(null, async sceneId => {
                try {
                    const fresh = SiteSceneLinkService.inspectReplacement(context);
                    const source = SiteSceneLinkService.inspectSource(game.scenes.get(sceneId), { parentSceneId: fresh.parent?.id || fresh.oldScene?.flags?.["augur-nexus"]?.lineage?.parentSceneId });
                    const escape = foundry.utils.escapeHTML;
                    const confirmed = await foundry.applications.api.DialogV2.confirm({ window: { title: "Replace Linked Scene" }, modal: true, rejectClose: false,
                        content: `<p>${source.copyRequired ? "Copy and link" : "Link"} <strong>${escape(source.scene.name)}</strong> as the map for <strong>${escape(fresh.name || fresh.record?.siteName || fresh.oldScene?.name)}</strong>?</p><p>The Site keeps its name, icon, notes, connections, and parent. ${fresh.oldScene ? `The old Scene, ${escape(fresh.oldScene.name)}, is kept as an independent Scene.` : "No existing Scene is removed."}${source.copyRequired ? " Only the selected map is copied; the original Site, its notes, connections, and children are unchanged." : ""}</p>`,
                        yes: { label: source.actionLabel }, no: { label: "Cancel" } });
                    if (!confirmed) return false;
                    const result = await SiteSceneLinkService.replace(context, sceneId);
                    await onChanged?.(result);
                    return true;
                } catch (error) { ui.notifications.warn(error.message || "The linked Scene could not be replaced."); return false; }
            }, { parentSceneId: plan.parent?.id, excludedSceneIds: [plan.parent?.id, plan.oldScene?.id].filter(Boolean) }).render({ force: true });
        } catch (error) { ui.notifications.warn(error.message); return null; }
    }
}
