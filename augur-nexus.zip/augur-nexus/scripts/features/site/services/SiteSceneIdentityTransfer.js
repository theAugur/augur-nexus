import { SiteRecordManager } from "./SiteRecordManager.js";
import { SiteSceneCopyService } from "./SiteSceneCopyService.js";
import { SiteJournalManager } from "./SiteJournalManager.js";
import { SiteSceneReferenceTransfer } from "./SiteSceneReferenceTransfer.js";
import { PlaceJournalManager } from "../../connections/services/PlaceJournalManager.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { ConnectionGraphLayoutStore } from "../../connections/services/ConnectionGraphLayoutStore.js";
import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { NexusSceneNavigationManager } from "../../nexus/services/NexusSceneNavigationManager.js";

const MODULE = "augur-nexus";
const clone = value => foundry.utils.deepClone(value);
const list = collection => collection?.contents || [...(collection?.values?.() || [])];
const ORDINARY = new Set(["empty", "existing", "from-image", "instant-dungeons-generator"]);
const IDENTITY = ["site", "siteScene", "sites", "siteJournalId", "lineage", "navigation", "rootSceneCreation", "connectionGraphLayouts", "connectionDossier", "markerRefs", "placePreview", "playerAccess", "alwaysShowInNexus", "hideFromNexus"];

/** Transfers a place identity between maps; map content and generator data never change owners. */
export class SiteSceneIdentityTransfer {
    static #pending = new Set();

    static inspect(context = {}) {
        if (!game.user?.isGM) throw new Error("Only a GM can replace a Site Scene.");
        let record = context.record || null;
        let oldScene = context.scene || game.scenes.get(context.sceneId) || null;
        if (!record && context.siteId) record = SiteRecordManager.getSceneRecord(game.scenes.get(context.parentSceneId), context.siteId);
        if (!record && oldScene) record = SiteRecordManager.findSiteRecordForLinkedScene(oldScene);
        const parent = record ? game.scenes.get(record.parentSceneId) : null;
        if (record) {
            record = SiteRecordManager.getSceneRecord(parent, record.siteId);
            if (!record || record.legacyJournalBacked) throw new Error("This Site's current record could not be resolved safely.");
            if (!ORDINARY.has(record.siteSceneType || "empty")) throw new Error("Only ordinary Sites can replace their Scene; Sci-Fi places and generated regions are excluded.");
            oldScene = game.scenes.get(record.linkedSceneId || record.siteSceneId) || null;
            if (!oldScene && (record.linkedSceneId || record.siteSceneId)) throw new Error("The Site's current Scene is missing.");
        }
        if (!record && !oldScene) throw new Error("This Site could not be found.");
        if (oldScene) {
            SiteSceneCopyService.assertCanCopy(oldScene);
            const owners = list(game.scenes).flatMap(scene => SiteRecordManager.getSceneRecordList(scene))
                .filter(site => (site.linkedSceneId || site.siteSceneId) === oldScene.id);
            if (owners.length > 1 || (!record && (owners.length || oldScene.flags?.[MODULE]?.site?.siteId))) throw new Error("This Scene has ambiguous Site ownership.");
        }
        if (this.hasChildren(record, oldScene)) throw new Error("Sites with child Scenes, Sites, or Locations cannot replace their Scene. Move those children first.");
        if (oldScene && list(game.macros).some(macro => String(macro.command || "").includes(oldScene.id))) throw new Error("A Macro references this Scene directly. Update that Macro before replacing the Scene.");
        return { record, parent, oldScene, name: record?.siteName || oldScene.name };
    }

    static hasChildren(record, scene) {
        const siteParent = value => !!record && value?.parentSceneId === record.parentSceneId && value?.parentSiteId === record.siteId;
        if (scene && SiteRecordManager.getSceneRecordList(scene).length) return true;
        const container = scene && game.journal?.get(scene.flags?.[MODULE]?.siteJournalId);
        if (container && list(container.pages).some(page => page.flags?.[MODULE]?.sitePage && page.flags[MODULE].parentSceneId === scene.id)) return true;
        if (list(game.scenes).some(child => child.id !== scene?.id && [child.flags?.[MODULE]?.lineage, child.flags?.[MODULE]?.navigation, child.flags?.[MODULE]?.site]
            .some(parent => siteParent(parent) || scene && parent?.parentSceneId === scene.id))) return true;
        return LocationEntityStore.getLocations().some(location => {
            const parent = location.hierarchy?.parent;
            return !!record && parent?.kind === "site" && parent.parentSceneId === record.parentSceneId && parent.siteId === record.siteId
                || !!scene && parent?.kind === "scene" && parent.sceneId === scene.id;
        });
    }

    static async replace(context, sourceSceneId, { inspectSource } = {}) {
        await ConnectionGraphLayoutStore.flush();
        const plan = this.inspect(context), { record, parent, oldScene } = plan;
        if (oldScene?.id === sourceSceneId) throw new Error("This is already the Site's Scene.");
        const source = inspectSource(game.scenes.get(sourceSceneId), { parentSceneId: parent?.id || oldScene?.flags?.[MODULE]?.lineage?.parentSceneId });
        const key = record ? `site:${parent.id}:${record.siteId}` : `scene:${oldScene.id}`;
        if (this.#pending.has(key)) throw new Error("This Site is already changing its Scene.");
        this.#pending.add(key);
        const undo = [];
        let linked, copied = false, refs;
        const write = async (document, patch) => {
            const before = {};
            for (const path of Object.keys(patch)) {
                if (path.startsWith("flags.==") && document.flags?.[path.slice(8)] === undefined) before[`flags.-=${path.slice(8)}`] = null;
                else before[path] = clone(path.startsWith("flags.==") ? document.flags[path.slice(8)] : path.split(".").reduce((value, key) => value?.[key], document));
            }
            undo.push(() => document.update(before));
            await document.update(patch);
        };
        try {
            linked = source.copyRequired ? await SiteSceneCopyService.copy(source.scene) : source.scene;
            if (!linked?.id) throw new Error("The replacement Scene could not be prepared.");
            copied = source.copyRequired;
            const oldFlags = clone(oldScene?.flags?.[MODULE] || {}), nextFlags = clone(linked.flags?.[MODULE] || {});
            for (const key of IDENTITY) { delete nextFlags[key]; if (oldFlags[key] !== undefined) nextFlags[key] = clone(oldFlags[key]); }
            const idMap = {}, moves = [];
            const page = record ? SiteJournalManager.findSitePage(record.journalEntryId, record.siteId) : PlaceJournalManager.getJournalPage(oldScene);
            if (page && record) {
                const before = clone(page.flags?.[MODULE] || {});
                undo.push(() => page.update({ [`flags.==${MODULE}`]: before }));
            }
            for (const type of ["Tile", "Note", "Drawing"]) {
                const collection = { Tile: "tiles", Note: "notes", Drawing: "drawings" }[type];
                const docs = list(oldScene?.[collection]).filter(doc => {
                    const flags = doc.flags?.[MODULE] || {};
                    if (flags.site && !flags.marker) throw new Error("Resolve legacy Site markers on this map before replacing its Scene.");
                    return flags.marker || flags.markerLabel || flags.siteLabel || flags.ownerTileId
                        || type === "Note" && page && doc.entryId === page.parent.id && doc.pageId === page.id;
                });
                for (const doc of docs) {
                    if (idMap[doc.id]) throw new Error("Managed map objects have ambiguous embedded IDs.");
                    const occupied = ["tiles", "notes", "drawings"].some(name => linked[name]?.get(doc.id));
                    idMap[doc.id] = occupied ? foundry.utils.randomID() : doc.id;
                }
                if (docs.length) moves.push({ type, docs });
            }
            refs = oldScene ? SiteSceneReferenceTransfer.prepare({ oldScene, newScene: linked, record, idMap }) : null;
            const remap = value => refs?.remap(value) ?? value;
            for (const move of moves) {
                const data = move.docs.map(doc => { const next = clone(doc.toObject()); next._id = idMap[doc.id]; if (next.flags?.[MODULE]) next.flags[MODULE] = remap(next.flags[MODULE]); return next; });
                undo.push(async () => { const collection = { Tile: "tiles", Note: "notes", Drawing: "drawings" }[move.type]; const ids = data.map(doc => doc._id).filter(id => linked[collection]?.get(id)); if (ids.length) await linked.deleteEmbeddedDocuments(move.type, ids, { [MODULE]: { managedCascade: true, managedMarkerDelete: true } }); });
                await linked.createEmbeddedDocuments(move.type, data, { keepId: true, [MODULE]: { managedCascade: true } });
            }
            await ConnectionStore.runBatch(async () => {
                const finalFlags = remap(nextFlags);
                await write(linked, { name: plan.name, [`flags.==${MODULE}`]: finalFlags,
                    ...(oldScene?.ownership ? { ownership: clone(oldScene.ownership) } : {}), folder: oldScene?.folder?.id || oldScene?.folder || parent?.folder?.id || parent?.folder || null });
                if (record) {
                    const prior = clone(record);
                    undo.push(async () => { await SiteRecordManager.upsertSceneRecord(parent, prior); await SiteRecordManager.syncRecordToVisuals(parent, prior); });
                    const next = await SiteRecordManager.persistLinkedScene(record, linked.id, plan.name);
                    await NexusSceneNavigationManager.setSceneNavigation(linked, { parentSceneId: parent.id, parentSiteId: record.siteId,
                        transitionStyle: oldFlags.navigation?.transitionStyle || "focus-note", transitionContext: oldFlags.navigation?.transitionContext || { placeableId: record.placeableId, documentName: record.placeableDocumentName || "Tile", moduleId: MODULE, flagKey: "marker.target.siteId", flagValue: record.siteId } });
                    await linked.update({ [`flags.${MODULE}.siteScene`]: true, [`flags.${MODULE}.site`]: next });
                    if (!oldScene && record.playerVisibility !== "inherit") await linked.setFlag(MODULE, "playerAccess", { nexus: record.playerVisibility });
                }
                if (oldScene) {
                    const graph = ConnectionStore.getGraph(), oldTarget = ConnectionTargetResolver.fromSceneReference({ sceneId: oldScene.id });
                    const newTarget = ConnectionTargetResolver.fromSceneReference({ sceneId: linked.id });
                    if (graph.nodes?.[oldTarget.id]) await ConnectionStore.replaceTarget(oldTarget, { ...graph.nodes[oldTarget.id], ...newTarget });
                    await refs.apply();
                    for (const move of moves) {
                        const original = move.docs.map(doc => clone(doc.toObject()));
                        undo.push(async () => { const collection = { Tile: "tiles", Note: "notes", Drawing: "drawings" }[move.type]; const missing = original.filter(doc => !oldScene[collection]?.get(doc._id)); if (missing.length) await oldScene.createEmbeddedDocuments(move.type, missing, { keepId: true, [MODULE]: { managedCascade: true } }); });
                        await oldScene.deleteEmbeddedDocuments(move.type, move.docs.map(doc => doc.id), { [MODULE]: { managedCascade: true, managedMarkerDelete: true } });
                    }
                    const detached = clone(oldFlags);
                    for (const key of IDENTITY) delete detached[key];
                    // Retained maps keep their prior player access rather than becoming newly exposed.
                    if (oldFlags.playerAccess) detached.playerAccess = clone(oldFlags.playerAccess);
                    await write(oldScene, { [`flags.==${MODULE}`]: detached });
                }
            }, { reason: "replaceSiteScene" });
            if (oldScene) Hooks.callAll("augurNexusPlaceSceneReplaced", { sourceId: `nexus-scene:${oldScene.id}`, destinationId: `nexus-scene:${linked.id}` });
            Hooks.callAll("augurNexusLineageChanged");
            return { record: record ? SiteRecordManager.getSceneRecord(parent, record.siteId) : null, scene: linked, copied };
        } catch (error) {
            const failures = [];
            try { await refs?.rollback(); } catch (failure) { failures.push(failure); }
            for (const restore of undo.reverse()) try { await restore(); } catch (failure) { failures.push(failure); }
            if (copied) try { await linked.delete({ [MODULE]: { managedCascade: true } }); } catch (failure) { failures.push(failure); }
            Hooks.callAll("augurNexusLineageChanged");
            if (failures.length) throw new AggregateError([error, ...failures], "Scene replacement failed and some changes could not be restored.");
            throw error;
        } finally { this.#pending.delete(key); }
    }
}
