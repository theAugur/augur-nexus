import { LocationSceneService } from "../../campaign-entities/services/LocationSceneService.js";
import { NexusLineageManager } from "../../nexus/services/NexusLineageManager.js";
import { DevelopedRegionProviderRegistry } from "../../region-dossier/DevelopedRegionProviderRegistry.js";
import { SiteRecordManager } from "./SiteRecordManager.js";

const MODULE_ID = "augur-nexus";
const ORDINARY_TYPES = new Set(["empty", "existing", "from-image", "instant-dungeons-generator"]);
const OWNERSHIP_FLAGS = ["site", "siteScene", "sites", "siteJournalId", "lineage", "navigation", "nexusRoot", "rootSceneCreation", "connectionGraphLayouts", "connectionDossier", "campaignEntity", "campaignEntityRef", "markerRefs", "placePreview", "alwaysShowInNexus", "hideFromNexus"];
const EMBEDDED_COLLECTIONS = ["tiles", "drawings", "tokens", "walls", "lights", "sounds", "templates", "regions"];

export class SiteSceneCopyService {
    static assertCanCopy(scene) {
        if (!game.user?.isGM) throw new Error("Only the GM can copy a Scene for a Site.");
        if (!scene || scene.documentName !== "Scene" || !game.scenes.get(scene.id)) throw new Error("The source Scene could not be found.");
        if (scene.id === NexusLineageManager.getRootScene()?.id || scene.getFlag(MODULE_ID, NexusLineageManager.ROOT_FLAG) === true) throw new Error("The designated Nexus root cannot be copied for a Site.");
        if (LocationSceneService.getLocationForScene(scene.id)) throw new Error("A Scene owned by a Location cannot be copied for a Site.");
        const record = SiteRecordManager.findSiteRecordForLinkedScene(scene);
        const flags = scene.flags || {};
        const types = [record?.siteSceneType, flags[MODULE_ID]?.rootSceneCreation?.sceneType, flags[MODULE_ID]?.site?.siteSceneType].filter(Boolean);
        if (types.some(type => !ORDINARY_TYPES.has(type))
            || Object.keys(flags["augur-scifi"] || {}).length || Object.keys(flags.hexlands || {}).length
            || Object.keys(flags["augur-fantasy"]?.region || {}).length
            || DevelopedRegionProviderRegistry.find({ scene, record, user: game.user })) {
            throw new Error("Only ordinary Scenes can be copied for a Site; Sci-Fi places and generated regions are excluded.");
        }
        return scene;
    }

    static async copy(scene, { name = `${scene?.name || "Scene"} (Copy)` } = {}) {
        this.assertCanCopy(scene);
        const data = foundry.utils.deepClone(scene.toObject());
        delete data._id;
        data.name = name;
        data.active = false;
        data.navigation = false;
        data.folder = null;
        const owner = SiteRecordManager.findSiteRecordForLinkedScene(scene);
        const siteRecords = [owner, data.flags?.[MODULE_ID]?.site, ...Object.values(data.flags?.[MODULE_ID]?.sites?.records || {})].filter(Boolean);
        const siteJournalId = data.flags?.[MODULE_ID]?.siteJournalId;
        const removedIds = new Set(), labelIds = new Set();
        const isMarker = document => {
            const flags = document.flags?.[MODULE_ID] || {};
            return !!(flags.marker || flags.site || flags.markerLabel || flags.siteLabel);
        };
        for (const key of [...EMBEDDED_COLLECTIONS, "notes"]) {
            for (const document of data[key] || []) {
                if (!isMarker(document)) continue;
                removedIds.add(document._id);
                const flags = document.flags?.[MODULE_ID] || {};
                if (flags.marker?.label?.id) labelIds.add(flags.marker.label.id);
                if (flags.labelId) labelIds.add(flags.labelId);
            }
        }
        for (const record of Object.values(data.flags?.[MODULE_ID]?.sites?.records || {})) {
            if (record.labelId) labelIds.add(record.labelId);
        }
        for (const key of EMBEDDED_COLLECTIONS) {
            if (!Array.isArray(data[key])) continue;
            data[key] = data[key].filter(document => !isMarker(document)
                && !(key === "drawings" && (labelIds.has(document._id) || removedIds.has(document.flags?.[MODULE_ID]?.ownerTileId))));
            for (const document of data[key]) this.#clearOwnership(document);
        }
        data.notes = (data.notes || []).filter(note => !isMarker(note)
            && !(siteJournalId && note.entryId === siteJournalId)
            && !siteRecords.some(record => record.journalEntryId && note.entryId === record.journalEntryId
                && (!record.journalPageId || note.pageId === record.journalPageId)));
        for (const note of data.notes) this.#clearOwnership(note);
        this.#clearOwnership(data);
        // Generator attachments use scene-local IDs (floorTileId, attachedWallIds, attachedLightId).
        // A fresh Scene UUID makes retained embedded IDs distinct without breaking those attachments.
        return Scene.create(data, { keepEmbeddedIds: true });
    }

    static #clearOwnership(data) {
        const flags = data.flags?.[MODULE_ID];
        if (!flags) return;
        for (const key of OWNERSHIP_FLAGS) delete flags[key];
        if (!Object.keys(flags).length) delete data.flags[MODULE_ID];
    }
}
