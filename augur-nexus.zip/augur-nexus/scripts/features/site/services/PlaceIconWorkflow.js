import { SiteIconPicker } from "../applications/SiteIconPicker.js";
import { SitePanel } from "../applications/SitePanel.js";
import { SiteRecordManager } from "./SiteRecordManager.js";
import { NexusMarkerService } from "../../markers/services/NexusMarkerService.js";

const MODULE_ID = "augur-nexus";

export class PlaceIconWorkflow {
    static resolve({ sceneId, parentSceneId, siteId } = {}) {
        const scene = sceneId ? game.scenes.get(sceneId) : null;
        const parentScene = parentSceneId ? game.scenes.get(parentSceneId) : null;
        const record = siteId ? SiteRecordManager.resolveSite({ parentScene, siteId })
            : scene ? SiteRecordManager.findSiteRecordForLinkedScene(scene) : null;
        return { scene, record };
    }

    static async open({ onChanged, ...reference } = {}) {
        if (!game.user.isGM) return null;
        const { scene, record } = this.resolve(reference);
        if (!scene && !record) return null;
        const allBuiltInIcons = await SitePanel.getAllBuiltInIcons();
        if (!game.user.isGM) return null;
        const flags = scene?.getFlag(MODULE_ID, "placePreview") || {};
        const currentIconId = record?.siteIcon || flags.iconId || null;
        const currentIconSrc = record?.siteIconSrc || flags.iconSrc || "";
        const currentRole = record?.siteIconRole || "landmark";
        const apply = icon => {
            void this.setIcon(reference, icon).then(result => result && onChanged?.(result))
                .catch(error => ui.notifications.error(error.message || "Could not change the place icon."));
        };
        const picker = new SiteIconPicker(allBuiltInIcons, currentIconId, currentRole, selection => {
            if (typeof selection === "object" && selection?.id === "custom") {
                apply({ iconId: "custom", iconSrc: selection.src || "" });
                return;
            }
            const nextIcon = allBuiltInIcons.find(icon => icon.id === selection && (icon.role || "landmark") === currentRole)
                || allBuiltInIcons.find(icon => icon.id === selection);
            apply({ iconId: selection || null, iconSrc: nextIcon?.src || currentIconSrc });
        }, { currentCustomIconSrc: currentIconId === "custom" ? currentIconSrc : "", allBuiltInIcons,
            showThemeIconsOnly: false, filterByRole: !!record, themeIconsOnlyLabel: "Show Role Icons Only" });
        picker.render(true);
        return picker;
    }

    static async setIcon(reference, { iconId = null, iconSrc = "" } = {}) {
        if (!game.user.isGM) return null;
        // Resolve again at selection time so a picker cannot overwrite an older copy of the Site record.
        const { scene, record } = this.resolve(reference);
        if (record?.siteId) {
            const parentScene = SiteRecordManager.getParentScene(record);
            if (!parentScene) return null;
            const updated = SiteRecordManager.normalizeRecord({ ...record, siteIcon: iconId, siteIconSrc: iconSrc || "" }, { parentScene });
            await SiteRecordManager.upsertSceneRecord(parentScene, updated);
            await SiteRecordManager.syncRecordToVisuals(parentScene, updated);
            Hooks.callAll("augurNexusLineageChanged");
            return { scene, record: updated };
        }
        if (!scene) return null;
        await scene.setFlag(MODULE_ID, "placePreview", { ...(scene.getFlag(MODULE_ID, "placePreview") || {}), iconId, iconSrc: iconSrc || "" });
        await NexusMarkerService.syncMarkersForTarget({ kind: "nexus-scene", sceneId: scene.id });
        Hooks.callAll("augurNexusLineageChanged");
        return { scene, record: null };
    }
}
