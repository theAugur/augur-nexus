import { SiteRecordManager } from "./SiteRecordManager.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";

// Read-only visibility policy also serves connection permissions without importing marker workflows.
export class SitePlayerVisibility {
    static getOverride({ scene = canvas.scene, siteId = null, linkedScene = null, record = null } = {}) {
        const siteRecord = record || SiteRecordManager.getSceneRecord(scene, siteId);
        const resolved = linkedScene || game.scenes.get(siteRecord?.siteSceneId || siteRecord?.linkedSceneId) || null;
        const sceneOverride = resolved ? NexusPlayerSceneAccess.getSceneNexusVisibilityOverride(resolved) : "inherit";
        if (sceneOverride !== "inherit") return sceneOverride;
        return NexusPlayerSceneAccess.normalizeNexusVisibilityOverride(siteRecord?.playerVisibility);
    }
    static isVisible(options = {}) { return NexusPlayerSceneAccess.isNexusVisibilityVisible(this.getOverride(options)); }
    static canUserSee(options = {}, user = game.user) { return !!user?.isGM || this.isVisible(options); }
}
