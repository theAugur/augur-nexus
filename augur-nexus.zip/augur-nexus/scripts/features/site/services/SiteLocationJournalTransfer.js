import { requirePremiumAccess } from "../../access/PremiumAccess.js";
import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { CampaignEntityIndex } from "../../campaign-entities/services/CampaignEntityIndex.js";
import { SiteRecordManager } from "./SiteRecordManager.js";

const MODULE_ID = "augur-nexus";
const NOTES_IDENTITY_KEYS = ["sitePage", "siteNotesPage", "siteId", "placePage", "sceneId", "connectionDossier", "dossierPage", "targetUuid", "targetDocumentType"];

export class SiteLocationJournalTransfer {
    static describe(record = {}, { sourceTarget = null } = {}) {
        const { sourceEntry, shared } = this.#inspect(record, sourceTarget);
        return !sourceEntry ? "new" : shared ? "transferred" : "reused";
    }

    static async prepare(record = {}, locationData = {}, { sourceTarget = null } = {}) {
        if (!game.user.isGM) throw new Error("Only the GM can convert a place to a Location.");
        requirePremiumAccess("location");
        const { sourceEntry, sourcePage, shared, containers } = this.#inspect(record, sourceTarget);
        const sourcePageData = sourcePage?.toObject() || null;
        const adopted = !!sourceEntry && !shared;
        const original = adopted ? { name: sourceEntry.name, folder: sourceEntry.folder?.id || sourceEntry.folder || null, campaignEntity: foundry.utils.deepClone(sourceEntry.getFlag(MODULE_ID, "campaignEntity") ?? null) } : null;
        let entity, document, page;
        let rolledBack = false;

        const restoreSourcePage = async () => {
            if (!shared || !sourcePageData || sourceEntry.pages.has(sourcePageData._id)) return;
            await sourceEntry.createEmbeddedDocuments("JournalEntryPage", [sourcePageData], { keepId: true });
        };
        const restoreAdoptedEntry = async () => {
            await sourceEntry.update({ name: original.name, folder: original.folder, ...(original.campaignEntity
                ? { [`flags.${MODULE_ID}.campaignEntity`]: original.campaignEntity }
                : { [`flags.${MODULE_ID}.-=campaignEntity`]: null }) });
            CampaignEntityIndex.upsert(sourceEntry);
        };
        const restoreNotesFlags = async () => {
            if (sourcePageData && page) await page.update({ flags: foundry.utils.deepClone(sourcePageData.flags || {}) }, { diff: false, recursive: false });
        };
        try {
            const pageData = shared ? foundry.utils.deepClone(sourcePageData) : null;
            if (pageData) delete pageData._id;
            entity = await LocationEntityStore.createLocation({ ...locationData, journal: { ...locationData.journal, notesPageId: adopted ? sourcePage.id : null } }, {
                ownership: sourceEntry ? foundry.utils.deepClone(sourceEntry.ownership) : { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE },
                journalEntry: adopted ? sourceEntry : null,
                journalPageData: pageData
            });
            document = LocationEntityStore.resolveDocument(entity.id);
            page = LocationEntityStore.getJournalPage(entity.id);
            if (!document || !page) throw new Error("The Location Journal could not be prepared.");
        } catch (error) {
            if (adopted) await restoreAdoptedEntry();
            else if (entity) {
                await LocationEntityStore.resolveDocument(entity.id)?.delete({ [MODULE_ID]: { managedCascade: true } });
                CampaignEntityIndex.remove(entity.id);
            }
            throw error;
        }

        return {
            entity, document, page, adopted, shared,
            oldEntryId: sourceEntry?.id || null,
            oldPageId: sourcePage?.id || null,
            oldPageUuid: sourcePage?.uuid || null,
            newEntryId: document.id,
            newPageId: page.id,
            newPageUuid: page.uuid,
            async commit() {
                if (rolledBack) throw new Error("This Journal transfer has been rolled back.");
                try {
                    const flags = page.flags?.[MODULE_ID] || {};
                    const cleanup = Object.fromEntries(NOTES_IDENTITY_KEYS.filter(key => Object.hasOwn(flags, key)).map(key => [`flags.${MODULE_ID}.-=${key}`, null]));
                    if (Object.keys(cleanup).length) await page.update(cleanup);
                    if (shared && sourceEntry.pages.has(sourcePage.id)) await sourceEntry.deleteEmbeddedDocuments("JournalEntryPage", [sourcePage.id]);
                    for (const scene of containers) {
                        if (scene.getFlag(MODULE_ID, "siteJournalId") === sourceEntry.id) await scene.unsetFlag(MODULE_ID, "siteJournalId");
                    }
                } catch (error) {
                    await restoreSourcePage();
                    await restoreNotesFlags();
                    for (const scene of containers) await scene.setFlag(MODULE_ID, "siteJournalId", sourceEntry.id);
                    throw error;
                }
            },
            async rollback() {
                if (rolledBack) return;
                await restoreSourcePage();
                if (adopted) {
                    await restoreNotesFlags();
                    await restoreAdoptedEntry();
                }
                else {
                    await document.delete({ [MODULE_ID]: { managedCascade: true } });
                    CampaignEntityIndex.remove(entity.id);
                }
                for (const scene of containers) await scene.setFlag(MODULE_ID, "siteJournalId", sourceEntry.id);
                rolledBack = true;
            }
        };
    }

    static #inspect(record, sourceTarget) {
        const sourceEntry = record.journalEntryId ? game.journal.get(record.journalEntryId) : null;
        if (record.journalEntryId && !sourceEntry) throw new Error("The source Journal could not be found.");
        const sourcePage = sourceEntry?.pages.get(record.journalPageId);
        if (sourceEntry && (!record.journalPageId || sourcePage?.type !== "text")) throw new Error("The designated source notes page could not be found.");
        const pageSiteId = sourcePage?.flags?.[MODULE_ID]?.siteId;
        if (record.siteId && pageSiteId && pageSiteId !== record.siteId) throw new Error("The designated notes page belongs to another Site.");
        const containers = [];
        const shared = sourceEntry ? this.#isShared(sourceEntry, record, sourceTarget, containers) : false;
        if (shared) containers.length = 0;
        return { sourceEntry, sourcePage, shared, containers };
    }

    static #isShared(entry, record, sourceTarget, containers) {
        // Global containers remain shared even while they contain a single notes page.
        for (const key of ["placeJournalEntryId", "connectionDossierJournalEntryId"]) {
            if (game.settings.get(MODULE_ID, key) === entry.id) return true;
        }
        for (const page of entry.pages.contents) {
            const flags = page.flags?.[MODULE_ID] || {};
            if (flags.siteId && flags.siteId !== record.siteId) return true;
            if (page.id !== record.journalPageId && (flags.placePage || flags.dossierPage)) return true;
            if (!record.siteId && page.id !== record.journalPageId) return true;
        }
        for (const scene of game.scenes.contents) {
            const containerId = scene.getFlag(MODULE_ID, "siteJournalId");
            if (containerId === entry.id) {
                if (scene.id !== record.parentSceneId || !record.siteId) return true;
                containers.push(scene);
            }
            for (const candidate of SiteRecordManager.getSceneRecordList(scene)) {
                if (candidate.siteId === record.siteId && scene.id === record.parentSceneId) continue;
                if ((candidate.journalEntryId || containerId) === entry.id) return true;
            }
            for (const flag of ["placePreview", "connectionDossier"]) {
                if (scene.getFlag(MODULE_ID, flag)?.journalEntryId !== entry.id) continue;
                if (sourceTarget?.kind !== "nexus-scene" || sourceTarget.sceneId !== scene.id) return true;
            }
        }
        return false;
    }
}
