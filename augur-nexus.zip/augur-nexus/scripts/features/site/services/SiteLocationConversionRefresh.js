import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { SiteRecordManager } from "./SiteRecordManager.js";

const CHANNEL = "module.augur-nexus";
const TYPE = "siteLocationConverted";

/** Conversion notifications invalidate views; documents and normal permissions remain authoritative. */
export class SiteLocationConversionRefresh {
    static #registered = false;
    static #apps = new Set();
    static #seen = new Set();

    static register() {
        if (this.#registered) return;
        this.#registered = true;
        const listen = () => game.socket?.on(CHANNEL, message => {
            if (message?.type !== TYPE || !game.users?.get(message.senderId)?.isGM) return;
            const change = this.#validate(message);
            if (change) void this.#dispatch(change);
            else globalThis.setTimeout(() => {
                const pending = this.#validate(message);
                if (pending) void this.#dispatch(pending);
            }, 150);
        });
        if (game.socket) listen();
        else Hooks.once("ready", listen);
    }

    static watch(app) { this.register(); this.#apps.add(app); }
    static unwatch(app) { this.#apps.delete(app); }

    static async notify(change) {
        if (!game.user?.isGM) return false;
        this.register();
        const checked = this.#validate(change);
        if (!checked) return false;
        await this.#dispatch(checked);
        game.socket?.emit(CHANNEL, { type: TYPE, senderId: game.user.id, ...checked });
        return true;
    }

    static #validate({ sourceIds, destinationId } = {}) {
        if (!Array.isArray(sourceIds) || !sourceIds.length || sourceIds.length > 8 || typeof destinationId !== "string") return null;
        const entity = LocationEntityStore.getLocation(destinationId);
        if (!entity) return null;
        const ids = [...new Set(sourceIds)].filter(id => {
            if (typeof id !== "string") return false;
            const [kind, parentId, ...parts] = id.split(":");
            if (kind === "nexus-scene") return !parts.length && !!parentId && entity.scenes?.primarySceneId === parentId;
            if (kind !== "nexus-site" || !parentId || !parts.length) return false;
            const parent = game.scenes.get(parentId);
            return !!parent && !SiteRecordManager.getSceneRecord(parent, parts.join(":"));
        });
        return ids.length === new Set(sourceIds).size ? { sourceIds: ids, destinationId } : null;
    }

    static async #dispatch(change) {
        const key = `${change.destinationId}:${[...change.sourceIds].sort().join("|")}`;
        if (this.#seen.has(key)) return;
        this.#seen.add(key);
        if (this.#seen.size > 128) this.#seen.delete(this.#seen.values().next().value);
        Hooks.callAll("augurNexusPlaceConverted", change);
        await Promise.allSettled([...this.#apps].filter(app => app.matchesConvertedPlace?.(change)).map(app => app.handlePlaceConverted?.(change)));
    }
}
