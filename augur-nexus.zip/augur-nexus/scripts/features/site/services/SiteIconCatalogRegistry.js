const text = value => String(value || "").trim();
const imagePath = value => text(value).replace(/\\/g, "/");
const active = catalog => globalThis.game?.modules?.get(catalog.moduleId)?.active === true;

export class SiteIconCatalogRegistry {
    static #catalogs = new Map();

    static register(definition = {}) {
        const id = text(definition.id), moduleId = text(definition.moduleId);
        if (!id || ["built-in", "custom"].includes(id.toLowerCase())) throw new Error("Site icon catalogs require a non-reserved id.");
        if (!moduleId || typeof definition.loadIcons !== "function") throw new Error("Site icon catalogs require a moduleId and loadIcons function.");
        const catalog = { id, moduleId, label: text(definition.label) || id, loadIcons: definition.loadIcons, pending: null };
        this.#catalogs.set(id, catalog);
        globalThis.Hooks?.callAll?.("augurNexusSiteIconCatalogsChanged");
        return this.#metadata(catalog);
    }

    static list() {
        return [...this.#catalogs.values()].filter(active)
            .sort((a, b) => a.label.localeCompare(b.label) || a.id.localeCompare(b.id)).map(catalog => this.#metadata(catalog));
    }

    static async getIcons(id) {
        const catalog = this.#catalogs.get(text(id));
        if (!catalog || !active(catalog)) return [];
        // Each registered definition owns its load, so replacing a provider cannot reuse stale rows.
        catalog.pending ||= Promise.resolve().then(() => catalog.loadIcons()).then(rows => this.#normalize(rows, catalog));
        let icons;
        try { icons = await catalog.pending; }
        catch (error) { catalog.pending = null; throw error; }
        if (this.#catalogs.get(catalog.id) !== catalog || !active(catalog)) return [];
        return icons.map(icon => ({ ...icon, categories: [...icon.categories] }));
    }

    static #normalize(rows, catalog) {
        const icons = [], seen = new Set();
        for (const row of Array.isArray(rows) ? rows : []) {
            if (!row || typeof row !== "object") continue;
            const src = imagePath(row.src);
            if (!src) continue;
            const id = text(row.id) || src;
            if (seen.has(id)) continue;
            seen.add(id);
            const label = text(row.label) || src.split("/").at(-1).replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ");
            icons.push({ id, label, src, thumbnailSrc: imagePath(row.thumbnailSrc) || src,
                categories: [...new Set((Array.isArray(row.categories) ? row.categories : []).map(text).filter(Boolean))],
                catalogId: catalog.id, moduleId: catalog.moduleId });
        }
        return icons;
    }

    static #metadata(catalog) {
        return { id: catalog.id, label: catalog.label, moduleId: catalog.moduleId };
    }
}
