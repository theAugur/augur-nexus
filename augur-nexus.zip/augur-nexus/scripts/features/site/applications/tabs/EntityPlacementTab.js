import { hasPremiumAccess } from "../../../access/PremiumAccess.js";
import {
    createNpc,
    generateNpc,
    getNpcGeneratorOptions,
    getNpcGenerators,
    getNpcs,
    openNpcDossier
} from "../../../../api/npcs.js";
import {
    createShip,
    generateShip,
    getShipGeneratorOptions,
    getShipGenerators,
    getShips,
    openShipDossier
} from "../../../../api/ships.js";
import {
    createFaction,
    generateFaction,
    getFactionGeneratorOptions,
    getFactionGenerators,
    getFactions,
    openFactionDossier
} from "../../../../api/factions.js";
import {
    composeLocationGeneratorCandidate,
    createLocation,
    generateLocation,
    getLocationGeneratorOptions,
    getLocationGenerators,
    getLocations,
    openLocation,
    prepareBlankLocationCandidate,
    randomizeLocationName,
    reconcileLocationGeneratorCandidate,
    renderLocationGeneratorCandidatePreview
} from "../../../../api/locations.js";
import { NpcDataEditor } from "../../../campaign-entities/applications/NpcDataEditor.js";
import { ShipDataEditor } from "../../../campaign-entities/applications/ShipDataEditor.js";
import { FactionDataEditor } from "../../../campaign-entities/applications/FactionDataEditor.js";
import { LocationDataEditor } from "../../../campaign-entities/applications/LocationDataEditor.js";
import { NpcEntityModel } from "../../../campaign-entities/models/NpcEntityModel.js";
import { ShipEntityModel } from "../../../campaign-entities/models/ShipEntityModel.js";
import { FactionEntityModel } from "../../../campaign-entities/models/FactionEntityModel.js";
import { LocationEntityModel } from "../../../campaign-entities/models/LocationEntityModel.js";
import { NpcProfileViewModel } from "../../../campaign-entities/models/NpcProfileViewModel.js";
import { ShipProfileViewModel } from "../../../campaign-entities/models/ShipProfileViewModel.js";
import { FactionProfileViewModel } from "../../../campaign-entities/models/FactionProfileViewModel.js";
import { LocationProfileViewModel } from "../../../campaign-entities/models/LocationProfileViewModel.js";
import { GeneratorSessionPreference } from "../../../campaign-entities/services/GeneratorSessionPreference.js";
import { SiteCreateTab } from "./SiteCreateTab.js";
import { SiteLabelManager } from "../../services/SiteLabelManager.js";

const GENERATOR_GENRES = [
    { id: "fantasy", label: "Fantasy" },
    { id: "scifi", label: "Sci-Fi" }
];

const GENRE_MODULE_REQUIREMENTS = {
    fantasy: {
        moduleId: "augur-fantasy",
        label: "Augur: Fantasy",
        url: "https://www.patreon.com/TheAugur"
    },
    scifi: {
        moduleId: "augur-scifi",
        label: "Augur: Sci-Fi",
        url: "https://foundryvtt.com/packages/augur-scifi"
    }
};

const CONFIGS = {
    location: {
        type: "location",
        label: "Location",
        plural: "Locations",
        icon: "fas fa-map-location-dot",
        generatorLabel: "Generator",
        manualLabel: "Manual Location",
        getGenerators: getLocationGenerators,
        getGeneratorOptions: getLocationGeneratorOptions,
        generate: generateLocation,
        prepareBlank: prepareBlankLocationCandidate,
        randomizeName: randomizeLocationName,
        create: createLocation,
        list: getLocations,
        open: openLocation,
        editor: LocationDataEditor,
        model: LocationEntityModel,
        viewModel: LocationProfileViewModel,
        profilePartial: "modules/augur-nexus/templates/campaign-entities/location-profile-panel.hbs",
        composeCandidate: composeLocationGeneratorCandidate,
        reconcileCandidate: reconcileLocationGeneratorCandidate,
        renderCandidatePreview: renderLocationGeneratorCandidatePreview,
        optionGroups: [
            { key: "typeId", name: "generatorTypeId", label: "Kind", source: "types", defaultKey: "typeId" },
            { key: "inhabitantsSpeciesId", name: "generatorInhabitantsSpeciesId", label: "Inhabitants", source: "inhabitants", allowRandom: false, emptyLabel: "Use location default" }
        ],
    },
    npc: {
        type: "npc",
        label: "People",
        plural: "People",
        icon: "fas fa-user-astronaut",
        generatorLabel: "Generator",
        manualLabel: "Manual Person",
        getGenerators: getNpcGenerators,
        getGeneratorOptions: getNpcGeneratorOptions,
        generate: generateNpc,
        create: createNpc,
        list: getNpcs,
        open: openNpcDossier,
        editor: NpcDataEditor,
        model: NpcEntityModel,
        viewModel: NpcProfileViewModel,
        profilePartial: "modules/augur-nexus/templates/campaign-entities/npc-profile-panel.hbs",
        optionGroups: [
            { key: "speciesId", name: "generatorSpeciesId", label: "Race", source: "species", defaultKey: "speciesId", allowRandom: false },
            { key: "roleId", name: "generatorRoleId", label: "Role", source: "roles", defaultKey: "roleId" },
            { key: "gender", name: "generatorGender", label: "Appearance", source: "genders", defaultKey: "gender" }
        ],
    },
    ship: {
        type: "ship",
        label: "Ship",
        plural: "Ships",
        icon: "fas fa-rocket",
        generatorLabel: "Generator",
        manualLabel: "Manual Ship",
        getGenerators: getShipGenerators,
        getGeneratorOptions: getShipGeneratorOptions,
        generate: generateShip,
        create: createShip,
        list: getShips,
        open: openShipDossier,
        editor: ShipDataEditor,
        model: ShipEntityModel,
        viewModel: ShipProfileViewModel,
        profilePartial: "modules/augur-nexus/templates/campaign-entities/ship-profile-panel.hbs",
        optionGroups: [
            { key: "templateId", name: "generatorTemplateId", label: "Template", source: "templates", defaultKey: "templateId" }
        ],
    },
    faction: {
        type: "faction",
        label: "Organizations",
        plural: "Organizations",
        icon: "fas fa-shield-halved",
        generatorLabel: "Generator",
        manualLabel: "Manual Organization",
        getGenerators: getFactionGenerators,
        getGeneratorOptions: getFactionGeneratorOptions,
        generate: generateFaction,
        create: createFaction,
        list: getFactions,
        open: openFactionDossier,
        editor: FactionDataEditor,
        model: FactionEntityModel,
        viewModel: FactionProfileViewModel,
        profilePartial: "modules/augur-nexus/templates/campaign-entities/faction-profile-panel.hbs",
        optionGroups: [
            { key: "typeId", name: "generatorTypeId", label: "Type", source: "types", defaultKey: "typeId" }
        ],
    }
};

const STATES = new Map();

export class EntityPlacementTab {
    constructor(app, type) {
        this.app = app;
        this.type = type;
        this.config = CONFIGS[type];
        if (!this.config) throw new Error(`Unknown Nexus placement entity type: ${type}`);
        if (!STATES.has(type)) STATES.set(type, this.getDefaultState());
    }

    static isEntityTab(tabId) {
        return Object.hasOwn(CONFIGS, tabId);
    }

    static getConfig(type) {
        return CONFIGS[type] || null;
    }

    static getState(type) {
        return STATES.get(type) || null;
    }

    static selectGenre(genreId) {
        for (const state of STATES.values()) {
            if (state.genreId === genreId) continue;
            // Creation filters may change while a candidate keeps its original content and provider.
            state.genreId = genreId;
            state.selectedGeneratorId = "";
            state.options = {};
            state.generationRequest = (state.generationRequest || 0) + 1;
            state.isGeneratingCandidate = false;
        }
    }

    static getPlacementStyle(type) {
        const state = STATES.get(type) || null;
        if (!state) return null;
        const iconSize = this._getEffectiveIconSizeStatic(state);
        return {
            ...state,
            iconSize,
            labelFontSize: this._getEffectiveLabelFontSizeStatic(state, iconSize),
            labelFontFamily: SiteLabelManager.resolveFontFamily(state)
        };
    }

    static transformPlacementStyle(type, { rotationDelta = 0, iconSizeDelta = 0, resetIconSize = false } = {}) {
        const state = STATES.get(type);
        if (!state) return null;

        if (rotationDelta) {
            state.rotation = this._normalizeRotation(Number(state.rotation || 0) + Number(rotationDelta || 0));
        }

        if (resetIconSize) {
            state.iconSizeMode = "scene-default";
            state.customIconSize = null;
            state.labelFontSizeMode = "auto";
            state.customLabelFontSize = null;
        } else if (iconSizeDelta) {
            state.iconSizeMode = "custom";
            state.customIconSize = this._clampIconSizeStatic(this._getEffectiveIconSizeStatic(state) + Number(iconSizeDelta || 0));
            state.labelFontSizeMode = "auto";
            state.customLabelFontSize = null;
        }

        Hooks.callAll("augurNexusEntityPlacementStyleChanged", type);
        return this.getPlacementStyle(type);
    }

    static getActiveEntityType(activeTab) {
        return this.isEntityTab(activeTab) ? activeTab : null;
    }

    static async getPlacementDraft(type) {
        if (!hasPremiumAccess()) return null;
        const config = CONFIGS[type];
        const state = STATES.get(type);
        if (!config || !state) return null;
        if (state.isGeneratingCandidate) return null;
        if (!state.candidate) {
            const tab = state.controller;
            if (!tab) return null;
            await tab.generateCandidate({ render: false });
        }
        if (!state.candidate || state.isGeneratingCandidate) return null;
        if (type === "location" && !state.startBlank && state.candidateOptions?.inhabitantsSpeciesId) {
            const request = state.generationRequest;
            const options = await config.getGeneratorOptions(state.candidateGeneratorId || state.selectedGeneratorId);
            if (state.isGeneratingCandidate || request !== state.generationRequest || !state.candidate) return null;
            try {
                this._validateOptionalChoices(config, options, state.candidateOptions);
            } catch (error) {
                state.candidate = null;
                state.composition = { members: [] };
                throw error;
            }
        }
        if (type === "npc") {
            const request = state.generationRequest;
            const options = await config.getGeneratorOptions(state.candidateGeneratorId || state.selectedGeneratorId);
            if (state.isGeneratingCandidate || request !== state.generationRequest || !state.candidate) return null;
            if ((options.requiresRole && !options.roles.some(role => role.id === state.candidate.generation?.templateId)) || (options.requiresSpecies && !options.species.some(race => race.id === state.candidate.generation?.raceTemplateId))) {
                state.candidate = null;
                throw new Error("This race or role is no longer available. Generate a new candidate.");
            }
        }
        if (!hasPremiumAccess()) return null;
        return foundry.utils.deepClone({
            type,
            candidate: state.candidate,
            composition: state.composition || { members: [] }
        });
    }

    static async completePlacement(type, entity = null) {
        const state = STATES.get(type);
        if (!state) return;
        state.candidate = null;
        state.candidateEdited = false;
        state.composition = { members: [] };
        state.lastPlacedEntityId = entity?.id || "";
        await state.controller?.generateCandidate();
    }

    static async onWorldTemplatesChanged({ reason = "", deletedId = "" } = {}) {
        for (const type of ["npc", "location"]) {
            const state = STATES.get(type);
            if (!state) continue;
            state.generationRequest = (state.generationRequest || 0) + 1;
            state.isGeneratingCandidate = false;
            if (type === "npc" && state.candidate) {
                const options = await CONFIGS.npc.getGeneratorOptions(state.candidateGeneratorId || state.selectedGeneratorId);
                if ((options.requiresRole && !options.roles.some(role => role.id === state.candidate?.generation?.templateId)) || (options.requiresSpecies && !options.species.some(race => race.id === state.candidate?.generation?.raceTemplateId))) state.candidate = null;
            }
            if (type === "location" && !state.startBlank && (reason === "visibility" || deletedId || state.options.inhabitantsSpeciesId)) {
                state.candidate = null;
                state.composition = { members: [] };
            }
            if (state.controller?.app?.rendered) state.controller.render();
        }
    }

    async _prepareContext() {
        const state = this._state;
        state.controller = this;
        const allGenerators = this.config.getGenerators();
        if (this.app?.genreId && state.genreId !== this.app.genreId) {
            EntityPlacementTab.selectGenre(this.app.genreId);
        }
        if (state.selectedGeneratorId === null) {
            state.selectedGeneratorId = GeneratorSessionPreference.resolve(this.type, allGenerators);
            const preferredGenerator = allGenerators.find(generator => generator.id === state.selectedGeneratorId);
            if (!this.app?.genreId && preferredGenerator?.genreId) state.genreId = preferredGenerator.genreId;
        }
        state.genreId = GENERATOR_GENRES.some(genre => genre.id === state.genreId) ? state.genreId : "fantasy";
        const genreRequirement = GENRE_MODULE_REQUIREMENTS[state.genreId];
        const genreModuleAvailable = globalThis.game?.modules?.get(genreRequirement.moduleId)?.active === true;
        const premiumAvailable = hasPremiumAccess();
        const blankMode = premiumAvailable && this.type === "location" && state.startBlank;
        const genreModuleRequired = !genreModuleAvailable && !blankMode;
        const genreGenerators = !genreModuleAvailable ? [] : allGenerators.filter(generator => generator.genreId === state.genreId);
        const moduleGenerators = genreGenerators.filter(generator => generator.moduleId !== "augur-nexus");
        const generators = moduleGenerators.length ? moduleGenerators : genreGenerators;
        if (!generators.some(generator => generator.id === state.selectedGeneratorId)) {
            state.selectedGeneratorId = generators[0]?.id || "";
            if (!blankMode) {
                state.options = {};
            }
        }
        const selectedGeneratorId = state.selectedGeneratorId || "";
        const generatorOptions = selectedGeneratorId ? await this.config.getGeneratorOptions(selectedGeneratorId) : {};
        const optionGroups = this._buildOptionGroups(generatorOptions).map(group => ({ ...group, disabled: blankMode && group.key === "inhabitantsSpeciesId" }));
        const noRoles = generatorOptions.requiresRole && !generatorOptions.roles?.length;
        const noSpecies = generatorOptions.requiresSpecies && !generatorOptions.species?.length;
        if ((blankMode || selectedGeneratorId) && !noSpecies && !noRoles && !state.candidate && !state.isGeneratingCandidate) {
            try {
                await this.generateCandidate({ render: false });
            } catch (err) {
                console.warn(`Augur: Nexus | Failed to generate initial ${this.config.label} candidate.`, err);
            }
        }

        const candidateProfileOptions = {
            emptyTraitsLabel: "No personality traits rolled.",
            emptyLabel: `No ${this.config.label.toLowerCase()} profile details selected.`,
            showBody: this.type !== "location"
        };
        if (this.type === "npc") {
            Object.assign(candidateProfileOptions, {
                compactMode: true,
                includeDescriptorInSubtitle: true,
                showDefaultFields: false
            });
        }
        if (this.type === "faction") candidateProfileOptions.showCurrentThread = false;
        const candidateProfile = premiumAvailable && state.candidate && !blankMode
            ? this.config.viewModel.fromCandidate(state.candidate, candidateProfileOptions)
            : null;
        if (candidateProfile && this.type === "faction") {
            candidateProfile.imageSrc = await FactionEntityModel.getImageAsync(state.candidate);
        }
        if (candidateProfile) {
            // Context previews render before the host application's PARTS templates are loaded.
            await foundry.applications.handlebars.loadTemplates([
                "modules/augur-nexus/templates/campaign-entities/quest-world-ties.hbs",
                "modules/augur-nexus/templates/campaign-entities/npc-portrait.hbs"
            ]);
        }
        const candidateHtml = candidateProfile
            ? await foundry.applications.handlebars.renderTemplate(this.config.profilePartial, { profile: candidateProfile })
            : "";
        const candidateExtensionHtml = premiumAvailable && state.candidate && !blankMode && this.config.renderCandidatePreview
            ? await this.config.renderCandidatePreview(state.candidateGeneratorId || selectedGeneratorId, state.candidate, state.composition)
            : "";
        const style = this._getStyleContext();

        const context = {
            entityType: this.type,
            startBlank: !!blankMode,
            canStartBlank: premiumAvailable && this.type === "location",
            canShowCandidate: premiumAvailable && (!!state.candidate || blankMode || generators.length > 0),
            canRandomizeName: !!generators.find(generator => generator.id === selectedGeneratorId)?.canRandomizeName,
            blankImageSrc: blankMode ? LocationEntityModel.getThumbnail(state.candidate) : "",
            blankName: state.candidate?.display?.name || "New Location",
            blankKind: state.candidate?.profile?.type || state.candidate?.profile?.kindLabel || "Location",
            isLocation: this.type === "location",
            isNpc: this.type === "npc",
            isShip: this.type === "ship",
            isFaction: this.type === "faction",
            label: this.config.label,
            plural: this.config.plural,
            icon: this.config.icon,
            genreModuleRequired,
            genreModuleRequiresText: `${genreRequirement.label} Module required`,
            genreModuleRequiresUrl: genreRequirement.url,
            hasGenreProvider: generators.length > 0,
            hasMultipleGenreGenerators: generators.length > 1,
            genres: GENERATOR_GENRES.map(genre => ({ ...genre, selected: genre.id === state.genreId })),
            selectedGenreId: state.genreId,
            selectedGenreLabel: GENERATOR_GENRES.find(genre => genre.id === state.genreId)?.label || "Fantasy",
            emptyGenreText: `No ${GENERATOR_GENRES.find(genre => genre.id === state.genreId)?.label || "Fantasy"} ${this.config.label} templates are currently available.`,
            generators: generators.map(generator => ({
                ...generator,
                selected: generator.id === selectedGeneratorId
            })),
            selectedGeneratorId,
            hasGeneratorSelected: !!selectedGeneratorId,
            optionGroups,
            noSpecies, noRoles,
            hasOptionGroups: optionGroups.length > 0,
            candidate: state.candidate ? {
                profile: candidateProfile,
                html: candidateHtml,
                extensionHtml: candidateExtensionHtml,
                data: state.candidate
            } : null,
            hasCandidate: premiumAvailable && !!state.candidate,
            ...style
        };
        context.advancedHtml = await foundry.applications.handlebars.renderTemplate(
            "modules/augur-nexus/templates/site/parts/placement-style-advanced.hbs",
            context
        );
        return context;
    }

    _attachPartListeners(partId, htmlElement) {
        const el = htmlElement instanceof HTMLElement ? htmlElement : htmlElement[0];
        if (!el) return;
        const root = el.querySelector(`[data-entity-placement="${this.type}"]`);
        if (!root) return;

        root.querySelector("[data-action='viewRequiredGenreModule']")?.addEventListener("click", event => {
            event.preventDefault();
            const url = String(event.currentTarget.dataset.requiresUrl || "").trim();
            if (url) window.open(url, "_blank", "noopener,noreferrer");
        });

        root.querySelector("[name='generatorId']")?.addEventListener("change", event => {
            this._state.selectedGeneratorId = event.currentTarget.value || "";
            GeneratorSessionPreference.remember(this.type, this._state.selectedGeneratorId, this.config.getGenerators());
            this._resetOptionState();
            this._state.candidate = null;
            this._state.composition = { members: [] };
            this.render();
        });

        root.querySelector("[name='startBlank']")?.addEventListener("change", async event => {
            const checkbox = event.currentTarget;
            await this.setStartBlank(checkbox.checked);
            checkbox.checked = !!this._state.startBlank;
        });
        root.querySelector("[name='blankLocationName']")?.addEventListener("input", event => {
            if (!this._state.candidate) return;
            this._state.candidate.display.name = event.currentTarget.value;
            this._state.candidateEdited = true;
            Hooks.callAll("augurNexusEntityPlacementCandidateChanged", this.type);
        });
        root.querySelector("[data-action='randomizeBlankName']")?.addEventListener("click", event => {
            event.preventDefault();
            this.randomizeBlankName();
        });
        for (const group of this.config.optionGroups) {
            root.querySelector(`[name='${group.name}']`)?.addEventListener("change", event => {
                this._state.options[group.key] = event.currentTarget.value || (group.emptyLabel ? "" : "random");
                this.generateCandidate();
            });
        }

        root.querySelector("[data-action='generateCandidate']")?.addEventListener("click", event => {
            event.preventDefault();
            this.generateCandidate();
        });

        root.querySelector("[data-action='rerollCandidate']")?.addEventListener("click", event => {
            event.preventDefault();
            this.generateCandidate();
        });

        root.querySelector("[data-action='editCandidate']")?.addEventListener("click", event => {
            event.preventDefault();
            if (!this._state.candidate) return;
            this.config.editor.show({
                candidate: this._state.candidate,
                onSave: async updated => {
                    this._state.candidate = updated;
                    this._state.candidateEdited = true;
                    if (!this._state.startBlank && this.config.reconcileCandidate) {
                        this._state.composition = await this.config.reconcileCandidate(
                            this._state.candidateGeneratorId || this._state.selectedGeneratorId,
                            updated,
                            this._state.composition
                        );
                    }
                    this.render();
                }
            });
        });

        root.querySelector("[data-action='editCandidateIcon']")?.addEventListener("click", async event => {
            event.preventDefault();
            const candidate = this._state.candidate;
            if (this.type !== "location" || !candidate) return;
            const { SitePanel } = await import("../SitePanel.js");
            const { SiteIconPicker } = await import("../SiteIconPicker.js");
            const icons = await SitePanel.getAllBuiltInIcons();
            const currentSrc = candidate.display?.imageSrc || "";
            const currentIconId = icons.find(icon => icon.src === currentSrc)?.id || "custom";
            new SiteIconPicker(icons, currentIconId, "landmark", selection => {
                // A reroll or clear while the picker is open must not change a different candidate.
                if (this._state.candidate !== candidate) return;
                const src = typeof selection === "object" ? selection?.src : icons.find(icon => icon.id === selection)?.src;
                if (!src) return;
                candidate.display = { ...candidate.display, imageSrc: src, thumbnailSrc: "" };
                this._state.candidateEdited = true;
                Hooks.callAll("augurNexusEntityPlacementCandidateChanged", this.type);
                this.render();
            }, { currentCustomIconSrc: currentSrc, allBuiltInIcons: icons, showThemeIconsOnly: false, filterByRole: false }).render(true);
        });

        root.querySelector("[data-action='clearCandidate']")?.addEventListener("click", event => {
            event.preventDefault();
            this._state.candidate = null;
            this._state.composition = { members: [] };
            this.render();
        });
        this._attachStyleListeners(root);
    }

    render(force, options) {
        return this.app?.render(force, options);
    }

    async setStartBlank(checked) {
        if (checked && !hasPremiumAccess()) return false;
        if (this.type !== "location" || !!checked === !!this._state.startBlank) return true;
        if (this._state.candidateEdited && this._state.candidate) {
            const confirmed = await foundry.applications.api.DialogV2.confirm({
                window: { title: "Replace edited location?" },
                content: "<p>Changing creation mode replaces this candidate and its manual edits.</p>",
                yes: { label: "Replace" }, no: { label: "Keep Editing" }, rejectClose: false
            });
            if (!confirmed) return false;
        }
        this._state.generationRequest = (this._state.generationRequest || 0) + 1;
        this._state.isGeneratingCandidate = false;
        this._state.startBlank = !!checked;
        this._state.candidate = null;
        this._state.candidateEdited = false;
        this._state.composition = { members: [] };
        await this.generateCandidate({ render: false });
        this.render();
        return true;
    }

    async prepareBlankCandidate({ render = true } = {}) {
        if (!hasPremiumAccess()) return;
        const state = this._state;
        const generatorId = state.selectedGeneratorId || "";
        const request = state.generationRequest = (state.generationRequest || 0) + 1;
        state.isGeneratingCandidate = true;
        Hooks.callAll("augurNexusEntityPlacementCandidateChanged", this.type);
        try {
            const typeId = state.options.typeId || "random";
            const prepared = await this.config.prepareBlank?.(generatorId, { typeId });
            if (!hasPremiumAccess() || request !== state.generationRequest || !state.startBlank) return;
            const choices = generatorId ? await this.config.getGeneratorOptions(generatorId) : {};
            if (!hasPremiumAccess() || request !== state.generationRequest || !state.startBlank) return;
            const label = choices.types?.find(row => row.id === typeId)?.label || "Location";
            state.candidate = prepared || {
                type: "location", sourceModule: "augur-nexus",
                display: { name: "New Location", imageSrc: "", thumbnailSrc: "" },
                profile: { kindId: "location", kindLabel: "Location", type: typeId === "random" ? "" : label, summary: "", fields: [] }
            };
            state.candidateOptions = { typeId };
            state.candidateEdited = false;
            state.composition = { members: [] };
        } catch (error) {
            if (request === state.generationRequest) ui.notifications.error(error.message);
        } finally {
            if (request === state.generationRequest) {
                state.isGeneratingCandidate = false;
                Hooks.callAll("augurNexusEntityPlacementCandidateChanged", this.type);
            }
        }
        if (render) this.render();
    }

    async randomizeBlankName() {
        const state = this._state;
        if (!state.startBlank || !state.candidate || state.isGeneratingCandidate) return;
        const candidate = state.candidate;
        const previousName = candidate.display.name;
        try {
            const name = await this.config.randomizeName?.(state.selectedGeneratorId, {
                candidate: foundry.utils.deepClone(candidate), typeId: state.candidateOptions.typeId
            });
            if (!name || state.candidate !== candidate || candidate.display.name !== previousName) return;
            candidate.display.name = String(name);
            state.candidateEdited = true;
            Hooks.callAll("augurNexusEntityPlacementCandidateChanged", this.type);
            this.render();
        } catch (error) { ui.notifications.error(error.message); }
    }

    async generateCandidate({ render = true } = {}) {
        if (!hasPremiumAccess()) return;
        if (this.type === "location" && this._state.startBlank) return this.prepareBlankCandidate({ render });
        const generatorId = this._state.selectedGeneratorId || "";
        if (!generatorId) return;
        const options = {};
        for (const group of this.config.optionGroups) {
            const value = this._state.options[group.key];
            if (value || group.allowRandom !== false) options[group.key] = value || "random";
        }
        const request = this._state.generationRequest = (this._state.generationRequest || 0) + 1;
        this._state.isGeneratingCandidate = true;
        Hooks.callAll("augurNexusEntityPlacementCandidateChanged", this.type);
        try {
            const generatorOptions = await this.config.getGeneratorOptions(generatorId);
            if (request !== this._state.generationRequest) return;
            for (const group of this.config.optionGroups) {
                if (group.emptyLabel && !Array.isArray(generatorOptions[group.source])) delete options[group.key];
            }
            EntityPlacementTab._validateOptionalChoices(this.config, generatorOptions, options);
            if (generatorOptions.requiresSpecies && !generatorOptions.species?.length) {
                this._state.candidate = null;
                ui.notifications.warn("No races are available. Show or create a race in World Templates.");
                return;
            }
            if (generatorOptions.requiresRole && !generatorOptions.roles?.length) {
                this._state.candidate = null;
                ui.notifications.warn("No roles are available. Show or create a role in World Templates.");
                return;
            }
            const candidate = await this.config.generate(generatorId, options);
            const composition = candidate && this.config.composeCandidate
                ? await this.config.composeCandidate(generatorId, candidate, options)
                : { members: [] };
            if (!hasPremiumAccess() || request !== this._state.generationRequest || generatorId !== this._state.selectedGeneratorId) return;
            this._state.candidate = candidate;
            this._state.candidateGeneratorId = generatorId;
            this._state.candidateEdited = false;
            this._state.candidateOptions = { ...options };
            this._state.composition = composition || { members: [] };
        } catch (error) {
            if (request === this._state.generationRequest) {
                this._state.candidate = null;
                this._state.composition = { members: [] };
                ui.notifications.error(error.message);
            }
        } finally {
            if (request === this._state.generationRequest) {
                this._state.isGeneratingCandidate = false;
                Hooks.callAll("augurNexusEntityPlacementCandidateChanged", this.type);
            }
        }
        if (render) this.render();
    }

    _buildOptionGroups(generatorOptions = {}) {
        return this.config.optionGroups
            .filter(group => {
                if (!group.emptyLabel || Array.isArray(generatorOptions[group.source])) return true;
                delete this._state.options[group.key];
                return false;
            })
            .map(group => {
                const available = generatorOptions[group.source] || [];
                if (group.emptyLabel) {
                    const selected = this._state.options[group.key] || "";
                    const choices = [{ id: "", label: group.emptyLabel }, ...available];
                    if (selected && !available.some(option => option.id === selected)) {
                        choices.push({ id: selected, label: "Unavailable — choose another race" });
                    }
                    this._state.options[group.key] = selected;
                    return { ...group, options: this._buildOptions(choices, selected, false), hasOptions: true };
                }
                let selected = this._state.options[group.key] || generatorOptions.defaults?.[group.defaultKey] || "random";
                if (group.allowRandom === false && !available.some(option => option.id === selected)) {
                    selected = available.find(option => option.id === generatorOptions.defaults?.[group.defaultKey])?.id || available[0]?.id || "";
                }
                this._state.options[group.key] = selected;
                const options = this._buildOptions(available, selected, group.allowRandom !== false);
                return {
                    ...group,
                    options,
                    hasOptions: options.length > 0
                };
            })
            .filter(group => group.hasOptions);
    }

    _buildOptions(options = [], selectedId = "random", allowRandom = true) {
        const rows = options.map(option => ({
            ...option,
            selected: option.id === selectedId
        }));
        if (allowRandom && !rows.some(option => option.id === "random")) {
            rows.unshift({ id: "random", label: "Any", selected: selectedId === "random" });
        }
        return rows.map(option => ({
            ...option,
            label: option.id === "random" ? "Any" : option.label
        }));
    }

    _resetOptionState() {
        this._state.generationRequest = (this._state.generationRequest || 0) + 1;
        this._state.isGeneratingCandidate = false;
        this._state.options = {};
    }

    static _validateOptionalChoices(config, generatorOptions, selections = {}) {
        for (const group of config.optionGroups) {
            const selected = selections[group.key];
            if (group.emptyLabel && selected && !generatorOptions[group.source]?.some(option => option.id === selected)) {
                throw new Error(`${group.label} selection is no longer available. Choose another race or use the location default.`);
            }
        }
    }

    getDefaultState() {
        return {
            genreId: GeneratorSessionPreference.getPreferredGenre(),
            selectedGeneratorId: null,
            options: {},
            advancedOpen: false,
            iconSizeMode: "scene-default",
            customIconSize: null,
            rotation: 0,
            showLabel: true,
            labelFontSizeMode: "auto",
            customLabelFontSize: null,
            labelFontFamily: SiteLabelManager.FONT_FAMILY,
            labelColor: SiteCreateTab.DEFAULT_COLOR,
            snapToGrid: false,
            candidate: null,
            startBlank: false,
            candidateEdited: false,
            candidateOptions: {},
            composition: { members: [] },
            isGeneratingCandidate: false,
            controller: null,
            lastPlacedEntityId: ""
        };
    }

    _getStyleContext() {
        const state = this._state;
        const iconSize = this._getEffectiveIconSize();
        const labelFontSize = this._getEffectiveLabelFontSize(iconSize);
        return {
            advancedOpen: !!state.advancedOpen,
            selectedIconSize: iconSize,
            rotation: EntityPlacementTab._normalizeRotation(state.rotation),
            iconSizeUsesSceneDefault: state.iconSizeMode !== "custom",
            showResetIconSize: true,
            showLabel: state.showLabel !== false,
            showLabelToggleInAdvanced: true,
            selectedLabelFontSize: labelFontSize,
            labelFontSizeUsesAuto: state.labelFontSizeMode !== "custom",
            showResetLabelFontSize: true,
            minLabelFontSize: SiteLabelManager.MIN_FONT_SIZE,
            maxLabelFontSize: SiteLabelManager.MAX_FONT_SIZE,
            selectedLabelFontFamily: SiteLabelManager.resolveFontFamily(state),
            labelFontOptions: SiteLabelManager.FONT_OPTIONS,
            selectedLabelColor: state.labelColor || SiteCreateTab.DEFAULT_COLOR,
            showLabelColorControls: true,
            colors: SiteCreateTab.COLOR_OPTIONS,
            showSnapToGrid: true,
            snapToGrid: !!state.snapToGrid,
            showRandomizeToggle: false
        };
    }

    _attachStyleListeners(root) {
        const state = this._state;
        const advancedDetails = root.querySelector("[data-placement-advanced]");
        const iconSizeInput = root.querySelector("input[name='iconSize']");
        const iconSizeValue = root.querySelector("[data-site-icon-size-value]");
        const labelFontSizeInput = root.querySelector("input[name='labelFontSize']");
        const labelFontSizeValue = root.querySelector("[data-site-label-font-size-value]");
        const resetIconSizeButton = root.querySelector("[data-action='resetIconSize']");
        const resetLabelFontSizeButton = root.querySelector("[data-action='resetLabelFontSize']");
        const labelFontFamilySelect = root.querySelector("select[name='labelFontFamily']");
        const showLabelCheckbox = root.querySelector("input[name='showLabel']");
        const snapToGridCheckbox = root.querySelector("input[name='snapToGrid']");

        advancedDetails?.addEventListener("toggle", event => {
            state.advancedOpen = !!event.currentTarget.open;
        });

        iconSizeInput?.addEventListener("input", event => {
            const nextSize = this._clampIconSize(event.currentTarget.value);
            state.iconSizeMode = "custom";
            state.customIconSize = nextSize;
            state.labelFontSizeMode = "auto";
            state.customLabelFontSize = null;
            const nextLabelFontSize = this._getEffectiveLabelFontSize(nextSize);
            if (iconSizeValue) iconSizeValue.textContent = String(nextSize);
            if (labelFontSizeInput) labelFontSizeInput.value = String(nextLabelFontSize);
            if (labelFontSizeValue) labelFontSizeValue.textContent = String(nextLabelFontSize);
            if (resetIconSizeButton) resetIconSizeButton.disabled = false;
            if (resetLabelFontSizeButton) resetLabelFontSizeButton.disabled = true;
            this._notifyStyleChanged();
        });

        labelFontSizeInput?.addEventListener("input", event => {
            state.labelFontSizeMode = "custom";
            state.customLabelFontSize = SiteLabelManager.clampFontSize(event.currentTarget.value);
            if (labelFontSizeValue) labelFontSizeValue.textContent = String(this._getEffectiveLabelFontSize());
            if (resetLabelFontSizeButton) resetLabelFontSizeButton.disabled = false;
            this._notifyStyleChanged();
        });

        resetIconSizeButton?.addEventListener("click", event => {
            event.preventDefault();
            state.iconSizeMode = "scene-default";
            state.customIconSize = null;
            state.labelFontSizeMode = "auto";
            state.customLabelFontSize = null;
            const nextSize = this._getEffectiveIconSize();
            const nextLabelFontSize = this._getEffectiveLabelFontSize(nextSize);
            if (iconSizeInput) iconSizeInput.value = String(nextSize);
            if (iconSizeValue) iconSizeValue.textContent = String(nextSize);
            if (labelFontSizeInput) labelFontSizeInput.value = String(nextLabelFontSize);
            if (labelFontSizeValue) labelFontSizeValue.textContent = String(nextLabelFontSize);
            resetIconSizeButton.disabled = true;
            if (resetLabelFontSizeButton) resetLabelFontSizeButton.disabled = true;
            this._notifyStyleChanged();
            this.render();
        });

        resetLabelFontSizeButton?.addEventListener("click", event => {
            event.preventDefault();
            state.labelFontSizeMode = "auto";
            state.customLabelFontSize = null;
            const nextSize = this._getEffectiveLabelFontSize();
            if (labelFontSizeInput) labelFontSizeInput.value = String(nextSize);
            if (labelFontSizeValue) labelFontSizeValue.textContent = String(nextSize);
            resetLabelFontSizeButton.disabled = true;
            this._notifyStyleChanged();
            this.render();
        });

        labelFontFamilySelect?.addEventListener("change", event => {
            state.labelFontFamily = SiteLabelManager.resolveFontFamily({ labelFontFamily: event.currentTarget.value });
            this._notifyStyleChanged();
        });

        showLabelCheckbox?.addEventListener("change", event => {
            state.showLabel = !!event.currentTarget.checked;
            this._notifyStyleChanged();
            this.render();
        });

        snapToGridCheckbox?.addEventListener("change", event => {
            state.snapToGrid = !!event.currentTarget.checked;
            this._notifyStyleChanged();
        });

        root.querySelectorAll("[data-placement-label-color]").forEach(button => {
            button.addEventListener("click", event => {
                event.preventDefault();
                state.labelColor = event.currentTarget.dataset.placementLabelColor || SiteCreateTab.DEFAULT_COLOR;
                this._notifyStyleChanged();
                this.render();
            });
        });
    }

    _clampIconSize(value) {
        return EntityPlacementTab._clampIconSizeStatic(value);
    }

    _getSceneDefaultIconSize() {
        return EntityPlacementTab._getSceneDefaultIconSizeStatic();
    }

    _getEffectiveIconSize() {
        return EntityPlacementTab._getEffectiveIconSizeStatic(this._state);
    }

    _getEffectiveLabelFontSize(iconSize = null) {
        return EntityPlacementTab._getEffectiveLabelFontSizeStatic(this._state, iconSize ?? this._getEffectiveIconSize());
    }

    static _clampIconSizeStatic(value) {
        const numeric = Number(value);
        if (!Number.isFinite(numeric)) return 100;
        return Math.min(SiteCreateTab.MAX_ICON_SIZE, Math.max(SiteCreateTab.MIN_ICON_SIZE, Math.round(numeric)));
    }

    static _getEffectiveIconSizeStatic(state = {}) {
        if (state.iconSizeMode !== "custom") return this._getSceneDefaultIconSizeStatic();
        return this._clampIconSizeStatic(state.customIconSize ?? state.iconSize ?? 100);
    }

    static _getEffectiveLabelFontSizeStatic(state = {}, iconSize = null) {
        const resolvedIconSize = iconSize ?? this._getEffectiveIconSizeStatic(state);
        if (state.labelFontSizeMode !== "custom") return SiteLabelManager.getDefaultFontSize(resolvedIconSize);
        return SiteLabelManager.clampFontSize(state.customLabelFontSize ?? state.labelFontSize);
    }

    static _getSceneDefaultIconSizeStatic() {
        const sceneGridSize = canvas.grid?.size ?? canvas.dimensions?.size ?? 100;
        return this._clampIconSizeStatic(sceneGridSize);
    }

    static _normalizeRotation(value) {
        const numeric = Number(value);
        if (!Number.isFinite(numeric)) return 0;
        return ((Math.round(numeric) % 360) + 360) % 360;
    }

    _notifyStyleChanged() {
        Hooks.callAll("augurNexusEntityPlacementStyleChanged", this.type);
    }

    get _state() {
        if (!STATES.has(this.type)) STATES.set(this.type, this.getDefaultState());
        return STATES.get(this.type);
    }
}


