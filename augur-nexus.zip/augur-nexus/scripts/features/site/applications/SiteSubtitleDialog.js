import { SiteRecordManager } from "../services/SiteRecordManager.js";

export class SiteSubtitleDialog {
    static async show(record) {
        if (!game.user?.isGM) return null;

        const site = SiteRecordManager.normalizeRecord(record);
        if (!site?.siteId) return null;

        const automaticSubtitle = SiteRecordManager.getDossierSubtitle({
            ...site,
            siteSubtitleMode: "automatic"
        });
        const safeAutomaticSubtitle = foundry.utils.escapeHTML(automaticSubtitle);
        const safeCustomSubtitle = foundry.utils.escapeHTML(site.siteSubtitle || "");
        const currentMode = site.siteSubtitleMode || "automatic";
        const checked = mode => currentMode === mode ? "checked" : "";

        const result = await foundry.applications.api.DialogV2.wait({
            window: { title: "Edit Site Subtitle" },
            position: { width: 480 },
            modal: true,
            rejectClose: false,
            content: `
                <div class="nexus-player-open-dialog site-subtitle-dialog">
                    <p>Choose how the subtitle appears in this Site's dossier.</p>
                    <div class="nexus-player-open-options">
                        <label class="nexus-player-open-option">
                            <input type="radio" name="siteSubtitleMode" value="automatic" ${checked("automatic")}>
                            <span>
                                <strong>Automatic</strong>
                                <small>Use the Site genre and scene type: ${safeAutomaticSubtitle}</small>
                            </span>
                        </label>
                        <label class="nexus-player-open-option">
                            <input type="radio" name="siteSubtitleMode" value="custom" ${checked("custom")}>
                            <span>
                                <strong>Custom</strong>
                                <small>Show your own text without changing the Site's underlying type.</small>
                            </span>
                        </label>
                        <label class="nexus-player-open-option">
                            <input type="radio" name="siteSubtitleMode" value="hidden" ${checked("hidden")}>
                            <span>
                                <strong>Hidden</strong>
                                <small>Do not show a subtitle in the dossier header.</small>
                            </span>
                        </label>
                    </div>
                    <label class="site-subtitle-custom-field">
                        <span>Custom subtitle</span>
                        <input type="text" name="siteSubtitle" value="${safeCustomSubtitle}" maxlength="120" placeholder="Enter a subtitle">
                    </label>
                </div>
            `,
            buttons: [
                {
                    action: "save",
                    label: "Save",
                    icon: "fa-solid fa-check",
                    default: true,
                    callback: (_event, button) => ({
                        siteSubtitleMode: button.form?.elements?.siteSubtitleMode?.value || "automatic",
                        siteSubtitle: String(button.form?.elements?.siteSubtitle?.value || "").trim()
                    })
                },
                {
                    action: "cancel",
                    label: "Cancel",
                    icon: "fa-solid fa-xmark",
                    callback: () => null
                }
            ]
        });

        if (!result) return null;
        if (result.siteSubtitleMode === "custom" && !result.siteSubtitle) {
            ui.notifications.warn("Enter a custom subtitle, or choose Automatic or Hidden.");
            return null;
        }
        return result;
    }
}
