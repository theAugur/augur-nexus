// Shared picker for adopting an eligible world Scene into a Site or Location workflow.

import { NexusLineageManager } from "../../nexus/services/NexusLineageManager.js";
import { LegacySciFiCompatibility } from "../../../support/compatibility/LegacySciFiCompatibility.js";
import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { PlaceHierarchyModel } from "../../places/models/PlaceHierarchyModel.js";
import { PlaceTypeRegistry } from "../../places/services/PlaceTypeRegistry.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class SiteScenePicker extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
        id: "augur-nexus-site-scene-picker",
        classes: ["augur-nexus", "site-scene-picker-dialog"],
        tag: "div",
        window: {
            title: "Select Scene",
            resizable: true,
            minimizable: false
        },
        position: {
            width: 420,
            height: 520
        }
    };

    static PARTS = {
        main: {
            template: "modules/augur-nexus/templates/site/site-scene-picker.hbs"
        }
    };

    constructor(currentSelection, onSelect, { mode = "site", excludedSceneIds = [], locationId = null } = {}) {
        super();
        this.currentSelection = currentSelection || null;
        this.onSelect = onSelect;
        this.mode = mode === "location" ? "location" : "site";
        this.locationId = String(locationId || "").trim() || null;
        this.includeEstablishedBranches = false;
        this.showUnavailableScenes = false;
        this.excludedSceneIds = new Set((excludedSceneIds || []).map(id => String(id || "").trim()).filter(Boolean));
    }

    async _prepareContext() {
        const currentSceneId = canvas.scene?.id || null;
        const rootSceneId = NexusLineageManager.getRootScene()?.id || null;
        const locationSceneOwners = new Map();
        for (const location of LocationEntityStore.getLocations()) {
            const sceneId = location.scenes?.primarySceneId;
            if (sceneId && !locationSceneOwners.has(sceneId)) locationSceneOwners.set(sceneId, location);
        }
        const branchIndex = this.#buildBranchIndex(PlaceTypeRegistry.getNodes({ isGM: true, includeHidden: true }));
        const candidates = game.scenes.contents
            .map(scene => {
                const sceneKey = `scene:${scene.id}`;
                const descendantCount = branchIndex.descendantCounts.get(sceneKey) || 0;
                const availability = this.#getSceneAvailability(scene, {
                    currentSceneId,
                    rootSceneId,
                    locationSceneOwners,
                    excludedSceneIds: this.excludedSceneIds,
                    excludeCurrentScene: this.mode !== "location",
                    descendantCount,
                    containsLocation: branchIndex.containingSceneKeys.has(sceneKey)
                });
                return {
                    scene,
                    descendantCount,
                    ...availability
                };
            })
            .sort((left, right) => Number(right.isAvailable) - Number(left.isAvailable)
                || (left.scene.folder?.sort ?? 0) - (right.scene.folder?.sort ?? 0)
                || left.scene.sort - right.scene.sort
                || left.scene.name.localeCompare(right.scene.name));
        const scenes = candidates
            .filter(candidate => candidate.isAvailable || this.showUnavailableScenes)
            .map(({ scene, descendantCount, isAvailable, unavailableReason }) => ({
                id: scene.id,
                name: scene.name,
                folderName: scene.folder?.name || "",
                thumb: scene.thumb || "",
                isCurrent: scene.id === currentSceneId,
                isActiveForPlayers: scene.active,
                isSelected: scene.id === this.currentSelection,
                isAvailable,
                unavailableReason,
                descendantCount,
                hasDescendants: descendantCount > 0,
                descendantLabel: `${descendantCount} ${descendantCount === 1 ? "descendant" : "descendants"}`
            }));

        return {
            scenes,
            hasScenes: scenes.length > 0,
            emptyLabel: this.mode === "location" && !this.includeEstablishedBranches
                ? "No standalone Scenes found. Include established branches or show unavailable Scenes for details."
                : "No eligible Scenes found. Show unavailable Scenes for details.",
            hasUnavailableScenes: candidates.some(candidate => !candidate.isAvailable),
            showUnavailableScenes: this.showUnavailableScenes,
            showEstablishedBranchToggle: this.mode === "location",
            includeEstablishedBranches: this.includeEstablishedBranches,
            explainer: this.mode === "location"
                ? this.includeEstablishedBranches
                    ? "Eligible root Scene branches are shown. Site maps, linked Scenes, and branches containing this Location remain excluded."
                    : "Only standalone Scenes are shown. Enable established branches to include eligible roots with descendants."
                : "Only unclaimed Scenes can become Site maps. Show unavailable Scenes to see why other Scenes cannot be linked."
        };
    }

    #getSceneAvailability(scene, { currentSceneId = null, rootSceneId = null, locationSceneOwners = new Map(), excludedSceneIds = new Set(), excludeCurrentScene = true, descendantCount = 0, containsLocation = false } = {}) {
        const unavailable = unavailableReason => ({ isAvailable: false, unavailableReason });
        if (!scene?.id) return unavailable("Invalid Scene");
        if (excludeCurrentScene && scene.id === currentSceneId) return unavailable("Current Scene cannot be its own Site map");
        if (excludedSceneIds.has(scene.id)) {
            return unavailable(this.mode === "location" ? "Scene currently containing this Location" : "Unavailable in this workflow");
        }
        if (scene.id === rootSceneId || scene.getFlag("augur-nexus", NexusLineageManager.ROOT_FLAG) === true) {
            return unavailable("Designated Nexus root Scene");
        }

        const locationOwner = locationSceneOwners.get(scene.id);
        if (locationOwner) {
            const locationName = locationOwner.display?.name || "another Location";
            return unavailable(locationOwner.id === this.locationId
                ? "Already linked to this Location"
                : `Primary map of ${locationName}`);
        }

        const site = scene.getFlag("augur-nexus", "site") || {};
        if (scene.getFlag("augur-nexus", "siteScene") === true || site.parentSceneId) {
            return unavailable(site.siteName ? `Site map of ${site.siteName}` : "Already belongs to a Site");
        }
        if (LegacySciFiCompatibility.getSceneKind(scene)) return unavailable("Managed by Augur: Sci-Fi");
        if (LegacySciFiCompatibility.getParentScene(scene)) return unavailable("Child of an Augur: Sci-Fi Scene");
        if (containsLocation) return unavailable("Scene branch already contains this Location");

        const lineage = scene.getFlag("augur-nexus", NexusLineageManager.LINEAGE_FLAG) || {};
        if (lineage.parentSceneId || lineage.parentSiteId) return unavailable("Already nested in another Nexus branch");
        if (scene.getFlag("augur-nexus", "navigation")?.parentSceneId) return unavailable("Already has return navigation to another Scene");
        if (this.mode === "location" && descendantCount > 0 && !this.includeEstablishedBranches) {
            return unavailable("Has descendants; include established branches to link it");
        }
        if (this.mode === "site" && currentSceneId) {
            const validation = NexusLineageManager.validateSceneParent(scene, { parentSceneId: currentSceneId });
            if (!validation.valid) return unavailable(validation.reason === "cycle"
                ? "Would create a circular Scene hierarchy"
                : (validation.message || "Cannot be adopted beneath the current Scene"));
        }
        return { isAvailable: true, unavailableReason: "" };
    }

    #buildBranchIndex(nodes = []) {
        const rows = PlaceHierarchyModel.buildRows(nodes);
        const byKey = new Map(rows.map(row => [row.key, row]));
        const descendantCounts = new Map();

        for (const row of rows) {
            const visited = new Set();
            let parentKey = row.parentNodeId;
            while (parentKey && !visited.has(parentKey)) {
                visited.add(parentKey);
                descendantCounts.set(parentKey, (descendantCounts.get(parentKey) || 0) + 1);
                parentKey = byKey.get(parentKey)?.parentNodeId || null;
            }
        }

        const containingSceneKeys = new Set();
        const targetKey = this.locationId ? `location:${this.locationId}` : null;
        const visited = new Set();
        let parentKey = targetKey ? byKey.get(targetKey)?.parentNodeId || null : null;
        while (parentKey && !visited.has(parentKey)) {
            visited.add(parentKey);
            const parent = byKey.get(parentKey);
            if (parent?.type === "scene") containingSceneKeys.add(parent.key);
            parentKey = parent?.parentNodeId || null;
        }

        return { descendantCounts, containingSceneKeys };
    }
    _attachPartListeners(partId, htmlElement, options) {
        super._attachPartListeners(partId, htmlElement, options);
        const el = htmlElement instanceof HTMLElement ? htmlElement : htmlElement[0];
        if (!el) return;

        const branchToggle = el.querySelector("input[name='includeEstablishedBranches']");
        const unavailableToggle = el.querySelector("input[name='showUnavailableScenes']");
        const searchInput = el.querySelector("input[name='sceneSearch']");
        const cards = [...el.querySelectorAll("[data-scene-card]")];

        const applyFilter = () => {
            const query = (searchInput?.value || "").trim().toLowerCase();
            for (const card of cards) {
                const haystack = `${card.dataset.sceneName || ""} ${card.dataset.sceneFolder || ""}`.toLowerCase();
                card.hidden = !!query && !haystack.includes(query);
            }
        };

        searchInput?.addEventListener("input", applyFilter);

        branchToggle?.addEventListener("change", event => {
            this.includeEstablishedBranches = !!event.currentTarget.checked;
            this.render({ parts: ["main"] });
        });

        unavailableToggle?.addEventListener("change", event => {
            this.showUnavailableScenes = !!event.currentTarget.checked;
            this.render({ parts: ["main"] });
        });

        for (const card of cards) {
            if (card.dataset.sceneAvailable !== "true") continue;
            const choose = async () => {
                const sceneId = card.dataset.sceneId;
                if (!sceneId) return;
                const descendantCount = Number(card.dataset.descendantCount || 0);
                const accepted = await this.onSelect?.(sceneId, { descendantCount });
                if (accepted === false) return;
                await this.close();
            };

            card.addEventListener("click", () => void choose());
            card.addEventListener("keydown", event => {
                if (event.key !== "Enter" && event.key !== " ") return;
                event.preventDefault();
                void choose();
            });
        }
    }
}



