import { SiteCoverCatalog } from "../services/SiteCoverCatalog.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const FilePicker = foundry.applications.apps.FilePicker.implementation;

export class SiteCoverPicker extends HandlebarsApplicationMixin(ApplicationV2) {
    #current = "";
    #sourceCover = null;
    #onSelect = null;
    #category = null;

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-site-cover-picker",
        classes: ["augur-nexus", "site-cover-picker-dialog"],
        tag: "div",
        window: {
            title: "Select Cover Image",
            resizable: true,
            minimizable: false
        },
        actions: {
            setCoverCategory: function (_event, target) {
                this.#category = target.dataset.category;
                this.render({ parts: ["main"] });
            },
            selectCover: function (_event, target) { return this.#selectCover(target.dataset.coverSrc || ""); },
            useSourceCover: function () { return this.#selectSourceCover(); },
            pickCustomCover: function (_event, target) { this.#openCustomPicker(target); }
        },
        position: {
            width: 760,
            height: 560
        }
    };

    static PARTS = {
        main: {
            template: "modules/augur-nexus/templates/site/site-cover-picker.hbs"
        }
    };

    static show({ current = "", sourceCover = null, onSelect = null } = {}) {
        const app = new this({ current, sourceCover, onSelect });
        app.render(true, { focus: true });
        return app;
    }

    constructor({ current = "", sourceCover = null, onSelect = null } = {}, options = {}) {
        super(options);
        this.#current = current || "";
        this.#sourceCover = this.#normalizeSourceCover(sourceCover);
        this.#onSelect = onSelect;
    }

    async _prepareContext() {
        const categories = await SiteCoverCatalog.getCategories();
        const currentCategory = categories.find(category => category.covers.some(cover => cover.src === this.#current));
        this.#category ??= currentCategory?.id || "abstract";
        const selected = categories.find(category => category.id === this.#category) || categories[0];
        this.#category = selected.id;
        const covers = selected.covers.map(cover => ({
            ...cover,
            active: cover.src === this.#current
        }));

        return {
            categories: categories.map(category => ({ id: category.id, label: category.label, active: category.id === this.#category })),
            showCategories: categories.length > 1,
            covers,
            sourceCover: this.#sourceCover ? {
                ...this.#sourceCover,
                active: !this.#current
            } : null,
            customActive: !!this.#current && !currentCategory,
            customSrc: this.#current
        };
    }

    async #selectCover(src) {
        if (!src) return;
        await this.#onSelect?.(src);
        this.close();
    }

    async #selectSourceCover() {
        await this.#onSelect?.("");
        this.close();
    }

    #openCustomPicker(target) {
        const rect = target?.getBoundingClientRect?.() || { top: 120, left: 120 };
        new FilePicker({
            type: "image",
            current: this.#current || "",
            callback: async path => {
                if (!path) return;
                await this.#onSelect?.(path);
                this.close();
            },
            top: rect.top,
            left: rect.left
        }).render({ force: true });
    }

    #normalizeSourceCover(sourceCover = null) {
        const src = String(sourceCover?.src || sourceCover?.sourceCoverSrc || "").trim();
        if (!src) return null;
        return {
            src,
            label: String(sourceCover?.label || sourceCover?.sourceCoverLabel || "Source Background").trim() || "Source Background"
        };
    }
}
