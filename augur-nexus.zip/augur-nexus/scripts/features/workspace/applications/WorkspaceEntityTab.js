import { LocationSceneWorkflow } from "../../campaign-entities/services/LocationSceneWorkflow.js";
import { renderDossierControls, bindDossierControls, openEntityDossierVisibility } from "../../campaign-entities/components/DossierHeaderControls.js";
import { prepareDossierCover } from "../../../support/appearance/DossierCoverPresentation.js";
import { prepareNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";
import { NpcReadingViewModel } from "../../campaign-entities/models/NpcReadingViewModel.js";
import { prepareNpcDossierFooter, openNpcLinkedActor, manageNpcActorLink } from "../../campaign-entities/components/NpcDossierFooter.js";
import { WorkspaceShipView } from "./WorkspaceShipView.js";
import { workspaceDossierHost } from "../services/WorkspaceDossierHost.js";
import { DossierCompactSections } from "../../campaign-entities/components/DossierCompactSections.js";
import { bindConnectedObjectMenus, connectedObjectSources, connectedObjectNode, openConnectedObjectMenu } from "../../connections/services/ConnectedObjectMenu.js";
import { bindOrganizationMemberMenus } from "../../connections/services/OrganizationMemberMenu.js";
import { openActionMenu } from "../../../api/ui.js";
import { openNpcCreator, canRerollNpcCurrentThread, rerollNpcCurrentThread } from "../../../api/npcs.js";
import { NpcLifeViewModel } from "../../campaign-entities/models/NpcLifeViewModel.js";
import { NpcProfileViewModel } from "../../campaign-entities/models/NpcProfileViewModel.js";
import { NpcCompactProfile } from "../../campaign-entities/components/NpcCompactProfile.js";
import { bindEntityDisclosureControls, openEntityDisclosureMenu } from "../../campaign-entities/services/EntityDisclosureControls.js";
import { CampaignEntityVisibilityManager } from "../../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { ConnectionsBoard } from "../../connections/components/ConnectionsBoard.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { EntityChroniclePanel } from "../../region-population/components/EntityChroniclePanel.js";
import { bindWorkspaceEntityDrags, workspaceDragTarget, workspaceObjectEntity } from "../services/WorkspaceEntityDrag.js";
import { bindWorkspaceObjectNavigation } from "../services/WorkspaceObjectNavigation.js";
import { WorkspaceRelationshipDrops } from "../services/WorkspaceRelationshipDrops.js";
import { WorkspaceEntities } from "../services/WorkspaceEntities.js";
import { remapWorkspacePlaceScene } from "../services/WorkspacePlaces.js";
import { WorkspaceEntityView } from "../models/WorkspaceEntityView.js";
import { openFactionCreator, rerollFactionCurrentThread } from "../../../api/factions.js";
import { openShipCreator, rerollShipCurrentAssignment } from "../../../api/ships.js";
import { createLocationViewPanel, openLocationCreator, getLocationOverview, rerollLocationCurrentThread } from "../../../api/locations.js";
import { openShopCreator, openShopTrade } from "../../../api/shops.js";
import { SettlementDossierProviderRegistry } from "../../campaign-entities/services/SettlementDossierProviderRegistry.js";
import { LocationActionRegistry } from "../../campaign-entities/services/LocationActionRegistry.js";
import { workspaceEdgeDirection } from "../models/WorkspaceConnectionPresentation.js";
import { ConnectionExplorer } from "../../connections/components/ConnectionExplorer.js";
import { buildConnectionExplorerData, canViewExplorerTarget } from "../../connections/services/ConnectionExplorerData.js";

import { canSelectWorkspaceNode } from "../services/WorkspaceBrowserPolicy.js";
import { WorkspacePlaceView } from "./WorkspacePlaceView.js";
import { WorkspaceQuestView, workspaceQuestActions } from "./WorkspaceQuestView.js";

export const workspaceViewActions = [...workspaceQuestActions, "regionDossierObject", "regionDossierBrowse", "toggleRegionSection", "toggleRegionCompact", "openStandaloneRegionDossier", "openChronicleParticipant", "runPlaceProfileAction", "runPlacePreviewAction", "toggleNpcCompactSection", "toggleDossierCompactSection", "entityDisclosureMenu", "workspaceNew", "workspaceGenerate", "workspaceTab", "workspaceBack", "workspaceForward", "workspaceEditJournal", "openPlaceScene", "openPlaceActions", "createJournalPage", "setPlaceTab", "togglePlaceCategory", "openPlaceOwner",
    "openNpcLinkedActor", "manageNpcActorLink", "openLocationScene", "openLocationSceneMenu", "workspacePopout", "workspaceVisibility", "workspaceFollow", "workspaceEdge", "workspaceBrowserToggle", "workspaceEdit", "workspaceConnectionView", "workspaceCompact", "setNpcDossierTab", "setFactionDossierTab", "setShipDossierTab", "setLocationDossierTab", "setShipCollectionTab", "openSettlementOwner", "openSettlementLeader", "openSettlementTrade", "openSettlementPerson", "openSettlementSite", "openSettlementParent", "openSettlementTradeGood", "rerollNpcCurrentThread", "rerollFactionCurrentThread", "rerollLocationCurrentThread", "rerollShipCurrentAssignment", "createFactionMember", "createFactionLeader", "createShipCrewMember", "createSettlementPerson", "createSettlementShop", "recreateSettlementMarketplace"];
const readingActions = new Set(["runPlaceProfileAction", "setPlaceTab", "togglePlaceCategory", "openPlaceScene", "openPlaceOwner", "workspaceTab", "workspaceBack", "workspaceForward", "workspacePopout", "workspaceFollow",
    "workspaceEdge", "workspaceBrowserToggle", "workspaceConnectionView", "workspaceCompact", "setNpcDossierTab", "setFactionDossierTab", "setShipDossierTab", "setLocationDossierTab", "setShipCollectionTab", "openSettlementOwner", "openSettlementLeader", "openSettlementTrade", "openSettlementPerson", "openSettlementSite", "openSettlementParent", "openSettlementTradeGood"]);

export class WorkspaceEntityTab {
    constructor(host, id) { this.host = host; this.id = id; }
    pinned = false;
    get minimumExpandedWidth() { return this.entityType === "ship" ? 981 : this.#hostedView?.minimumExpandedWidth || 0; }
    get element() { return this.host.element?.querySelector(`[data-workspace-tab-view="${this.id}"]`); }
    get closed() { return this.#closed; }
    get helpContext() { return this.entityType === "place" ? this.#placeView?.helpContext || {} : {}; }
    redirectConvertedPlace(sourceIds, destinationId, { canViewDestination = true } = {}) {
        const ids = new Set(sourceIds);
        if (!canViewDestination) this.history = this.history.filter(entry => entry.type !== "place" || !ids.has(entry.id));
        for (const entry of this.history) if (entry.type === "place" && ids.has(entry.id)) { entry.id = destinationId; entry.type = "location"; if (entry.view === "chronicle") entry.view = "profile"; }
        for (const id of ids) this.#placeSessions.delete(id);
        if (this.entityType !== "place" || !ids.has(this.entityId)) return false;
        const previous = this.#placeView; this.#placeView = null;
        this.entityId = canViewDestination ? destinationId : ""; this.entityType = canViewDestination ? "location" : "npc";
        if (!canViewDestination || this.view === "chronicle") this.view = "profile";
        void previous?.dispose();
        return true;
    }
    redirectReplacedScene(sourceId, destinationId) {
        this.history = remapWorkspacePlaceScene(this.history, sourceId, destinationId);
        this.#placeSessions = new Map(remapWorkspacePlaceScene([...this.#placeSessions], sourceId, destinationId));
        if (this.entityType !== "place" || this.entityId !== sourceId) return false;
        const previous = this.#placeView;
        if (previous) this.#placeSessions.set(destinationId, remapWorkspacePlaceScene(previous.snapshotView(), sourceId, destinationId));
        this.#placeView = null;
        this.entityId = destinationId;
        void previous?.dispose();
        return true;
    }
    perform(callback) { return this.host.perform(callback); }
    render() { return this.redraw(); }
    redraw() { return this.#closed ? Promise.resolve() : this.host.redraw(); }
    entityId = "";
    entityType = "npc";
    view = "profile";
    #connectionView = null;
    #connectionDensity = null;
    get connectionView() {
        return this.#connectionView || (this.compact ? "list" : "graph");
    }
    set connectionView(mode) {
        this.#connectionView = ["list", "graph"].includes(mode) ? mode : null;
        this.#connectionDensity = this.compact;
    }
    history = [];
    historyIndex = -1;
    graphCategory = "all";
    explorerState = null;
    compact = false;
    shipCollection = "crew";
    #board;
    #hostedView;
    #hostedResolved = false;
    #selectionRevision = 0;
    #hostedSessions = new Map();
    #placeView;
    #placeSessions = new Map();
    #questView;
    #explorer;
    #explorerData;
    #chronicle = new EntityChroniclePanel();
    #closed = false;
    #restoreScroll = null;
    #compactProfile = new NpcCompactProfile();
    #shipSections = new DossierCompactSections({ sections: ["information", "thread", "crew", "ties"] });
    #locationSections = new DossierCompactSections({ sections: ["economy", "establishments", "thread", "people"] });
    #organizationSections = new DossierCompactSections({ sections: ["beliefs", "thread", "diplomacy", "members", "holdings"] });
    #placeScroll = [];

    scrollTop = 0;
    snapshotSession() {
        this.#remember();
        if (this.#hostedView) this.#hostedSessions.set(`${this.entityType}:${this.entityId}`, this.#hostedView.snapshot());
        if (this.#placeView) this.#placeSessions.set(this.entityId, this.#placeView.snapshotView());
        return {
            kind: "entity", pinned: this.pinned, compact: this.compact, entityId: this.entityId, entityType: this.entityType,
            view: this.view, connectionView: this.#connectionView, connectionDensity: this.#connectionDensity,
            history: this.history.map(entry => ({ ...entry, explorerState: entry.explorerState && structuredClone(entry.explorerState) })), historyIndex: this.historyIndex,
            graphCategory: this.graphCategory, explorerState: this.explorerState && structuredClone(this.explorerState),
            shipCollection: this.shipCollection, scrollTop: this.element?.querySelector("[data-workspace-scroll]")?.scrollTop ?? this.scrollTop,
            hostedViews: [...this.#hostedSessions],
            placeViews: [...this.#placeSessions],
            placeScroll: this.#placeScroll.map(position => ({ ...position })),
            quest: this.#questView?.snapshotSession?.() || this.#questSession,
            compactProfile: this.#compactProfile.snapshot(), organizationSections: this.#organizationSections.snapshot(), locationSections: this.#locationSections.snapshot(), shipSections: this.#shipSections.snapshot()
        };
    }
    #questSession;
    restoreSession(state) {
        this.#hostedSessions = new Map((state.hostedViews || []).filter(([id]) => { const [type, ...parts] = String(id).split(":"); return WorkspaceEntities.canView(WorkspaceEntities.get(parts.join(":"), type)); }));
        this.#compactProfile.restore(state.compactProfile);
        this.#organizationSections.restore(state.organizationSections);
        this.#locationSections.restore(state.locationSections);
        this.#shipSections.restore(state.shipSections);
        this.#placeSessions = new Map((state.placeViews || []).filter(([id]) => WorkspaceEntities.canView(WorkspaceEntities.get(id, "place"))));
        this.compact = state.compact !== false;
        const available = entry => WorkspaceEntities.canView(WorkspaceEntities.get(entry.id, entry.type));
        const currentAvailable = !!state.entityId && WorkspaceEntities.canView(WorkspaceEntities.get(state.entityId, state.entityType));
        this.entityId = currentAvailable ? state.entityId : "";
        this.entityType = currentAvailable ? state.entityType : "npc";
        this.pinned = currentAvailable && !!state.pinned;
        this.view = currentAvailable ? state.view || "profile" : "profile";
        if (!game.user.isGM && this.view === "gm") this.view = "profile";
        this.history = (state.history || []).filter(available).map(entry => ({ ...entry }));
        this.historyIndex = (state.history || []).slice(0, state.historyIndex + 1).filter(available).length - 1;
        this.#connectionView = state.connectionView;
        this.#connectionDensity = state.connectionDensity;
        this.graphCategory = state.graphCategory || "all";
        this.explorerState = state.explorerState ? structuredClone(state.explorerState) : null;
        this.shipCollection = state.shipCollection || "crew";
        this.scrollTop = currentAvailable ? state.scrollTop || 0 : 0;
        this.#restoreScroll = this.scrollTop;
        this.#placeScroll = currentAvailable ? state.placeScroll || [] : [];
        this.#questSession = currentAvailable && this.entityType === "quest" ? state.quest : null;
    }
    async prepare() {
        const live = WorkspaceEntities.get(this.entityId, this.entityType);
        if (!live || !WorkspaceEntities.canView(live)) {
            await this.#hostedView?.dispose(); this.#hostedView = null; this.#hostedResolved = false;
            return { workspace: { compact: this.compact, missing: true, canEdit: game.user.isGM, hadSelection: !!this.entityId,
                canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1 } };
        }
        if (live.type === "place") {
            if (!this.#placeView) {
                this.#placeView = new WorkspacePlaceView(this, live);
                this.#placeView.restoreView(this.#placeSessions.get(this.entityId) || { tab: this.view });
            }
            return { workspace: { isPlace: true, placeHtml: await this.#placeView.prepare(), compact: this.compact,
                appearance: this.#placeView.appearance,
                isBoundStarChart: this.#placeView.navigationTheme === "bound-star-chart",
                canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1 } };
        }
        if (live.type === "quest") {
            if (!this.#questView) {
                this.#questView = new WorkspaceQuestView(this, live);
                this.#questView.restoreSession?.(this.#questSession);
                this.#questSession = null;
            }
            return { workspace: { isQuest: true, questHtml: await this.#questView.prepare(), compact: this.compact,
                canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1 } };
        }
        if (!this.#hostedResolved && ["ship", "location"].includes(live.type)) {
            const revision = this.#selectionRevision;
            this.#hostedResolved = true;
            const panel = live.type === "ship" ? new WorkspaceShipView(this, live)
                : await createLocationViewPanel(live, { host: workspaceDossierHost(this) });
            if (this.#closed || revision !== this.#selectionRevision || live.id !== this.entityId || live.type !== this.entityType) {
                await panel?.dispose();
                return { workspace: { missing: true, compact: this.compact } };
            }
            this.#hostedView = panel;
            this.#hostedView?.restore(this.#hostedSessions.get(`${this.entityType}:${this.entityId}`));
        }
        if (this.#hostedView) {
            const paneWidth = this.host.paneWidth(this.host.groupFor(this));
            return { workspace: { isHostedDossier: true, dossierHtml: await this.#hostedView.prepare({ compact: this.compact || (paneWidth > 0 && paneWidth + .01 < this.minimumExpandedWidth), view: this.view }),
                isShip: live.type === "ship",
                isBoundStarChart: live.type === "ship" || this.#hostedView.navigationTheme === "bound-star-chart",
                ownsBackground: this.#hostedView.ownsBackground === true,
                compact: this.compact, canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1 } };
        }
        const entity = live;
        const target = ConnectionTargetResolver.fromCampaignEntity(live);
        this.#board ??= new ConnectionsBoard({ target, readOnly: true, manageCards: true, openNode: node => this.followNode(node), getNavigationItems: node => this.host.objectNavigationItems(node, this) });
        this.#board.setTarget(target);
        this.#chronicle.setEntityId(live.id);
        // Chronicle indexing has no player-disclosure projection yet.
        const hasChronicle = game.user.isGM && this.#chronicle.hasEvents();
        if (this.view === "chronicle" && !hasChronicle) this.view = "profile";
        const isNpc = live.type === "npc";
        const npcFooter = isNpc ? await prepareNpcDossierFooter(live) : null;
        const sharedConnectionsLayout = ["npc", "faction", "location"].includes(live.type);
        const locationSceneControl = live.type === "location" ? LocationSceneWorkflow.getControlModel(live.id) : null;
        const locationFooterControlsHtml = live.type === "location" && game.user.isGM ? await renderDossierControls({ entity: live, showEdit: false, options: false }) : "";
        const controlsHtml = await renderDossierControls({ entity: live, canEdit: game.user.isGM, popout: true, ...(isNpc ? { visibility: null } : {}), ...(live.type === "location" ? { visibility: null, sceneControl: game.user.isGM ? null : locationSceneControl } : {}) });
        const entityView = isNpc ? null : await WorkspaceEntityView.prepare(live, { controlsHtml, compact: this.compact, view: this.view, hasChronicle, shipCollection: this.shipCollection, compactSections: (live.type === "ship" ? this.#shipSections : live.type === "location" ? this.#locationSections : this.#organizationSections).context(entity.id) });
        const life = isNpc ? NpcLifeViewModel.fromEntity(live) : {};
        const profile = entityView?.profile || NpcProfileViewModel.fromEntity(entity, {
            ...this.#compactProfile.context(entity.id, life), canToggleSections: this.compact, canEditTies: game.user.isGM,
            showDefaultFields: false, showCore: this.compact, compactMode: this.compact,
            showTabs: true, activeTab: this.view, hasChronicle,
            includeDescriptorInSubtitle: this.compact, importance: life.importance,
            currentThread: life.currentThread, canDrag: true,
            canRerollCurrentThread: game.user.isGM && canRerollNpcCurrentThread(entity)
        });
        const journalConnections = sharedConnectionsLayout && this.view === "journal";
        const all = journalConnections ? this.#board?.getContext({ display: "list", hideViewToggle: true })
            : this.view === "connections" ? this.#board?.getContext(sharedConnectionsLayout ? { display: this.connectionView } : {}) : null;
        if (this.view === "connections" && all && !all.categories.some(category => category.id === this.graphCategory)) this.graphCategory = "all";
        const connectionGroups = (all?.groups || []).filter(group => this.graphCategory === "all" || group.id === this.graphCategory)
            .map(group => ({ ...group, cards: group.cards.map(card => {
                const node = ConnectionStore.getNode(card.nodeId);
                const edge = ConnectionStore.getConnectionEdge(card.edgeId);
                const direction = workspaceEdgeDirection(edge, target.id);
                return { ...card, img: card.img || "", navigable: canSelectWorkspaceNode(node) && WorkspaceEntities.canView(WorkspaceEntities.get(node.entityId, node.entityType)),
                    categoryLabel: group.label, categoryIcon: group.icon, hiddenCategory: group.hiddenForPlayers,
                    outgoing: direction === "out", incoming: direction === "in" };
            }) }));
        this.#explorerData = this.view === "connections" && all && this.connectionView === "graph"
            ? buildConnectionExplorerData({ extraTargets: [target] }) : null;
        const page = WorkspaceEntities.journal(live);
        const canReadJournal = !!page && (game.user.isGM || page.testUserPermission(game.user, "OBSERVER"));
        let journalHtml = "";
        if (this.view === "journal" && canReadJournal) {
            journalHtml = await foundry.applications.ux.TextEditor.implementation.enrichHTML(page.text?.content || "", {
                relativeTo: page, secrets: game.user.isGM && page.isOwner
            });
        }
        const appearance = isNpc ? prepareNexusThemeSurface() : entityView?.appearance;
        return { workspace: {
            entity, profile, life, isNpc, isFaction: live.type === "faction", entityType: live.type, typeLabel: WorkspaceEntities.describe(live.type).label, icon: WorkspaceEntities.describe(live.type).icon,
            controlsHtml, npcFooter, npcManagement: isNpc && game.user.isGM, locationSceneControl, locationFooterControlsHtml, locationManagement: live.type === "location" && game.user.isGM, headerHtml: entityView?.headerHtml, profileHtml: entityView?.profileHtml, canEdit: game.user.isGM, compact: this.compact,
            appearance,
            npcReading: isNpc ? NpcReadingViewModel.fromProfile(profile, life) : null,
            compactHeader: { ...profile, controlsHtml, hideLinkedActorTab: isNpc && game.user.isGM, hidePortrait: isNpc && this.view === "profile", showBody: false },
            profileBody: { ...profile, bodyOnly: true, showBody: true },
            hasLife: life.hasTraits || life.hasIdeology || life.hasWorldTies || life.hasImportance,
            missing: false, hasChronicle,
            visible: CampaignEntityVisibilityManager.isVisibleToPlayers(live),
            hasJournal: canReadJournal, journalHtml,
            dossierCover: prepareDossierCover(live),
            cover: "",
            tabs: ["profile", "journal", "connections", ...(hasChronicle ? ["chronicle"] : [])]
                .map(id => ({ id, label: id[0].toUpperCase() + id.slice(1), active: id === this.view })),
            isProfile: this.view === "profile", isJournal: this.view === "journal",
            isConnections: this.view === "connections", isGraph: this.connectionView === "graph", isList: this.connectionView === "list", isChronicle: this.view === "chronicle",
            connectionGroups, connectionBoard: sharedConnectionsLayout ? all : null, sharedConnectionsLayout,
            graphCategories: (all?.categories || []).map(category => ({ ...category, selected: category.id === this.graphCategory })),
            chronicleHtml: this.view === "chronicle" ? await this.#chronicle.render() : "",
            canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1
        }};
    }

    #openEditor(entity) {
        if (!game.user.isGM) return;
        return WorkspaceEntities.edit(entity, () => {
            if (!this.#closed && this.entityId === entity.id) return this.redraw();
        });
    }

    #remember() {
        const entry = this.history[this.historyIndex];
        if (!entry) return;
        Object.assign(entry, { view: this.view, shipCollection: this.shipCollection, connectionView: this.#connectionView, connectionDensity: this.#connectionDensity, graphCategory: this.graphCategory,
            explorerState: this.explorerState && structuredClone(this.explorerState),
            scroll: this.element?.querySelector("[data-workspace-scroll]")?.scrollTop ?? this.scrollTop });
    }

    async selectEntity(id, { history = true, view = this.view, type = "npc", target = "current" } = {}) {
        const entity = WorkspaceEntities.get(id, type);
        if (!WorkspaceEntities.canView(entity)) { ui.notifications.warn("This entry is unavailable or its details have not been revealed."); return false; }
        const group = this.host.groupFor(this);
        const existing = history ? this.host.findEntityTab(group, id, type) : null;
        if (existing && existing !== this) return this.host.selectExisting(group, existing);
        if (target !== "current" || (history && this.pinned && (id !== this.entityId || type !== this.entityType)))
            return this.host.openEntity(id, { type, view, target: target === "current" ? "new" : target, source: this });
        this.#remember();
        this.#selectionRevision++;
        if (this.#hostedView) {
            this.#hostedSessions.set(`${this.entityType}:${this.entityId}`, this.#hostedView.snapshot());
            await this.#hostedView.dispose();
            this.#hostedView = null;
        }
        this.#hostedResolved = false;
        this.#questSession = null;
        this.#placeScroll = [];
        if (this.#placeView) { this.#placeSessions.set(this.entityId, this.#placeView.snapshotView()); void this.#placeView.dispose(); this.#placeView = null; }
        if (this.#questView) { void this.#questView.dispose(); this.#questView = null; }
        this.entityId = entity.id;
        this.entityType = entity.type;
        this.host.updateLayout(false);
        this.view = type !== "quest" && ["log", "gm"].includes(view) ? "profile" : view;
        this.#board = null;
        this.#explorer?.destroy(); this.#explorer = null;
        this.explorerState = null; this.#explorerData = null;
        this.#restoreScroll = 0;
        if (history) {
            this.history.splice(this.historyIndex + 1);
            this.history.push({ id: entity.id, type: entity.type, view: this.view });
            this.historyIndex = this.history.length - 1;
        }
        await (this.host.redrawTab?.(this) ?? this.redraw());
        return true;
    }

    async followNode(node, target = "current") {
        if (!workspaceObjectEntity(node)) return this.#unsupported();
        return this.perform(() => this.host.openObjectNode(node, { source: this, target }));
    }

    #unsupported() { ui.notifications.info("Campaign Nexus opens people, organizations, locations, ships, sites, and quests. Use the standalone tools for other objects."); }

    resolveObjectTarget(element) {
        if (this.entityType === "quest" && element.dataset.edgeId) return this.#questView?.resolveObjectTarget(element);
        if (this.entityType === "place" && (element.dataset.action === "openPlaceOwner" || element.dataset.regionNode)) return this.#placeView?.resolveObjectTarget(element);
        return workspaceDragTarget(element.dataset, WorkspaceEntities.get(this.entityId, this.entityType));
    }
    attachListeners(root) {
        if (this.#hostedView) {
            this.#hostedView.activate(root.querySelector("[data-workspace-dossier]"));
            bindWorkspaceEntityDrags(root, this);
            return;
        }
        const sharedConnectionList = ["npc", "faction", "location"].includes(this.entityType) && (this.view === "journal" || this.view === "connections" && this.connectionView === "list");
        bindEntityDisclosureControls(root, () => this.entityId, { type: this.entityType });
        if (!["ship", "place", "quest"].includes(this.entityType) && !this.#hostedView) bindDossierControls(root, {
            scene: () => this.entityType === "location" && LocationSceneWorkflow.open(this.entityId),
            edit: () => this.#openEditor(WorkspaceEntities.get(this.entityId, this.entityType)),
            popout: () => WorkspaceEntities.open(WorkspaceEntities.get(this.entityId, this.entityType)),
            visibility: anchor => openEntityDossierVisibility(WorkspaceEntities.get(this.entityId, this.entityType), anchor, () => this.redraw()),
            options: async anchor => {
                const { openWorkspaceDossierMenu } = await import("../services/WorkspaceDossierMenu.js");
                return openWorkspaceDossierMenu(WorkspaceEntities.get(this.entityId, this.entityType), anchor, this);
            }
        });
        if (this.entityType === "faction") bindOrganizationMemberMenus(root, {
            getOwner: () => WorkspaceEntities.get(this.entityId, this.entityType),
            navigateOnClick: true,
            navigation: node => this.host.objectNavigationItems(node, this),
            onChanged: () => this.redraw()
        });
        if (!["quest", "place"].includes(this.entityType)) bindConnectedObjectMenus(root, {
            selector: sharedConnectionList ? `:is(${connectedObjectSources}):not([data-connections-board] *)` : connectedObjectSources,
            getOwner: () => ConnectionTargetResolver.fromCampaignEntity(WorkspaceEntities.get(this.entityId, this.entityType)),
            resolveNode: card => this.resolveObjectTarget(card) || connectedObjectNode(card), navigation: node => this.host.objectNavigationItems(node, this),
            getItems: ({ edge, card }) => this.#board?.getCardItems(edge.id, this, card), onChanged: () => this.redraw()
        });
        bindWorkspaceObjectNavigation(root, this);
        if (this.entityType === "quest") { this.#questView?.activate(); bindWorkspaceEntityDrags(root, this); return; }
        if (this.entityType === "place") {
            this.#placeView?.activate(root.querySelector("[data-workspace-place]"));
            const surfaces = [...root.querySelectorAll(".site-preview-stage, .site-preview-section")];
            surfaces.forEach((surface, index) => {
                surface.addEventListener("scroll", () => { this.#placeScroll[index] = { top: surface.scrollTop, left: surface.scrollLeft }; });
            });
            bindWorkspaceEntityDrags(root, this);
            return;
        }
        root.addEventListener("change", event => {
            if (event.target.matches("[data-graph-category]")) {
                this.graphCategory = event.target.value;
                void this.perform(() => this.redraw());
            }
        });
        if (game.user.isGM) this.#chronicle.activateListeners(root, this);
        root.addEventListener("click", event => {
            const participant = event.target.closest("[data-npc-life-node], [data-faction-domain-node], [data-ship-domain-node], [data-action='openChronicleParticipant']");
            const blocked = event.target.closest(".content-link, [data-quest-id]");
            if (!participant && !blocked) return;
            event.preventDefault(); event.stopImmediatePropagation();
            const documentLink = event.target.closest(".content-link[data-uuid]");
            if (documentLink) {
                void ConnectionTargetResolver.fromUuid(documentLink.dataset.uuid).then(node => {
                    if (canSelectWorkspaceNode(node) || ["nexus-site", "nexus-scene"].includes(node?.kind))
                        return this.host.openObjectNode(node, { source: this, target: event.ctrlKey || event.metaKey ? "new" : "current" });
                    if (node) return ConnectionTargetResolver.openNode(node);
                });
                return;
            }
            const questLink = event.target.closest("[data-quest-id]");
            if (questLink) {
                void this.perform(() => this.selectEntity(questLink.dataset.questId, { type: "quest", target: event.ctrlKey || event.metaKey ? "new" : "current" }));
                return;
            }
            if (participant) {
                const nodeId = participant.dataset.npcLifeNode || participant.dataset.factionDomainNode || participant.dataset.shipDomainNode;
                const node = nodeId ? ConnectionStore.getNode(nodeId)
                    : ConnectionTargetResolver.fromEntityReference({ entityId: participant.dataset.entityId });
                void this.followNode(node, event.ctrlKey || event.metaKey ? "new" : "current");
            } else this.#unsupported();
        }, true);
        bindWorkspaceEntityDrags(root, this);
        WorkspaceRelationshipDrops.bind(root, this);
        root.querySelectorAll("[data-npc-life-opinion], [data-faction-diplomacy-opinion]").forEach(button => button.addEventListener("click", () => this.#board.openOpinionSummary(button, this)));
        const scroll = root.querySelector("[data-workspace-scroll]");
        if (scroll) {
            scroll.addEventListener("scroll", () => { if (root.isConnected) this.scrollTop = scroll.scrollTop; });
        }
        const board = root.querySelector("[data-connections-board]");
        if (["npc", "faction", "location"].includes(this.entityType) && this.view === "profile") void this.#board?.suspend?.();
        if (sharedConnectionList && board && !board.dataset.connectionsBoardBound) {
            root.addEventListener("click", event => {
                const button = event.target.closest("[data-connections-display]");
                if (!button) return;
                event.preventDefault(); event.stopImmediatePropagation();
                void this.perform(() => this.handleAction("workspaceConnectionView", { dataset: { mode: button.dataset.connectionsDisplay } }));
            }, true);
            this.#board.activateListeners(root.querySelector(".dossier-compact-connections") || root.querySelector(".npc-life-connections") || root, this);
        }
        this.#mountExplorer(root);
    }

    restoreView() {
        const root = this.element;
        if (!root) return;
        root.querySelectorAll(".site-preview-stage, .site-preview-section").forEach((surface, index) => {
            const position = this.#placeScroll[index];
            if (position) { surface.scrollTop = position.top; surface.scrollLeft = position.left; }
        });
        const scroll = root.querySelector("[data-workspace-scroll]");
        if (scroll) {
            scroll.scrollTop = this.#restoreScroll ?? this.scrollTop;
            this.#restoreScroll = null;
        }
    }

    showProfile() {
        this.view = "profile";
        if (this.#placeView) this.#placeView.restoreView({ ...this.#placeView.snapshotView(), tab: "profile" });
    }
    get connectionExplorer() { return this.#explorer || this.#placeView?.connectionExplorer; }
    get connectionExplorerHost() {
        return {
            open: target => this.openExplorerNode(target),
            beside: target => this.perform(() => {
                this.connectionView = "graph";
                const explorer = this.connectionExplorer;
                if (explorer) { explorer.state.fitToView = false; explorer.changed(); }
                return this.host.openObjectNode(target, { source: this, target: "other", compactProfile: true });
            })
        };
    }

    openExplorerNode(node) {
        return this.perform(() => {
            const target = node?.target || node;
            if (!canViewExplorerTarget(target)) return;
            return workspaceObjectEntity(target)
                ? this.host.openObjectNode(target, { source: this, target: "new" })
                : ConnectionTargetResolver.openNode(target);
        });
    }

    #mountExplorer(root) {
        if (this.#explorer) this.explorerState = this.#explorer.snapshot();
        this.#explorer?.destroy();
        this.#explorer = null;
        const element = root?.querySelector("[data-connection-explorer]");
        if (!element || !this.#explorerData) return;
        const owner = ConnectionTargetResolver.fromCampaignEntity(WorkspaceEntities.get(this.entityId, this.entityType));
        this.#explorer = new ConnectionExplorer({
            data: this.#explorerData,
            focusId: ConnectionTargetResolver.getNodeId(owner),
            state: this.explorerState,
            onOpen: node => this.openExplorerNode(node),
            onDisplayChange: mode => this.perform(() => { this.connectionView = mode; return this.redraw(); }),
            onOpenBeside: node => this.connectionExplorerHost.beside(node.target || node),
            ...this.#board.createExplorerCallbacks(this, {
                getExplorer: () => this.#explorer,
                navigation: target => this.host.objectNavigationItems(target, this),
                canDrop: () => game.user.isGM
            }),
            onStateChange: state => { this.explorerState = state; }
        });
        this.#explorer.mount(element);
    }

    async handleAction(action, button) {
        if (this.#hostedView?.handlesAction?.(action)) return this.#hostedView.handleAction(action, button);
        if (action === "toggleDossierCompactSection" && this.entityType === "ship" && this.compact)
            return this.#shipSections.toggle(this.entityId, button.dataset.section, () => this.redraw(), () => this.element);
        if (action === "toggleDossierCompactSection" && this.entityType === "location" && this.compact)
            return this.#locationSections.toggle(this.entityId, button.dataset.section, () => this.redraw(), () => this.element);
        if (action === "toggleDossierCompactSection" && this.entityType === "faction" && this.compact)
            return this.#organizationSections.toggle(this.entityId, button.dataset.section, () => this.redraw(), () => this.element);
        if (action === "toggleNpcCompactSection" && this.entityType === "npc" && this.compact)
            return this.#compactProfile.toggle(this.entityId, button.dataset.section, () => this.redraw(), () => this.element);
        if (this.entityType === "quest" && workspaceQuestActions.includes(action)) return this.#questView?.handleAction(action, button);
        if (!game.user.isGM && !readingActions.has(action)) return;
        if (action === "entityDisclosureMenu") return openEntityDisclosureMenu(this.entityId, button, this.entityType);
        if (["createFactionMember", "createFactionLeader", "createShipCrewMember", "createSettlementPerson"].includes(action)) {
            const kind = { createFactionMember: "member", createFactionLeader: "leader", createShipCrewMember: "crew", createSettlementPerson: "resident" }[action];
            return WorkspaceRelationshipDrops.createPerson(WorkspaceEntities.get(this.entityId, this.entityType), button, kind, () => this.redraw());
        }
        if (["createSettlementShop", "recreateSettlementMarketplace"].includes(action)) {
            const entity = WorkspaceEntities.get(this.entityId, this.entityType);
            if (!entity) return;
            const provider = SettlementDossierProviderRegistry.getFor(entity);
            const refresh = () => this.redraw();
            if (action === "recreateSettlementMarketplace") return provider?.recreateMarketplace?.({ entity, state: {}, refresh });
            if (provider?.createEstablishment) return provider.createEstablishment({ entity, state: {}, refresh });
            const createShop = () => openShopCreator({ locationId: entity.id, onSaved: refresh });
            // Module-registered location actions (such as a Fantasy marketplace) share the standalone Location dossier's New menu.
            const locationActions = LocationActionRegistry.listFor(entity, { onChanged: refresh });
            if (!locationActions.length) return createShop();
            return openActionMenu({ anchor: button, items: [{ id: "shop", label: "New Shop", icon: "fas fa-store", onSelect: createShop }, ...locationActions] });
        }
        if (["workspaceNew", "workspaceGenerate"].includes(action)) {
            const type = button?.dataset.entityType || ({ createNpc: "npc", createFaction: "faction", createShip: "ship", createLocation: "location", questCreate: "quest" })[button?.dataset.action];
            if (!type) return openActionMenu({ anchor: button, items: WorkspaceEntities.types().filter(item => action !== "workspaceGenerate" || item.type !== "quest").map(item => ({
                id: item.type, label: `${action === "workspaceNew" ? "New" : "Generate"} ${item.label}`, icon: item.icon,
                onSelect: () => this.perform(() => this.handleAction(action, { dataset: { entityType: item.type } }))
            })) });
            if (action === "workspaceNew") {
                const entity = await WorkspaceEntities.create(type, { folderId: button?.dataset.folderId || "" });
                if (!entity) return;
                await this.selectEntity(entity.id, { type, view: "profile" });
                if (type === "quest") return;
                return this.#openEditor(entity);
            }
            const creator = { npc: openNpcCreator, faction: openFactionCreator, location: openLocationCreator, ship: openShipCreator }[type];
            return creator({ openAfterCreate: false, openDossier: false, onCreated: entity => {
                if (!this.#closed) return this.perform(() => this.selectEntity(entity.id, { type }));
            }});
        }
        if (["workspaceBack", "workspaceForward"].includes(action)) {
            const delta = action === "workspaceBack" ? -1 : 1;
            let index = this.historyIndex + delta;
            while (this.history[index] && !WorkspaceEntities.canView(WorkspaceEntities.get(this.history[index].id, this.history[index].type))) index += delta;
            const entry = this.history[index];
            if (!entry) return;
            if (!await this.selectEntity(entry.id, { history: false, type: entry.type })) return;
            this.historyIndex = index; this.view = entry.view; this.shipCollection = entry.shipCollection || "crew";
            this.connectionView = entry.connectionView;
            this.graphCategory = entry.graphCategory || "all";
            this.explorerState = entry.explorerState ? structuredClone(entry.explorerState) : null;
            this.#restoreScroll = entry.scroll || 0;
            await (this.host.redrawTab?.(this) ?? this.redraw()); return;
        }
        if (action === "workspaceFollow") {
            const node = ConnectionStore.getNode(button.dataset.nodeId);
            if (workspaceObjectEntity(node)) return this.host.openObjectNode(node, { source: this });
            this.#unsupported();
            return;
        }
        const entity = WorkspaceEntities.get(this.entityId, this.entityType);
        if (!entity || !WorkspaceEntities.canView(entity)) return this.#unsupported();
        if (entity.type === "npc" && action === "openNpcLinkedActor") return openNpcLinkedActor(entity);
        if (entity.type === "npc" && action === "manageNpcActorLink") return manageNpcActorLink(entity, () => this.redraw());
        if (entity.type === "location" && action === "openLocationScene") return LocationSceneWorkflow.open(entity.id);
        if (entity.type === "location" && action === "openLocationSceneMenu") return LocationSceneWorkflow.openMenu(entity.id, button, { onChanged: () => this.redraw() });
        if (entity.type === "quest") {
            if (action === "workspacePopout") return WorkspaceEntities.open(entity);
            return;
        }
        if (entity.type === "place") {
            if (action === "workspacePopout") return WorkspaceEntities.open(entity);
            return this.#placeView?.handleAction(action, button);
        }
        if (action === "workspaceEditJournal") {
            await WorkspaceEntities.editJournal(entity);
            return this.redraw();
        }
        if (["workspaceTab", "setNpcDossierTab", "setFactionDossierTab", "setShipDossierTab", "setLocationDossierTab"].includes(action)) {
            this.#remember(); this.view = button.dataset.view || button.dataset.tab; this.#restoreScroll = 0; await this.redraw(); return;
        }
        if (action === "workspaceConnectionView") {
            if (!["graph", "list"].includes(button.dataset.mode)) return;
            this.connectionView = button.dataset.mode;
            this.#restoreScroll = 0;
            await this.redraw(); return;
        }
        if (action === "openSettlementTradeGood" && entity.type === "location") {
            const { TradeGoodDetailApplication } = await import("../../trade/applications/TradeGoodDetailApplication.js");
            return TradeGoodDetailApplication.show({ goodId: button.dataset.goodId, locationId: entity.id });
        }
        if (action.startsWith("openSettlement") && entity.type === "location") {
            if (action === "openSettlementParent") return this.selectEntity(button.dataset.organizationId, { type: "faction" });
            if (action === "openSettlementPerson") return this.selectEntity(button.dataset.personId);
            if (action === "openSettlementSite") {
                const id = String(button.dataset.cardId || "");
                if (!id) return;
                if (button.dataset.cardKind === "location") return this.selectEntity(id, { type: "location" });
                const provider = SettlementDossierProviderRegistry.getFor(entity);
                if (provider?.openEstablishment) return provider.openEstablishment({ entity, state: {}, kind: button.dataset.cardKind || "", id });
                if (button.dataset.cardKind === "shop") return openShopTrade(id);
                return this.#unsupported();
            }
            const overview = getLocationOverview(entity);
            const target = ({ openSettlementOwner: overview?.owner, openSettlementLeader: overview?.leader,
                openSettlementTrade: overview?.trade })[action];
            const nodeId = button.dataset.nodeId || target?.nodeId;
            const node = nodeId ? ConnectionStore.getNode(nodeId) : null;
            if (canSelectWorkspaceNode(node)) return this.selectEntity(node.entityId, { type: node.entityType });
            return this.#unsupported();
        }
        if (action === "workspacePopout") return WorkspaceEntities.open(entity);
        if (action === "workspaceEdit") return this.#openEditor(entity);
        if (action === "setShipCollectionTab") {
            this.shipCollection = button.dataset.tab === "ties" ? "ties" : "crew"; await this.redraw(); return;
        }
        const reroll = { npc: ["rerollNpcCurrentThread", rerollNpcCurrentThread], faction: ["rerollFactionCurrentThread", rerollFactionCurrentThread],
            location: ["rerollLocationCurrentThread", rerollLocationCurrentThread], ship: ["rerollShipCurrentAssignment", rerollShipCurrentAssignment] }[entity.type];
        if (action === reroll?.[0]) {
            await reroll[1](entity);
            await this.redraw(); return;
        }
        if (action === "workspaceVisibility") {
            return openEntityDossierVisibility(entity, button, () => this.redraw());
        }
        if (action === "workspaceEdge") {
            this.#board.openOpinionSummary(button, this);
            return;
        }
    }

    async destroy() {
        this.#closed = true; this.#chronicle.destroy();
        await this.#explorer?.flushLayout?.();
        this.#explorer?.destroy(); this.#explorer = null;
        await Promise.all([this.#placeView?.dispose(), this.#questView?.dispose(), this.#hostedView?.dispose()]);
        this.#hostedView = null; this.#placeView = null; this.#questView = null; this.#board = null;
    }
}
