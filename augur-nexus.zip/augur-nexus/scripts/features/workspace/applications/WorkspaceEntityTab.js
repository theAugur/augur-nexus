import { WorkspaceShipView } from "./WorkspaceShipView.js";
import { workspaceDossierHost } from "../services/WorkspaceDossierHost.js";
import { DossierCompactSections } from "../../campaign-entities/components/DossierCompactSections.js";
import { bindConnectedObjectMenus, connectedObjectNode } from "../../connections/services/ConnectedObjectMenu.js";
import { bindOrganizationMemberMenus } from "../../connections/services/OrganizationMemberMenu.js";
import { openActionMenu } from "../../../api/ui.js";
import { openNpcCreator, getNpcGenerators, canRerollNpcCurrentThread, rerollNpcCurrentThread } from "../../../api/npcs.js";
import { NpcHeaderModel } from "../../campaign-entities/models/NpcHeaderModel.js";
import { NpcLifeViewModel } from "../../campaign-entities/models/NpcLifeViewModel.js";
import { NpcProfileViewModel } from "../../campaign-entities/models/NpcProfileViewModel.js";
import { NpcCompactProfile } from "../../campaign-entities/components/NpcCompactProfile.js";
import { bindEntityDisclosureControls, openEntityDisclosureMenu } from "../../campaign-entities/services/EntityDisclosureControls.js";
import { CampaignEntityVisibilityManager } from "../../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { ConnectionsBoard } from "../../connections/components/ConnectionsBoard.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { EntityChroniclePanel } from "../../region-population/components/EntityChroniclePanel.js";
import { bindWorkspaceEntityDrags, workspaceDragTarget } from "../services/WorkspaceEntityDrag.js";
import { bindWorkspaceObjectNavigation } from "../services/WorkspaceObjectNavigation.js";
import { WorkspaceRelationshipDrops } from "../services/WorkspaceRelationshipDrops.js";
import { WorkspaceEntities } from "../services/WorkspaceEntities.js";
import { WorkspaceEntityView } from "../models/WorkspaceEntityView.js";
import { getFactionGenerators, openFactionCreator, rerollFactionCurrentThread } from "../../../api/factions.js";
import { getShipGenerators, openShipCreator, rerollShipCurrentAssignment } from "../../../api/ships.js";
import { createLocationViewPanel, getLocationGenerators, openLocationCreator, getLocationOverview, rerollLocationCurrentThread } from "../../../api/locations.js";
import { openShopCreator } from "../../../api/shops.js";
import { SettlementDossierProviderRegistry } from "../../campaign-entities/services/SettlementDossierProviderRegistry.js";
import { LocationActionRegistry } from "../../campaign-entities/services/LocationActionRegistry.js";
import { layoutWorkspaceGraph, workspaceEdgeDirection, workspaceGraphRelationship } from "../models/WorkspaceGraphLayout.js";

import { canSelectWorkspaceNode } from "../services/WorkspaceBrowserPolicy.js";
import { WorkspacePlaceView } from "./WorkspacePlaceView.js";
import { WorkspaceQuestView, workspaceQuestActions } from "./WorkspaceQuestView.js";

export const workspaceViewActions = [...workspaceQuestActions, "runPlacePreviewAction", "toggleNpcCompactSection", "toggleDossierCompactSection", "entityDisclosureMenu", "workspaceNew", "workspaceGenerate", "workspaceTab", "workspaceBack", "workspaceForward", "workspaceEditJournal", "openPlaceScene", "openPlaceActions", "createJournalPage", "setPlaceTab", "togglePlaceCategory", "openPlaceOwner",
    "workspacePopout", "workspaceVisibility", "workspaceFollow", "workspaceGraphPage", "workspaceGraphZoom",
    "workspaceGraphReset", "workspaceEdge", "workspaceBrowserToggle", "workspaceEdit", "workspaceConnectionView", "workspaceCompact", "setNpcDossierTab", "setFactionDossierTab", "setShipDossierTab", "setLocationDossierTab", "setShipCollectionTab", "openSettlementOwner", "openSettlementLeader", "openSettlementTrade", "openSettlementPerson", "openSettlementSite", "openSettlementParent", "openSettlementTradeGood", "rerollNpcCurrentThread", "rerollFactionCurrentThread", "rerollLocationCurrentThread", "rerollShipCurrentAssignment", "createFactionMember", "createFactionLeader", "createShipCrewMember", "createSettlementPerson", "createSettlementShop", "recreateSettlementMarketplace"];
const readingActions = new Set(["setPlaceTab", "togglePlaceCategory", "openPlaceScene", "openPlaceOwner", "workspaceTab", "workspaceBack", "workspaceForward", "workspacePopout", "workspaceFollow",
    "workspaceGraphPage", "workspaceGraphZoom", "workspaceGraphReset", "workspaceEdge", "workspaceBrowserToggle", "workspaceConnectionView", "workspaceCompact", "setNpcDossierTab", "setFactionDossierTab", "setShipDossierTab", "setLocationDossierTab", "setShipCollectionTab", "openSettlementOwner", "openSettlementLeader", "openSettlementTrade", "openSettlementPerson", "openSettlementSite", "openSettlementParent", "openSettlementTradeGood"]);

export class WorkspaceEntityTab {
    constructor(host, id) { this.host = host; this.id = id; }
    pinned = false;
    get minimumExpandedWidth() { return this.entityType === "ship" ? 981 : this.#hostedView?.minimumExpandedWidth || 0; }
    get element() { return this.host.element?.querySelector(`[data-workspace-tab-view="${this.id}"]`); }
    get closed() { return this.#closed; }
    perform(callback) { return this.host.perform(callback); }
    render() { return this.redraw(); }
    redraw() { return this.#closed ? Promise.resolve() : this.host.redraw(); }
    entityId = "";
    entityType = "npc";
    view = "profile";
    #connectionView = null;
    #connectionDensity = null;
    get connectionView() {
        return this.#connectionDensity === this.compact && this.#connectionView
            ? this.#connectionView : this.compact ? "list" : "graph";
    }
    set connectionView(mode) {
        this.#connectionView = ["list", "graph"].includes(mode) ? mode : null;
        this.#connectionDensity = this.compact;
    }
    history = [];
    historyIndex = -1;
    graphPage = 0;
    graphCategory = "all";
    graphZoom = 1;
    compact = false;
    shipCollection = "crew";
    #board;
    #hostedView;
    #hostedResolved = false;
    #selectionRevision = 0;
    #hostedSessions = new Map();
    #placeView;
    #placeSessions = new Map();
    #questView;
    #graphCards = [];
    #chronicle = new EntityChroniclePanel();
    #closed = false;
    #restoreScroll = null;
    #graphScroll = { left: 0, top: 0 };
    #graphManual = false;
    #graphObserver;
    #compactProfile = new NpcCompactProfile();
    #shipSections = new DossierCompactSections({ sections: ["information", "thread", "crew", "ties"] });
    #locationSections = new DossierCompactSections({ sections: ["economy", "establishments", "thread", "people"] });
    #organizationSections = new DossierCompactSections({ sections: ["beliefs", "thread", "diplomacy", "members", "holdings"] });
    #placeScroll = [];

    scrollTop = 0;
    snapshotSession() {
        this.#remember();
        if (this.#hostedView) this.#hostedSessions.set(`${this.entityType}:${this.entityId}`, this.#hostedView.snapshot());
        if (this.#placeView) this.#placeSessions.set(this.entityId, this.#placeView.snapshotView());
        return {
            kind: "entity", pinned: this.pinned, compact: this.compact, entityId: this.entityId, entityType: this.entityType,
            view: this.view, connectionView: this.#connectionView, connectionDensity: this.#connectionDensity,
            history: this.history.map(entry => ({ ...entry, graphScroll: entry.graphScroll && { ...entry.graphScroll } })), historyIndex: this.historyIndex,
            graphPage: this.graphPage, graphCategory: this.graphCategory, graphZoom: this.graphZoom, graphScroll: { ...this.#graphScroll }, graphManual: this.#graphManual,
            shipCollection: this.shipCollection, scrollTop: this.element?.querySelector("[data-workspace-scroll]")?.scrollTop ?? this.scrollTop,
            hostedViews: [...this.#hostedSessions],
            placeViews: [...this.#placeSessions],
            placeScroll: this.#placeScroll.map(position => ({ ...position })),
            quest: this.#questView?.snapshotSession?.() || this.#questSession,
            compactProfile: this.#compactProfile.snapshot(), organizationSections: this.#organizationSections.snapshot(), locationSections: this.#locationSections.snapshot(), shipSections: this.#shipSections.snapshot()
        };
    }
    #questSession;
    restoreSession(state) {
        this.#hostedSessions = new Map((state.hostedViews || []).filter(([id]) => { const [type, ...parts] = String(id).split(":"); return WorkspaceEntities.canView(WorkspaceEntities.get(parts.join(":"), type)); }));
        this.#compactProfile.restore(state.compactProfile);
        this.#organizationSections.restore(state.organizationSections);
        this.#locationSections.restore(state.locationSections);
        this.#shipSections.restore(state.shipSections);
        this.#placeSessions = new Map((state.placeViews || []).filter(([id]) => WorkspaceEntities.canView(WorkspaceEntities.get(id, "place"))));
        this.compact = state.compact !== false;
        const available = entry => WorkspaceEntities.canView(WorkspaceEntities.get(entry.id, entry.type));
        const currentAvailable = !!state.entityId && WorkspaceEntities.canView(WorkspaceEntities.get(state.entityId, state.entityType));
        this.entityId = currentAvailable ? state.entityId : "";
        this.entityType = currentAvailable ? state.entityType : "npc";
        this.pinned = currentAvailable && !!state.pinned;
        this.view = currentAvailable ? state.view || "profile" : "profile";
        if (!game.user.isGM && this.view === "gm") this.view = "profile";
        this.history = (state.history || []).filter(available).map(entry => ({ ...entry }));
        this.historyIndex = (state.history || []).slice(0, state.historyIndex + 1).filter(available).length - 1;
        this.#connectionView = state.connectionView;
        this.#connectionDensity = state.connectionDensity;
        this.graphPage = state.graphPage || 0; this.graphCategory = state.graphCategory || "all"; this.graphZoom = state.graphZoom || 1;
        this.#graphScroll = { ...(state.graphScroll || { left: 0, top: 0 }) };
        this.#graphManual = !!state.graphManual;
        this.shipCollection = state.shipCollection || "crew";
        this.scrollTop = currentAvailable ? state.scrollTop || 0 : 0;
        this.#restoreScroll = this.scrollTop;
        this.#placeScroll = currentAvailable ? state.placeScroll || [] : [];
        this.#questSession = currentAvailable && this.entityType === "quest" ? state.quest : null;
    }
    async prepare() {
        const live = WorkspaceEntities.get(this.entityId, this.entityType);
        if (!live || !WorkspaceEntities.canView(live)) {
            await this.#hostedView?.dispose(); this.#hostedView = null; this.#hostedResolved = false;
            return { workspace: { compact: this.compact, missing: true, canEdit: game.user.isGM, hadSelection: !!this.entityId,
                canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1 } };
        }
        if (live.type === "place") {
            if (!this.#placeView) {
                this.#placeView = new WorkspacePlaceView(this, live);
                this.#placeView.restoreView(this.#placeSessions.get(this.entityId));
            }
            return { workspace: { isPlace: true, placeHtml: await this.#placeView.prepare(), compact: this.compact,
                canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1 } };
        }
        if (live.type === "quest") {
            if (!this.#questView) {
                this.#questView = new WorkspaceQuestView(this, live);
                this.#questView.restoreSession?.(this.#questSession);
                this.#questSession = null;
            }
            return { workspace: { isQuest: true, questHtml: await this.#questView.prepare(), compact: this.compact,
                canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1 } };
        }
        if (!this.#hostedResolved && ["ship", "location"].includes(live.type)) {
            const revision = this.#selectionRevision;
            this.#hostedResolved = true;
            const panel = live.type === "ship" ? new WorkspaceShipView(this, live)
                : await createLocationViewPanel(live, { host: workspaceDossierHost(this) });
            if (this.#closed || revision !== this.#selectionRevision || live.id !== this.entityId || live.type !== this.entityType) {
                await panel?.dispose();
                return { workspace: { missing: true, compact: this.compact } };
            }
            this.#hostedView = panel;
            this.#hostedView?.restore(this.#hostedSessions.get(`${this.entityType}:${this.entityId}`));
        }
        if (this.#hostedView) {
            const paneWidth = this.host.paneWidth(this.host.groupFor(this));
            return { workspace: { isHostedDossier: true, dossierHtml: await this.#hostedView.prepare({ compact: this.compact || (paneWidth > 0 && paneWidth + .01 < this.minimumExpandedWidth), view: this.view }),
                compact: this.compact, canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1 } };
        }
        const entity = live;
        const target = ConnectionTargetResolver.fromCampaignEntity(live);
        this.#board ??= new ConnectionsBoard({ target, readOnly: true, manageCards: true, openNode: node => this.followNode(node) });
        this.#board.setTarget(target);
        this.#chronicle.setEntityId(live.id);
        // Chronicle indexing has no player-disclosure projection yet.
        const hasChronicle = game.user.isGM && this.#chronicle.hasEvents();
        if (this.view === "chronicle" && !hasChronicle) this.view = "profile";
        const isNpc = live.type === "npc";
        const entityView = isNpc ? null : await WorkspaceEntityView.prepare(live, { compact: this.compact, view: this.view, hasChronicle, shipCollection: this.shipCollection, compactSections: (live.type === "ship" ? this.#shipSections : live.type === "location" ? this.#locationSections : this.#organizationSections).context(entity.id) });
        const life = isNpc ? NpcLifeViewModel.fromEntity(live) : {};
        const profile = entityView?.profile || NpcProfileViewModel.fromEntity(entity, {
            ...(this.compact ? this.#compactProfile.context(entity.id, life) : {}), canEditTies: game.user.isGM,
            showDefaultFields: false, showCore: this.compact, compactMode: this.compact,
            showTabs: true, activeTab: this.view, hasChronicle,
            includeDescriptorInSubtitle: this.compact, importance: life.importance,
            currentThread: life.currentThread, canDrag: true,
            canRerollCurrentThread: game.user.isGM && canRerollNpcCurrentThread(entity)
        });
        const all = this.#board.getContext();
        if (!all.categories.some(category => category.id === this.graphCategory)) this.graphCategory = "all";
        const connectionGroups = all.groups.filter(group => this.graphCategory === "all" || group.id === this.graphCategory)
            .map(group => ({ ...group, cards: group.cards.map(card => {
                const node = ConnectionStore.getNode(card.nodeId);
                const edge = ConnectionStore.getConnectionEdge(card.edgeId);
                const direction = workspaceEdgeDirection(edge, target.id);
                return { ...card, img: card.img || "", navigable: canSelectWorkspaceNode(node) && WorkspaceEntities.canView(WorkspaceEntities.get(node.entityId, node.entityType)),
                    categoryLabel: group.label, categoryIcon: group.icon, hiddenCategory: group.hiddenForPlayers,
                    outgoing: direction === "out", incoming: direction === "in" };
            }) }));
        this.#graphCards = connectionGroups.flatMap(group => group.cards).map(card => ({ ...card,
            graphRelationship: workspaceGraphRelationship(card, ConnectionStore.getConnectionEdge(card.edgeId)?.views?.[target.id]?.role) }));
        const graph = layoutWorkspaceGraph(this.#graphCards, this.graphPage);
        this.graphPage = graph.page;
        const page = WorkspaceEntities.journal(live);
        const canReadJournal = !!page && (game.user.isGM || page.testUserPermission(game.user, "OBSERVER"));
        let journalHtml = "";
        if (this.view === "journal" && canReadJournal) {
            journalHtml = await foundry.applications.ux.TextEditor.implementation.enrichHTML(page.text?.content || "", {
                relativeTo: page, secrets: game.user.isGM && page.isOwner
            });
        }
        return { workspace: {
            arrowId: `nexus-workspace-arrow-${this.id}`, entity, profile, life, isNpc, entityType: live.type, typeLabel: WorkspaceEntities.describe(live.type).label, icon: WorkspaceEntities.describe(live.type).icon,
            headerHtml: entityView?.headerHtml, profileHtml: entityView?.profileHtml, canEdit: game.user.isGM, compact: this.compact,
            compactHeader: { ...profile, showBody: false },
            profileBody: { ...profile, bodyOnly: true, showBody: true },
            hasLife: life.hasTraits || life.hasIdeology || life.hasWorldTies || life.hasImportance,
            missing: false, hasChronicle,
            visible: CampaignEntityVisibilityManager.isVisibleToPlayers(live),
            hasJournal: canReadJournal, journalHtml,
            cover: isNpc ? NpcHeaderModel.coverImage(live) : entityView.cover,
            tabs: ["profile", "journal", "connections", ...(hasChronicle ? ["chronicle"] : [])]
                .map(id => ({ id, label: id[0].toUpperCase() + id.slice(1), active: id === this.view })),
            isProfile: this.view === "profile", isJournal: this.view === "journal",
            isConnections: this.view === "connections", isGraph: this.connectionView === "graph", isList: this.connectionView === "list", isChronicle: this.view === "chronicle",
            connectionGroups, graph,
            graphCategories: all.categories.map(category => ({ ...category, selected: category.id === this.graphCategory })),
            chronicleHtml: this.view === "chronicle" ? await this.#chronicle.render() : "",
            canBack: this.historyIndex > 0, canForward: this.historyIndex < this.history.length - 1
        }};
    }

    #openEditor(entity) {
        if (!game.user.isGM) return;
        return WorkspaceEntities.edit(entity, () => {
            if (!this.#closed && this.entityId === entity.id) return this.redraw();
        });
    }

    #remember() {
        const entry = this.history[this.historyIndex];
        if (!entry) return;
        Object.assign(entry, { view: this.view, shipCollection: this.shipCollection, connectionView: this.#connectionView, connectionDensity: this.#connectionDensity, graphPage: this.graphPage, graphCategory: this.graphCategory,
            graphZoom: this.graphZoom, graphScroll: { ...this.#graphScroll }, graphManual: this.#graphManual,
            scroll: this.element?.querySelector("[data-workspace-scroll]")?.scrollTop ?? this.scrollTop });
    }

    async selectEntity(id, { history = true, view = this.view, type = "npc", target = "current" } = {}) {
        const entity = WorkspaceEntities.get(id, type);
        if (!WorkspaceEntities.canView(entity)) { ui.notifications.warn("This entry is unavailable or its details have not been revealed."); return false; }
        const group = this.host.groupFor(this);
        const existing = history ? this.host.findEntityTab(group, id, type) : null;
        if (existing && existing !== this) return this.host.selectExisting(group, existing);
        if (target !== "current" || (history && this.pinned && (id !== this.entityId || type !== this.entityType)))
            return this.host.openEntity(id, { type, view, target: target === "current" ? "new" : target, source: this });
        this.#remember();
        this.#selectionRevision++;
        if (this.#hostedView) {
            this.#hostedSessions.set(`${this.entityType}:${this.entityId}`, this.#hostedView.snapshot());
            await this.#hostedView.dispose();
            this.#hostedView = null;
        }
        this.#hostedResolved = false;
        this.#questSession = null;
        this.#placeScroll = [];
        if (this.#placeView) { this.#placeSessions.set(this.entityId, this.#placeView.snapshotView()); void this.#placeView.dispose(); this.#placeView = null; }
        if (this.#questView) { void this.#questView.dispose(); this.#questView = null; }
        this.entityId = entity.id;
        this.entityType = entity.type;
        this.host.updateLayout(false);
        this.view = type !== "quest" && ["log", "gm"].includes(view) ? "profile" : view;
        this.#board = null;
        this.graphPage = 0;
        this.#graphScroll = { left: 0, top: 0 };
        this.#graphManual = false;
        this.#restoreScroll = 0;
        if (history) {
            this.history.splice(this.historyIndex + 1);
            this.history.push({ id: entity.id, type: entity.type, view: this.view });
            this.historyIndex = this.history.length - 1;
        }
        await this.redraw();
        return true;
    }

    async followNode(node, target = "current") {
        if (!canSelectWorkspaceNode(node)) return this.#unsupported();
        return this.perform(() => this.selectEntity(node.entityId, { type: node.entityType, target }));
    }

    #unsupported() { ui.notifications.info("This workspace opens people, organizations, locations, ships, sites, and quests. Use the standalone tools for other objects."); }

    resolveObjectTarget(element) {
        if (this.entityType === "quest" && element.dataset.edgeId) return this.#questView?.resolveObjectTarget(element);
        if (this.entityType === "place" && element.dataset.action === "openPlaceOwner") return this.#placeView?.resolveObjectTarget(element);
        return workspaceDragTarget(element.dataset, WorkspaceEntities.get(this.entityId, this.entityType));
    }
    attachListeners(root) {
        if (this.#hostedView) {
            this.#hostedView.activate(root.querySelector("[data-workspace-dossier]"));
            bindWorkspaceEntityDrags(root, this);
            return;
        }
        bindEntityDisclosureControls(root, () => this.entityId, { type: this.entityType });
        if (this.entityType === "faction") bindOrganizationMemberMenus(root, {
            getOwner: () => WorkspaceEntities.get(this.entityId, this.entityType),
            navigation: node => this.host.objectNavigationItems(node, this),
            onChanged: () => this.redraw()
        });
        if (!["quest", "place"].includes(this.entityType)) bindConnectedObjectMenus(root, {
            getOwner: () => ConnectionTargetResolver.fromCampaignEntity(WorkspaceEntities.get(this.entityId, this.entityType)),
            resolveNode: card => this.resolveObjectTarget(card) || connectedObjectNode(card), navigation: node => this.host.objectNavigationItems(node, this),
            getItems: ({ edge, card }) => this.#board?.getCardItems(edge.id, this, card), onChanged: () => this.redraw()
        });
        bindWorkspaceObjectNavigation(root, this);
        if (this.entityType === "quest") { this.#questView?.activate(); bindWorkspaceEntityDrags(root, this); return; }
        if (this.entityType === "place") {
            this.#placeView?.activate(root.querySelector("[data-workspace-place]"));
            const surfaces = [...root.querySelectorAll(".site-preview-stage, .site-preview-section")];
            surfaces.forEach((surface, index) => {
                surface.addEventListener("scroll", () => { this.#placeScroll[index] = { top: surface.scrollTop, left: surface.scrollLeft }; });
            });
            bindWorkspaceEntityDrags(root, this);
            return;
        }
        root.addEventListener("change", event => {
            if (event.target.matches("[data-graph-category]")) {
                this.graphCategory = event.target.value; this.graphPage = 0;
                void this.perform(() => this.redraw());
            }
        });
        if (game.user.isGM) this.#chronicle.activateListeners(root, this);
        root.addEventListener("click", event => {
            const participant = event.target.closest("[data-npc-life-node], [data-faction-domain-node], [data-ship-domain-node], [data-action='openChronicleParticipant']");
            const blocked = event.target.closest("[data-action='openFullChronicle'], .content-link, [data-quest-id]");
            if (!participant && !blocked) return;
            event.preventDefault(); event.stopImmediatePropagation();
            const documentLink = event.target.closest(".content-link[data-uuid]");
            if (documentLink) {
                void ConnectionTargetResolver.fromUuid(documentLink.dataset.uuid).then(node => {
                    if (canSelectWorkspaceNode(node) || ["nexus-site", "nexus-scene"].includes(node?.kind))
                        return this.host.openObjectNode(node, { source: this, target: event.ctrlKey || event.metaKey ? "new" : "current" });
                    if (node) return ConnectionTargetResolver.openNode(node);
                });
                return;
            }
            const questLink = event.target.closest("[data-quest-id]");
            if (questLink) {
                void this.perform(() => this.selectEntity(questLink.dataset.questId, { type: "quest", target: event.ctrlKey || event.metaKey ? "new" : "current" }));
                return;
            }
            if (participant) {
                const nodeId = participant.dataset.npcLifeNode || participant.dataset.factionDomainNode || participant.dataset.shipDomainNode;
                const node = nodeId ? ConnectionStore.getNode(nodeId)
                    : ConnectionTargetResolver.fromEntityReference({ entityId: participant.dataset.entityId });
                void this.followNode(node, event.ctrlKey || event.metaKey ? "new" : "current");
            } else this.#unsupported();
        }, true);
        bindWorkspaceEntityDrags(root, this);
        WorkspaceRelationshipDrops.bind(root, this);
        root.querySelectorAll("[data-npc-life-opinion], [data-faction-diplomacy-opinion]").forEach(button => button.addEventListener("click", () => this.#board.openOpinionSummary(button, this)));
        const scroll = root.querySelector("[data-workspace-scroll]");
        if (scroll) {
            scroll.addEventListener("scroll", () => { if (root.isConnected) this.scrollTop = scroll.scrollTop; });
        }
        this.#bindGraph(root);
    }

    restoreView() {
        const root = this.element;
        if (!root) return;
        root.querySelectorAll(".site-preview-stage, .site-preview-section").forEach((surface, index) => {
            const position = this.#placeScroll[index];
            if (position) { surface.scrollTop = position.top; surface.scrollLeft = position.left; }
        });
        this.#layoutGraph(root);
        const scroll = root.querySelector("[data-workspace-scroll]");
        if (scroll) {
            scroll.scrollTop = this.#restoreScroll ?? this.scrollTop;
            this.#restoreScroll = null;
        }
    }

    #bindGraph(root) {
        this.#graphObserver?.disconnect();
        const viewport = root?.querySelector("[data-graph-viewport]");
        if (!viewport) return;
        let drag;
        viewport.addEventListener("pointerdown", event => {
            if (event.button !== 0 || event.target.closest("button, [data-graph-card], [data-graph-center]")) return;
            this.#graphManual = true;
            drag = { x: event.clientX, y: event.clientY, left: viewport.scrollLeft, top: viewport.scrollTop };
            viewport.setPointerCapture(event.pointerId);
        });
        viewport.addEventListener("pointermove", event => {
            if (drag) { viewport.scrollLeft = drag.left + drag.x - event.clientX; viewport.scrollTop = drag.top + drag.y - event.clientY; }
        });
        viewport.addEventListener("pointerup", () => { drag = null; });
        viewport.addEventListener("pointercancel", () => { drag = null; });
        viewport.addEventListener("scroll", () => { this.#graphScroll = { left: viewport.scrollLeft, top: viewport.scrollTop }; });
        viewport.addEventListener("wheel", () => { this.#graphManual = true; }, { passive: true });
        viewport.addEventListener("keydown", event => { if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End", "PageUp", "PageDown"].includes(event.key)) this.#graphManual = true; });
        this.#graphObserver = new ResizeObserver(() => { if (root.isConnected && !this.#closed) this.#layoutGraph(root); });
        this.#graphObserver.observe(viewport);
        this.#applyGraphZoom();
        viewport.scrollLeft = this.#graphScroll.left;
        viewport.scrollTop = this.#graphScroll.top;
    }

    #layoutGraph(root) {
        const viewport = root?.querySelector("[data-graph-viewport]");
        if (!viewport) return;
        // Names and disposition labels still grow with the user's text size.
        const cards = [...root.querySelectorAll("[data-graph-card]")];
        const graph = layoutWorkspaceGraph(this.#graphCards, this.graphPage, cards.map(card => card.offsetHeight));
        cards.forEach((card, index) => { card.style.top = `${graph.nodes[index].top}px`; });
        root.querySelectorAll("[data-graph-path]").forEach((path, index) => path.setAttribute("d", graph.nodes[index].path));
        root.querySelector("[data-graph-canvas]").style.height = `${graph.height}px`;
        root.querySelector("[data-graph-canvas] > svg").setAttribute("height", graph.height);
        root.querySelector("[data-graph-center]").style.top = `${graph.center.y}px`;
        this.#applyGraphZoom();
        this.#positionGraph(viewport);
    }

    #positionGraph(viewport) {
        if (!this.#graphManual) this.#graphScroll = { left: Math.max(0, (viewport.scrollWidth - viewport.clientWidth) / 2), top: 0 };
        viewport.scrollLeft = this.#graphScroll.left;
        viewport.scrollTop = this.#graphScroll.top;
    }

    #applyGraphZoom() {
        const canvas = this.element?.querySelector("[data-graph-canvas]");
        if (canvas) canvas.style.zoom = String(this.graphZoom);
    }

    async handleAction(action, button) {
        if (this.#hostedView?.handlesAction?.(action)) return this.#hostedView.handleAction(action, button);
        if (action === "toggleDossierCompactSection" && this.entityType === "ship" && this.compact)
            return this.#shipSections.toggle(this.entityId, button.dataset.section, () => this.redraw(), () => this.element);
        if (action === "toggleDossierCompactSection" && this.entityType === "location" && this.compact)
            return this.#locationSections.toggle(this.entityId, button.dataset.section, () => this.redraw(), () => this.element);
        if (action === "toggleDossierCompactSection" && this.entityType === "faction" && this.compact)
            return this.#organizationSections.toggle(this.entityId, button.dataset.section, () => this.redraw(), () => this.element);
        if (action === "toggleNpcCompactSection" && this.entityType === "npc" && this.compact)
            return this.#compactProfile.toggle(this.entityId, button.dataset.section, () => this.redraw(), () => this.element);
        if (this.entityType === "quest" && workspaceQuestActions.includes(action)) return this.#questView?.handleAction(action, button);
        if (!game.user.isGM && !readingActions.has(action)) return;
        if (action === "entityDisclosureMenu") return openEntityDisclosureMenu(this.entityId, button, this.entityType);
        if (["createFactionMember", "createFactionLeader", "createShipCrewMember", "createSettlementPerson"].includes(action)) {
            const kind = { createFactionMember: "member", createFactionLeader: "leader", createShipCrewMember: "crew", createSettlementPerson: "resident" }[action];
            return WorkspaceRelationshipDrops.createPerson(WorkspaceEntities.get(this.entityId, this.entityType), button, kind, () => this.redraw());
        }
        if (["createSettlementShop", "recreateSettlementMarketplace"].includes(action)) {
            const entity = WorkspaceEntities.get(this.entityId, this.entityType);
            if (!entity) return;
            const provider = SettlementDossierProviderRegistry.getFor(entity);
            const refresh = () => this.redraw();
            if (action === "recreateSettlementMarketplace") return provider?.recreateMarketplace?.({ entity, state: {}, refresh });
            if (provider?.createEstablishment) return provider.createEstablishment({ entity, state: {}, refresh });
            const createShop = () => openShopCreator({ locationId: entity.id, onSaved: refresh });
            // Module-registered location actions (such as a Fantasy marketplace) share the standalone Location dossier's New menu.
            const locationActions = LocationActionRegistry.listFor(entity, { onChanged: refresh });
            if (!locationActions.length) return createShop();
            return openActionMenu({ anchor: button, items: [{ id: "shop", label: "New Shop", icon: "fas fa-store", onSelect: createShop }, ...locationActions] });
        }
        if (["workspaceNew", "workspaceGenerate"].includes(action)) {
            const type = button?.dataset.entityType || ({ createNpc: "npc", createFaction: "faction", createShip: "ship", createLocation: "location", questCreate: "quest" })[button?.dataset.action];
            if (!type) return openActionMenu({ anchor: button, items: WorkspaceEntities.types().filter(item => action !== "workspaceGenerate" || item.type !== "quest").map(item => ({
                id: item.type, label: `${action === "workspaceNew" ? "New" : "Generate"} ${item.label}`, icon: item.icon,
                onSelect: () => this.perform(() => this.handleAction(action, { dataset: { entityType: item.type } }))
            })) });
            if (action === "workspaceNew") {
                const entity = await WorkspaceEntities.create(type, { folderId: button?.dataset.folderId || "" });
                await this.selectEntity(entity.id, { type, view: "profile" });
                if (type === "quest") return;
                return this.#openEditor(entity);
            }
            const generators = { npc: getNpcGenerators, faction: getFactionGenerators, location: getLocationGenerators, ship: getShipGenerators };
            if (!["npc", "faction"].includes(type) && !generators[type]?.().length) return foundry.applications.api.DialogV2.wait({
                window: { title: `Generate ${WorkspaceEntities.describe(type).label}` },
                content: '<p>Manual creation is always available through New. Augur content modules add generators, curated content, and artwork.</p><p><a href="https://www.patreon.com/TheAugur" target="_blank" rel="noopener noreferrer">Explore Augur modules</a></p>',
                buttons: [{ action: "close", label: "Close", default: true }]
            });
            const creator = { npc: openNpcCreator, faction: openFactionCreator, location: openLocationCreator, ship: openShipCreator }[type];
            return creator({ openAfterCreate: false, openDossier: false, onCreated: entity => {
                if (!this.#closed) return this.perform(() => this.selectEntity(entity.id, { type }));
            }});
        }
        if (["workspaceBack", "workspaceForward"].includes(action)) {
            const delta = action === "workspaceBack" ? -1 : 1;
            let index = this.historyIndex + delta;
            while (this.history[index] && !WorkspaceEntities.canView(WorkspaceEntities.get(this.history[index].id, this.history[index].type))) index += delta;
            const entry = this.history[index];
            if (!entry) return;
            if (!await this.selectEntity(entry.id, { history: false, type: entry.type })) return;
            this.historyIndex = index; this.view = entry.view; this.shipCollection = entry.shipCollection || "crew";
            this.connectionView = entry.connectionDensity === this.compact ? entry.connectionView : null;
            this.graphPage = entry.graphPage || 0; this.graphCategory = entry.graphCategory || "all";
            this.graphZoom = entry.graphZoom || 1; this.#restoreScroll = entry.scroll || 0;
            this.#graphScroll = entry.graphScroll || { left: 0, top: 0 };
            this.#graphManual = !!entry.graphManual;
            await this.redraw(); return;
        }
        if (action === "workspaceFollow") {
            const node = ConnectionStore.getNode(button.dataset.nodeId);
            if (canSelectWorkspaceNode(node)) await this.selectEntity(node.entityId, { type: node.entityType }); else this.#unsupported();
            return;
        }
        const entity = WorkspaceEntities.get(this.entityId, this.entityType);
        if (!entity || !WorkspaceEntities.canView(entity)) return this.#unsupported();
        if (entity.type === "quest") {
            if (action === "workspacePopout") return WorkspaceEntities.open(entity);
            return;
        }
        if (entity.type === "place") {
            if (action === "workspacePopout") return WorkspaceEntities.open(entity);
            return this.#placeView?.handleAction(action, button);
        }
        if (action === "workspaceEditJournal") {
            await WorkspaceEntities.editJournal(entity);
            return this.redraw();
        }
        if (["workspaceTab", "setNpcDossierTab", "setFactionDossierTab", "setShipDossierTab", "setLocationDossierTab"].includes(action)) {
            this.#remember(); this.view = button.dataset.view || button.dataset.tab; this.#restoreScroll = 0; await this.redraw(); return;
        }
        if (action === "workspaceConnectionView") {
            if (!["graph", "list"].includes(button.dataset.mode)) return;
            this.connectionView = button.dataset.mode;
            this.#restoreScroll = 0;
            await this.redraw(); return;
        }
        if (action === "openSettlementTradeGood" && entity.type === "location") {
            const { TradeGoodDetailApplication } = await import("../../trade/applications/TradeGoodDetailApplication.js");
            return TradeGoodDetailApplication.show({ goodId: button.dataset.goodId, locationId: entity.id });
        }
        if (action.startsWith("openSettlement") && entity.type === "location") {
            if (action === "openSettlementParent") return this.selectEntity(button.dataset.organizationId, { type: "faction" });
            if (action === "openSettlementPerson") return this.selectEntity(button.dataset.personId);
            if (action === "openSettlementSite") {
                if (button.dataset.cardKind === "location") return this.selectEntity(button.dataset.cardId, { type: "location" });
                return this.#unsupported();
            }
            const overview = getLocationOverview(entity);
            const target = ({ openSettlementOwner: overview?.owner, openSettlementLeader: overview?.leader,
                openSettlementTrade: overview?.trade })[action];
            const nodeId = button.dataset.nodeId || target?.nodeId;
            const node = nodeId ? ConnectionStore.getNode(nodeId) : null;
            if (canSelectWorkspaceNode(node)) return this.selectEntity(node.entityId, { type: node.entityType });
            return this.#unsupported();
        }
        if (action === "workspacePopout") return WorkspaceEntities.open(entity);
        if (action === "workspaceEdit") return this.#openEditor(entity);
        if (action === "setShipCollectionTab") {
            this.shipCollection = button.dataset.tab === "ties" ? "ties" : "crew"; await this.redraw(); return;
        }
        const reroll = { npc: ["rerollNpcCurrentThread", rerollNpcCurrentThread], faction: ["rerollFactionCurrentThread", rerollFactionCurrentThread],
            location: ["rerollLocationCurrentThread", rerollLocationCurrentThread], ship: ["rerollShipCurrentAssignment", rerollShipCurrentAssignment] }[entity.type];
        if (action === reroll?.[0]) {
            await reroll[1](entity);
            await this.redraw(); return;
        }
        if (action === "workspaceVisibility") {
            await WorkspaceEntities.setVisibility(entity, !CampaignEntityVisibilityManager.isVisibleToPlayers(entity));
            await this.redraw(); return;
        }
        if (action === "workspaceGraphPage") { this.graphPage += Number(button.dataset.delta); await this.redraw(); return; }
        if (action === "workspaceGraphZoom") { this.#graphManual = true; this.graphZoom = Math.min(2, Math.max(.35, this.graphZoom + Number(button.dataset.delta))); this.#applyGraphZoom(); return; }
        if (action === "workspaceGraphReset") {
            const viewport = this.element.querySelector("[data-graph-viewport]");
            const graph = this.element.querySelector("[data-graph-canvas]");
            this.graphZoom = Math.min(1, viewport.clientWidth / graph.offsetWidth, viewport.clientHeight / graph.offsetHeight);
            this.#graphManual = false; this.#applyGraphZoom(); this.#positionGraph(viewport); return;
        }
        if (action === "workspaceEdge") {
            this.#board.openOpinionSummary(button, this);
            return;
        }
    }

    async destroy() {
        this.#closed = true; this.#chronicle.destroy();
        this.#graphObserver?.disconnect();
        await Promise.all([this.#placeView?.dispose(), this.#questView?.dispose(), this.#hostedView?.dispose()]);
        this.#hostedView = null; this.#placeView = null; this.#questView = null; this.#board = null;
    }
}
