import { ShipDossier } from "../../campaign-entities/applications/ShipDossier.js";
import { workspaceDossierHost } from "../services/WorkspaceDossierHost.js";

export class WorkspaceShipView {
    get ownsBackground() { return true; }

    constructor(tab, entity) {
        this.tab = tab;
        this.controller = new ShipDossier({ shipId: entity.id, contentHost: workspaceDossierHost(tab) });
    }
    prepare({ compact, view }) { return this.controller.prepareContent({ compact, tab: view }); }
    activate(root) { this.controller.activateContent(root); }
    handlesAction(action) { return this.controller.handlesContentAction(action); }
    handleAction(action, button) { return this.controller.handleContentAction(action, button); }
    snapshot() { return this.controller.snapshotContent(); }
    restore(state) { if (state) this.controller.restoreContent(state); }
    dispose() { return this.controller.close(); }
}
