import { clampFloatingPosition, startFloatingMove, moveFloatingControl, endFloatingMove } from "../../../support/ui/FloatingControlMovement.js";
import { gmWheelTools, activateGmWheelTool } from "../services/GmWheelTools.js";
import { NexusSettingsApplication } from "../../nexus/applications/NexusSettingsApplication.js";
import { getNexusThemePreferences } from "../../../support/appearance/NexusThemes.js";
import { openPlayerSetup } from "../../../api/player-gateway.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const MODULE_ID = "augur-nexus";
const INTENT = "Left-click: expand/collapse Nexus Wheel\nRight-click: expand/collapse Nexus Wheel\nDrag to move";

export class GmNexusButton extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
        id: "nexus-gm-button", tag: "div", classes: ["nexus-player-wheel", "is-collapsed", "nexus-gm-button"],
        window: { frame: false, positioned: true, minimizable: false, resizable: false },
        position: { width: 58, height: 58 },
        actions: { toggleRing() { return this.toggleRing(); }, chooseTool(event, button) { return this.chooseTool(button.dataset.tool, event); } }
    };
    static PARTS = { body: { template: "modules/augur-nexus/templates/workspace/gm-nexus-button.hbs" } };
    workspace = null;
    expanded = false;
    transitioning = false;
    #toggle = Promise.resolve();

    _prepareContext() { return { expanded: this.expanded, shortcuts: gmWheelTools({ workspaceOpen: !!this.workspace?.rendered, transitioning: this.transitioning }) }; }
    async toggleRing(expanded = !this.expanded) {
        if (!game.user?.isGM || !game.settings.get(MODULE_ID, "gmNexusButtonEnabled")) return;
        this.expanded = expanded;
        await this.render({ force: true });
        this.element?.querySelector('[data-action="toggleRing"]')?.focus();
    }
    async chooseTool(name, event) {
        if (!game.user?.isGM || (this.transitioning && !["nexus-browser", "nexus-settings", "player-identity"].includes(name)) || !game.settings.get(MODULE_ID, "gmNexusButtonEnabled")) return;
        try {
            if (name === "nexus-browser") await this.toggleWorkspace();
            else if (name === "nexus-settings") await NexusSettingsApplication.show();
            else if (name === "player-identity") await openPlayerSetup();
            else await activateGmWheelTool(name, event);
        } catch (error) { ui.notifications.error(error.message || "Nexus Wheel tool could not be opened."); }
    }
    refreshTools() {
        // rendered is false during template work; Foundry's semaphore must queue those updates too.
        if (game.user?.isGM && game.settings.get(MODULE_ID, "gmNexusButtonEnabled")) return this.render({ force: true });
    }
    syncAppearance() {
        if (this.element) this.element.dataset.nexusTheme = getNexusThemePreferences().theme;
    }
    suspendTools() {
        this.transitioning = true;
        this.#syncAvailableShortcuts();
        return this.refreshTools();
    }
    #syncAvailableShortcuts() {
        const available = new Map(this._prepareContext().shortcuts.map(tool => [tool.name, tool]));
        for (const shortcut of this.element?.querySelectorAll?.(".gm-wheel-shortcut") || []) {
            const tool = available.get(shortcut.dataset.tool);
            shortcut.hidden = !tool;
            shortcut.classList?.toggle("is-active", !!tool?.active);
            shortcut.setAttribute?.("aria-pressed", String(!!tool?.active));
        }
    }
    hideImmediately() {
        if (this.element) this.element.style.visibility = "hidden";
    }
    syncWorkspace(workspace) {
        this.workspace = workspace;
        const open = !!workspace?.rendered;
        const shortcut = this.element?.querySelector('[data-tool="nexus-browser"]');
        shortcut?.classList.toggle("is-active", open);
        shortcut?.setAttribute("aria-pressed", String(open));
        const button = this.element?.querySelector('[data-action="toggleRing"]');
        button?.setAttribute("aria-expanded", String(this.expanded));
        if (button) {
            button.title = INTENT;
            button.setAttribute("aria-label", button.title);
            button.setAttribute("aria-description", `Nexus Wheel ${this.expanded ? "expanded" : "collapsed"}`);
        }
    }
    toggleWorkspace() {
        const toggle = async () => {
            if (!game.user?.isGM || !game.settings.get(MODULE_ID, "gmNexusButtonEnabled")) return;
            if (this.workspace?.rendered) await this.workspace.close();
            else {
                const { CampaignWorkspace } = await import("./CampaignWorkspace.js");
                const workspace = await CampaignWorkspace.show();
                if (workspace) this.syncWorkspace(workspace);
            }
        };
        this.#toggle = this.#toggle.then(toggle).catch(error => ui.notifications.error(error.message || "Campaign Nexus could not be toggled."));
        return this.#toggle;
    }
    _onRender(context, options) {
        super._onRender(context, options);
        // A disable can arrive while Foundry is awaiting templates in its render queue.
        if (!game.user?.isGM || !game.settings.get(MODULE_ID, "gmNexusButtonEnabled")) {
            this.hideImmediately();
            return;
        }
        this.syncWorkspace(this.workspace);
        this.syncAppearance();
        this.element.classList.toggle("is-wheel-expanded", this.expanded);
        this.element.querySelector(".gm-wheel-shortcuts")?.toggleAttribute?.("hidden", !this.expanded);
        // An older template may finish after teardown; never expose its stale scene actions.
        this.#syncAvailableShortcuts();
        this.interactions?.abort(); this.interactions = new AbortController();
        const signal = this.interactions.signal;
        this.element.addEventListener("pointerdown", event => startFloatingMove(this, event, "toggleRing"), { signal });
        this.element.addEventListener("pointermove", event => moveFloatingControl(this, event), { signal });
        this.element.addEventListener("pointerup", event => endFloatingMove(this, event), { signal });
        this.element.addEventListener("pointercancel", event => endFloatingMove(this, event, true), { signal });
        this.element.addEventListener("lostpointercapture", event => { if (this.drag) endFloatingMove(this, event, true); }, { signal });
        this.element.addEventListener("click", event => {
            if (this.suppressPortraitClick && event.target.closest('[data-action="toggleRing"]') && event.detail !== 0) {
                event.preventDefault(); event.stopImmediatePropagation(); this.suppressPortraitClick = false;
            }
        }, { capture: true, signal });
        this.element.addEventListener("contextmenu", event => {
            if (!event.target.closest('[data-action="toggleRing"]')) return;
            event.preventDefault(); event.stopImmediatePropagation();
            if (!this.drag) void this.toggleRing();
        }, { capture: true, signal });
        this.element.addEventListener("keydown", event => {
            if (event.key === "Escape" && this.expanded) { event.preventDefault(); void this.toggleRing(false); return; }
            if (event.target.dataset.action !== "toggleRing") return;
            if (event.key === "ContextMenu" || (event.shiftKey && event.key === "F10")) {
                event.preventDefault(); event.stopPropagation(); void this.toggleRing(); return;
            }
            const delta = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[event.key];
            if (!delta) return;
            event.preventDefault(); event.stopPropagation();
            const step = event.shiftKey ? 30 : 10;
            this.place(this.position.left + delta[0] * step, this.position.top + delta[1] * step);
            void this.rememberPosition();
        }, { signal });
        window.addEventListener("resize", () => { this.place(this.position.left, this.position.top); void this.rememberPosition(); }, { signal });
        if (!this.placed) {
            this.placed = true;
            const saved = game.settings.get(MODULE_ID, "gmNexusButtonPosition") || {};
            const players = document.querySelector("#players")?.getBoundingClientRect();
            this.place(saved.left ?? 75, saved.top ?? Math.max(20, (players?.top || window.innerHeight - 110) - 72));
        } else this.place(this.position.left, this.position.top);
    }
    place(left, top) {
        const margin = this.expanded ? 50 : 0;
        const position = clampFloatingPosition(left - margin, top - margin, 58 + 2 * margin, 58 + 2 * margin, window.innerWidth, window.innerHeight);
        this.setPosition({ left: position.left + margin, top: position.top + margin, width: 58, height: 58 });
    }
    async rememberPosition() {
        try { await game.settings.set(MODULE_ID, "gmNexusButtonPosition", { left: this.position.left, top: this.position.top }); }
        catch (error) { ui.notifications.error(`Could not remember Nexus Wheel position: ${error.message}`); }
    }
    async close(options) {
        this.hideImmediately();
        this.interactions?.abort(); this.drag = null;
        // Frameless HUDs have no window-collapse transition to wait for.
        return super.close({ ...options, animate: false });
    }
}
