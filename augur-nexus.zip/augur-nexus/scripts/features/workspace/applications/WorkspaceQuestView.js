import { QuestDossier } from "../../quests/applications/QuestDossier.js";
import { QuestApplication } from "../../quests/applications/QuestApplication.js";
import { WorkspaceEntities } from "../services/WorkspaceEntities.js";
import { canSelectWorkspaceNode } from "../services/WorkspaceBrowserPolicy.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";

export const workspaceQuestActions = Object.keys(QuestDossier.DEFAULT_OPTIONS.actions);
const readingActions = new Set(["viewTab", "openEntity", "contribute", "noteMenu"]);

export class WorkspaceQuestView extends QuestDossier {
    constructor(tab, entry) {
        super({ questId: entry.id });
        this.tab = tab;
        this.activeView = tab.view;
        this.scrollPositions = new Map();
        this.openConnectionNode = node => this.openNode(node);
        this.objectNavigationItems = node => this.tab.host.objectNavigationItems(node, this.tab);
    }
    get element() { return this.tab?.element?.querySelector("[data-workspace-quest]"); }
    snapshotSession() {
        return { compact: this.compact, expandedView: this.expandedView, scrollPositions: [...this.scrollPositions],
            contribution: this.element?.querySelector('[name="contribution"]')?.value ?? this.contribution ?? "" };
    }
    restoreSession(state) {
        if (!state) return;
        this.compact = state.compact;
        this.expandedView = state.expandedView;
        this.scrollPositions = new Map(state.scrollPositions || []);
        this.contribution = state.contribution || "";
    }
    render() {
        if (!this.tab || this.tab.closed) return Promise.resolve(this);
        this.tab.view = this.activeView;
        return this.tab.redraw();
    }
    async close() { return this.tab.host.closeTab(this.tab.host.groupFor(this.tab), this.tab); }
    // Embedded instances must not unregister a separately opened standalone dossier.
    dispose() { return QuestApplication.prototype.close.call(this); }
    async prepare() {
        if (this.tab.compact && !this.compact) {
            this.expandedView = this.tab.view;
            this.tab.view = "profile";
        } else if (!this.tab.compact && this.compact && this.tab.view === "profile") this.tab.view = this.expandedView || "journal";
        this.compact = this.tab.compact;
        this.activeView = this.tab.view;
        if (!["profile", "journal", "log", "connections", "gm"].includes(this.activeView)) this.activeView = "profile";
        if (!this.compact && this.activeView === "profile") this.activeView = "journal";
        const model = await super._prepareContext();
        this.tab.view = this.activeView;
        if (model.header) model.header.showCompactToggle = false;
        this.model = model;
        await foundry.applications.handlebars.loadTemplates(QuestDossier.PARTS.content.templates);
        return foundry.applications.handlebars.renderTemplate(QuestDossier.PARTS.content.template, model);
    }
    openNode(node) {
        if (canSelectWorkspaceNode(node)) return this.tab.selectEntity(node.entityId, { type: node.entityType });
        if (["nexus-site", "nexus-scene"].includes(node?.kind)) return this.tab.selectEntity(node.id, { type: "place" });
        return ConnectionTargetResolver.openNode(node);
    }
    resolveObjectTarget(element) {
        const edge = this.quest?.connections.find(edge => edge.id === element.dataset.edgeId);
        return edge && !edge.missing ? edge.target : null;
    }
    activate() {
        this.activateContentListeners(this.model);
        const signal = this.dragEvents.signal;
        this.element?.querySelector('[name="contribution"]')?.addEventListener("input", event => {
            this.contribution = event.target.value;
        }, { signal });
        for (const selector of QuestDossier.PARTS.content.scrollable) {
            const element = this.element?.querySelector(selector);
            if (!element) continue;
            const key = `${this.activeView}:${selector}`;
            element.scrollTop = this.scrollPositions.get(key) || 0;
            element.addEventListener("scroll", () => this.scrollPositions.set(key, element.scrollTop), { signal });
        }
    }
    async handleAction(action, button) {
        if (!WorkspaceEntities.canView(WorkspaceEntities.get(this.questId, "quest"))) return;
        if (!readingActions.has(action) && !this.quest?.canEdit) return;
        if (action === "toggleCompact") return this.tab.host.handleAction("workspaceCompact", button);
        if (action === "openEntity") {
            const target = this.quest.connections.find(edge => edge.id === button.dataset.edgeId)?.target;
            if (target) return this.openNode(target);
        }
        return QuestDossier.DEFAULT_OPTIONS.actions[action]?.call(this, null, button);
    }
}
