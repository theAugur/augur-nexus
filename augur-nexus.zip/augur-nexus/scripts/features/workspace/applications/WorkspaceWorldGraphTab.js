import { placeWorldGraph, WORLD_NODE } from "../models/WorldGraphLayout.js";
import { buildWorldGraph, filterWorldGraph, WORLD_GRAPH_TYPES } from "../models/WorldGraphModel.js";
import { WorkspaceEntities } from "../services/WorkspaceEntities.js";

export const worldGraphActions = ["workspaceWorldGraph", "worldGraphSelect", "worldGraphFit", "worldGraphZoom", "worldGraphOpen", "worldGraphBeside", "worldGraphFocus", "worldGraphAll", "worldGraphPin", "worldGraphArrange"];

export class WorkspaceWorldGraphTab {
    constructor(host, id) { this.host = host; this.id = id; }
    kind = "world-graph";
    pinned = false;
    compact = false;
    entityId = "";
    entityType = "";
    view = "world-graph";
    selected = "";
    filters = { search: "", type: "", faction: "", factionMode: "highlight", relationship: "", color: "faction", labels: "auto", focus: "", depth: "1" };
    positions = new Map();
    camera = { x: 0, y: 0, zoom: 1 };
    graph = { nodes: [], edges: [] };
    visible = { nodes: [], edges: [] };
    closed = false;
    #fitPending = true;
    #suppressClick = false;
    #hoverTimer = null;
    #hoverActive = false;
    snapshotSession() {
        return { kind: this.kind, pinned: this.pinned, compact: this.compact, selected: this.selected,
            filters: { ...this.filters }, positions: [...this.positions].map(([id, position]) => [id, { ...position }]), camera: { ...this.camera } };
    }
    restoreSession(state) {
        this.pinned = !!state.pinned; this.compact = !!state.compact; this.selected = state.selected || "";
        Object.assign(this.filters, state.filters);
        this.positions = new Map(state.positions || []); this.camera = { ...this.camera, ...state.camera };
        this.#fitPending = false;
    }
    #clearHover(restore = true) {
        clearTimeout(this.#hoverTimer);
        this.#hoverTimer = null;
        if (restore && this.#hoverActive) this.highlight(this.selected);
        this.#hoverActive = false;
    }
    get element() { return this.host.element?.querySelector(`[data-workspace-tab-view="${this.id}"]`); }
    async prepare() {
        this.#clearHover(false);
        this.graph = buildWorldGraph();
        const liveIds = new Set(this.graph.nodes.map(node => node.id));
        for (const id of this.positions.keys()) if (!liveIds.has(id)) this.positions.delete(id);
        if (!this.graph.nodes.some(n => n.id === this.selected)) this.selected = "";
        if (!this.graph.nodes.some(n => n.id === this.filters.focus)) this.filters.focus = "";
        if (!this.graph.factions.some(f => f.id === this.filters.faction)) this.filters.faction = "";
        if (!this.graph.kinds.includes(this.filters.relationship)) this.filters.relationship = "";
        placeWorldGraph(this.graph.nodes, this.graph.edges, this.positions);
        this.visible = filterWorldGraph(this.graph, this.filters);
        const selected = this.visible.nodes.find(n => n.id === this.selected);
        if (!selected) this.selected = "";
        const neighbors = new Set([this.selected]);
        for (const edge of this.visible.edges) if ([edge.source,edge.target].includes(this.selected)) { neighbors.add(edge.source); neighbors.add(edge.target); }
        const emphasized = n => !this.selected ? (!this.filters.faction || this.filters.factionMode !== "highlight" || n.factionIds.includes(this.filters.faction)) : neighbors.has(n.id);
        const byId = new Map(this.visible.nodes.map(n => [n.id,n]));
        const options = (items, value) => items.map(item => ({ ...item, selected: item.id === value }));
        return { worldGraph: {
            search: this.filters.search,
            types: options(WORLD_GRAPH_TYPES, this.filters.type), factions: options(this.graph.factions, this.filters.faction),
            relationships: options(this.graph.kinds.map(id=>({id,label:id})), this.filters.relationship),
            colors: options([{id:"faction",label:"Faction"},{id:"type",label:"Entity type"},{id:"neutral",label:"Neutral"}],this.filters.color),
            labels: options([{id:"auto",label:"Automatic"},{id:"all",label:"All names"},{id:"icons",label:"Icons only"}],this.filters.labels),
            factionModes: options([{id:"highlight",label:"Highlight faction"},{id:"filter",label:"Only this faction"}],this.filters.factionMode),
            depths: options([{id:"1",label:"1 connection away"},{id:"2",label:"2 connections away"},{id:"3",label:"3 connections away"}],this.filters.depth),
            focused: !!this.filters.focus, selected, pinned: this.positions.get(this.selected)?.pinned,
            focusName: this.graph.nodes.find(n=>n.id===this.filters.focus)?.name,
            count: this.visible.nodes.length, edgeCount: this.visible.edges.length, total: this.graph.nodes.length,
            nodes: this.visible.nodes.map(node => ({ ...node, ...this.positions.get(node.id), active: node.id === this.selected, dimmed: !emphasized(node),
                color: this.filters.color === "type" ? node.typeColor : this.filters.color === "neutral" ? "#888c96" : node.color })),
            edges: this.visible.edges.map(edge => ({ ...edge, highlighted: [edge.source,edge.target].includes(this.selected),
                dimmed: !emphasized(byId.get(edge.source)) || !emphasized(byId.get(edge.target)) }))
        } };
    }
    async handleAction(action, button) {
        this.#clearHover();
        if (action === "worldGraphSelect") {
            if (this.#suppressClick) { this.#suppressClick = false; return; }
            this.selected = button.dataset.graphNode; return this.host.redraw();
        }
        if (action === "worldGraphArrange") {
            placeWorldGraph(this.graph.nodes, this.graph.edges, this.positions, { reset: true });
            this.#fitPending = true; return this.host.redraw();
        }
        if (action === "worldGraphFit") return this.fit();
        if (action === "worldGraphZoom") return this.zoom(Number(button.dataset.delta));
        if (action === "worldGraphAll") { this.filters.focus = ""; this.selected = ""; return this.host.redraw(); }
        if (action === "worldGraphFocus" && this.selected) { this.filters.focus = this.selected; this.filters.search = ""; this.#fitPending = true; return this.host.redraw(); }
        if (action === "worldGraphPin") {
            const position = this.positions.get(this.selected); if (position) position.pinned = !position.pinned;
            return this.host.redraw();
        }
        if (["worldGraphOpen", "worldGraphBeside"].includes(action)) {
            const node = this.visible.nodes.find(n => n.id === this.selected);
            if (!node || !WorkspaceEntities.canView(WorkspaceEntities.get(node.entityId, node.type))) return;
            return this.host.openGraphEntity(this, node, action === "worldGraphBeside");
        }
    }
    attachListeners(root) {
        this.#clearHover(false);
        root.addEventListener("change", event => {
            const key = event.target.dataset.worldFilter;
            if (!Object.hasOwn(this.filters, key)) return;
            this.filters[key] = event.target.value;
            void this.host.perform(() => this.host.redraw());
        });
        const search = root.querySelector('[data-world-filter="search"]');
        search?.addEventListener("keydown", event => {
            if (event.key !== "Enter") return;
            event.preventDefault(); this.filters.search = search.value;
            void this.host.perform(() => this.host.redraw());
        });
        const stage = root.querySelector("[data-world-stage]");
        if (!stage) return;
        let drag;
        stage.addEventListener("wheel", event => {
            this.#clearHover();
            event.preventDefault();
            const bounds = stage.getBoundingClientRect();
            this.zoom(event.deltaY < 0 ? 1.12 : 1 / 1.12, event.clientX - bounds.left, event.clientY - bounds.top);
        }, { passive: false });
        stage.addEventListener("pointerover", event => {
            const node = event.target.closest("[data-graph-node]");
            if (!node || node.contains(event.relatedTarget) || drag || event.buttons) return;
            this.#clearHover();
            // Passing over nodes while navigating should not flash the whole graph.
            this.#hoverTimer = setTimeout(() => {
                this.#hoverTimer = null;
                if (this.closed || this.element !== root || drag) return;
                this.#hoverActive = true;
                this.highlight(node.dataset.graphNode);
            }, 200);
        });
        stage.addEventListener("pointerout", event => {
            const node = event.target.closest("[data-graph-node]");
            if (node && !node.contains(event.relatedTarget)) this.#clearHover();
        });
        stage.addEventListener("pointerleave", () => this.#clearHover());
        stage.addEventListener("contextmenu", event => { event.preventDefault(); event.stopPropagation(); });
        stage.addEventListener("pointerdown", event => {
            this.#clearHover();
            if (![0, 2].includes(event.button) || drag) return;
            const pan = event.button === 2;
            const node = pan ? null : event.target.closest("[data-graph-node]");
            const position = node && this.positions.get(node.dataset.graphNode);
            this.#suppressClick = false;
            if (position?.pinned) return;
            if (pan) { event.preventDefault(); event.stopPropagation(); }
            drag = { x: event.clientX, y: event.clientY, pointerId: event.pointerId, pan,
                origin: { ...(position || this.camera) }, node: node?.dataset.graphNode, moved: false };
            if (!node) stage.setPointerCapture(event.pointerId);
        });
        stage.addEventListener("pointermove", event => {
            if (!drag || event.pointerId !== drag.pointerId) return;
            const dx = event.clientX-drag.x, dy = event.clientY-drag.y;
            if (!drag.moved && Math.hypot(dx,dy) < 4) return;
            drag.moved = true;
            stage.setPointerCapture(event.pointerId);
            if (drag.node) {
                Object.assign(this.positions.get(drag.node), { x: drag.origin.x+dx/this.camera.zoom, y: drag.origin.y+dy/this.camera.zoom });
                this.drawPositions();
            } else if (drag.pan) { this.camera.x = drag.origin.x+dx; this.camera.y = drag.origin.y+dy; this.transform(); }
        });
        const finish = event => {
            if (!drag || event.pointerId !== drag.pointerId) return;
            this.#clearHover();
            const clearFocus = event.type === "pointerup" && !drag.pan && !drag.node && !drag.moved;
            if (drag.node && drag.moved) this.#suppressClick = true;
            drag = null;
            if (stage.hasPointerCapture(event.pointerId)) stage.releasePointerCapture(event.pointerId);
            if (clearFocus && (this.selected || this.filters.focus))
                void this.host.perform(() => this.handleAction("worldGraphAll"));
        };
        stage.addEventListener("pointerup", finish); stage.addEventListener("pointercancel", finish);
        stage.addEventListener("lostpointercapture", finish);
        stage.addEventListener("keydown", event => {
            if (event.target.closest("button")) return;
            const move = { ArrowLeft: [40,0], ArrowRight: [-40,0], ArrowUp: [0,40], ArrowDown: [0,-40] }[event.key];
            if (move) { event.preventDefault(); this.camera.x += move[0]; this.camera.y += move[1]; this.transform(); }
            if (["+","-","="].includes(event.key)) { event.preventDefault(); this.zoom(event.key === "-" ? 1/1.2 : 1.2); }
        });
    }
    restoreView() { this.drawPositions(); if (this.#fitPending && this.visible.nodes.length) { this.fit(); this.#fitPending = false; } else this.transform(); }
    drawPositions() {
        const root = this.element; if (!root) return;
        for (const element of root.querySelectorAll("[data-graph-node]")) {
            const p = this.positions.get(element.dataset.graphNode);
            element.style.left = `${p.x}px`; element.style.top = `${p.y}px`;
        }
        for (const element of root.querySelectorAll("[data-world-edge]")) {
            const a = this.positions.get(element.dataset.source), b = this.positions.get(element.dataset.target);
            if (!a || !b) continue;
            const line = element.querySelector("line"), label = element.querySelector("text");
            const dx=b.x-a.x, dy=b.y-a.y, distance=Math.hypot(dx,dy)||1;
            const insetA=Math.min((a.size || 50)/2+3,distance/2), insetB=Math.min((b.size || 50)/2+3,distance/2);
            line.setAttribute("x1", a.x+WORLD_NODE.cx+dx/distance*insetA); line.setAttribute("y1", a.y+WORLD_NODE.cy+dy/distance*insetA);
            line.setAttribute("x2", b.x+WORLD_NODE.cx-dx/distance*insetB); line.setAttribute("y2", b.y+WORLD_NODE.cy-dy/distance*insetB);
            label.setAttribute("x", (a.x+b.x)/2+WORLD_NODE.cx); label.setAttribute("y", (a.y+b.y)/2+WORLD_NODE.cy-8);
        }
    }
    highlight(id) {
        const related = new Set([id]);
        for (const edge of this.visible.edges) if ([edge.source,edge.target].includes(id)) { related.add(edge.source); related.add(edge.target); }
        const emphasized = new Set(this.visible.nodes.filter(n => id ? related.has(n.id)
            : !this.filters.faction || this.filters.factionMode !== "highlight" || n.factionIds.includes(this.filters.faction)).map(n=>n.id));
        this.element?.querySelectorAll("[data-graph-node]").forEach(node => {
            node.classList.toggle("is-dimmed", !emphasized.has(node.dataset.graphNode));
            node.classList.toggle("is-hovered", node.dataset.graphNode === id);
        });
        this.element?.querySelectorAll("[data-world-edge]").forEach(edge => {
            edge.classList.toggle("is-highlighted", [edge.dataset.source,edge.dataset.target].includes(id));
            edge.classList.toggle("is-dimmed", !emphasized.has(edge.dataset.source) || !emphasized.has(edge.dataset.target));
        });
    }
    transform() {
        const layer = this.element?.querySelector("[data-world-layer]");
        const root=this.element;
        if (root) {
            root.dataset.nameMode=this.filters.labels;
            root.dataset.zoomDetail=this.camera.zoom < .3 ? "overview" : this.camera.zoom < .65 ? "groups" : "detail";
            root.style.setProperty("--world-edge-scale", 1/this.camera.zoom);
            root.style.setProperty("--world-label-scale", Math.min(1.8, 1/this.camera.zoom));
            root.style.setProperty("--world-hover-label-scale", 1/this.camera.zoom);
        }
        if (layer) layer.style.transform = `translate(${this.camera.x}px, ${this.camera.y}px) scale(${this.camera.zoom})`;
    }
    fit() {
        const stage = this.element?.querySelector("[data-world-stage]");
        if (!stage || !this.visible.nodes.length) return;
        const positions = this.visible.nodes.map(n => this.positions.get(n.id));
        const minX = Math.min(...positions.map(p=>p.x)), minY = Math.min(...positions.map(p=>p.y));
        const width = Math.max(...positions.map(p=>p.x)) - minX + WORLD_NODE.width;
        const height = Math.max(...positions.map(p=>p.y)) - minY + WORLD_NODE.height;
        this.camera.zoom = Math.min(1.25, Math.max(.04, Math.min((stage.clientWidth-70)/width, (stage.clientHeight-70)/height)));
        this.camera.x = (stage.clientWidth-width*this.camera.zoom)/2-minX*this.camera.zoom;
        this.camera.y = (stage.clientHeight-height*this.camera.zoom)/2-minY*this.camera.zoom;
        this.transform();
    }
    zoom(factor, x, y) {
        const stage = this.element?.querySelector("[data-world-stage]"); if (!stage) return;
        x ??= stage.clientWidth/2; y ??= stage.clientHeight/2;
        const next = Math.max(.04, Math.min(2.5, this.camera.zoom*factor));
        const ratio = next/this.camera.zoom;
        this.camera.x = x-(x-this.camera.x)*ratio; this.camera.y = y-(y-this.camera.y)*ratio; this.camera.zoom = next;
        this.transform();
    }
    destroy() { this.#clearHover(false); this.closed = true; this.positions.clear(); }
}
