import { NexusTool } from "../../../support/utils/NexusTool.js";
import { ToolWindowLifecycle } from "../../../support/toolbar/ToolWindowLifecycle.js";
import { bindNexusDragOrigin } from "../../../support/ui/NexusDragOrigin.js";
import { openActionMenu } from "../../../api/ui.js";
import { applySessionWindowPlacement } from "../../../api/window-placement.js";
import { NexusBrowserApplicationMixin } from "../../nexus/applications/NexusBrowserApplicationMixin.js?v=20260805-site-branch-notice";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { WorkspaceEntities } from "../services/WorkspaceEntities.js";
import { WorkspacePlaces } from "../services/WorkspacePlaces.js";
import { planWorkspacePaneSizing } from "../services/WorkspacePaneSizing.js";
import { workspaceBrowserAction, canSelectWorkspaceNode } from "../services/WorkspaceBrowserPolicy.js";
import { WorkspaceEntityTab, workspaceViewActions } from "./WorkspaceEntityTab.js";

import { setWorkspaceEntityDrag, workspaceObjectEntity, workspaceDropTarget } from "../services/WorkspaceEntityDrag.js";

import { WorkspaceWorldGraphTab, worldGraphActions } from "./WorkspaceWorldGraphTab.js";

const tabIdentity = tab => tab.kind === "world-graph" ? `graph:${tab.id}` : tab.entityId ? `${tab.entityType}:${tab.entityId}` : "empty";

const ROOT = "modules/augur-nexus/templates/";
const layoutActions = ["workspaceNewTab", "workspaceSelectTab", "workspaceCloseTab", "workspaceTabMenu", "workspaceSplit", "workspacePaneSelect", "workspaceRestoreSplit", "workspaceFullscreen"];
const MIN_PANE_WIDTH = 420;
const DIVIDER_WIDTH = 6;
const expandedWidth = tab => tab.minimumExpandedWidth || (tab.entityType === "quest" ? 981 : 621);

export class CampaignWorkspace extends NexusBrowserApplicationMixin(NexusTool) {
    static WORKSPACE_BROWSER = true;
    static BROWSER_INITIAL_TAB = "people";
    static #instance;
    static #sessions = new Map();
    static DEFAULT_OPTIONS = {
        id: "augur-nexus-campaign-workspace", tag: "div",
        classes: ["augur-nexus", "augur-theme-fantasy", "nexus-campaign-workspace"],
        window: { title: "Nexus Workspace", resizable: true, minimizable: true },
        position: { width: 720, height: 750 },
        actions: Object.fromEntries([...workspaceViewActions, ...layoutActions, ...worldGraphActions].map(name => [name, function(event, button) {
            return this.perform(() => this.handleAction(name, button, event));
        }]))
    };
    static PARTS = {
        ...super.PARTS,
        main: { ...super.PARTS.main, scrollable: [".nexus-browser-section", ".nexus-browser-tree", ".nexus-quest-list"] },
        content: {
            template: `${ROOT}workspace/campaign-workspace.hbs`,
            templates: [`${ROOT}workspace/workspace-world-graph.hbs`, `${ROOT}workspace/workspace-entity-tab.hbs`, `${ROOT}campaign-entities/npc-portrait.hbs`,
                `${ROOT}workspace/workspace-connection-card.hbs`, `${ROOT}workspace/npc-workspace-profile-view.hbs`,
                `${ROOT}campaign-entities/npc-profile-panel.hbs`, `${ROOT}campaign-entities/npc-life-overview.hbs`,
                `${ROOT}campaign-entities/npc-world-ties.hbs`,
                `${ROOT}campaign-entities/compact-section-heading.hbs`,
                `${ROOT}campaign-entities/quest-world-ties.hbs`]
        }
    };

    #sequence = 0;
    #hooks = [];
    #observer;
    #busy = false;
    #closed = false;
    #expandedPosition;
    #windowedPosition;
    #viewportResize = () => {
        if (this.fullscreen && this.rendered && !this.#closed) {
            this.#positioning = true;
            try { this.setPosition({}); }
            finally { this.#positioning = false; }
            this.updateLayout(true);
        }
    };
    #positioning = false;
    #lastWidth = 0;
    #expandedSplit;
    #compactPane;
    #sizedDeckWidth;
    #compactColumns = false;
    #sessionPosition;
    #densityOverrides = new WeakMap();
    #expansionAvailability = new WeakMap();
    groups = [];
    activeGroupId = "";
    focusedGroupId = "";
    browserCollapsed = false;
    narrow = false;
    ratio = .5;

    constructor({ workspaceSession, ...options } = {}) {
        super(options);
        this.#sessionPosition = options.position;
        if (workspaceSession) this.restoreSession(workspaceSession);
        else this.addGroup();
    }
    snapshotSession() {
        const tabId = tab => tab?.id;
        return {
            position: { ...this.position }, browser: this.captureBrowserSession?.(),
            groups: this.groups.map(group => ({ id: group.id, activeId: group.activeId,
                tabs: group.tabs.map(tab => ({ id: tab.id, ...tab.snapshotSession() })) })),
            activeGroupId: this.activeGroupId, focusedGroupId: this.focusedGroupId, browserCollapsed: this.browserCollapsed, ratio: this.ratio,
            expandedPosition: this.#expandedPosition && { ...this.#expandedPosition }, windowedPosition: this.#windowedPosition && { ...this.#windowedPosition },
            compactPane: this.#compactPane && { ...this.#compactPane },
            compactColumns: this.#compactColumns,
            expandedSplit: this.#expandedSplit && { ...this.#expandedSplit, tab: tabId(this.#expandedSplit.tab), otherTab: tabId(this.#expandedSplit.otherTab) }
        };
    }
    restoreSession(state) {
        this.groups = (state.groups || []).slice(0, 2).map(saved => ({ id: saved.id, activeId: saved.activeId,
            tabs: saved.tabs.map(tabState => {
                const Tab = tabState.kind === "world-graph" ? WorkspaceWorldGraphTab : WorkspaceEntityTab;
                const tab = new Tab(this, tabState.id); tab.restoreSession(tabState); return tab;
            }) }));
        const ids = this.groups.flatMap(group => [group.id, ...group.tabs.map(tab => tab.id)]);
        this.#sequence = Math.max(0, ...ids.map(id => Number(id.split("-").at(-1)) || 0));
        if (!this.groups.length) this.addGroup();
        for (const group of this.groups) {
            if (!group.tabs.length) this.addTab(group);
            if (!group.tabs.some(tab => tab.id === group.activeId)) group.activeId = group.tabs[0].id;
        }
        this.activeGroupId = this.groups.some(group => group.id === state.activeGroupId) ? state.activeGroupId : this.groups[0].id;
        this.focusedGroupId = this.groups.length > 1 && this.groups.some(group => group.id === state.focusedGroupId) ? state.focusedGroupId : "";
        this.browserCollapsed = !!state.browserCollapsed; this.ratio = state.ratio ?? .5;
        this.#expandedPosition = state.expandedPosition; this.#windowedPosition = state.windowedPosition;
        this.#compactPane = state.compactPane;
        this.#compactColumns = !!state.compactColumns;
        const tabs = this.groups.flatMap(group => group.tabs);
        if (state.expandedSplit) {
            const tab = tabs.find(tab => tab.id === state.expandedSplit.tab), otherTab = tabs.find(tab => tab.id === state.expandedSplit.otherTab);
            if (tab && otherTab) this.#expandedSplit = { ...state.expandedSplit, tab, otherTab };
        }
        this.restoreBrowserSession?.(state.browser);
    }
    addGroup() {
        const group = { id: `pane-${++this.#sequence}`, tabs: [], activeId: "" };
        this.groups.push(group);
        this.addTab(group);
        if (this.groups.length === 2) {
            for (const pane of this.groups) for (const tab of pane.tabs) tab.compact = true;
        }
        return group;
    }
    addTab(group, kind = "entity") {
        const Tab = kind === "world-graph" ? WorkspaceWorldGraphTab : WorkspaceEntityTab;
        const tab = new Tab(this, `tab-${++this.#sequence}`);
        tab.compact = group.tabs.find(t => t.id === group.activeId)?.compact ?? true;
        group.tabs.push(tab);
        group.activeId = tab.id;
        this.activeGroupId = group.id;
        return tab;
    }
    get activeGroup() { return this.groups.find(g => g.id === this.activeGroupId) || this.groups[0]; }
    get activeTab() { return this.activeGroup.tabs.find(t => t.id === this.activeGroup.activeId); }
    get entityId() { return this.activeTab.entityId; }
    get entityType() { return this.activeTab.entityType; }
    get fullscreen() { return !!this.#windowedPosition; }
    async _renderFrame(options) {
        const frame = await super._renderFrame(options);
        frame.classList.toggle("is-browser-collapsed", this.browserCollapsed);
        frame.classList.toggle("is-workspace-fullscreen", this.fullscreen);
        const button = document.createElement("button");
        button.type = "button";
        button.className = "header-control icon fa-solid fa-expand";
        button.dataset.action = "workspaceFullscreen";
        button.title = "Full screen";
        button.setAttribute("aria-label", "Full screen");
        button.setAttribute("aria-pressed", "false");
        frame.querySelector('.window-header [data-action="close"]')?.before(button);
        return frame;
    }
    #updateFullscreenControl() {
        this.element?.classList.toggle("is-workspace-fullscreen", this.fullscreen);
        const button = this.element?.querySelector('[data-action="workspaceFullscreen"]');
        if (!button) return;
        button.classList.toggle("fa-expand", !this.fullscreen);
        button.classList.toggle("fa-compress", this.fullscreen);
        button.title = this.fullscreen ? "Restore window size" : "Full screen";
        button.setAttribute("aria-label", button.title);
        button.setAttribute("aria-pressed", String(this.fullscreen));
    }
    async toggleFullscreen() {
        if (this.minimized) await this.maximize();
        const previous = this.#windowedPosition;
        const { width, height, left, top, scale } = this.position;
        this.#windowedPosition = previous ? null : { width, height, left, top, scale };
        this.#updateFullscreenControl();
        this.#positioning = true;
        try { this.setPosition(previous || {}); }
        finally { this.#positioning = false; }
        this.updateLayout(false, Math.max(0, this.position.width - (this.browserCollapsed ? 0 : this.browserWidth)));
        return this.redraw();
    }
    _prePosition(position) {
        super._prePosition?.(position);
        // Use Foundry's window positioning, keeping editors and dialogs in the same document.
        if (this.fullscreen) Object.assign(position, {
            left: 0, top: 0, scale: 1,
            width: document.documentElement?.clientWidth || window.innerWidth,
            height: document.documentElement?.clientHeight || window.innerHeight
        });
    }
    async minimize() {
        if (this.fullscreen) await this.toggleFullscreen();
        return super.minimize();
    }
    get browserWidth() {
        const sidebar = document.getElementById?.("sidebar") || document.documentElement;
        return (sidebar && Number.parseFloat(globalThis.getComputedStyle?.(sidebar).getPropertyValue("--sidebar-width-expanded"))) || 300;
    }
    get deckWidth() {
        return this.#sizedDeckWidth ?? (this.element?.querySelector(".nexus-workspace-deck")?.clientWidth
            || Math.max(0, this.position.width - (this.browserCollapsed ? 0 : this.browserWidth)));
    }
    canExpand(tab, width = this.deckWidth) {
        const viewport = document.documentElement?.clientWidth || window.innerWidth;
        const capacity = (viewport - (this.fullscreen ? 0 : 40)) / (this.position.scale || 1);
        return capacity - (this.browserCollapsed ? 0 : this.browserWidth) >= expandedWidth(tab) + (this.groups.length > 1 ? MIN_PANE_WIDTH + DIVIDER_WIDTH : 0);
    }
    groupFor(tab) { return this.groups.find(g => g.tabs.includes(tab)); }
    tabFor(button) {
        const id = button?.closest?.("[data-workspace-tab-view]")?.dataset.workspaceTabView;
        return this.groups.flatMap(g => g.tabs).find(t => t.id === id) || this.activeTab;
    }
    static show() {
        return ToolWindowLifecycle.open("nexus-browser", () => {
            if (this.#instance) return this.#instance;
            const saved = this.#sessions.get(game.user.id);
            const session = saved ? foundry.utils.deepClone(saved) : null;
            const position = session?.position || { width: Math.min(720, window.innerWidth - 50), height: Math.min(750, window.innerHeight - 70) };
            const app = this.#instance = new this({ workspaceSession: session, position });
            if (!session) position.width = Math.min(MIN_PANE_WIDTH + app.browserWidth, window.innerWidth - 50);
            app.narrow = app.groups.length > 1 && Math.min(position.width, window.innerWidth - 40) - (app.browserCollapsed ? 0 : app.browserWidth) < MIN_PANE_WIDTH * 2 + DIVIDER_WIDTH;
            return app;
        });
    }
    async perform(callback) {
        if (this.#busy || this.#closed) return;
        this.#busy = true;
        try { return await callback(); }
        catch (error) { ui.notifications.error(error.message || "The workspace action failed."); }
        finally { this.#busy = false; }
    }
    render(options = {}, legacy = {}) {
        if (this.#closed) return Promise.resolve(this);
        if (typeof options === "boolean") options = { ...legacy, force: options };
        return super.render(options);
    }
    // Foundry raises forced renders; background updates must leave the active editor in front.
    redraw() { return this.render({ force: !this.rendered }); }
    async _prepareContext(options) {
        const context = await super._prepareContext(options);
        if (options.parts?.length === 1 && options.parts[0] === "main") return context;
        const split = this.groups.length > 1;
        const single = !split || this.narrow || !!this.focusedGroupId;
        const visibleId = this.focusedGroupId || this.activeGroupId;
        const groups = [];
        for (const [index, group] of this.groups.entries()) {
            const tab = group.tabs.find(t => t.id === group.activeId);
            const visible = !single || group.id === visibleId;
            const view = visible ? await tab.prepare() : {};
            if (view.workspace) view.workspace.expansionUnavailable = tab.compact && !this.canExpand(tab);
            tab.context = view;
            groups.push({ id: group.id, number: index + 1, side: index ? "Right" : "Left", layoutControl: single ? visible : index === this.groups.length - 1, active: group.id === this.activeGroupId, visible,
                tabId: tab.id, split, focused: !!this.focusedGroupId, ...view,
                tabs: group.tabs.map(t => {
                    if (t.kind === "world-graph") return { id: t.id, active: t.id === group.activeId, pinned: t.pinned, label: "World Graph", icon: "fas fa-diagram-project" };
                    const entity = WorkspaceEntities.get(t.entityId, t.entityType);
                    const available = WorkspaceEntities.canView(entity);
                    return { id: t.id, active: t.id === group.activeId, pinned: t.pinned,
                        label: available ? entity.display.name : t.entityId ? "Unavailable" : "New tab",
                        image: available ? (entity.type === "place" ? entity.target.img : ConnectionTargetResolver.fromCampaignEntity(entity)?.img) || "" : "",
                        icon: available ? WorkspaceEntities.describe(t.entityType).icon : "fas fa-file" };
                }) });
        }
        return { ...context, layout: { groups, split, single, showSwitcher: split && single, narrow: this.narrow, focused: !!this.focusedGroupId,
            ratioPercent: Math.round(this.ratio * 100), columns: this.#compactColumns ? `${MIN_PANE_WIDTH}px 6px ${MIN_PANE_WIDTH}px` : `${this.ratio}fr 6px ${1 - this.ratio}fr` } };
    }
    activate(group, tabId = group.activeId) {
        if (!group.tabs.some(t => t.id === tabId)) return;
        this.activeGroupId = group.id;
        group.activeId = tabId;
        if (this.focusedGroupId) this.focusedGroupId = group.id;
        this.element?.querySelectorAll?.('[data-action="workspacePaneSelect"]').forEach(button => {
            const active = button.dataset.paneId === group.id;
            button.classList.toggle("is-active", active);
            button.setAttribute("aria-pressed", String(active));
        });
        this.element?.querySelectorAll?.(".nexus-browser-pill-shell[data-entity-type]").forEach(row => {
            const place = this.entityType === "place" ? WorkspacePlaces.fromBrowser(row.dataset) : null;
            row.classList.toggle("is-workspace-selected", place ? place.id === this.entityId
                : row.dataset.entityId === this.entityId && row.dataset.entityType === this.entityType);
        });
        this.element?.querySelectorAll?.("[data-workspace-pane]").forEach(el => el.classList.toggle("is-active-pane", el.dataset.workspacePane === group.id));
    }
    selectEntity(id, options = {}) { return this.openEntity(id, options); }
    createWorkspaceQuest({ folderId = "" } = {}) {
        return this.perform(async () => {
            const quest = await WorkspaceEntities.create("quest", { folderId });
            return this.openEntity(quest.id, { type: "quest", view: "profile", target: "new" });
        });
    }
    async openEntity(id, { type = "npc", view, target = "current", source = this.activeTab } = {}) {
        if (!WorkspaceEntities.canView(WorkspaceEntities.get(id, type))) {
            ui.notifications.warn("This entry is unavailable or its details have not been revealed."); return false;
        }
        const group = this.groupFor(source) || this.activeGroup;
        const existing = this.findEntityTab(group, id, type);
        if (existing) return this.selectExisting(group, existing);
        const tab = target === "new" || source.pinned || source.kind === "world-graph" ? this.addTab(group) : source;
        this.activate(group, tab.id);
        this.updateLayout(false);
        return tab.selectEntity(id, { type, view: view ?? (source.kind === "world-graph" ? "profile" : source.view) });
    }
    async openWorldGraph(group = this.activeGroup) {
        const existing = group.tabs.find(tab => tab.kind === "world-graph");
        if (existing) return this.selectExisting(group, existing);
        const empty = group.tabs.find(tab => tab.id === group.activeId && !tab.entityId && tab.kind !== "world-graph");
        if (empty) { empty.destroy(); group.tabs.splice(group.tabs.indexOf(empty), 1); }
        this.addTab(group, "world-graph");
        return this.redraw();
    }
    async openGraphEntity(source, node, beside = false) {
        const ownGroup = this.groupFor(source);
        const group = beside ? this.groups.find(group => group !== ownGroup) || this.addGroup() : ownGroup;
        const existing = this.findEntityTab(group, node.entityId, node.type);
        if (existing) return this.selectExisting(group, existing);
        const active = group.tabs.find(tab => tab.id === group.activeId);
        const tab = !active.entityId && active.kind !== "world-graph" ? active : this.addTab(group);
        this.activate(group, tab.id); this.updateLayout(false);
        return tab.selectEntity(node.entityId, { type: node.type, view: "profile" });
    }
    findEntityTab(group, id, type) {
        return group?.tabs.find(tab => tab.entityId === id && tab.entityType === type);
    }
    objectNavigationItems(node, source) {
        if (!workspaceObjectEntity(node)) return [{ id: "open-object", label: "Open Object", icon: "fas fa-up-right-from-square", onSelect: () => ConnectionTargetResolver.openNode(node) }];
        const own = this.groupFor(source);
        const label = this.groups.length === 1 ? "Open in a second pane"
            : this.groups.indexOf(own) === 0 ? "Open in right pane" : "Open in left pane";
        return [
            { id: "open-here", label: "Open here", icon: "fas fa-address-card", onSelect: () => this.perform(() => this.openObjectNode(node, { source })) },
            { id: "open-tab", label: "Open in new tab", icon: "fas fa-plus", onSelect: () => this.perform(() => this.openObjectNode(node, { source, target: "new" })) },
            { id: "open-other", label, icon: "fas fa-columns", onSelect: () => this.perform(() => this.openObjectNode(node, { source, target: "other" })) }
        ];
    }
    async openObjectNode(node, { source = this.activeTab, target = "current", destination } = {}) {
        const entity = workspaceObjectEntity(node);
        if (!entity || !this.groupFor(source)) return false;
        if (target === "other") {
            destination = this.groups.find(group => group !== this.groupFor(source)) || this.addGroup();
            this.focusedGroupId = "";
        }
        if (!destination) return this.openEntity(entity.id, { type: entity.type, target, source, view: "profile" });
        if (!this.groups.includes(destination)) return false;
        const existing = this.findEntityTab(destination, entity.id, entity.type);
        if (existing) { this.updateLayout(false); return this.selectExisting(destination, existing); }
        const empty = destination.tabs.find(tab => !tab.entityId && tab.kind !== "world-graph" && !tab.pinned);
        const tab = empty || this.addTab(destination);
        return this.openEntity(entity.id, { type: entity.type, source: tab, view: "profile" });
    }
    async selectExisting(group, tab) {
        this.activate(group, tab.id);
        await this.redraw();
        return true;
    }
    async toggleSplit() {
        let resizedDeckWidth;
        if (this.groups.length === 1) {
            this.addGroup();
            if (!this.fullscreen) {
                const chromeWidth = Math.max(0, this.position.width - this.deckWidth);
                const requiredWidth = MIN_PANE_WIDTH * 2 + DIVIDER_WIDTH + chromeWidth;
                const viewportWidth = document.documentElement?.clientWidth || window.innerWidth;
                const scale = this.position.scale || 1;
                const width = Math.min(requiredWidth, viewportWidth / scale);
                if (width > this.position.width) {
                    const left = Math.max(0, Math.min(this.position.left, viewportWidth - width * scale));
                    this.setPosition({ width, left });
                    // The rendered deck can still have its old dimensions until the next layout pass.
                    resizedDeckWidth = this.position.width - chromeWidth;
                }
            }
        } else {
            const selected = this.activeTab;
            const tabs = this.groups.flatMap(group => group.tabs);
            const populated = tabs.some(tab => tab.entityId || tab.kind === "world-graph");
            const unique = new Map();
            const survivors = [];
            for (const tab of tabs) {
                if (!tab.entityId && tab.kind !== "world-graph" && populated) { tab.destroy(); continue; }
                const key = tabIdentity(tab);
                const first = unique.get(key);
                if (first) { first.pinned ||= tab.pinned; tab.destroy(); }
                else { unique.set(key, tab); survivors.push(tab); }
            }
            const group = this.groups[0];
            group.tabs = survivors;
            const selectedKey = tabIdentity(selected);
            group.activeId = (unique.get(selectedKey) || survivors[0]).id;
            this.groups = [group];
            this.activeGroupId = group.id;
        }
        this.focusedGroupId = "";
        this.#expandedSplit = null;
        this.#compactPane = null;
        this.updateLayout(false, resizedDeckWidth);
        await this.redraw();
    }
    async followNode(node, target = "current") {
        if (!canSelectWorkspaceNode(node)) return this.#unsupported();
        return this.perform(() => this.openEntity(node.entityId, { type: node.entityType, target }));
    }
    #unsupported() { ui.notifications.info("This workspace opens people, organizations, locations, ships, sites, and quests. Use the standalone tools for other objects."); }
    async closeTab(group, tab) {
        this.#expandedSplit = null;
        const index = group.tabs.indexOf(tab);
        tab.destroy(); group.tabs.splice(index, 1);
        if (!group.tabs.length && this.groups.length > 1) {
            this.groups.splice(this.groups.indexOf(group), 1);
            this.activeGroupId = this.groups[0].id; this.focusedGroupId = "";
        } else if (!group.tabs.length) this.addTab(group);
        else if (group.activeId === tab.id) group.activeId = group.tabs[Math.min(index, group.tabs.length - 1)].id;
        this.updateLayout(false);
        await this.redraw();
    }
    async moveTab(tab, destination, beforeId = "") {
        const source = this.groupFor(tab);
        if (!source || !destination || beforeId === tab.id) return;
        this.#expandedSplit = null;
        source.tabs.splice(source.tabs.indexOf(tab), 1);
        const existing = tab.entityId ? this.findEntityTab(destination, tab.entityId, tab.entityType) : null;
        if (existing) { existing.pinned ||= tab.pinned; tab.destroy(); }
        const at = destination.tabs.findIndex(t => t.id === beforeId);
        if (!existing) destination.tabs.splice(at < 0 ? destination.tabs.length : at, 0, tab);
        if (!source.tabs.length && source !== destination) this.groups.splice(this.groups.indexOf(source), 1);
        else if (source.activeId === tab.id) source.activeId = source.tabs[0].id;
        this.activate(destination, (existing || tab).id);
        this.focusedGroupId = "";
        this.updateLayout(false);
        await this.redraw();
    }
    tabMenu(tab, anchor) {
        const group = this.groupFor(tab);
        return openActionMenu({ anchor, items: [
            { id: "pin", label: tab.pinned ? "Unpin Tab" : "Pin Tab", icon: "fas fa-thumbtack", onSelect: () => this.perform(async () => { tab.pinned = !tab.pinned; await this.redraw(); }) },
            ...(this.groups.length > 1 ? [
                { id: "move", label: "Move to Other Pane", icon: "fas fa-arrow-right-arrow-left", onSelect: () => this.perform(() => this.moveTab(tab, this.groups.find(g => g !== group))) },
                { id: "focus", label: this.focusedGroupId ? "Restore Split" : "Focus This Pane", icon: "fas fa-expand", onSelect: () => this.perform(async () => {
                    this.#expandedSplit = null;
                    this.focusedGroupId = this.focusedGroupId ? "" : group.id;
                    this.activate(group); this.updateLayout(false); await this.redraw();
                }) }
            ] : []),
            { id: "close", label: "Close Tab", icon: "fas fa-xmark", onSelect: () => this.perform(() => this.closeTab(group, tab)) }
        ] });
    }
    async handleAction(action, button, event) {
        if (action === "workspaceFullscreen") return this.toggleFullscreen();
        const group = this.groups.find(g => g.id === button?.closest?.("[data-workspace-pane]")?.dataset.workspacePane) || this.activeGroup;
        const tab = this.tabFor(button);
        if (action === "workspaceWorldGraph") return this.openWorldGraph(group);
        if (["workspaceNew", "workspaceGenerate"].includes(action) && tab.kind === "world-graph") return this.addTab(group).handleAction(action, button);
        if (action === "workspaceSelectTab") { this.activate(group, button.dataset.tabId); return this.redraw(); }
        if (action === "workspaceNewTab") { this.addTab(group); return this.redraw(); }
        if (action === "workspaceCloseTab" || action === "workspaceTabMenu") {
            const selected = group.tabs.find(t => t.id === button.dataset.tabId);
            if (!selected) return;
            return action === "workspaceCloseTab" ? this.closeTab(group, selected) : this.tabMenu(selected, button);
        }
        if (action === "workspacePaneSelect") {
            this.activate(this.groups.find(g => g.id === button.dataset.paneId));
            this.updateLayout(false); return this.redraw();
        }
        if (action === "workspaceSplit") return this.toggleSplit();
        if (action === "workspaceRestoreSplit") {
            this.focusedGroupId = "";
            this.updateLayout(false); return this.redraw();
        }
        if (action === "workspaceBrowserToggle") {
            this.browserCollapsed = !this.browserCollapsed;
            this.element?.classList.toggle("is-browser-collapsed", this.browserCollapsed);
            this.updateLayout(false); return this.redraw();
        }
        if (action === "workspaceCompact") {
            if (this.groups.length > 1) {
                const compact = !tab.compact;
                const tabs = this.groups.map(pane => pane.tabs.find(t => t.id === pane.activeId));
                const browserWidth = this.browserCollapsed ? 0 : this.browserWidth;
                const chromeWidth = Math.max(0, this.position.width - this.deckWidth - browserWidth);
                const viewportWidth = document.documentElement?.clientWidth || window.innerWidth;
                const plan = planWorkspacePaneSizing({ action: compact ? "compact" : "expand", paneIndex: this.groups.indexOf(group),
                    panes: tabs.map((entry, index) => ({ compact: entry.compact, minimumExpandedWidth: expandedWidth(entry),
                        compactWidth: this.#compactPane?.groupId === this.groups[index].id ? this.#compactPane.width : MIN_PANE_WIDTH })),
                    browserWidth, chromeWidth, currentWidth: this.position.width, viewportWidth, scale: this.position.scale || 1, fullscreen: this.fullscreen });
                if (!plan.success) {
                    ui.notifications.info("This viewport cannot fit an expanded dossier beside its compact neighbor. Both panes and the browser remain available; widen the browser window or reduce browser zoom.");
                    return;
                }
                this.#expandedSplit = null;
                this.#compactColumns = plan.compact.every(Boolean);
                this.#positioning = true;
                try {
                    const scale = this.position.scale || 1;
                    const margin = this.fullscreen ? 0 : 20;
                    const left = Math.max(margin, Math.min(this.position.left || margin, viewportWidth - plan.width * scale - margin));
                    this.setPosition({ width: plan.width, left });
                } finally { this.#positioning = false; }
                this.#sizedDeckWidth = plan.width - browserWidth - chromeWidth;
                const available = this.#sizedDeckWidth - DIVIDER_WIDTH;
                this.ratio = this.#compactColumns ? .5 : plan.paneWidths[0] / available;
                this.narrow = false;
                this.focusedGroupId = "";
                tabs.forEach((entry, index) => { entry.compact = plan.compact[index]; this.#densityOverrides.set(entry, plan.paneWidths[index]); });
                const compactIndex = plan.compact.filter(Boolean).length === 1 ? plan.compact.indexOf(true) : -1;
                this.#compactPane = compactIndex >= 0 ? { groupId: this.groups[compactIndex].id, width: plan.paneWidths[compactIndex] } : null;
                try { return await this.redraw(); }
                finally { this.#sizedDeckWidth = undefined; }
            }
            if (this.fullscreen) {
                if (tab.compact && this.deckWidth < expandedWidth(tab)) {
                    ui.notifications.info("This viewport is too narrow for the expanded dossier. Widen the browser window or reduce browser zoom.");
                    return;
                }
                tab.compact = !tab.compact;
                this.#densityOverrides.set(tab, this.deckWidth);
                return this.redraw();
            }
            if (!tab.compact) this.#expandedPosition = { ...this.position };
            tab.compact = !tab.compact;
            this.#positioning = true;
            try {
                const expanded = { ...(this.#expandedPosition || { width: 1440 }) };
                expanded.width = Math.max(expanded.width, expandedWidth(tab) + (this.browserCollapsed ? 0 : this.browserWidth));
                const viewport = document.documentElement?.clientWidth || window.innerWidth;
                const scale = this.position.scale || 1;
                const width = Math.min(tab.compact ? MIN_PANE_WIDTH + (this.browserCollapsed ? 0 : this.browserWidth) : expanded.width, (viewport - 40) / scale);
                this.setPosition({ ...(!tab.compact ? expanded : {}), width,
                    left: Math.max(20, Math.min(this.position.left || 20, viewport - width * scale - 20)) });
                if (!tab.compact && width - (this.browserCollapsed ? 0 : this.browserWidth) < expandedWidth(tab)) tab.compact = true;
            }
            finally { this.#positioning = false; }
            this.#densityOverrides.set(tab, this.position.width - (this.browserCollapsed ? 0 : this.browserWidth));
            return this.redraw();
        }
        this.activate(this.groupFor(tab));
        if (action === "workspaceFollow" && (event?.ctrlKey || event?.metaKey)) {
            const node = ConnectionStore.getNode(button.dataset.nodeId);
            if (canSelectWorkspaceNode(node)) return this.openEntity(node.entityId, { type: node.entityType, target: "new", source: tab });
        }
        return tab.handleAction(action, button);
    }

    paneWidth(group, width = this.deckWidth) {
        const split = this.groups.length > 1 && !this.narrow && !this.focusedGroupId;
        if (split && this.#compactColumns) return MIN_PANE_WIDTH;
        return split ? (width - DIVIDER_WIDTH) * (this.groups.indexOf(group) ? 1 - this.ratio : this.ratio) : width;
    }
    mixedCompactGroup() {
        if (this.groups.length !== 2) return null;
        const compact = this.groups.filter(group => {
            const tab = group.tabs.find(t => t.id === group.activeId);
            return tab.kind !== "world-graph" && tab.compact;
        });
        return compact.length === 1 ? compact[0] : null;
    }
    setCompactPaneWidth(group, width, available) {
        const paneWidth = Math.max(MIN_PANE_WIDTH, Math.min(available - MIN_PANE_WIDTH, width));
        this.ratio = this.groups.indexOf(group) ? 1 - paneWidth / available : paneWidth / available;
    }
    // Use each pane's width; the quest's three-column dossier needs more room to expand.
    updateLayout(redraw = true, suppliedWidth, manualDivider = false) {
        const width = suppliedWidth ?? this.deckWidth;
        if (!width) return;
        const previousNarrow = this.narrow;
        this.narrow = this.groups.length > 1 && width < MIN_PANE_WIDTH * 2 + DIVIDER_WIDTH;
        let changed = previousNarrow !== this.narrow;
        const split = this.groups.length > 1 && !this.narrow && !this.focusedGroupId;
        const previousRatio = this.ratio;
        if (split) this.ratio = Math.max(MIN_PANE_WIDTH / (width - DIVIDER_WIDTH), Math.min(1 - MIN_PANE_WIDTH / (width - DIVIDER_WIDTH), this.ratio));
        const compactGroup = this.mixedCompactGroup();
        if (split && !manualDivider && this.#compactPane?.groupId === compactGroup?.id && compactGroup) {
            this.setCompactPaneWidth(compactGroup, this.#compactPane.width, width - DIVIDER_WIDTH);
        }
        const updateDensity = () => {
            for (const group of this.groups) {
                const paneWidth = this.paneWidth(group, width);
                for (const tab of group.tabs) {
                    const available = this.canExpand(tab, width);
                    if (this.#expansionAvailability.get(tab) !== available) changed = true;
                    this.#expansionAvailability.set(tab, available);
                    if (Math.abs((this.#densityOverrides.get(tab) ?? -1) - paneWidth) < 1) continue;
                    this.#densityOverrides.delete(tab);
                    const minimum = expandedWidth(tab);
                    const compact = tab.compact ? paneWidth + .01 < minimum : paneWidth + .01 < (minimum > 621 ? minimum : minimum - 80);
                    if (tab.compact !== compact) { tab.compact = compact; changed = true; }
                }
            }
        };
        updateDensity();
        if (split) {
            const compactGroup = this.mixedCompactGroup();
            if (!compactGroup) this.#compactPane = null;
            else {
                // A compact reference keeps its pixel width while its neighbor takes window resizing.
                if (manualDivider || this.#compactPane?.groupId !== compactGroup.id) {
                    this.#compactPane = { groupId: compactGroup.id,
                        width: manualDivider ? this.paneWidth(compactGroup, width) : MIN_PANE_WIDTH };
                }
                this.setCompactPaneWidth(compactGroup, this.#compactPane.width, width - DIVIDER_WIDTH);
                updateDensity();
            }
        }
        changed ||= previousRatio !== this.ratio;
        if (changed && redraw) return this.redraw();
    }
    _onPosition(position) {
        super._onPosition?.(position);
        const width = Number(position.width);
        if (width === this.#lastWidth) return;
        this.#lastWidth = width;
        if (this.#positioning || !this.rendered || this.#closed) return;
        this.#sizedDeckWidth = undefined;
        this.#compactColumns = false;
        if (!this.fullscreen && this.groups.length === 1 && width - (this.browserCollapsed ? 0 : this.browserWidth) > (this.activeTab.entityType === "quest" ? 980 : 620))
            this.#expandedPosition = { ...position };
        return this.updateLayout(true, Math.max(0, width - (this.browserCollapsed ? 0 : this.browserWidth)));
    }
    _attachPartListeners(partId, root, options) {
        super._attachPartListeners(partId, root, options);
        if (partId !== "content") return;
        for (const group of this.groups) {
            const tab = group.tabs.find(t => t.id === group.activeId);
            const surface = root.querySelector(`[data-workspace-tab-view="${tab.id}"]`);
            if (surface) tab.attachListeners(surface);
        }
        root.addEventListener("pointerdown", event => {
            const group = this.groups.find(g => g.id === event.target.closest("[data-workspace-pane]")?.dataset.workspacePane);
            if (group) this.activate(group);
        }, true);
        root.addEventListener("focusin", event => {
            const group = this.groups.find(g => g.id === event.target.closest("[data-workspace-pane]")?.dataset.workspacePane);
            if (group) this.activate(group);
        });
        root.addEventListener("keydown", event => {
            const control = event.target.closest('[role="tab"][data-tab-id]');
            if (!control || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
            event.preventDefault();
            const group = this.groups.find(g => g.id === control.closest("[data-workspace-pane]").dataset.workspacePane);
            const index = group.tabs.findIndex(t => t.id === control.dataset.tabId);
            const next = event.key === "Home" ? 0 : event.key === "End" ? group.tabs.length - 1
                : (index + (event.key === "ArrowLeft" ? -1 : 1) + group.tabs.length) % group.tabs.length;
            void this.perform(async () => {
                this.activate(group, group.tabs[next].id); await this.redraw();
                this.element.querySelector(`#${group.activeId}-label`)?.focus();
            });
        });
        root.addEventListener("contextmenu", event => {
            const header = event.target.closest("[data-entity-tab]");
            if (!header) return;
            event.preventDefault(); event.stopPropagation();
            const tab = this.groups.flatMap(g => g.tabs).find(t => t.id === header.dataset.entityTab);
            this.tabMenu(tab, header);
        });
        root.addEventListener("dragstart", event => {
            const header = event.target.closest("[data-entity-tab]");
            if (!header) return;
            const tab = this.groups.flatMap(group => group.tabs).find(tab => tab.id === header.dataset.entityTab);
            if (!tab) return;
            if (!tab.entityId) {
                event.dataTransfer.setData("application/x-nexus-workspace-tab", tab.id);
                event.dataTransfer.effectAllowed = "move";
            } else if (!setWorkspaceEntityDrag(event.dataTransfer, WorkspaceEntities.get(tab.entityId, tab.entityType), tab.id)) event.preventDefault();
        });
        root.addEventListener("dragover", event => {
            const bar = event.target.closest(".nexus-workspace-entity-tabs");
            if (!bar || !["application/x-nexus-workspace-tab", "text/plain", "application/json"].some(type => event.dataTransfer.types.includes(type))) return;
            event.preventDefault(); event.stopPropagation();
            event.dataTransfer.dropEffect = event.dataTransfer.types.includes("application/x-nexus-workspace-tab") ? "move" : "copy";
            bar.classList.add("is-workspace-tab-drop");
        });
        root.addEventListener("dragleave", event => {
            const bar = event.target.closest(".nexus-workspace-entity-tabs");
            if (bar && !bar.contains(event.relatedTarget)) bar.classList.remove("is-workspace-tab-drop");
        });
        root.addEventListener("dragend", () => {
            root.querySelectorAll(".is-workspace-tab-drop").forEach(bar => bar.classList.remove("is-workspace-tab-drop"));
        });
        root.addEventListener("drop", event => {
            const id = event.dataTransfer.getData("application/x-nexus-workspace-tab");
            const bar = event.target.closest(".nexus-workspace-entity-tabs");
            if (!bar) return;
            event.preventDefault(); event.stopPropagation();
            bar.classList.remove("is-workspace-tab-drop");
            const group = this.groups.find(g => g.id === bar.closest("[data-workspace-pane]").dataset.workspacePane);
            const tab = this.groups.flatMap(g => g.tabs).find(t => t.id === id);
            if (tab) void this.perform(() => this.moveTab(tab, group, event.target.closest("[data-entity-tab]")?.dataset.entityTab));
            else {
                const node = workspaceDropTarget(event.dataTransfer);
                if (node) void this.perform(() => this.openObjectNode(node, { destination: group }));
            }
        });
        const divider = root.querySelector("[data-workspace-divider]");
        if (divider) {
            let dragging = false;
            const deck = root.querySelector(".nexus-workspace-deck");
            const resize = ratio => {
                this.#expandedSplit = null;
                this.#compactPane = null;
                this.#compactColumns = false;
                this.#sizedDeckWidth = undefined;
                const width = deck.clientWidth - DIVIDER_WIDTH;
                this.ratio = Math.max(MIN_PANE_WIDTH / width, Math.min(1 - MIN_PANE_WIDTH / width, ratio));
                deck.style.gridTemplateColumns = `${this.ratio}fr 6px ${1-this.ratio}fr`;
                divider.setAttribute("aria-valuenow", Math.round(this.ratio * 100));
            };
            divider.addEventListener("pointerdown", event => { if (event.button !== 0) return; dragging = true; divider.setPointerCapture(event.pointerId); event.preventDefault(); });
            divider.addEventListener("pointermove", event => { if (dragging) resize((event.clientX - deck.getBoundingClientRect().left) / deck.clientWidth); });
            const finish = () => { if (!dragging) return; dragging = false; this.updateLayout(true, undefined, true); };
            divider.addEventListener("pointerup", finish); divider.addEventListener("pointercancel", finish);
            divider.addEventListener("keydown", event => {
                if (!["ArrowLeft", "ArrowRight", "Home"].includes(event.key)) return;
                event.preventDefault(); resize(event.key === "Home" ? .5 : this.ratio + (event.key === "ArrowLeft" ? -.05 : .05)); this.updateLayout(true, undefined, true);
            });
        }
    }
    async _onRender(context, options) {
        await super._onRender?.(context, options);
        this.restoreBrowserSessionScroll?.();
        this.#updateFullscreenControl();
        this.element.classList.toggle("is-browser-collapsed", this.browserCollapsed);
        this.element.style?.setProperty("--nexus-workspace-browser-width", `${this.browserWidth}px`);
        if (options.parts?.length === 1 && options.parts[0] === "main") return;
        for (const group of this.groups) group.tabs.find(t => t.id === group.activeId).restoreView();
        this.#observer?.disconnect();
        const deck = this.element.querySelector(".nexus-workspace-deck");
        if (deck) {
            // The previous DOM can still report the old width while the resized panes prepare.
            this.#sizedDeckWidth = undefined;
            let previousWidth = deck.clientWidth;
            this.#observer = new ResizeObserver(() => {
                if (this.#closed || deck.clientWidth === previousWidth) return;
                previousWidth = deck.clientWidth; this.updateLayout();
            });
            this.#observer.observe(deck);
        }
    }
    _onFirstRender(context, options) {
        super._onFirstRender(context, options);
        bindNexusDragOrigin(this.element, "workspace");
        // ApplicationV2 setPosition requires an existing frame in both V13 and V14.
        if (this.#sessionPosition) {
            this.#positioning = true;
            try { applySessionWindowPlacement(this, "nexus-workspace-session", { position: this.#sessionPosition, fallback: "default" }); }
            finally { this.#positioning = false; }
            this.#sessionPosition = null;
            this.narrow = this.groups.length > 1 && this.deckWidth < MIN_PANE_WIDTH * 2 + DIVIDER_WIDTH;
            // Keep explicit density choices until their pane's width actually changes.
            for (const group of this.groups) for (const tab of group.tabs) this.#densityOverrides.set(tab, this.paneWidth(group));
        }
        window.addEventListener("resize", this.#viewportResize);
        for (const name of ["updateJournalEntryPage", "deleteJournalEntryPage", "updateJournalEntry", "deleteJournalEntry",
            "augurNexusCampaignEntityVisibilityChanged", "augurNexusCampaignEntityDisclosureChanged", "augurNexusCampaignEntitiesChanged", "updateUser", "updateSetting", "augurNexusConnectionsChanged",
            "updateScene", "deleteScene", "augurNexusLineageChanged", "augurNexusPlayerSceneAccessChanged", "augurNexusQuestsChanged"]) {
            this.#hooks.push([name, Hooks.on(name, () => { void this.render(); })]);
        }
    }
    async close(options) {
        if (this.#closed) return this;
        const session = this.snapshotSession();
        this.#closed = true;
        window.removeEventListener("resize", this.#viewportResize);
        this.#observer?.disconnect();
        await Promise.all(this.groups.flatMap(g => g.tabs).map(tab => tab.destroy()));
        for (const [name, id] of this.#hooks) Hooks.off(name, id);
        this.#hooks = [];
        const result = await super.close(options);
        // Foundry restores the pre-minimized dimensions during close.
        session.position = { ...this.position };
        CampaignWorkspace.#sessions.set(game.user.id, session);
        CampaignWorkspace.#instance = null;
        ToolWindowLifecycle.released(this);
        return result;
    }
    _prepareBrowserEntryMenuItems(button, items) {
        const row = button.closest(".nexus-browser-pill-shell, [data-node-id]");
        const data = { ...row?.dataset, ...button.dataset };
        let type = data.entityType || ({ toggleNpcOptions: "npc", toggleFactionOptions: "faction",
            toggleShipOptions: "ship", toggleLocationOptions: "location", questListquestOptions: "quest" })[data.action];
        let id = data.entityId || (type === "quest" ? data.id : "");
        if (!["npc", "faction", "location", "ship", "quest"].includes(type)) {
            const place = WorkspacePlaces.fromBrowser(data);
            if (!place) return items;
            type = "place"; id = place.id;
        }
        if (!id || !WorkspaceEntities.canView(WorkspaceEntities.get(id, type))) return items;
        const navigation = [
            { id: "workspace", label: "Open in Workspace", icon: "fas fa-address-card", onSelect: () => this.perform(() => this.selectEntity(id, { type, target: "current" })) },
            { id: "new-tab", label: "Open in New Tab", icon: "fas fa-plus", onSelect: () => this.perform(() => this.openEntity(id, { type, target: "new" })) },
            { id: "standalone", label: "Open Standalone Dossier", icon: "fas fa-up-right-from-square", onSelect: () => this.perform(() => WorkspaceEntities.open(WorkspaceEntities.get(id, type))) }
        ];
        return [...navigation, ...(items.length ? [{ type: "separator" }, ...items] : [])];
    }

    attachBrowserHostPolicy(root) {
        // Workspace dossiers provide connections; the browser stays focused on navigation.
        root.querySelectorAll(".nexus-browser-connection-toggle, .nexus-browser-connection-drawer").forEach(element => element.remove());
        root.addEventListener("drop", event => {
            if (game.user.isGM) return;
            event.preventDefault(); event.stopImmediatePropagation();
        }, true);
        // Capture before shared browser listeners, so no legacy open action can also run.
        const route = event => {
            if (event.type === "keydown" && !["Enter", " "].includes(event.key)) return;
            if (event.target.closest("input, textarea, select")) return;
            const control = event.target.closest("[data-action]");
            const row = event.target.closest(".nexus-browser-pill-shell, [data-node-id]");
            if (!control && !row) return;
            const action = control?.dataset.action || "";
            const policy = control ? workspaceBrowserAction(action, control.dataset.intent) : "select";
            if (action === "workspaceWorldGraph") { event.preventDefault(); event.stopImmediatePropagation(); return void this.perform(() => this.openWorldGraph()); }
            if (policy === "browse") return;
            event.preventDefault(); event.stopImmediatePropagation();
            if (policy === "create") return void this.perform(() => this.handleAction("workspaceNew", control));
            if (policy === "generate") return void this.perform(() => this.handleAction("workspaceGenerate", control));
            const data = control?.dataset || row?.dataset || {};
            const type = data.entityType || row?.dataset.entityType || ((data.nodeKind || row?.dataset.nodeKind) === "location" ? "location" : "") || ({
                openNpcDossier: "npc", toggleNpcOptions: "npc", openFactionDossier: "faction", toggleFactionOptions: "faction",
                openShipDossier: "ship", toggleShipOptions: "ship", openLocation: "location", toggleLocationOptions: "location"
            })[action];
            const id = data.entityId || row?.dataset.entityId;
            if (policy === "select") {
                if (action === "questListopen") return void this.perform(() => this.selectEntity(data.id, { type: "quest", target: event.ctrlKey || event.metaKey ? "new" : "current" }));
                const place = WorkspacePlaces.fromBrowser({ ...row?.dataset, ...data });
                if (place && !["npc", "faction", "ship", "location"].includes(type))
                    return void this.perform(() => this.selectEntity(place.id, { type: "place", target: event.ctrlKey || event.metaKey ? "new" : "current" }));
                if (action === "playerDirectoryAction") {
                    const doc = foundry.utils.fromUuidSync(data.uuid);
                    const entity = doc?.getFlag?.("augur-nexus", "campaignEntity");
                    if (entity) return void this.perform(() => this.selectEntity(entity.id, { type: entity.type, target: event.ctrlKey || event.metaKey ? "new" : "current" }));
                }
                if (id && ["npc", "faction", "ship", "location", "quest"].includes(type))
                    return void this.perform(() => this.selectEntity(id, { type, target: event.ctrlKey || event.metaKey ? "new" : "current" }));
            }
            this.#unsupported();
        };
        root.addEventListener("click", route, true);
        root.addEventListener("keydown", route, true);
        root.querySelectorAll(".nexus-browser-pill-shell[data-entity-type]").forEach(row => {
            if (row.dataset.nodeKind === "scene" || row.dataset.nodeKind === "pending-site") {
                const place = WorkspacePlaces.fromBrowser(row.dataset);
                row.tabIndex = 0; row.setAttribute("role", "button");
                row.classList.toggle("is-workspace-selected", !!place && this.entityType === "place" && place.id === this.entityId);
                row.setAttribute("aria-label", `Open ${row.dataset.name} in workspace`);
                return;
            }
            if (!["npc", "faction", "location", "ship"].includes(row.dataset.entityType)) return;
            row.tabIndex = 0; row.setAttribute("role", "button");
            row.classList.toggle("is-workspace-selected", row.dataset.entityId === this.entityId && row.dataset.entityType === this.entityType);
            row.setAttribute("aria-label", `Open ${row.dataset.name} in workspace`);
        });
        root.querySelectorAll("[data-action]").forEach(control => {
            if (control.dataset.action === "workspaceWorldGraph" || workspaceBrowserAction(control.dataset.action, control.dataset.intent) !== "blocked") return;
            control.setAttribute("aria-disabled", "true");
            control.title = "Open the standalone tool for this action";
        });
    }


}
