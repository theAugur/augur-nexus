import { PlacePreview } from "../../connections/applications/PlacePreview.js";
import { JournalAssociationService } from "../../connections/services/JournalAssociationService.js";
import { OwnershipService } from "../../connections/services/OwnershipService.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { regionDossierNode } from "../../region-dossier/RegionDossierViewModel.js";
import { PlaceProfileRegistry } from "../../places/services/PlaceProfileRegistry.js";

// Host the existing dossier controller without creating a second Foundry window.
export class WorkspacePlaceView extends PlacePreview {
    #profilePanel = null;
    #profileSession = null;
    #disposed = false;
    constructor(tab, entry) {
        super({ scene: entry.scene, record: entry.record });
        this.tab = tab;
        this.entry = entry;
        this.objectNavigationItems = node => this.tab.host.objectNavigationItems(node, this.tab);
    }
    get connectionExplorerHost() { return this.tab.connectionExplorerHost; }
    get previewCompact() { return this.tab?.compact === true; }
    get hasDedicatedPlaceProfile() { return !!this.#profilePanel; }
    get ownsPlaceSurface() { return this.#profilePanel?.ownsSurface === true; }
    get navigationTheme() { return this.#profilePanel?.navigationTheme || null; }
    get element() { return this.tab?.element?.querySelector("[data-workspace-place]"); }
    render() { return this.tab?.redraw() || Promise.resolve(this); }
    async close() { /* Scene opening leaves the workspace available. */ }
    handlePlaceConverted() { return this.render(); } // The Workspace conversion hook owns tab disposal and permission checks.
    openConvertedLocation(entity) { return this.tab.entityType === "location" && this.tab.entityId === entity.id ? this.tab.redraw() : this.tab.selectEntity(entity.id, { type: "location", view: "profile" }); }
    snapshotView() { return { ...super.snapshotView(), profile: this.#profilePanel?.snapshot?.() || this.#profileSession }; }
    restoreView(state = {}) { super.restoreView(state); this.#profileSession = state.profile || null; }
    async dispose() {
        this.#disposed = true;
        await this.#profilePanel?.dispose();
        this.#profilePanel = null;
        return super.close();
    }
    async prepare() {
        if (!this.#profilePanel) {
            const panel = await PlaceProfileRegistry.createPanel({ scene: this.entry.scene, record: this.entry.record, target: this.entry.target,
                host: { refresh: () => this.#disposed ? Promise.resolve() : this.render(),
                    openNode: node => this.openConnectionNode(node), getNavigationItems: node => this.objectNavigationItems(node) } });
            if (this.#disposed) { await panel?.dispose(); return ""; }
            this.#profilePanel = panel;
            panel?.restore?.(this.#profileSession || {});
        }
        const model = await super._prepareContext();
        this.helpContext = { genericSite: model.genericSite === true && !model.unavailable };
        if (model.unavailable) {
            await foundry.applications.handlebars.loadTemplates(PlacePreview.PARTS.content.templates);
            return foundry.applications.handlebars.renderTemplate(PlacePreview.PARTS.content.template, model);
        }
        model.fullSurface = this.ownsPlaceSurface;
        if ((model.tabs.isProfile || model.fullSurface) && this.#profilePanel) model.profileHtml = await this.#profilePanel.prepare({ compact: this.previewCompact, controlsHtml: model.surfaceControlsHtml || "" });
        this.appearance = model.appearance || null;
        const page = await JournalAssociationService.getJournalPage(this.entry.target);
        if (!game.user.isGM && !page?.testUserPermission(game.user, "OBSERVER")) {
            model.journal = { hasPage: false, hasContent: false, content: "" };
        }
        await foundry.applications.handlebars.loadTemplates(PlacePreview.PARTS.content.templates);
        return foundry.applications.handlebars.renderTemplate(PlacePreview.PARTS.content.template, model);
    }
    activate(root) {
        this.activateContentListeners(root);
        const profileRoot = root?.querySelector?.("[data-place-profile]");
        if (!this.#profilePanel) return;
        if (!profileRoot) { this.#profilePanel.activate(null); return; }
        // Scope module actions to this panel so body Journal controls cannot hit the place Journal.
        for (const button of profileRoot.querySelectorAll("[data-action]")) {
            if (!this.#profilePanel.handlesAction(button.dataset.action)) continue;
            button.dataset.profileAction = button.dataset.action;
            button.dataset.action = "runPlaceProfileAction";
        }
        this.#profilePanel.activate(profileRoot);
    }
    openPreviewTarget(target) { return this.tab.followNode(target); }
    openConnectionNode(node) { return this.objectNavigationItems(node)[0]?.onSelect(); }
    // Application actions already own the workspace's busy guard.
    navigateRegionObject(node) { return this.tab.host.openObjectNode(node, { source: this.tab }); }
    toggleHostedRegionCompact() { return this.tab.host.handleAction("workspaceCompact", this.tab.element?.querySelector("[data-action='workspaceCompact']")); }
    resolveObjectTarget(element) {
        if (element?.dataset?.regionNode) return regionDossierNode(element.dataset.regionNode);
        const ownership = OwnershipService.getOwnership(this.entry.target);
        return ownership ? ConnectionStore.getNode(ownership.ownerNodeId) : null;
    }
    async handleAction(action, button) {
        if (action === "runPlaceProfileAction") return this.#profilePanel?.handleAction(button.dataset.profileAction, button);
        const handler = PlacePreview.DEFAULT_OPTIONS.actions[action];
        if (!handler || (!game.user.isGM && !["setPlaceTab", "togglePlaceCategory", "openPlaceScene", "openPlaceOwner"].includes(action))) return;
        return handler.call(this, null, button);
    }
}
