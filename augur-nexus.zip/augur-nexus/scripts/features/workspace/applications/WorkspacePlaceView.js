import { PlacePreview } from "../../connections/applications/PlacePreview.js";
import { JournalAssociationService } from "../../connections/services/JournalAssociationService.js";
import { OwnershipService } from "../../connections/services/OwnershipService.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";

// Host the existing dossier controller without creating a second Foundry window.
export class WorkspacePlaceView extends PlacePreview {
    constructor(tab, entry) {
        super({ scene: entry.scene, record: entry.record });
        this.tab = tab;
        this.entry = entry;
        this.objectNavigationItems = node => this.tab.host.objectNavigationItems(node, this.tab);
    }
    get previewCompact() { return this.tab?.compact === true; }
    get element() { return this.tab?.element?.querySelector("[data-workspace-place]"); }
    render() { return this.tab?.redraw() || Promise.resolve(this); }
    async close() { /* Scene opening leaves the workspace available. */ }
    dispose() { return super.close(); }
    async prepare() {
        const model = await super._prepareContext();
        const page = await JournalAssociationService.getJournalPage(this.entry.target);
        if (!game.user.isGM && !page?.testUserPermission(game.user, "OBSERVER")) {
            model.journal = { hasPage: false, hasContent: false, content: "" };
        }
        await foundry.applications.handlebars.loadTemplates(PlacePreview.PARTS.content.templates);
        return foundry.applications.handlebars.renderTemplate(PlacePreview.PARTS.content.template, model);
    }
    activate(root) { this.activateContentListeners(root); }
    openPreviewTarget(target) { return this.tab.followNode(target); }
    resolveObjectTarget() {
        const ownership = OwnershipService.getOwnership(this.entry.target);
        return ownership ? ConnectionStore.getNode(ownership.ownerNodeId) : null;
    }
    async handleAction(action, button) {
        const handler = PlacePreview.DEFAULT_OPTIONS.actions[action];
        if (!handler || (!game.user.isGM && !["setPlaceTab", "togglePlaceCategory", "openPlaceScene", "openPlaceOwner"].includes(action))) return;
        return handler.call(this, null, button);
    }
}
