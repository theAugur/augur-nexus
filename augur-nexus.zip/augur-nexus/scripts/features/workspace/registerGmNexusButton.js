import { GmNexusButton } from "./applications/GmNexusButton.js";

const MODULE_ID = "augur-nexus";

export function registerGmNexusButton() {
    let button, workspace, ready = false;
    let sceneReady = true, controlsReady = true;
    let updates = Promise.resolve();
    const enabled = () => game.user?.isGM && game.settings.get(MODULE_ID, "gmNexusButtonEnabled");
    const refresh = () => {
        // Hide synchronously; teardown may wait behind an in-flight ApplicationV2 render.
        if (!enabled()) button?.hideImmediately();
        updates = updates.then(async () => {
            if (!ready) return;
            if (!enabled()) {
                await button?.close(); button = null;
                return;
            }
            button ??= new GmNexusButton();
            button.transitioning = !(sceneReady && controlsReady);
            button.syncWorkspace(workspace);
            if (!button.rendered) await button.render({ force: true });
            if (!enabled()) {
                await button.close(); button = null;
            } else if (button.element) button.element.style.visibility = "";
        }).catch(error => ui.notifications.error(error.message || "Nexus Wheel could not be updated."));
        return updates;
    };
    game.settings.register(MODULE_ID, "gmNexusButtonEnabled", {
        name: "Nexus Wheel", hint: "Show a movable Nexus Wheel with Nexus Workspace and available scene tools on this GM client.",
        scope: "client", config: false, type: Boolean, default: true,
        onChange: () => { void refresh(); Hooks.callAll("augurNexusAppearanceChanged"); }
    });
    game.settings.register(MODULE_ID, "gmNexusButtonPosition", { scope: "client", config: false, type: Object, default: {} });
    Hooks.on("renderCampaignWorkspace", app => { workspace = app; button?.syncWorkspace(app); });
    Hooks.on("closeCampaignWorkspace", app => { if (workspace === app) { workspace = null; button?.syncWorkspace(null); } });
    const refreshTools = () => {
        if (!button) return;
        button.transitioning = !(sceneReady && controlsReady);
        void button.refreshTools();
    };
    Hooks.on("renderSceneControls", () => { controlsReady = true; refreshTools(); });
    Hooks.on("activateSceneControls", refreshTools);
    Hooks.on("canvasTearDown", () => {
        sceneReady = controlsReady = false;
        if (!button) return;
        void button.suspendTools();
    });
    Hooks.on("canvasReady", () => { sceneReady = true; refreshTools(); });
    Hooks.once("ready", () => { ready = true; void refresh(); });
}
