const MODULE_ID = "augur-nexus";

export function isPlayerWorkspaceAllowed() {
    return game.settings.get(MODULE_ID, "allowPlayerWorkspace") !== false;
}

export function canUseWorkspace() {
    return !!game.user.isGM || isPlayerWorkspaceAllowed();
}

export function requireWorkspaceAccess() {
    if (!canUseWorkspace()) throw new Error("Player Campaign Nexus access is disabled by the GM.");
}

export async function setPlayerWorkspaceAllowed(allowed) {
    if (!game.user.isGM) throw new Error("Only the GM can change Player Campaign Nexus access.");
    await game.settings.set(MODULE_ID, "allowPlayerWorkspace", !!allowed);
}
