import { getNpc, openNpcDossier } from "../../../api/npcs.js";
import { getFaction, openFactionDossier } from "../../../api/factions.js";
import { getShip, openShipDossier } from "../../../api/ships.js";
import { getLocation, openLocation, canUserViewLocationDetails } from "../../../api/locations.js";
import { CampaignEntityVisibilityManager } from "../../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { CampaignEntityJournalStore } from "../../campaign-entities/services/CampaignEntityJournalStore.js";
import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { NpcDataEditor } from "../../campaign-entities/applications/NpcDataEditor.js";
import { FactionDataEditor } from "../../campaign-entities/applications/FactionDataEditor.js";
import { ShipDataEditor } from "../../campaign-entities/applications/ShipDataEditor.js";
import { LocationDataEditor } from "../../campaign-entities/applications/LocationDataEditor.js";
import { WorkspacePlaces } from "./WorkspacePlaces.js";
import { WorkspaceQuests } from "./WorkspaceQuests.js";
import { createQuest, openQuest } from "../../../api/quests.js";
import { CampaignEntityCreation } from "../../campaign-entities/services/CampaignEntityCreation.js";
import { requestPremiumAccess } from "../../access/PremiumAccess.js";

// Host capabilities only; the existing entity stores remain authoritative.
const TYPES = {
    npc: { label: "Person", icon: "fas fa-user", get: getNpc, open: openNpcDossier, editor: NpcDataEditor },
    faction: { label: "Organization", icon: "fas fa-shield-halved", get: getFaction, open: openFactionDossier, editor: FactionDataEditor },
    location: { label: "Location", icon: "fas fa-map-location-dot", get: getLocation, open: openLocation, editor: LocationDataEditor },
    quest: { label: "Quest", icon: "fas fa-scroll", get: id => WorkspaceQuests.get(id), open: openQuest },
    ship: { label: "Ship", icon: "fas fa-rocket", get: getShip, open: openShipDossier, editor: ShipDataEditor }
};

export class WorkspaceEntities {
    static types() { return Object.entries(TYPES).map(([type, { label, icon }]) => ({ type, label, icon })); }
    static get(id, type) { return type === "place" ? WorkspacePlaces.get(id) : TYPES[type]?.get(id) || null; }
    static canView(entity) {
        if (entity?.type === "place") return WorkspacePlaces.canView(entity);
        if (entity?.type === "quest") return WorkspaceQuests.canView(entity);
        return !!TYPES[entity?.type] && CampaignEntityVisibilityManager.canUserSee(entity)
            && (entity.type !== "location" || canUserViewLocationDetails(entity));
    }
    static describe(type) { return type === "place" ? { label: "Site", icon: "fas fa-map-location-dot" } : TYPES[type] || TYPES.npc; }
    static document(entity) {
        return entity.type === "location" ? LocationEntityStore.resolveDocument(entity.id)
            : CampaignEntityJournalStore.resolveCampaignEntityDocument(entity.id);
    }
    static journal(entity) {
        return entity.type === "location" ? LocationEntityStore.getJournalPage(entity.id)
            : CampaignEntityJournalStore.getJournalPage(entity.id);
    }
    static async open(entity) {
        if (!this.canView(entity)) return;
        if (entity.type === "place") {
            const { PlacePreview } = await import("../../connections/applications/PlacePreview.js");
            return PlacePreview.show({ scene: entity.scene, record: entity.record });
        }
        return TYPES[entity.type].open(entity.id);
    }
    static async editJournal(entity) {
        if (!game.user.isGM || !this.canView(entity)) return;
        const store = entity.type === "location" ? LocationEntityStore : CampaignEntityJournalStore;
        const page = await store.getOrCreateJournalPage(entity.id);
        if (!page?.parent) throw new Error("The journal for this entry is unavailable.");
        return page.sheet?.render(true);
    }
    static edit(entity, onSave) {
        if (!game.user.isGM || !this.canView(entity)) return;
        return TYPES[entity.type].editor.show({ [`${entity.type}Id`]: entity.id, onSave });
    }
    static async create(type, { folderId = "" } = {}) {
        if (!game.user.isGM) throw new Error("Only a GM can create campaign entries.");
        if (!await requestPremiumAccess(type)) return null;
        if (type === "quest") {
            const quest = await createQuest({ folderId, audience: "private", objectives: [{ intent: "find" }] });
            return this.get(quest.id, "quest");
        }
        return CampaignEntityCreation.create(type);
    }
    static async setVisibility(entity, visible) {
        if (!game.user.isGM) throw new Error("Only a GM can change visibility.");
        const document = this.document(entity);
        if (!document) throw new Error("This entry is no longer available.");
        await document.update({
            "flags.augur-nexus.campaignEntity.access.playerVisibility": visible ? "show" : "hide",
            "ownership.default": visible ? CONST.DOCUMENT_OWNERSHIP_LEVELS.OBSERVER : CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE
        });
        const updated = this.get(entity.id, entity.type);
        Hooks.callAll("augurNexusCampaignEntityVisibilityChanged", { entityType: entity.type, entity: updated });
        Hooks.callAll("augurNexusCampaignEntitiesChanged", { reason: "workspaceVisibility", entity: updated, document });
        return updated;
    }
}
