import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { WorkspaceEntities } from "./WorkspaceEntities.js";

export function setWorkspaceEntityDrag(dataTransfer, entity, tabId = "") {
    if (!WorkspaceEntities.canView(entity)) return false;
    const target = entity.type === "place" ? entity.target : ConnectionTargetResolver.fromCampaignEntity(entity);
    if (!ConnectionTargetResolver.setDragData(dataTransfer, target, { effectAllowed: "all" })) return false;
    // Tab bars consume only this extra identity; all other destinations receive an ordinary entity.
    if (tabId) dataTransfer.setData("application/x-nexus-workspace-tab", tabId);
    return true;
}

export const workspaceDragSources = "[data-npc-life-node], [data-faction-domain-node], [data-ship-domain-node], [data-workspace-portrait], [data-workspace-connection], [data-npc-dossier-drag], [data-authority-entity-id], [data-settlement-person-card], [data-card-kind='location'], [data-organization-id], [data-graph-center], [data-connection-node-id], [data-quest-id], [data-quest-entity-drag], [data-action='openChronicleParticipant'], [data-action='openPlaceOwner']";

export function workspaceDragTarget(data, entity) {
    const nodeId = data.npcLifeNode || data.factionDomainNode || data.shipDomainNode || data.workspaceConnection || data.connectionNodeId;
    const entityId = data.authorityEntityId || data.personId || data.organizationId || data.questId
        || (data.action === "openChronicleParticipant" ? data.entityId : "") || (data.cardKind === "location" ? data.cardId : "");
    const self = ["workspacePortrait", "npcDossierDrag", "graphCenter"].some(key => Object.hasOwn(data, key));
    const target = nodeId ? ConnectionStore.getNode(nodeId)
        : entityId ? ConnectionTargetResolver.fromEntityReference({ entityId })
        : self && entity && WorkspaceEntities.canView(entity) ? (entity.type === "place" ? entity.target : ConnectionTargetResolver.fromCampaignEntity(entity)) : null;
    return target && !target.missing && ConnectionTargetResolver.canUserSeeNode(target) ? target : null;
}

export function workspaceObjectEntity(node) {
    if (!node || node.missing || !ConnectionTargetResolver.canUserSeeNode(node)) return null;
    const type = ["nexus-site", "nexus-scene"].includes(node.kind) ? "place"
        : node.kind === "nexus-entity" ? node.entityType : "";
    if (!["npc", "faction", "location", "ship", "quest", "place"].includes(type)) return null;
    const entity = WorkspaceEntities.get(type === "place" ? node.id : node.entityId, type);
    return WorkspaceEntities.canView(entity) ? entity : null;
}

export function workspaceDropTarget(dataTransfer) {
    try {
        const data = JSON.parse(dataTransfer?.getData("text/plain") || dataTransfer?.getData("application/json") || "null");
        if (!data || !(["nexus-site", "nexus-scene", "nexus-entity"].includes(data.kind)
            || ["AugurNexusSite", "AugurNexusNode", "AugurNexusEntity"].includes(data.type))) return null;
        // Opening a tab must never import an Actor or create a relationship.
        return ConnectionTargetResolver.fromNodePayload(data);
    } catch { return null; }
}

export function bindWorkspaceEntityDrags(root, tab) {
    const portrait = root.querySelector(".npc-dossier-header .npc-dossier-portrait, .site-preview-header .site-preview-icon");
    if (portrait) portrait.dataset.workspacePortrait = "";
    for (const element of root.querySelectorAll(workspaceDragSources)) {
        const target = () => {
            const node = tab.resolveObjectTarget ? tab.resolveObjectTarget(element)
                : workspaceDragTarget(element.dataset, WorkspaceEntities.get(tab.entityId, tab.entityType));
            return node && !node.missing && ConnectionTargetResolver.canUserSeeNode(node) ? node : null;
        };
        element.draggable = !!target();
        element.querySelectorAll("img").forEach(image => { image.draggable = false; });
        element.addEventListener("dragstart", event => {
            event.stopPropagation();
            if (!ConnectionTargetResolver.setDragData(event.dataTransfer, target(), { effectAllowed: "all" })) event.preventDefault();
        });
    }
}
