// The workspace shares the browser's discovery controls, but owns document opening.
const BROWSE_ACTIONS = new Set([
    "createNpc", "createFaction", "createShip", "createLocation", "generateEntity",
    "setNexusTab", "toggleNexusAppearance", "toggleGmNexusButton", "togglePlayerWheelSystem", "setNexusAccent", "setNexusTextSize", "toggleRootSceneMenu",
    "toggleSceneTransitions", "toggleSceneIcons", "toggleHiddenSites", "clearSceneSearch", "clearPeopleSearch",
    "clearFactionSearch", "clearShipSearch", "collapseAllScenes", "toggleLineageBranch",
    "toggleSiteFactionGroup", "togglePeopleFactionGroup",
    "toggleShipFactionGroup", "toggleFactionBranch", "togglePeopleSceneFilter",
    "toggleFactionSceneFilter", "toggleShipSceneFilter", "togglePeopleFactionGrouping",
    "toggleShipFactionGrouping", "toggleSiteFactionGrouping", "toggleSiteBranchFocus",
    "toggleAllPeopleFactionGroups", "toggleAllShipFactionGroups", "questFilter",
    "questCollapseAll", "questListtoggleFolder", "questListaudience", "questListquestOptions", "questListfolderMenu", "questCreateFolder"
]);

export function workspaceBrowserAction(action, intent = "") {
    if (["openLineageScene", "toggleSceneOptions", "toggleNpcOptions", "toggleFactionOptions", "toggleShipOptions", "toggleLocationOptions", "toggleShopOptions"].includes(action)) return "browse";
    if (BROWSE_ACTIONS.has(action) || (action === "playerDirectoryAction" && ["filter", "options"].includes(intent))) return "browse";
    if (["workspaceNew", "questCreate"].includes(action)) return "create";
    if (action === "workspaceGenerate") return "generate";
    if (["questListopen", "openNpcDossier", "openFactionDossier", "openShipDossier", "openLocation"].includes(action)
        || (action === "playerDirectoryAction" && intent === "open")) return "select";
    return "blocked";
}

export function canSelectWorkspaceNode(node) {
    return node?.kind === "nexus-entity" && ["npc", "faction", "location", "ship", "quest"].includes(node.entityType) && !!node.entityId && !node.missing;
}
