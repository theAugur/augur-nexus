import { openActionMenu } from "../../../api/ui.js";
import { workspaceDragSources, workspaceObjectEntity } from "./WorkspaceEntityDrag.js";

const objectOpenActions = new Set([
    "workspaceFollow", "openEntity", "openPlaceOwner", "openChronicleParticipant", "regionDossierObject",
    "openSettlementOwner", "openSettlementLeader", "openSettlementPerson", "openSettlementParent", "openSettlementSite"
]);

// Only object references participate; field menus and embedded editors keep their own controls.
export function bindWorkspaceObjectNavigation(root, tab) {
    const open = event => {
        if (event.defaultPrevented) return;
        if (event.target.closest("input, textarea, select, [contenteditable='true'], [data-entity-disclosure-section]")) return;
        const anchor = event.target.closest(workspaceDragSources);
        if (!anchor || !root.contains(anchor)) return;
        const action = event.target.closest("[data-action]")?.dataset.action;
        if (action && !objectOpenActions.has(action)) return;
        const node = tab.resolveObjectTarget(anchor);
        if (!workspaceObjectEntity(node)) return;
        event.preventDefault(); event.stopPropagation();
        openActionMenu({ anchor, items: tab.host.objectNavigationItems(node, tab) });
    };
    root.addEventListener("contextmenu", open);
    root.addEventListener("keydown", event => {
        if (event.key === "ContextMenu" || (event.shiftKey && event.key === "F10")) open(event);
    });
}
