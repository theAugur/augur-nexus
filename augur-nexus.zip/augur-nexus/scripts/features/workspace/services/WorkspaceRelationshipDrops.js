import { ConnectionsBoard } from "../../connections/components/ConnectionsBoard.js";
import { ConnectionDropResolver } from "../../connections/services/ConnectionDropResolver.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { FactionMembershipService } from "../../connections/services/FactionMembershipService.js";
import { FactionSeatService } from "../../connections/services/FactionSeatService.js";
import { FactionHierarchyService } from "../../connections/services/FactionHierarchyService.js";
import { OwnershipService } from "../../connections/services/OwnershipService.js";
import { ShipOwnershipService } from "../../connections/services/ShipOwnershipService.js";
import { ShipCaptainService } from "../../connections/services/ShipCaptainService.js";
import { ShipCrewService } from "../../connections/services/ShipCrewService.js";
import { ShipLocationService } from "../../connections/services/ShipLocationService.js";
import { LocationLeadershipService } from "../../connections/services/LocationLeadershipService.js";
import { TradeRouteService } from "../../trade/services/TradeRouteService.js";
import { updateNpc } from "../../../api/npcs.js";
import { CampaignEntityCreation } from "../../campaign-entities/services/CampaignEntityCreation.js";
import { WorkspaceEntities } from "./WorkspaceEntities.js";

const surfaces = "[data-settlement-authority-drop], [data-settlement-people-drop], [data-settlement-trade-drop], [data-faction-domain-drop], [data-ship-domain-drop], [data-npc-featured-drop], [data-connections-drop-surface], [data-workspace-drop]";
const isEntity = (node, ...types) => node?.kind === "nexus-entity" && types.includes(node.entityType);
const isPlace = node => ["nexus-site", "nexus-scene"].includes(node?.kind) || isEntity(node, "location");

// The workspace supplies drop targets; the existing relationship services remain authoritative.
export class WorkspaceRelationshipDrops {
    static bind(root, tab) {
        if (!game.user.isGM) return;
        if (["profile", "connections"].includes(tab.view)) {
            const content = root.querySelector("[data-workspace-scroll]");
            if (content) content.dataset.workspaceDrop = "";
        }
        root.querySelectorAll(".nexus-workspace-reading, .nexus-workspace-entity-reading, .nexus-workspace-graph, .nexus-workspace-scroll > .npc-dossier-section")
            .forEach(element => { element.dataset.workspaceDrop = ""; });
        root.querySelectorAll(".faction-parent-row[data-faction-domain-node]").forEach(element => { element.dataset.factionDomainDrop = "parent"; });
        root.querySelectorAll(".faction-suborganizations").forEach(element => { element.dataset.factionDomainDrop = "suborganization"; });
        const surfaceFor = event => event.target.closest?.(surfaces);
        root.addEventListener("dragover", event => {
            const surface = surfaceFor(event);
            if (!surface || !game.user.isGM) return;
            event.preventDefault(); event.stopPropagation();
            event.dataTransfer.dropEffect = "copy";
            root.querySelectorAll(".is-workspace-drop-target").forEach(el => el.classList.remove("is-workspace-drop-target"));
            surface.classList.add("is-workspace-drop-target");
        });
        root.addEventListener("dragleave", event => {
            const surface = surfaceFor(event);
            if (surface && !surface.contains(event.relatedTarget)) surface.classList.remove("is-workspace-drop-target");
        });
        root.addEventListener("drop", event => {
            const surface = surfaceFor(event);
            if (!surface) return;
            event.preventDefault(); event.stopPropagation();
            root.querySelectorAll(".is-workspace-drop-target").forEach(el => el.classList.remove("is-workspace-drop-target"));
            // Capture the destination now; a dialog or a later pane selection must not retarget the drop.
            const entity = WorkspaceEntities.get(tab.entityId, tab.entityType);
            void tab.perform(async () => {
                await this.apply(event, entity, surface.dataset, { categoryId: event.target.closest?.("[data-workspace-category]")?.dataset.workspaceCategory || "" });
                await tab.redraw();
            });
        });
    }

    static async apply(event, entity, data = {}, { categoryId = "" } = {}) {
        if (!game.user.isGM || !entity || !WorkspaceEntities.canView(entity)) return;
        const target = ConnectionTargetResolver.fromCampaignEntity(entity);
        const board = new ConnectionsBoard({ target, readOnly: false });
        if (entity.type === "npc" && Object.hasOwn(data, "npcFeaturedDrop")) {
            const edge = await board.connectFromDrop(event);
            if (edge?.id) await updateNpc(entity.id, { dossier: { featuredConnectionId: edge.id } });
            return;
        }
        if (entity.type === "location" && Object.hasOwn(data, "settlementPeopleDrop")) {
            return board.connectFromDrop(event, { categoryId: "npc", actorDropOptions: { allowedEntityTypes: ["npc"], defaultEntityType: "npc" } });
        }
        const domain = entity.type === "faction" ? data.factionDomainDrop : entity.type === "ship" ? data.shipDomainDrop : data.settlementAuthorityDrop;
        const trade = entity.type === "location" && Object.hasOwn(data, "settlementTradeDrop");
        if (!domain && !trade) return board.connectFromDrop(event, { categoryId });
        let options = { convertActors: false };
        if (["member", "leader", "captain", "crew"].includes(domain)) options = { allowedEntityTypes: ["npc"], defaultEntityType: "npc" };
        else if (domain === "owner") options = { allowedEntityTypes: entity.type === "ship" ? ["npc", "faction"] : ["faction"], defaultEntityType: "faction" };
        else if (domain === "holding") options = { allowedEntityTypes: ["ship"], defaultEntityType: "ship" };
        else if (domain === "ties") options = { allowedEntityTypes: ["npc", "faction", "ship"], defaultEntityType: "npc", allowActorOnly: true };
        const related = await ConnectionDropResolver.fromEvent(event, options);
        if (!related) return;
        if (related.id === target.id) throw new Error("An entity cannot be connected to itself.");
        if (trade) {
            if (!isEntity(related, "location")) throw new Error("Drop a Nexus Location here.");
            return TradeRouteService.changeTradingCenter({ locationId: entity.id, centerLocationId: related.entityId });
        }
        if (entity.type === "location") {
            if (domain === "owner") {
                if (!isEntity(related, "faction")) throw new Error("Drop a Nexus Faction here.");
                return this.assignHolding(target, related);
            }
            if (domain === "leader") {
                if (!isEntity(related, "npc")) throw new Error("Drop a Nexus Person here.");
                return LocationLeadershipService.setLeader(target, related);
            }
        }
        if (entity.type === "faction") {
            if (["parent", "suborganization"].includes(domain)) return FactionHierarchyService.setParent(domain === "parent" ? target : related, domain === "parent" ? related : target);
            if (["member", "leader"].includes(domain)) {
                if (!isEntity(related, "npc")) throw new Error("Only a Nexus Person can join or lead an Organization.");
                if (domain === "leader") return FactionMembershipService.setLeader(target, related);
                return FactionMembershipService.setMember(target, related, { role: this.memberRole(entity) });
            }
            if (domain === "seat") {
                if (!isPlace(related)) throw new Error("Only a Nexus Place can become a seat of power.");
                return FactionSeatService.setSeat(target, related);
            }
            if (domain === "holding") {
                if (!isPlace(related) && !isEntity(related, "ship")) throw new Error("Only a Nexus Place or Ship can become a faction holding.");
                return this.assignHolding(related, target);
            }
        }
        if (entity.type === "ship") {
            if (["captain", "crew"].includes(domain)) {
                if (!isEntity(related, "npc")) throw new Error("Only a Nexus Person can serve aboard a Ship.");
                return domain === "captain" ? ShipCaptainService.setCaptain(target, related) : ShipCrewService.addCrew(target, related);
            }
            if (domain === "owner") {
                if (!isEntity(related, "npc", "faction")) throw new Error("A Ship owner must be a Person or Organization.");
                return ShipOwnershipService.setOwner(target, related);
            }
            if (domain === "location") {
                if (!isPlace(related)) throw new Error("Current Location requires a Nexus Place.");
                return ShipLocationService.setCurrentLocation(target, related, { source: "manual" });
            }
            if (domain === "ties") return ConnectionStore.addConnection(target, related);
        }
    }

    static memberRole(faction) {
        const moduleData = faction?.moduleData?.[faction.sourceModule] || faction?.moduleData?.["augur-scifi"] || {};
        const roles = (Array.isArray(moduleData.membershipRoles) ? moduleData.membershipRoles : []).map(role => String(role || "").trim()).filter(Boolean);
        return roles.length ? roles[Math.floor(Math.random() * roles.length)] : String(moduleData.defaultMembershipRole || "").trim() || "Member";
    }

    // New and Generate both go through the shared creation menu; only the relationship differs.
    static createPerson(entity, anchor, kind, onDone) {
        if (!game.user.isGM || !entity) return;
        const label = { member: "Member", leader: "Leader", crew: "Crew Member", resident: "Resident" }[kind];
        const affiliation = entity.type === "faction"
            ? { generationContext: { affiliation: { entityType: "faction", entityId: entity.id, ideology: foundry.utils.deepClone(entity.ideology || {}) } } }
            : {};
        return CampaignEntityCreation.menu("npc", anchor, {
            ...affiliation,
            generateFirst: true,
            openAfterCreate: false,
            onCreated: async npc => {
                const target = ConnectionTargetResolver.fromCampaignEntity(entity);
                const person = ConnectionTargetResolver.fromCampaignEntity(npc);
                if (!target || !person) return;
                if (kind === "leader") await FactionMembershipService.setLeader(target, person);
                else if (kind === "member") await FactionMembershipService.setMember(target, person, { role: this.memberRole(entity) });
                else if (kind === "crew") await ShipCrewService.addCrew(target, person);
                else await ConnectionStore.addConnection(target, person, {
                    sourceView: { category: "npc", role: "Resident" },
                    targetView: { category: "place", role: "Located At" }
                });
                await onDone?.();
            }
        }, label);
    }

    static async assignHolding(asset, owner) {
        const service = isEntity(asset, "ship") ? ShipOwnershipService : OwnershipService;
        const current = service === ShipOwnershipService ? service.getOwner(asset, { includeHidden: true }) : service.getOwnership(asset, { includeHidden: true });
        if (current && current.ownerNodeId !== owner.id) {
            const escape = foundry.utils.escapeHTML;
            const confirmed = await foundry.applications.api.DialogV2.confirm({
                window: { title: "Transfer Ownership" },
                content: `<p><strong>${escape(asset.name || "This holding")}</strong> is currently owned by <strong>${escape(current.owner?.name || "another owner")}</strong>.</p><p>Transfer it to <strong>${escape(owner.name || "this Organization")}</strong>?</p>`
            });
            if (!confirmed) return;
        }
        return service.setOwner(asset, owner);
    }
}
