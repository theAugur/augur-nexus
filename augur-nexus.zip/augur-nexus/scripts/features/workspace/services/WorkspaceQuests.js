import { QuestRecordStore } from "../../quests/storage/QuestRecordStore.js";
import { canReadQuest, projectQuest } from "../../quests/models/QuestModel.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";

// Only a disposable identity projection. The dossier loads its authorized content through getQuest.
export class WorkspaceQuests {
    static get(id) {
        const document = QuestRecordStore.document(id);
        const record = document && QuestRecordStore.read(document);
        if (!record || !canReadQuest(record, game.user)) return null;
        const view = projectQuest(record, game.user);
        const target = ConnectionTargetResolver.fromCampaignEntity({ ...view, type: "quest" }, document);
        return { ...view, type: "quest", target, display: { name: target.name, imageSrc: target.img } };
    }
    static canView(entity) {
        const record = QuestRecordStore.document(entity?.id)?.getFlag("augur-nexus", "campaignEntity");
        return !!record && canReadQuest(record, game.user);
    }
}
