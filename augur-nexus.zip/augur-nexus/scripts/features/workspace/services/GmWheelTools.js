import { ToolWindowLifecycle } from "../../../support/toolbar/ToolWindowLifecycle.js";
import { hasPremiumAccess } from "../../access/PremiumAccess.js";

const slots = ["nexus-sites", "nexus-back", "hexlands-mapper", "dungeon-mapper"];

// SceneControls has already applied every registered module's visibility contract.
export function gmWheelTools({ workspaceOpen = false, transitioning = false } = {}) {
    if (!game.user?.isGM) return [];
    const controls = ui.controls, augur = controls?.controls?.augurTools;
    const available = [{ name: "nexus-browser", title: "Campaign Nexus", icon: "fas fa-books", active: workspaceOpen }];
    const leftTools = Object.values(augur?.tools || {}).filter(tool => !slots.includes(tool.name) && tool.wheel?.side === "left");
    if (!transitioning && canvas.ready !== false && augur && augur.visible !== false) available.push(...[...slots, ...leftTools.map(tool => tool.name)].flatMap(name => {
        const tool = augur.tools?.[name];
        if (!tool || tool.visible === false) return [];
        return [{ name, title: game.i18n.localize(tool.title), icon: tool.icon, leftSide: tool.wheel?.side === "left",
            active: !tool.button && controls.control?.name === "augurTools" && (tool.toggle ? !!tool.active : controls.tool?.name === name) }];
    }));
    available.push({ name: "nexus-settings", title: "Nexus Settings", icon: "fas fa-cog", active: false });
    if (hasPremiumAccess()) available.push({ name: "player-identity", title: "Player Setup", icon: "fas fa-users-gear", active: false });
    const hasBack = available.some(tool => tool.name === "nexus-back");
    let clockwiseIndex = 0, leftIndex = hasBack ? 1 : 0;
    return available.map(tool => {
        // Left-side shortcuts never consume the other tools' packed clockwise slots.
        const degrees = tool.name === "nexus-back" ? -140
            : tool.leftSide ? -140 - leftIndex++ * 50
                : -90 + clockwiseIndex++ * 50;
        const angle = degrees * Math.PI / 180;
        return { ...tool, left: Math.round(10 + 60 * Math.cos(angle)), top: Math.round(10 + 60 * Math.sin(angle)) };
    });
}

export async function activateGmWheelTool(name, event) {
    if (!gmWheelTools().some(tool => tool.name === name && !["nexus-browser", "nexus-settings", "player-identity"].includes(name)) || !ToolWindowLifecycle.canSwitch(name)) return false;
    const tool = ui.controls.controls.augurTools.tools[name];
    // Foundry's button-tool path invokes onChange without selecting the button as a tool.
    if (tool.button) await tool.onChange?.(event ?? new Event("change"), true);
    else await ui.controls.activate({ control: "augurTools", tool: name });
    return true;
}
