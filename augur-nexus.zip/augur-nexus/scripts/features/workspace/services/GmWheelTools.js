import { ToolWindowLifecycle } from "../../../support/toolbar/ToolWindowLifecycle.js";

const slots = ["nexus-sites", "nexus-back", "hexlands-mapper", "dungeon-mapper"];

// SceneControls has already applied every registered module's visibility contract.
export function gmWheelTools({ workspaceOpen = false, transitioning = false } = {}) {
    if (!game.user?.isGM) return [];
    const controls = ui.controls, augur = controls?.controls?.augurTools;
    const available = [{ name: "nexus-browser", title: "Nexus Workspace", icon: "fas fa-books", active: workspaceOpen }];
    if (!transitioning && canvas.ready !== false && augur && augur.visible !== false) available.push(...slots.flatMap(name => {
        const tool = augur.tools?.[name];
        if (!tool || tool.visible === false) return [];
        return [{ name, title: game.i18n.localize(tool.title), icon: tool.icon,
            active: !tool.button && controls.control?.name === "augurTools" && (tool.toggle ? !!tool.active : controls.tool?.name === name) }];
    }));
    available.push({ name: "nexus-settings", title: "Nexus Settings", icon: "fas fa-cog", active: false });
    let clockwiseIndex = 0;
    return available.map(tool => {
        // Back has a fixed mirror of Placer's first slot; it never consumes a packed slot.
        const angle = (tool.name === "nexus-back" ? -140 : -90 + clockwiseIndex++ * 50) * Math.PI / 180;
        return { ...tool, left: Math.round(10 + 60 * Math.cos(angle)), top: Math.round(10 + 60 * Math.sin(angle)) };
    });
}

export async function activateGmWheelTool(name, event) {
    if (!slots.includes(name) || !gmWheelTools().some(tool => tool.name === name) || !ToolWindowLifecycle.canSwitch(name)) return false;
    const tool = ui.controls.controls.augurTools.tools[name];
    // Foundry's button-tool path invokes onChange without selecting the button as a tool.
    if (tool.button) await tool.onChange?.(event ?? new Event("change"), true);
    else await ui.controls.activate({ control: "augurTools", tool: name });
    return true;
}
