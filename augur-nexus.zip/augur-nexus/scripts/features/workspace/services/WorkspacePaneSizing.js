const COMPACT_WIDTH = 420;
const EXPANDED_WIDTH = 621;

const positive = (value, fallback) => Number.isFinite(value) && value > 0 ? value : fallback;
const nonnegative = value => Number.isFinite(value) ? Math.max(0, value) : 0;

/** Plan two panes in window CSS pixels without changing tabs or window state. */
export function planWorkspacePaneSizing({
    action,
    paneIndex,
    panes,
    browserWidth = 0,
    chromeWidth = 0,
    gap = 6,
    currentWidth,
    viewportWidth,
    scale = 1,
    fullscreen = false,
    margin = 20
}) {
    if (!["expand", "compact"].includes(action)) throw new RangeError("Unknown Workspace sizing action.");
    if (!Array.isArray(panes) || panes.length !== 2 || ![0, 1].includes(paneIndex)) {
        throw new RangeError("Workspace pane sizing requires two panes and an index of 0 or 1.");
    }
    const siblingIndex = 1 - paneIndex;
    const overhead = nonnegative(browserWidth) + nonnegative(chromeWidth) + nonnegative(gap);
    const capacity = Math.max(0, nonnegative(viewportWidth) - (fullscreen ? 0 : 2 * nonnegative(margin))) / positive(scale, 1);
    const deckCapacity = Math.max(0, capacity - overhead);
    const expanded = panes.map(pane => Math.max(COMPACT_WIDTH, positive(pane.minimumExpandedWidth, EXPANDED_WIDTH)));
    const compact = panes.map(pane => !!pane.compact);
    compact[paneIndex] = action === "compact";

    // Expanded content has priority over a manually widened compact sibling.
    if (!compact[paneIndex]) {
        if (!compact[siblingIndex] && expanded[0] + expanded[1] > deckCapacity) compact[siblingIndex] = true;
        const siblingMinimum = compact[siblingIndex] ? COMPACT_WIDTH : expanded[siblingIndex];
        if (expanded[paneIndex] + siblingMinimum > deckCapacity) {
            compact[paneIndex] = true;
            compact[siblingIndex] = !!panes[siblingIndex].compact;
        }
    }
    if (compact[paneIndex] && !compact[siblingIndex] && COMPACT_WIDTH + expanded[siblingIndex] > deckCapacity) {
        compact[siblingIndex] = true;
    }

    const paneWidths = compact.map((isCompact, index) => {
        if (!isCompact) return expanded[index];
        if (compact.every(Boolean) || (index === paneIndex && action === "compact")) return COMPACT_WIDTH;
        const desired = Math.max(COMPACT_WIDTH, positive(panes[index].compactWidth, COMPACT_WIDTH));
        const otherMinimum = compact[1 - index] ? COMPACT_WIDTH : expanded[1 - index];
        return Math.max(COMPACT_WIDTH, Math.min(desired, deckCapacity - otherMinimum));
    });
    const requiredWidth = overhead + paneWidths[0] + paneWidths[1];
    const fits = requiredWidth <= capacity;
    const width = fullscreen ? capacity : Math.min(capacity,
        compact.every(Boolean) ? requiredWidth : Math.max(requiredWidth, nonnegative(currentWidth)));
    const surplus = Math.max(0, width - requiredWidth);
    const expandedRecipient = !compact[paneIndex] ? paneIndex : !compact[siblingIndex] ? siblingIndex : -1;
    if (expandedRecipient >= 0) paneWidths[expandedRecipient] += surplus;

    return {
        width,
        paneWidths,
        compact,
        success: fits && compact[paneIndex] === (action === "compact"),
        fits,
        capacity,
        surplus: expandedRecipient < 0 ? surplus : 0
    };
}
