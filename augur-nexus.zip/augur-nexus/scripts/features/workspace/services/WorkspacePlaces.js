import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { SiteRecordManager } from "../../site/services/SiteRecordManager.js";
import { SiteSceneVisibilityManager } from "../../site/services/SiteSceneVisibilityManager.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";

// A disposable workspace projection; site records and scenes retain all authority.
export class WorkspacePlaces {
    static get(id) {
        const [kind, parentId, ...parts] = String(id || "").split(":");
        let record = null, scene = null, target = null;
        if (kind === "nexus-site") {
            const parentScene = game.scenes.get(parentId);
            record = parentScene && SiteRecordManager.resolveSite({ parentScene, siteId: parts.join(":") });
            if (record) target = ConnectionTargetResolver.fromSiteRecord(record);
        } else if (kind === "nexus-scene") {
            scene = game.scenes.get(parentId);
            if (scene) target = ConnectionTargetResolver.fromSceneReference({ sceneId: scene.id });
        }
        return target ? { id: target.id, type: "place", record, scene, target,
            display: { name: target.name, imageSrc: target.img } } : null;
    }
    static canView(entry) {
        if (!entry) return false;
        return entry.record ? SiteSceneVisibilityManager.canUserSeeSite({
            scene: game.scenes.get(entry.record.parentSceneId), siteId: entry.record.siteId, record: entry.record
        }) : NexusPlayerSceneAccess.canUserSeeSceneInNexus(entry.scene);
    }
    static fromBrowser(data) {
        if (data.parentSceneId && data.siteId) return this.get(ConnectionTargetResolver.getSiteNodeId(data.parentSceneId, data.siteId));
        if (data.sceneId && (!data.nodeKind || data.nodeKind === "scene")) return this.get(ConnectionTargetResolver.getSceneNodeId(data.sceneId));
        return null;
    }
}
