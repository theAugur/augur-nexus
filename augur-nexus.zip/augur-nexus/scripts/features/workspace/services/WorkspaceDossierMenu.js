import { buildDossierActionItems } from "../../campaign-entities/components/DossierActionItems.js";
import { openEntityDossierVisibility } from "../../campaign-entities/components/DossierHeaderControls.js";
import { WorkspaceEntities } from "./WorkspaceEntities.js";
import { updateNpc } from "../../../api/npcs.js";
import { updateFaction } from "../../../api/factions.js";
import { updateLocation, deleteLocation, getLocationViews, openLocationView } from "../../../api/locations.js";
import { openActionMenu, promptTextInput } from "../../../api/ui.js";
import { prepareNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";
import { prepareDossierCover } from "../../../support/appearance/DossierCoverPresentation.js";
import { DossierTabPreference } from "../../nexus/services/DossierTabPreference.js";
import { CampaignEntityActorBridge } from "../../campaign-entities/services/CampaignEntityActorBridge.js";
import { CampaignEntityDeletion } from "../../campaign-entities/services/CampaignEntityDeletion.js";
import { FactionActionRegistry } from "../../campaign-entities/services/FactionActionRegistry.js";
import { LocationSceneWorkflow } from "../../campaign-entities/services/LocationSceneWorkflow.js";
import { FactionHierarchyService } from "../../connections/services/FactionHierarchyService.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { PlayerLocationDisclosureDialog } from "../../nexus/applications/PlayerLocationDisclosureDialog.js";
import { EntityArtworkApplication } from "../../campaign-entities/applications/EntityArtworkApplication.js";
import { NpcPortraitPicker } from "../../campaign-entities/applications/NpcPortraitPicker.js";
import { NpcEntityModel } from "../../campaign-entities/models/NpcEntityModel.js";
import { FactionDossier } from "../../campaign-entities/applications/FactionDossier.js";
import { SiteCoverPicker } from "../../site/applications/SiteCoverPicker.js";
import { SiteIconPicker } from "../../site/applications/SiteIconPicker.js";
import { SitePanel } from "../../site/applications/SitePanel.js";
import { LocationEntityModel } from "../../campaign-entities/models/LocationEntityModel.js";

/** Native workspace dossiers supply host callbacks to the same menu as standalone windows. */
export function openWorkspaceDossierMenu(entity, anchor, tab) {
    if (!game.user.isGM || !entity || !["npc", "faction", "location"].includes(entity.type)) return;
    const live = () => WorkspaceEntities.get(entity.id, entity.type);
    if (!WorkspaceEntities.canView(live())) return;
    const changed = () => tab.redraw();
    const run = callback => (...args) => tab.perform(async () => {
        const current = live();
        if (!game.user.isGM || !WorkspaceEntities.canView(current)) return;
        return callback(current, ...args);
    });
    const update = { npc: updateNpc, faction: updateFaction, location: updateLocation }[entity.type];
    const patch = async data => { await update(entity.id, data); await changed(); };
    const setCover = run(async (_current, path) => {
        if (prepareNexusThemeSurface().mode === "dark") await patch({ display: { coverImageSrc: path || "" } });
    });
    const actions = {
        edit: run(current => WorkspaceEntities.edit(current, changed)),
        artwork: run(current => EntityArtworkApplication.show({
            entityId: current.id,
            onChooseArtwork: run(latest => new NpcPortraitPicker({
                currentPortraitSrc: NpcEntityModel.getImage(latest), raceTemplateId: NpcEntityModel.getRaceTemplateId(latest),
                onSelect: run(async (_record, selection) => {
                    if (selection?.src) await patch({ display: { imageSrc: selection.src, tokenImageSrc: selection.tokenImageSrc || "" } });
                })
            }).render(true, { focus: true }))
        })),
        linkedActor: run(async current => {
            const result = await CampaignEntityActorBridge.manageActorLink(current);
            if (result?.action && !["cancel", "open"].includes(result.action)) await changed();
        }),
        defaultTab: run(current => openActionMenu({ anchor, items: DossierTabPreference.buildMenuItems(
            DossierTabPreference.getDefaultTab(current), run(async (_record, value) => {
                const defaultTab = DossierTabPreference.normalizeTab(value);
                await update(entity.id, { dossier: { defaultTab } }); tab.view = defaultTab; await changed();
            })
        ) })),
        changeCover: run(current => {
            if (prepareNexusThemeSurface().mode !== "dark") return;
            return SiteCoverPicker.show({ current: prepareDossierCover(current).src, onSelect: setCover });
        }),
        clearCover: () => setCover(""),
        visibility: run(current => openEntityDossierVisibility(current, anchor, changed)),
        delete: run(async current => {
            const deleted = current.type === "location" ? await deleteLocation(current.id)
                : await CampaignEntityDeletion.confirm(current.type, current.id) === "deleted";
            if (deleted) await tab.host.closeTab(tab.host.groupFor(tab), tab);
        }),
        rename: run(async current => {
            const name = await promptTextInput({ title: "Rename Location", label: "Name", value: LocationEntityModel.getName(current), confirmLabel: "Rename" });
            if (name) await patch({ display: { name } });
        }),
        changeIcon: run(async current => {
            const icons = await SitePanel.getAllBuiltInIcons();
            const currentSrc = LocationEntityModel.getImage(current);
            const currentIconId = icons.find(icon => icon.src === currentSrc)?.id || (currentSrc ? "custom" : null);
            return new SiteIconPicker(icons, currentIconId, "landmark", run(async (_record, selection) => {
                const nextSrc = typeof selection === "object" && selection?.id === "custom" ? selection.src || ""
                    : icons.find(icon => icon.id === selection)?.src || currentSrc;
                if (nextSrc) await patch({ display: { imageSrc: nextSrc, thumbnailSrc: "" } });
            }), { currentCustomIconSrc: currentIconId === "custom" ? currentSrc : "", allBuiltInIcons: icons, showThemeIconsOnly: false, filterByRole: false }).render(true);
        }),
        journal: run(current => WorkspaceEntities.editJournal(current)),
        disclosure: run(current => PlayerLocationDisclosureDialog.openEntityMenu({ anchor, location: current, onChanged: changed }))
    };
    let extras = [], parentItem = null;
    if (entity.type === "faction") {
        extras = FactionActionRegistry.listFor(entity, { onChanged: changed });
        const target = ConnectionTargetResolver.fromCampaignEntity(entity);
        const parent = FactionHierarchyService.getParent(target, { includeHidden: true });
        parentItem = parent ? {
            id: "remove-faction-parent", label: "Remove Parent Organization", icon: "fas fa-unlink",
            onSelect: run(async current => { await FactionHierarchyService.clearParent(ConnectionTargetResolver.fromCampaignEntity(current)); await changed(); })
        } : {
            id: "add-faction-parent", label: "Add Parent Organization", icon: "fas fa-sitemap",
            onSelect: run(current => FactionDossier.showParentPicker(current.id))
        };
    } else if (entity.type === "location") {
        extras = [
            ...getLocationViews(entity).map(view => ({ id: `location-view:${view.id}`, label: view.label, icon: view.icon, onSelect: run(current => openLocationView(view.id, current)) })),
            ...LocationSceneWorkflow.getMenuItems(entity.id, { onChanged: changed })
        ];
    }
    return openActionMenu({ anchor, className: `${entity.type}-dossier-actions-menu`, items: buildDossierActionItems({
        entity, actions, extras, parentItem, hasCover: !!entity.display?.coverImageSrc, dark: prepareNexusThemeSurface().mode === "dark"
    }) });
}
