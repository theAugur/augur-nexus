import { ConnectionStore } from "../../connections/services/ConnectionStore.js";

/** Pane-owned navigation and redraw; feature controllers retain their own content lifecycle. */
export function workspaceDossierHost(tab) {
    const node = value => typeof value === "string" ? ConnectionStore.getNode(value) : value;
    return {
        element: () => tab.element?.querySelector("[data-workspace-dossier]"),
        redraw: () => tab.redraw(),
        onStateChange: state => { if (state.tab) tab.view = state.tab; if (state.collection) tab.shipCollection = state.collection; },
        toggleCompact: () => tab.host.handleAction("workspaceCompact", tab.element?.querySelector("[data-action='workspaceCompact']")),
        openNode: value => { const target = node(value); return target && tab.followNode(target); },
        navigation: value => { const target = node(value); return target ? tab.host.objectNavigationItems(target, tab) : []; }
    };
}
