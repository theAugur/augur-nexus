export const WORLD_NODE = Object.freeze({ width: 112, height: 114, cx: 56, cy: 38 });
const GOLDEN_ANGLE = Math.PI * (3 - Math.sqrt(5));
const phase = id => [...id].reduce((hash, char) => (hash * 31 + char.charCodeAt(0)) >>> 0, 7) / 4294967296 * Math.PI * 2;

// Solve a static constellation from the visible relationship graph. Nothing runs between interactions.
export function placeWorldGraph(nodes, edges = [], positions = new Map(), { reset = false } = {}) {
    const byId = new Map(nodes.map(node => [node.id, node]));
    for (const id of positions.keys()) if (!byId.has(id)) positions.delete(id);
    if (reset) for (const [id, position] of positions) if (!position.pinned) positions.delete(id);
    const adjacency = new Map(nodes.map(node => [node.id, new Set()]));
    for (const edge of edges) {
        if (!byId.has(edge.source) || !byId.has(edge.target) || edge.source === edge.target) continue;
        adjacency.get(edge.source).add(edge.target); adjacency.get(edge.target).add(edge.source);
    }
    const groups = new Map(), groupFor = new Map();
    const add = (node, key) => {
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(node); groupFor.set(node.id, key);
    };
    const ordered = [...nodes].sort((a,b) => a.id.localeCompare(b.id));
    for (const node of ordered) if (node.factionId) add(node, `faction:${node.factionId}`);
    // Unaffiliated entities form their own connected components instead of an arbitrary neutral grid.
    for (const node of ordered) {
        if (groupFor.has(node.id)) continue;
        const key = `component:${node.id}`, queue = [node.id];
        add(node, key);
        for (let index = 0; index < queue.length; index++) for (const id of [...adjacency.get(queue[index])].sort()) {
            if (groupFor.has(id)) continue;
            add(byId.get(id), key); queue.push(id);
        }
    }
    const clusters = [...groups].map(([key,members]) => {
        const memberIds = new Set(members.map(n=>n.id));
        const degree = id => [...adjacency.get(id)].filter(other=>memberIds.has(other)).length;
        const ranked = [...members].sort((a,b) => degree(b.id)-degree(a.id)
            || Number(b.type === "faction")-Number(a.type === "faction")
            || adjacency.get(b.id).size-adjacency.get(a.id).size || a.id.localeCompare(b.id));
        const hub = ranked[0], depth = new Map([[hub.id,0]]), queue = [hub.id];
        for (let index=0;index<queue.length;index++) for (const id of adjacency.get(queue[index])) {
            if (!memberIds.has(id) || depth.has(id)) continue;
            depth.set(id,depth.get(queue[index])+1); queue.push(id);
        }
        const satellites = ranked.slice(1).sort((a,b) => (depth.get(a.id) ?? Infinity)-(depth.get(b.id) ?? Infinity)
            || degree(b.id)-degree(a.id) || a.id.localeCompare(b.id));
        const local = new Map([[hub.id,{x:0,y:0}]]);
        let index=0, radius=0, ring=0;
        while (index<satellites.length) {
            ring++; radius=ring*180;
            const count=Math.min(satellites.length-index, Math.floor(2*Math.PI*radius/180));
            for (let slot=0;slot<count;slot++) {
                const angle=phase(key)+ring*GOLDEN_ANGLE+slot*2*Math.PI/count;
                local.set(satellites[index++].id,{x:Math.cos(angle)*radius,y:Math.sin(angle)*radius});
            }
        }
        return { key, members, hub:hub.id, local, radius:radius+95, x:0, y:0 };
    }).sort((a,b) => b.members.length-a.members.length || a.key.localeCompare(b.key));
    // Counts and hub emphasis are projections too: never retain information from a now-hidden edge.
    for (const cluster of clusters) for (const node of cluster.members) {
        const position=positions.get(node.id);
        if (position) {
            position.degree=adjacency.get(node.id).size;
            position.size=Math.min(72,50+Math.sqrt(position.degree)*5);
            position.hub=node.id===cluster.hub && cluster.members.length>1;
        }
    }
    if (nodes.every(node => positions.has(node.id))) return positions;
    const clusterByKey = new Map(clusters.map(c=>[c.key,c]));
    const bridges = new Map();
    for (const edge of edges) {
        const left = groupFor.get(edge.source), right = groupFor.get(edge.target);
        if (!left || !right || left===right) continue;
        const pair=[left,right].sort(), key=JSON.stringify(pair);
        if (!bridges.has(key)) bridges.set(key,{a:clusterByKey.get(pair[0]),b:clusterByKey.get(pair[1]),weight:0});
        bridges.get(key).weight++;
    }
    const largest=clusters[0]?.radius || 95;
    clusters.forEach((cluster,index) => {
        const radius=index ? (largest+cluster.radius+60)*Math.sqrt(index) : 0;
        cluster.x=Math.cos(index*GOLDEN_ANGLE)*radius; cluster.y=Math.sin(index*GOLDEN_ANGLE)*radius;
    });
    // Bridges draw neighboring communities together; collision separation keeps their orbits readable.
    if (clusters.length<=120) for (let pass=0;pass<80;pass++) {
        for (const {a,b,weight} of bridges.values()) {
            const dx=b.x-a.x,dy=b.y-a.y,distance=Math.hypot(dx,dy)||1;
            const force=Math.max(0,distance-a.radius-b.radius-70)*.035*Math.min(3,Math.sqrt(weight));
            a.x+=dx/distance*force; a.y+=dy/distance*force;
            b.x-=dx/distance*force; b.y-=dy/distance*force;
        }
        for (let i=0;i<clusters.length;i++) for (let j=i+1;j<clusters.length;j++) {
            const a=clusters[i],b=clusters[j],dx=b.x-a.x,dy=b.y-a.y,distance=Math.hypot(dx,dy)||1;
            const overlap=a.radius+b.radius+40-distance;
            if (overlap<=0) continue;
            a.x-=dx/distance*overlap*.51; a.y-=dy/distance*overlap*.51;
            b.x+=dx/distance*overlap*.51; b.y+=dy/distance*overlap*.51;
        }
    }
    const packed=[];
    for (const cluster of clusters) {
        const origin={x:cluster.x,y:cluster.y};
        let attempt=0;
        while (packed.some(other=>Math.hypot(cluster.x-other.x,cluster.y-other.y)<cluster.radius+other.radius+35)) {
            attempt++;
            const radius=Math.sqrt(attempt)*Math.max(100,cluster.radius*.75);
            cluster.x=origin.x+Math.cos(attempt*GOLDEN_ANGLE)*radius;
            cluster.y=origin.y+Math.sin(attempt*GOLDEN_ANGLE)*radius;
        }
        packed.push(cluster);
    }
    const occupied=[...positions.values()];
    for (const cluster of clusters) {
        const pinned=cluster.members.find(node=>positions.get(node.id)?.pinned);
        const anchor=pinned && positions.get(pinned.id), localAnchor=pinned && cluster.local.get(pinned.id);
        const offset=anchor ? {x:anchor.x+WORLD_NODE.cx-localAnchor.x,y:anchor.y+WORLD_NODE.cy-localAnchor.y} : cluster;
        for (const node of cluster.members) {
            if (positions.has(node.id)) continue;
            const local=cluster.local.get(node.id), degree=adjacency.get(node.id).size;
            const origin={x:offset.x+local.x-WORLD_NODE.cx,y:offset.y+local.y-WORLD_NODE.cy};
            const position={...origin,pinned:false,hub:node.id===cluster.hub && cluster.members.length>1,degree,size:Math.min(72,50+Math.sqrt(degree)*5)};
            let attempt=0;
            while (occupied.some(p=>Math.abs(p.x-position.x)<WORLD_NODE.width+12 && Math.abs(p.y-position.y)<WORLD_NODE.height+12)) {
                attempt++; const radius=Math.sqrt(attempt)*180;
                position.x=origin.x+Math.cos(attempt*GOLDEN_ANGLE)*radius;
                position.y=origin.y+Math.sin(attempt*GOLDEN_ANGLE)*radius;
            }
            positions.set(node.id,position); occupied.push(position);
        }
    }
    return positions;
}
