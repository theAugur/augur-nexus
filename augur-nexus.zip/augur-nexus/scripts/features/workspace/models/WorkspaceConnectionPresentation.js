export function workspaceEdgeDirection(edge, currentNodeId) {
    // Creation order is not direction. Only domain relationships define an arrow.
    const origin = edge?.relationType === "ownership" ? edge.sourceNodeId
        : edge?.locationLeadership?.leaderNodeId || edge?.factionMembership?.memberNodeId || "";
    return !origin ? "" : origin === currentNodeId ? "out" : "in";
}
