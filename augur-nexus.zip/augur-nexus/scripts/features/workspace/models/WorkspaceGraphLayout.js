export const GRAPH_PAGE_SIZE = 24;

export function workspaceGraphRelationship(card, role = "") {
    return card.isFactionLeader ? "Leader" : card.isFactionMember ? "Member"
        : card.isOwnership ? card.ownershipLabel : card.isFactionSeat ? card.factionSeatLabel
        : card.isLocationLeader ? card.locationLeadershipLabel : card.factionHierarchyLabel
        || String(role || card.subtitle || card.categoryLabel || "Connection").split(/\r?\n/)[0];
}

export function workspaceEdgeDirection(edge, currentNodeId) {
    // Creation order is not direction. Only domain relationships define an arrow.
    const origin = edge?.relationType === "ownership" ? edge.sourceNodeId
        : edge?.locationLeadership?.leaderNodeId || edge?.factionMembership?.memberNodeId || "";
    return !origin ? "" : origin === currentNodeId ? "out" : "in";
}

// Stable, bounded columns keep portraits and labels readable without a force simulation.
export function layoutWorkspaceGraph(cards, page = 0, measuredHeights = []) {
    const sorted = [...cards].sort((a, b) => a.name.localeCompare(b.name) || a.nodeId.localeCompare(b.nodeId));
    const pages = Math.max(1, Math.ceil(sorted.length / GRAPH_PAGE_SIZE));
    page = Math.min(Math.max(0, page), pages - 1);
    const visible = sorted.slice(page * GRAPH_PAGE_SIZE, (page + 1) * GRAPH_PAGE_SIZE);
    const heights = visible.map((_, index) => Math.max(104, measuredHeights[index] || 0));
    const rowTops = [];
    let bottom = 24;
    for (let index = 0; index < visible.length; index += 2) {
        rowTops.push(bottom);
        bottom += Math.max(heights[index], heights[index + 1] || 0) + 24;
    }
    const height = Math.max(500, bottom);
    const center = { x: 490, y: height / 2 };
    return {
        width: 980, height, center, page, pages, total: sorted.length,
        hasPrevious: page > 0, hasNext: page < pages - 1,
        pageLabel: `${page + 1} / ${pages}`,
        nodes: visible.map((card, index) => {
            const left = index % 2 === 0;
            const x = left ? 146 : 834;
            const top = rowTops[Math.floor(index / 2)];
            const y = top + heights[index] / 2;
            return { ...card, x, y, left: x - 130, top,
                path: `M ${center.x + (left ? -88 : 88)} ${center.y} C ${left ? 330 : 650} ${center.y}, ${left ? 330 : 650} ${y}, ${x + (left ? 130 : -130)} ${y}` };
        })
    };
}
