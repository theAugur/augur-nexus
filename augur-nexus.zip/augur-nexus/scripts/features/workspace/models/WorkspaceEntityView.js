import { prepareDossierCover } from "../../../support/appearance/DossierCoverPresentation.js";
import { canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { canRerollFactionCurrentThread } from "../../../api/factions.js";
import { canRerollShipCurrentAssignment } from "../../../api/ships.js";
import { FactionProfileViewModel } from "../../campaign-entities/models/FactionProfileViewModel.js";
import { FactionDomainViewModel } from "../../campaign-entities/models/FactionDomainViewModel.js";
import { FactionDiplomacyViewModel } from "../../campaign-entities/models/FactionDiplomacyViewModel.js";
import { ShipProfileViewModel } from "../../campaign-entities/models/ShipProfileViewModel.js";
import { ShipDomainViewModel } from "../../campaign-entities/models/ShipDomainViewModel.js";
import { LocationProfileViewModel } from "../../campaign-entities/models/LocationProfileViewModel.js";
import { getLocationOverview, getChildLocations, canRerollLocationCurrentThread } from "../../../api/locations.js";
import { prepareNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";
import { LOCATION_DOSSIER_VIEW_IDS } from "../../campaign-entities/services/LocationDossierViewIds.js";
import { getShopsForParentLocation } from "../../../api/shops.js";
import { TradeBasinEconomyService } from "../../trade/services/TradeBasinEconomyService.js";
import { SettlementDossierProviderRegistry } from "../../campaign-entities/services/SettlementDossierProviderRegistry.js";

const ROOT = "modules/augur-nexus/templates/";

export class WorkspaceEntityView {
    static async prepare(entity, { controlsHtml = "", compact, view, hasChronicle, shipCollection = "crew", compactSections = {} }) {
        await foundry.applications.handlebars.loadTemplates([
            ...["compact-section-heading", "faction-current-thread", "faction-diplomacy", "faction-holdings", "faction-members", "faction-profile-panel", "faction-domain-overview", "faction-parent", "faction-suborganizations", "faction-header", "faction-command", "faction-beliefs", "faction-reading-profile",
                "ship-crew-manifest", "ship-world-ties", "ship-profile-panel", "ship-domain-overview", "ship-command-cards", "ship-location-control", "ship-assignment",
                "location-current-thread", "settlement-notable-people", "location-profile-panel", "settlement-command", "settlement-owner", "settlement-domain-panels",
                "settlement-reading-profile", "settlement-trade", "npc-portrait", "quest-world-ties"]
                .map(name => `${ROOT}campaign-entities/${name}.hbs`)
        ]);
        const options = { compactMode: compact, activeTab: view, hasChronicle, showTabs: true,
            showActions: false, showBody: true, showIdentity: false };
        // Render shared reading partials in their own context so GM editing controls
        // from standalone dossiers cannot accidentally appear in this viewer. Creating
        // members and crew is the exception; WorkspaceEntityTab handles those actions.
        const context = { isGM: false, canCreateRelated: game.user.isGM, canEdit: false, factionHierarchyEnabled: true, compact,
            isFaction: entity.type === "faction", isShip: entity.type === "ship", isLocation: entity.type === "location" };
        if (context.isFaction) {
            context.canManageMembers = canControlPlayerEntity(entity);
            context.domain = FactionDomainViewModel.fromEntity(entity, { isGM: false, canEdit: false });
            context.profile = FactionProfileViewModel.fromEntity(entity, { ...options, ...(compact ? compactSections : {}), showIdeology: true, showDiplomacy: true, canRerollCurrentThread: game.user.isGM && canRerollFactionCurrentThread(entity) });
            context.diplomacy = FactionDiplomacyViewModel.fromEntity(entity);
        } else if (context.isShip) {
            context.domain = ShipDomainViewModel.fromEntity(entity, { isGM: false, canEdit: false });
            context.profile = ShipProfileViewModel.fromEntity(entity, { ...options, ...(compact ? compactSections : {}), showAssignmentChips: false });
            context.canRerollCurrentAssignment = game.user.isGM && canRerollShipCurrentAssignment(entity);
            context.assignment = ShipProfileViewModel.assignmentFromEntity(entity);
            context.dossier = { isCrewTab: shipCollection === "crew", isWorldTiesTab: shipCollection === "ties", isProfileTab: true, isCompact: compact };
        } else {
            context.profile = LocationProfileViewModel.fromEntity(entity, { ...options, ...(compact ? compactSections : {}), canRerollCurrentThread: game.user.isGM && canRerollLocationCurrentThread(entity) });
            context.profile.workspace = true;
            context.profile.connectionsActive = view === "connections";
            context.overview = getLocationOverview(entity);
            context.canManageTrade = game.user.isGM || !!context.overview?.trade;
            // Same provider contract as SettlementDossier, so content modules contribute identical cards and actions.
            const provider = SettlementDossierProviderRegistry.getFor(entity);
            const providerContext = provider?.prepare ? await provider.prepare({ entity, overview: context.overview, state: {} }) || {} : {};
            const cards = [
                ...getChildLocations(entity.id).map(location => ({ kind: "location", id: location.id, name: location.display.name,
                    imageSrc: location.display.thumbnailSrc || location.display.imageSrc, subtitle: location.profile.type || location.profile.kindLabel })),
                ...getShopsForParentLocation(entity.id)
                    .map(shop => ({ kind: "shop", id: shop.id, name: shop.name, imageSrc: shop.display?.imageSrc, subtitle: "Shop" })),
                ...(Array.isArray(providerContext.cards) ? providerContext.cards : [])
            ];
            context.cards = [...new Map(cards.map(card => [`${card.kind}:${card.id}`, card])).values()];
            context.missingMarketplace = providerContext.missingMarketplace === true;
            context.canCreateEstablishment = game.user.isGM && providerContext.canCreateEstablishment !== false;
            context.establishmentCount = context.cards.length + Number(context.missingMarketplace);
            context.hasEstablishmentCards = context.cards.length > 0;
            context.hasFewEstablishments = context.establishmentCount <= 3;
            if (view === "profile") {
                const economy = await TradeBasinEconomyService.getLocationView(entity, { user: game.user }) || {};
                context.economyHtml = await foundry.applications.handlebars.renderTemplate(`${ROOT}trade/settlement-economy.hbs`, { ...economy, iconOnly: true });
                context.hasEconomy = !!economy.hasGoods;
            }
        }
        context.profile.controlsHtml = controlsHtml;
        const profile = context.profile;
        const headerHtml = compact ? await foundry.applications.handlebars.renderTemplate(
            `${ROOT}campaign-entities/${entity.type}-profile-panel.hbs`,
            { ...context, headerOnly: true, profile: { ...profile, showBody: false } }) : "";
        const profileHtml = view === "profile" ? await foundry.applications.handlebars.renderTemplate(
            `${ROOT}workspace/entity-workspace-profile.hbs`, context) : "";
        const themedLocation = entity.type === "location" && entity.dossier?.viewId === LOCATION_DOSSIER_VIEW_IDS.settlement;
        const appearance = entity.type === "faction" || themedLocation ? prepareNexusThemeSurface() : null;
        const dossierCover = prepareDossierCover(entity), cover = dossierCover.src;
        return { profile, headerHtml, profileHtml, cover, appearance, dossierCover };
    }
}
