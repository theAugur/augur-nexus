import { CampaignEntityIndex } from "../../campaign-entities/services/CampaignEntityIndex.js";
import { FactionEntityModel } from "../../campaign-entities/models/FactionEntityModel.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { FactionMembershipService } from "../../connections/services/FactionMembershipService.js";
import { OwnershipService } from "../../connections/services/OwnershipService.js";
import { ShipOwnershipService } from "../../connections/services/ShipOwnershipService.js";
import { WorkspaceEntities } from "../services/WorkspaceEntities.js";

const colors = { npc: "#55bdec", faction: "#83c95f", location: "#b778ef", ship: "#e2b85d" };
export const WORLD_GRAPH_TYPES = [
    { id: "npc", label: "People" }, { id: "faction", label: "Organizations" },
    { id: "location", label: "Locations" }, { id: "ship", label: "Ships" }
];
const safeColor = color => /^#[0-9a-f]{6}$/i.test(color || "") ? color : "#888c96";

// Disposable, permission-filtered projection. No graph layout is written into campaign records.
export function buildWorldGraph() {
    const entities = [...CampaignEntityIndex.getNpcs(), ...CampaignEntityIndex.getFactions(),
        ...CampaignEntityIndex.getLocations(), ...CampaignEntityIndex.getShips()].filter(entity => WorkspaceEntities.canView(entity));
    const nodes = entities.map(entity => {
        const target = ConnectionTargetResolver.fromCampaignEntity(entity);
        return { id: target.id, entityId: entity.id, type: entity.type, name: target.name, img: target.img,
            icon: WorkspaceEntities.describe(entity.type).icon, factionIds: [], factionId: "", color: "#888c96", typeColor: colors[entity.type] };
    });
    const byId = new Map(nodes.map(node => [node.id, node]));
    const edges = Object.values(ConnectionStore.getGraphContext().graph.edges).filter(edge => {
        if (!byId.has(edge.sourceNodeId) || !byId.has(edge.targetNodeId) || !ConnectionStore.canUserSeeConnection(edge)) return false;
        return [edge.sourceNodeId, edge.targetNodeId].every(id => ConnectionStore.canUserSeeCategoryGroup(id, ConnectionStore.getConnectionView(edge, id).category, game.user));
    }).map(edge => {
        const source = ConnectionStore.getConnectionView(edge, edge.sourceNodeId);
        const target = ConnectionStore.getConnectionView(edge, edge.targetNodeId);
        const domainKind = edge.factionMembership ? "Membership" : edge.locationLeadership ? "Leadership"
            : edge.shipOwnership || edge.relationType === "ownership" ? "Ownership" : edge.factionHierarchy ? "Hierarchy"
            : edge.shipCaptain ? "Captain" : edge.shipLocation ? "Ship location" : edge.factionSeat ? "Seat of power" : "";
        const label = [...new Set([source.role, target.role].filter(Boolean))].join(" / ") || domainKind || "Connection";
        const kind = domainKind || label;
        return { id: edge.id, source: edge.sourceNodeId, target: edge.targetNodeId, kind, label,
            description: `${byId.get(edge.sourceNodeId).name} — ${label} — ${byId.get(edge.targetNodeId).name}` };
    });
    const visibleEdges = new Set(edges.map(edge => edge.id));
    const factions = new Map(entities.filter(entity => entity.type === "faction").map(entity => [entity.id, entity]));
    for (const node of nodes) {
        let ids = [];
        if (node.type === "faction") ids = [node.entityId];
        else if (node.type === "npc") ids = FactionMembershipService.getMembershipsForNpc({ id: node.id })
            .filter(m => visibleEdges.has(m.edgeId)).sort((a, b) => Number(b.rankValue || 0) - Number(a.rankValue || 0)
                || Number(b.isLeader) - Number(a.isLeader) || a.faction.name.localeCompare(b.faction.name)).map(m => m.faction.entityId);
        else {
            const ownership = node.type === "ship" ? ShipOwnershipService.getOwner({ id: node.id }) : OwnershipService.getOwnership({ id: node.id });
            if (ownership && visibleEdges.has(ownership.edgeId) && ownership.owner.entityType === "faction") ids = [ownership.owner.entityId];
        }
        node.factionIds = [...new Set(ids.filter(id => factions.has(id)))];
        node.factionId = node.factionIds[0] || "";
        if (node.factionId) node.color = safeColor(FactionEntityModel.getAccent(factions.get(node.factionId)));
    }
    return { nodes, edges, factions: [...factions.values()].map(f => ({ id: f.id, label: f.display.name })).sort((a,b) => a.label.localeCompare(b.label)),
        kinds: [...new Set(edges.map(edge => edge.kind))].sort() };
}

export function filterWorldGraph(graph, filters = {}) {
    const search = (filters.search || "").trim().toLocaleLowerCase();
    let nodes = graph.nodes.filter(node => (!filters.type || node.type === filters.type) && (!search || node.name.toLocaleLowerCase().includes(search))
        && (!filters.faction || filters.factionMode !== "filter" || node.factionIds.includes(filters.faction)));
    let edges = graph.edges.filter(edge => !filters.relationship || edge.kind === filters.relationship);
    if (filters.focus && filters.depth !== "all") {
        const visited = new Set([filters.focus]);
        let frontier = new Set(visited);
        const adjacency = new Map();
        for (const edge of edges) for (const [a,b] of [[edge.source,edge.target],[edge.target,edge.source]]) {
            if (!adjacency.has(a)) adjacency.set(a, []);
            adjacency.get(a).push(b);
        }
        for (let depth = 0; depth < Math.min(3, Math.max(1, Number(filters.depth) || 1)); depth++) {
            const next = new Set();
            for (const id of frontier) for (const neighbor of adjacency.get(id) || []) if (!visited.has(neighbor)) { visited.add(neighbor); next.add(neighbor); }
            frontier = next;
        }
        nodes = nodes.filter(node => visited.has(node.id));
    }
    const ids = new Set(nodes.map(node => node.id));
    edges = edges.filter(edge => ids.has(edge.source) && ids.has(edge.target));
    return { nodes, edges };
}

