import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";

const MODULE_ID = "augur-nexus";

export class LocationTradeProfileService {
    static async set(idOrEntity, profile = {}) {
        const entity = typeof idOrEntity === "string"
            ? LocationEntityStore.getLocation(idOrEntity)
            : idOrEntity;
        if (!entity?.id) throw new Error("Location could not be found.");

        const nexusData = foundry.utils.deepClone(entity.moduleData?.[MODULE_ID] || {});
        const current = nexusData.trade || {};
        const trade = {
            ...current,
            ...(Object.hasOwn(profile, "locationTypeId")
                ? { locationTypeId: String(profile.locationTypeId || "").trim() }
                : {}),
            ...(Object.hasOwn(profile, "marketTier")
                ? { marketTier: String(profile.marketTier || "").trim() }
                : {}),
            ...(Object.hasOwn(profile, "tradingCenterEligible")
                ? { tradingCenterEligible: profile.tradingCenterEligible === true }
                : {}),
            ...(Object.hasOwn(profile, "tradeGoodsProviderIds")
                ? {
                    tradeGoodsProviderIds: [...new Set((Array.isArray(profile.tradeGoodsProviderIds)
                        ? profile.tradeGoodsProviderIds
                        : []).map(value => String(value || "").trim()).filter(Boolean))]
                }
                : {})
        };
        if (foundry.utils.objectsEqual(current, trade)) return entity;

        return LocationEntityStore.updateLocation(entity.id, {
            moduleData: {
                [MODULE_ID]: {
                    ...nexusData,
                    trade
                }
            }
        }, { moduleId: MODULE_ID, syncMarkers: false });
    }
}
