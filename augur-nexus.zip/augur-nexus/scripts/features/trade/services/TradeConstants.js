export const NEXUS_TRADE_MODULE_ID = "augur-nexus";
export const NEXUS_TRADE_GOODS_POLICY_ID = "augur-nexus:regional-market";
export const NEXUS_CUSTOM_TRADE_GOODS_PROVIDER_ID = "augur-nexus:custom-trade-goods";

export function getTradeGoodsProviderIds() {
    return new Set([NEXUS_CUSTOM_TRADE_GOODS_PROVIDER_ID]);
}
