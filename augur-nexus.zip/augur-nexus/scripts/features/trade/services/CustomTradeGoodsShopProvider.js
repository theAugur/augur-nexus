import { getShopCurrencyId, registerShopProductProvider } from "../../../api/shops.js";
import { TradeGoodsCatalog } from "./TradeGoodsCatalog.js";

export const CUSTOM_TRADE_GOODS_PROVIDER_ID = "augur-nexus:custom-trade-goods";

export class CustomTradeGoodsShopProvider {
    static register() {
        registerShopProductProvider({
            id: CUSTOM_TRADE_GOODS_PROVIDER_ID,
            label: "Custom Trade Goods",
            getProduct: id => this.#getProduct(id)
        });
    }

    static async #getProduct(id) {
        const good = await TradeGoodsCatalog.getGood(id);
        if (!good || good.providerId !== CUSTOM_TRADE_GOODS_PROVIDER_ID) return null;
        return {
            id: good.id,
            name: good.name,
            lotLabel: good.lot?.label || good.name,
            category: good.familyId,
            typeLabel: "Cargo",
            subtypeLabel: "Trade Good",
            sourceLabel: "Custom Trade Goods",
            imageSrc: good.imageSrc,
            description: good.lot?.description || "",
            price: { amount: Math.round(Number(good.tradeValue || 0) * 100), currencyId: getShopCurrencyId() },
            weight: { value: Number(good.lot?.weightLb || 0), units: "lb" },
            cargoSlots: 1,
            sourceData: foundry.utils.deepClone(good)
        };
    }
}

