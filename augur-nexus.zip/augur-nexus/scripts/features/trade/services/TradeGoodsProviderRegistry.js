const providers = new Map();

export class TradeGoodsProviderRegistry {
    static register(definition = {}) {
        const id = String(definition.id || "").trim();
        const moduleId = String(definition.moduleId || "").trim();
        if (!id || !moduleId || typeof definition.getGoods !== "function") {
            throw new Error("Trade-good providers require id, moduleId, and getGoods().");
        }
        providers.set(id, Object.freeze({
            id,
            moduleId,
            label: String(definition.label || id).trim() || id,
            getGoods: definition.getGoods
        }));
        Hooks.callAll("augurNexusTradeGoodsChanged", { reason: "provider", providerId: id });
        return id;
    }

    static get(id) { return providers.get(String(id || "")) || null; }
    static getAll() { return [...providers.values()]; }
}
