import { registerFactionAction } from "../../api/factions.js";
import { registerLocationAction } from "../../api/locations.js";
import { RegionalTradeNetworkApplication } from "./applications/RegionalTradeNetworkApplication.js";
import { TradeBasinEconomyService } from "./services/TradeBasinEconomyService.js";
import { TradeGoodsCatalog } from "./services/TradeGoodsCatalog.js";
import { registerShopEditor } from "../../api/shops.js";
import { SettlementMarketplaceModel } from "./models/SettlementMarketplaceModel.js";
import { SettlementMarketplaceEditor } from "./applications/SettlementMarketplaceEditor.js";
import { RegionalMarketplaceTradePolicy } from "./services/RegionalMarketplaceTradePolicy.js";
import { RegionalMarketplaceService } from "./services/RegionalMarketplaceService.js";
import { CustomTradeGoodsShopProvider } from "./services/CustomTradeGoodsShopProvider.js";

export function registerTradeFeature() {
    TradeGoodsCatalog.registerSettings();
    Hooks.on("augurNexusTradeGoodsChanged", () => TradeGoodsCatalog.invalidate());
    TradeBasinEconomyService.registerHooks();
    RegionalMarketplaceTradePolicy.register();
    CustomTradeGoodsShopProvider.register();
    RegionalMarketplaceService.register();
    registerShopEditor({
        id: "augur-nexus:regional-marketplace",
        moduleId: "augur-nexus",
        priority: 100,
        matches: ({ shop }) => SettlementMarketplaceModel.isMarketplace(shop),
        open: options => SettlementMarketplaceEditor.show(options)
    });
    registerLocationAction({
        id: "augur-nexus:trade-network",
        moduleId: "augur-nexus",
        order: 115,
        icon: "fas fa-route",
        label: "Regional Trade Network",
        matches: ({ location, user }) => user?.isGM === true && location?.type === "location",
        onSelect: ({ location }) => RegionalTradeNetworkApplication.show({ locationId: location.id, scope: "connected" })
    });
    registerFactionAction({
        id: "augur-nexus:trade-network",
        moduleId: "augur-nexus",
        order: 115,
        icon: "fas fa-route",
        label: "Regional Trade Network",
        matches: ({ user }) => user?.isGM === true,
        onSelect: ({ faction }) => RegionalTradeNetworkApplication.show({ factionId: faction.id, scope: "faction" })
    });
}
