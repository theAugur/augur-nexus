import { LocationPlaceProvider } from "../campaign-entities/services/LocationPlaceProvider.js";
import { ShopPlaceProvider } from "../shops/services/ShopPlaceProvider.js";
import { ScenePlaceProvider, SitePlaceProvider } from "./services/LineagePlaceProviders.js";
import { PlaceTypeRegistry } from "./services/PlaceTypeRegistry.js";

export function registerPlacesFeature() {
    PlaceTypeRegistry.register(ScenePlaceProvider);
    PlaceTypeRegistry.register(SitePlaceProvider);
    PlaceTypeRegistry.register(LocationPlaceProvider);
    PlaceTypeRegistry.register(ShopPlaceProvider);
}