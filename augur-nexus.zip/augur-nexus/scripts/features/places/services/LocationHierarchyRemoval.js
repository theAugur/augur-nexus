import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { ShopStore } from "../../shops/services/ShopStore.js";

/** Remove campaign places without deleting the scenes they represent. */
export class LocationHierarchyRemoval {
    static inspect(locationId) {
        const root = LocationEntityStore.getLocation(locationId);
        if (!root) return null;
        const locations = [root];
        const ids = new Set([root.id]);
        const all = LocationEntityStore.getLocations();
        for (let index = 0; index < locations.length; index++) {
            const parent = locations[index];
            for (const candidate of all) {
                const ref = candidate.hierarchy?.parent;
                const contained = (ref?.kind === "location" && ref.locationId === parent.id)
                    || (ref?.kind === "scene" && parent.scenes?.primarySceneId && ref.sceneId === parent.scenes.primarySceneId);
                if (!contained || ids.has(candidate.id)) continue;
                ids.add(candidate.id);
                locations.push(candidate);
            }
        }
        const shops = ShopStore.getShops().filter(shop => ids.has(shop.hierarchy?.parentLocationId));
        const signature = JSON.stringify({
            locations: locations.map(location => [location.id, location.hierarchy, location.scenes]).sort(),
            shops: shops.map(shop => shop.id).sort()
        });
        return { locations, shops, signature };
    }

    static async remove(locationId, { expectedSignature } = {}) {
        if (!game.user?.isGM) throw new Error("Only a GM can remove a Location hierarchy.");
        const impact = this.inspect(locationId);
        if (!impact || !expectedSignature || impact.signature !== expectedSignature) {
            throw new Error("The contained places changed. Review the action again before continuing.");
        }
        for (const shop of impact.shops) await ShopStore.deleteShop(shop.id);
        for (const location of [...impact.locations].reverse()) {
            await LocationEntityStore.deleteLocation(location.id, { deleteOwnedScene: false });
        }
        return true;
    }
}
