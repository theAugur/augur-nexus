import { NexusDeletionConfirmation } from "../../deletion/applications/NexusDeletionConfirmation.js";
import { NexusDeletionPlanBuilder } from "../../deletion/services/NexusDeletionPlanBuilder.js";
import { NexusSceneDeletionCoordinator } from "../../nexus/services/NexusSceneDeletionCoordinator.js";

export class PlaceDeletionManager {
    static async deleteLocationBranch(locationId) {
        const plan = NexusDeletionPlanBuilder.buildForLocation(locationId);
        const root = plan.locations?.find(row => row.id === String(locationId || "")) || null;
        if (!root) return false;
        const participantImpacts = NexusSceneDeletionCoordinator.getPlanParticipantImpacts(plan, {
            intent: "delete-location",
            source: "location-delete"
        });

        const decision = await NexusDeletionConfirmation.confirm(plan, {
            title: "Delete Location Branch",
            message: `Delete <strong>${foundry.utils.escapeHTML(root.name)}</strong> and everything explicitly contained beneath it?`,
            confirmLabel: "Delete Branch",
            participantImpacts
        });
        if (!decision) return false;

        const executed = await NexusSceneDeletionCoordinator.executePlan(plan, {
            intent: "delete-location",
            source: "location-delete",
            selectedEntityIds: decision.selectedEntityIds || []
        });
        return executed !== false;
    }
}
