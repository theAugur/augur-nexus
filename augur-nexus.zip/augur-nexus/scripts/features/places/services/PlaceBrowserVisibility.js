import { NexusLineageManager } from "../../nexus/services/NexusLineageManager.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";
import { SiteRecordManager } from "../../site/services/SiteRecordManager.js";
import { SiteSceneVisibilityManager } from "../../site/services/SiteSceneVisibilityManager.js";
import { PlaceTypeRegistry } from "./PlaceTypeRegistry.js";

/** Browser-only branch exclusion, before missing parents can be promoted into roots. */
export class PlaceBrowserVisibility {
    static filterNodes(nodes = [], { lineageRows = null, user = game.user } = {}) {
        if (user?.isGM) return nodes;
        const rows = Array.isArray(lineageRows) ? lineageRows : NexusLineageManager.getLineageRows().rows;
        const aliases = PlaceTypeRegistry.getProjectionAliases(nodes);
        const children = new Map(), blocked = new Set();
        const connect = (parent, child) => {
            if (!parent || !child || parent === child) return;
            if (!children.has(parent)) children.set(parent, new Set());
            children.get(parent).add(child);
        };
        for (const node of nodes) {
            connect(node.parentKey, node.key);
            if (node.isPlayerHidden) blocked.add(node.key);
        }
        const representations = new Map(rows.map(row => {
            const sceneKey = row.sceneId ? `scene:${row.sceneId}` : null;
            const siteKey = row.parentSceneId && row.siteId ? `site:${row.parentSceneId}:${row.siteId}` : null;
            return [row.id, [...new Set([sceneKey, siteKey, aliases.get(sceneKey)].filter(Boolean))]];
        }));
        for (const row of rows) {
            const keys = representations.get(row.id);
            // Linked Scenes, their Site row and an owning Location describe the same browser place.
            for (const key of keys) { connect(keys[0], key); connect(key, keys[0]); }
            for (const parent of representations.get(row.parentNodeId) || [row.parentNodeId]) {
                for (const child of keys) connect(parent, child);
            }
            const scene = row.sceneId ? game.scenes.get(row.sceneId) : null;
            let visible = row.nodeKind === "scene"
                ? NexusPlayerSceneAccess.canUserSeeSceneInNexus(scene, user)
                : !!row.parentNodeId && representations.has(row.parentNodeId);
            const parentScene = row.parentSceneId ? game.scenes.get(row.parentSceneId) : null;
            const record = parentScene && row.siteId ? SiteRecordManager.getSceneRecord(parentScene, row.siteId) : null;
            if (record && !SiteSceneVisibilityManager.canUserSeeSite({ scene: parentScene, siteId: row.siteId, linkedScene: scene, record }, user)) visible = false;
            if (!visible) for (const key of keys) blocked.add(key);
        }
        const pending = [...blocked];
        for (let index = 0; index < pending.length; index++) {
            for (const child of children.get(pending[index]) || []) {
                if (blocked.has(child)) continue;
                blocked.add(child); pending.push(child);
            }
        }
        return nodes.filter(node => !blocked.has(node.key));
    }
}
