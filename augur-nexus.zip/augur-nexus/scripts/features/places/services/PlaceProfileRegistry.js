/** Feature-owned panels hosted in the workspace's place dossier. */
export class PlaceProfileRegistry {
    static #providers = new Map();

    /** createPanel({scene, record, target, host}) returns prepare/activate/handleAction/snapshot/restore/dispose.
     * ownsSurface opts into the whole dossier, including its title, actions and navigation.
     * navigationTheme may opt into a shared host surround such as "bound-star-chart".
     * prepare({compact, controlsHtml}) receives canonical visibility controls for full-surface hosts. */
    static register({ id, moduleId, priority = 0, isAvailable, createPanel } = {}) {
        if (!id || typeof isAvailable !== "function" || typeof createPanel !== "function") {
            throw new Error("Place profiles require an id, isAvailable(context), and createPanel(context).");
        }
        this.#providers.set(id, { id, moduleId, priority, isAvailable, createPanel });
        return () => this.#providers.delete(id);
    }

    static async createPanel(context) {
        for (const provider of [...this.#providers.values()].sort((a, b) => b.priority - a.priority)) {
            if (provider.moduleId && !game.modules.get(provider.moduleId)?.active) continue;
            if (provider.isAvailable(context)) return provider.createPanel(context);
        }
        return null;
    }
}
