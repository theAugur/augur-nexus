const entries = [
    ".nexus-browser-pill-shell", ".nexus-browser-people-group-header",
    ".nexus-browser-connection-row-wrap", ".nexus-browser-connection-group > h4",
    ".q-sidebar-card", ".q-browser-row", ".q-quest-folder-header", ".nexus-player-directory-row",
    // Empty child containers must not fall through to an enclosing entity's menu.
    ".nexus-browser-connection-drawer", ".nexus-browser-people-group-rows", ".q-quest-folder-entries"
].join(",");
const menus = ["toggleNpcOptions", "toggleFactionOptions", "toggleShipOptions", "toggleLocationOptions",
    "toggleShopOptions", "toggleSceneOptions", "openLineageConnectionActions", "openLineageConnectionGroupActions",
    "questListquestOptions", "questListfolderMenu"].map(action => `[data-action="${action}"]`)
    .concat('[data-action="playerDirectoryAction"][data-intent="options"]').join(",");
const bindings = new WeakMap();

/** Right-click delegates to the entry's existing accessible options button. */
export function bindNexusBrowserContextMenu(root) {
    if (!root?.addEventListener || bindings.has(root)) return;
    const state = { dragging: false, suppressUntil: 0 };
    bindings.set(root, state);
    root.addEventListener("dragstart", event => {
        state.dragging = true;
        // A row may reject the drag after capture; no dragend follows a cancelled start.
        Promise.resolve().then(() => { if (event.defaultPrevented) state.dragging = false; });
    }, true);
    root.addEventListener("dragend", () => { state.dragging = false; state.suppressUntil = Date.now() + 150; }, true);
    root.addEventListener("contextmenu", event => {
        const target = event.target?.closest ? event.target : event.target?.parentElement;
        if (!target || !target.closest(".nexus-browser-panel-shell")) return;
        if (target.closest('input, textarea, select, [contenteditable="true"], a[href]')) return;
        const entry = target.closest(entries);
        if (!entry || !root.contains(entry) || entry.closest("[hidden]")) return;
        const button = [...entry.querySelectorAll(menus)].find(candidate => candidate.closest(entries) === entry);
        if (!button || button.disabled || button.closest("[hidden]")) return;
        const control = target.closest("button, [role='button'], [data-action]");
        // Opening an entry is part of the entry surface; other controls keep their own behavior.
        if (control && control !== entry && control !== button && !control.matches('[data-action="openLineageConnection"], [data-action="questListopen"], [data-action="questListtoggleFolder"], [data-action="openFactionDossier"], [data-action="playerDirectoryAction"][data-intent="open"]')) return;
        event.preventDefault();
        event.stopPropagation();
        if (state.dragging || Date.now() < state.suppressUntil) return;
        button.click();
    });
}
