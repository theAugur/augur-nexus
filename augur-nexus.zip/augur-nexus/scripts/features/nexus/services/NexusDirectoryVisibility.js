const MODULE_ID = "augur-nexus";
const FLAG = "hideFromNexus";

// Directory exclusions are independent of scene permissions and marker visibility.
export class NexusDirectoryVisibility {
    static isHidden(document) {
        return document?.getFlag(MODULE_ID, FLAG) === true;
    }

    static async setHidden(document, hidden) {
        if (!game.user?.isGM || !document) return;
        await document.setFlag(MODULE_ID, FLAG, !!hidden);
    }

    static buildFolderReasons() {
        const reasons = new Map();
        const visiting = new Set();
        const resolve = folder => {
            if (!folder || folder.type !== "Scene") return "";
            if (reasons.has(folder.id)) return reasons.get(folder.id);
            if (visiting.has(folder.id)) return "";
            visiting.add(folder.id);
            const parentId = folder.folder?.id || folder.folder;
            const reason = this.isHidden(folder)
                ? `Hidden by folder: ${folder.name}`
                : resolve(game.folders.get(parentId));
            visiting.delete(folder.id);
            reasons.set(folder.id, reason);
            return reason;
        };
        for (const folder of game.folders.contents) resolve(folder);
        return reasons;
    }

    static filterRows(rows, { showHidden = false } = {}) {
        const folderReasons = this.buildFolderReasons();
        const reasons = new Map();
        const result = [];
        // Hierarchy rows are parent-first, so branch inheritance is one lookup.
        for (const row of rows) {
            const sceneId = row.lineageNode ? row.sceneId : row.primarySceneId;
            const scene = sceneId ? game.scenes.get(sceneId) : null;
            const folderId = scene?.folder?.id || scene?.folder;
            const reason = reasons.get(row.parentNodeId)
                || (this.isHidden(scene) ? "Hidden from Nexus" : "")
                || folderReasons.get(folderId) || "";
            reasons.set(row.id, reason ? `Hidden by parent: ${row.name}` : "");
            if (reason && !(game.user?.isGM && showHidden)) continue;
            result.push({ ...row, isNexusHidden: !!reason, nexusHiddenReason: reason });
        }
        const parents = new Set(result.map(row => row.parentNodeId).filter(Boolean));
        return result.map(row => ({ ...row, hasChildren: parents.has(row.id) }));
    }
}
