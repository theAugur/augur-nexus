import { getSceneTransitionProvider, prepareSceneTransition } from "../../../api/scene-transitions.js";

export class NexusSceneTransition {
    static #pending = null;

    static async transitionToScene(targetScene, {
        fromScene = canvas.scene, focusPlaceable = null, transitionStyle = "zoom-fade",
        audience = game.user.isGM ? "all" : "self", direction = "forward"
    } = {}) {
        if (!targetScene) throw new Error("No target scene provided for transition.");
        if (this.#pending) return this.#pending;
        const task = this.#navigate(targetScene, { fromScene, focusPlaceable, transitionStyle, audience, direction });
        this.#pending = task;
        try { return await task; }
        finally { this.#pending = null; }
    }

    static async returnToParent(scene, navigation) {
        const target = game.scenes.get(navigation?.parentSceneId);
        if (!target) return false;
        const focus = this.#findFocusDocument(target, navigation.transitionContext);
        await this.transitionToScene(target, { fromScene: scene || canvas.scene, focusPlaceable: focus,
            transitionStyle: navigation.transitionStyle || "scene-default", direction: "back" });
        return true;
    }

    static async #navigate(targetScene, options) {
        const shared = game.user.isGM && options.audience === "all";
        const participants = shared ? game.users.filter(user => user.active).map(user => user.id) : [game.user.id];
        const request = { owner: "augur-nexus", sourceSceneId: options.fromScene?.id,
            targetSceneId: targetScene.id, participants, direction: options.direction,
            transitionStyle: options.transitionStyle,
            focus: options.focusPlaceable ? this.#getPlaceableViewBox(options.focusPlaceable) : null };
        const provider = getSceneTransitionProvider();
        const cinematic = shared && options.transitionStyle !== "none" && provider
            && game.settings.get("augur-nexus", "cinematicSceneTransitions") !== false;
        let navigation;
        const commit = ({ cinematic = false } = {}) => {
            if (!navigation) {
                prepareSceneTransition(request);
                navigation = this.#showScene(targetScene, { shared, participants, cinematic });
            }
            return navigation;
        };
        if (cinematic) {
            try { await provider.play(request, commit); }
            catch (error) {
                // A failed effect must not retry a scene activation that already began.
                if (navigation || error.code === "TRANSITION_BUSY") throw error;
                console.warn("Augur Nexus | Cinematic transition unavailable; using normal navigation", error);
                await commit();
            }
        } else await commit();
        return targetScene;
    }

    static async #showScene(scene, { shared, participants, cinematic }) {
        const viewOptions = cinematic && Number(game.release.generation) >= 14 ? { transition: { type: null } } : {};
        if (shared) {
            if (scene.active) {
                const others = participants.filter(id => id !== game.user.id);
                if (others.length) scene.pullUsers(others, viewOptions);
            } else await scene.activate({ viewOptions });
        }
        // Activation starts drawing asynchronously. Do not issue a competing view while it is loading.
        if (canvas.loading) await this.#waitForIdle();
        if (canvas.scene?.id !== scene.id) await scene.view(viewOptions);
        return scene;
    }

    static #waitForIdle() {
        return new Promise((resolve, reject) => {
            // V14 can remain loading after canvasReady, so the hook alone is insufficient.
            const deadline = Date.now() + 15000;
            const check = () => {
                if (!canvas.loading) return resolve();
                if (Date.now() >= deadline) return reject(new Error("Scene loading did not complete."));
                setTimeout(check, 25);
            };
            check();
        });
    }

    static #findFocusDocument(scene, context = {}) {
        const type = String(context.placeableType || context.documentName || "").toLowerCase();
        const collections = type.startsWith("tile") ? [scene.tiles] : type.startsWith("drawing") ? [scene.drawings]
            : type.startsWith("note") ? [scene.notes] : [scene.notes, scene.tiles, scene.drawings];
        const documents = collections.flatMap(collection => collection?.contents || []);
        const id = context.noteId || context.placeableId || context.tileId || context.drawingId;
        return documents.find(doc => doc.id === id) || documents.find(doc => context.moduleId && context.flagKey
            && context.flagValue && doc.flags?.[context.moduleId]?.[context.flagKey] === context.flagValue) || null;
    }

    static #getPlaceableViewBox(placeable) {
        const doc = placeable?.document || placeable;
        if (!doc) throw new Error("Could not resolve placeable geometry for transition.");

        if (doc.documentName === "Note") {
            const size = doc.iconSize || 80;
            return {
                x: doc.x - (size / 2),
                y: doc.y - (size / 2),
                width: size,
                height: size
            };
        }

        if (doc.documentName === "Tile" && placeable?.mesh) {
            const width = Number(placeable.mesh.width) || doc.width;
            const height = Number(placeable.mesh.height) || doc.height;
            const anchorX = doc.texture?.anchorX ?? 0;
            const anchorY = doc.texture?.anchorY ?? 0;
            return {
                x: placeable.mesh.position.x - (width * anchorX),
                y: placeable.mesh.position.y - (height * anchorY),
                width,
                height
            };
        }

        return {
            x: doc.x,
            y: doc.y,
            width: doc.width ?? doc.shape?.width,
            height: doc.height ?? doc.shape?.height
        };
    }

}
