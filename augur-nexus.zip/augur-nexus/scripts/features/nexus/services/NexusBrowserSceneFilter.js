import { sceneHasContext } from "../../../support/scene/NexusSceneContextRegistry.js";
import { NexusDirectoryVisibility } from "./NexusDirectoryVisibility.js";

const MODULE_ID = "augur-nexus";
const INCLUDE_FLAG = "alwaysShowInNexus";
const GENERATED_CONTEXTS = [
    "hexlands:hexland", "instant-dungeons:dungeon", "instant-dungeons:settlement",
    "augur-scifi:system", "augur-scifi:sector", "augur-scifi:planet", "augur-scifi:moon", "augur-scifi:site"
];

// Browser presentation only: the raw place hierarchy and relationship indexes stay complete.
export class NexusBrowserSceneFilter {
    static isAlwaysShown(scene) {
        return scene?.getFlag(MODULE_ID, INCLUDE_FLAG) === true;
    }

    static async setAlwaysShown(scene, included) {
        if (!game.user?.isGM || !scene) return;
        if (included) await scene.setFlag(MODULE_ID, INCLUDE_FLAG, true);
        else await scene.unsetFlag(MODULE_ID, INCLUDE_FLAG);
    }

    static getVisibilityMenuItem(scene, { ordinaryRoot = false, hiddenReason = "" } = {}) {
        if (!game.user?.isGM || !scene) return null;
        const excluded = !!hiddenReason || NexusDirectoryVisibility.isHidden(scene)
            || (ordinaryRoot && !this.isAlwaysShown(scene));
        return {
            id: "nexus-directory-visibility",
            label: excluded ? "Show in Nexus" : "Hide from Nexus",
            icon: excluded ? "fas fa-square-plus" : "fas fa-square-minus",
            title: `${excluded ? "Add to" : "Remove from"} Nexus browser; player visibility is unchanged`,
            onSelect: async () => {
                if (excluded && ordinaryRoot) await this.setAlwaysShown(scene, true);
                await NexusDirectoryVisibility.setHidden(scene, !excluded);
                // Showing a scene never changes its parent's or folder's preference.
                if (excluded && hiddenReason.startsWith("Hidden by ")) {
                    ui.notifications.info(`${hiddenReason}. Show the parent or folder in Nexus to reveal this scene.`);
                }
            }
        };
    }

    static organizeMenuItems(items) {
        const accessIds = ["player-nexus-visibility", "player-location-visibility", "player-npc-visibility", "player-faction-visibility", "player-ship-visibility", "player-view-access"];
        const navigationIds = ["workspace", "new-tab", "standalone"];
        const access = accessIds.flatMap(id => items.filter(item => item.id === id));
        const membership = items.filter(item => item.id === "nexus-directory-visibility");
        const navigation = navigationIds.flatMap(id => items.filter(item => item.id === id));
        const grouped = new Set([...access, ...membership, ...navigation]);
        const remaining = items.filter(item => item.type !== "separator" && !grouped.has(item));
        return [access, navigation, [...membership, ...remaining]].filter(group => group.length)
            .flatMap((group, index) => index ? [{ type: "separator" }, ...group] : group);
    }

    static getOrdinaryRootSceneIds(rows) {
        return new Set(rows.filter(row => {
            if (row.parentNodeId || row.type !== "scene") return false;
            const scene = game.scenes.get(row.sceneId);
            if (!scene) return false;
            return !row.hasChildren
                && scene.getFlag(MODULE_ID, "nexusRoot") !== true
                && !scene.getFlag(MODULE_ID, "rootSceneCreation")?.sceneType
                && !GENERATED_CONTEXTS.some(context => sceneHasContext(scene, context));
        }).map(row => row.sceneId));
    }

    static filterRows(rows, { showAll = false, ordinaryRootSceneIds = this.getOrdinaryRootSceneIds(rows) } = {}) {
        if (game.user?.isGM && showAll) return rows;
        const includedBranches = new Map();
        return rows.filter(row => {
            const included = row.parentNodeId
                ? includedBranches.get(row.parentNodeId) === true
                : !ordinaryRootSceneIds.has(row.sceneId) || this.isAlwaysShown(game.scenes.get(row.sceneId));
            includedBranches.set(row.id, included);
            return included;
        });
    }
}
