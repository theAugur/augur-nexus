const DEFAULT_TAB = "profile";
const TABS = new Set(["profile", "journal"]);

export class DossierTabPreference {
    static DEFAULT_TAB = DEFAULT_TAB;

    static normalizeTab(value, fallback = DEFAULT_TAB) {
        const normalized = String(value || "").trim().toLocaleLowerCase();
        // Preserve extension preferences even while their provider is unavailable.
        if (TABS.has(normalized) || /^extension:[a-z0-9][a-z0-9:_-]*$/.test(normalized)) return normalized;
        return TABS.has(fallback) ? fallback : DEFAULT_TAB;
    }

    static normalizeDossier(dossier = {}) {
        return {
            defaultTab: this.normalizeTab(dossier?.defaultTab),
            hiddenDefaultFields: this.normalizeHiddenDefaultFields(dossier?.hiddenDefaultFields)
        };
    }

    static normalizeHiddenDefaultFields(fields = []) {
        return [...new Set((Array.isArray(fields) ? fields : [])
            .map(field => String(field || '').trim())
            .filter(Boolean))];
    }

    static getDefaultTab(source = {}) {
        return this.normalizeTab(source?.dossier?.defaultTab);
    }

    static getTabLabel(tab, extensions = []) {
        const extension = extensions.find(entry => entry.id === this.normalizeTab(tab));
        if (extension) return extension.label;
        return this.normalizeTab(tab) === "journal" ? "Journal" : "Profile";
    }

    static buildMenuItems(current, onSelect, extensions = []) {
        const available = ["profile", "journal", ...extensions.map(entry => entry.id)];
        const normalized = this.normalizeTab(current);
        const active = available.includes(normalized) ? normalized : DEFAULT_TAB;
        const icons = {
            profile: "fas fa-table-list",
            journal: "fas fa-book-open"
        };

        return available.map(tab => ({
            id: `default-tab-${tab}`,
            label: active === tab ? `${this.getTabLabel(tab, extensions)} (Current)` : this.getTabLabel(tab, extensions),
            icon: icons[tab] || "fas fa-table-list",
            onSelect: () => onSelect?.(tab)
        }));
    }
}
