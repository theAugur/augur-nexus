import { hasPremiumAccess } from "../../access/PremiumAccess.js";
import { openHelp } from "../../../api/help.js";
import { getNexusAccentColor, getNexusTextSize, NEXUS_ACCENT_PRESETS, NEXUS_TEXT_SIZE_PRESETS, setNexusAccentColor, setNexusTextSize } from "../../../support/appearance/NexusAppearance.js";
import { isPlayerWheelEnabled, setPlayerWheelEnabled } from "../../player-gateway/PlayerGatewayAvailability.js";
import { NEXUS_THEMES, getNexusThemePreferences, setNexusThemePreferences } from "../../../support/appearance/NexusThemes.js";
import { resolveDossierCover, setDossierCoverImage } from "../../../support/appearance/DossierCoverPresentation.js";
import { SiteCoverPicker } from "../../site/applications/SiteCoverPicker.js";

export function prepareNexusSettings() {
    const accentColor = getNexusAccentColor(), textSize = getNexusTextSize();
    const appearance = getNexusThemePreferences();
    return {
        isGM: !!game.user.isGM, accentColor, textSize,
        appearance, themePresets: NEXUS_THEMES.map(theme => ({ ...theme, selected: theme.id === appearance.theme })),
        showCoverControls: !!game.user.isGM && appearance.theme === "classic-dark",
        worldCoverSrc: resolveDossierCover(),
        worldCoverCustom: !!String(game.settings.get("augur-nexus", "dossierCoverImage") || "").trim(),
        gmNexusButtonEnabled: game.user.isGM && game.settings.get("augur-nexus", "gmNexusButtonEnabled") !== false,
        showPlayerWheelSetting: game.user.isGM && hasPremiumAccess(),
        playerWheelEnabled: isPlayerWheelEnabled(),
        showSceneTransitions: game.user.isGM && game.modules.get("augur-cinema-fx")?.active === true,
        sceneTransitionsEnabled: game.settings.get("augur-nexus", "cinematicSceneTransitions") !== false,
        customAccentSelected: !NEXUS_ACCENT_PRESETS.some(preset => preset.value.toLowerCase() === accentColor.toLowerCase()),
        accentPresets: NEXUS_ACCENT_PRESETS.map(preset => ({ ...preset, selected: preset.value.toLowerCase() === accentColor.toLowerCase() })),
        textSizePresets: NEXUS_TEXT_SIZE_PRESETS.map(preset => ({ ...preset, selected: preset.id === textSize }))
    };
}

async function updateSetting(app, label, update) {
    try { await update(); }
    catch (error) { ui.notifications.error(`Could not update ${label}: ${error.message}`); }
    app.render();
}

export const nexusSettingsActions = {
    openNexusAppearanceHelp() { return openHelp("augur-nexus:appearance"); },
    async setNexusTheme(_event, button) { return updateSetting(this, "theme", () => setNexusThemePreferences({ theme: button.dataset.theme })); },
    async toggleNexusDossierCover() { return updateSetting(this, "dossier cover", () => setNexusThemePreferences({ showCover: !getNexusThemePreferences().showCover })); },
    chooseNexusDossierCover() {
        if (!game.user.isGM) return;
        return SiteCoverPicker.show({ current: resolveDossierCover(),
            onSelect: path => updateSetting(this, "dossier cover", () => setDossierCoverImage(path)) });
    },
    async resetNexusDossierCover() { return updateSetting(this, "dossier cover", () => setDossierCoverImage("")); },
    async togglePlayerWheelSystem() {
        if (!game.user.isGM || !hasPremiumAccess()) return;
        return updateSetting(this, "Player Wheel", () => setPlayerWheelEnabled(!isPlayerWheelEnabled()));
    },
    async toggleGmNexusButton() {
        if (!game.user.isGM) return;
        return updateSetting(this, "Nexus Wheel", () => game.settings.set("augur-nexus", "gmNexusButtonEnabled", !game.settings.get("augur-nexus", "gmNexusButtonEnabled")));
    },
    async toggleSceneTransitions() {
        if (!game.user.isGM || !game.modules.get("augur-cinema-fx")?.active) return;
        return updateSetting(this, "scene transitions", () => game.settings.set("augur-nexus", "cinematicSceneTransitions", game.settings.get("augur-nexus", "cinematicSceneTransitions") === false));
    },
    async setNexusAccent(_event, button) {
        if (!game.user.isGM) return;
        return updateSetting(this, "Nexus accent", () => setNexusAccentColor(button.dataset.accent));
    },
    async setNexusTextSize(_event, button) {
        return updateSetting(this, "text size", () => setNexusTextSize(button.dataset.textSize));
    }
};

const pickers = new WeakSet();
export function bindNexusSettingsPanel(app, root) {
    const picker = root.querySelector("[data-nexus-accent-picker]");
    if (!picker || pickers.has(picker)) return;
    pickers.add(picker);
    picker.addEventListener("change", event => {
        if (game.user.isGM) void updateSetting(app, "Nexus accent", () => setNexusAccentColor(event.currentTarget.value));
    });
}
