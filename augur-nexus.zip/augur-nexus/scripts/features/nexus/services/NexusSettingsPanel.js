import { getNexusAccentColor, getNexusTextSize, NEXUS_ACCENT_PRESETS, NEXUS_TEXT_SIZE_PRESETS, setNexusAccentColor, setNexusTextSize } from "../../../support/appearance/NexusAppearance.js";
import { isPlayerWheelEnabled, setPlayerWheelEnabled } from "../../player-gateway/PlayerGatewayAvailability.js";

export function prepareNexusSettings() {
    const accentColor = getNexusAccentColor(), textSize = getNexusTextSize();
    return {
        isGM: !!game.user.isGM, accentColor, textSize,
        gmNexusButtonEnabled: game.user.isGM && game.settings.get("augur-nexus", "gmNexusButtonEnabled") !== false,
        showPlayerWheelSetting: game.user.isGM && !!(game.modules.get("augur-fantasy")?.active || game.modules.get("augur-scifi")?.active),
        playerWheelEnabled: isPlayerWheelEnabled(),
        showSceneTransitions: game.user.isGM && game.modules.get("augur-cinema-fx")?.active === true,
        sceneTransitionsEnabled: game.settings.get("augur-nexus", "cinematicSceneTransitions") !== false,
        customAccentSelected: !NEXUS_ACCENT_PRESETS.some(preset => preset.value.toLowerCase() === accentColor.toLowerCase()),
        accentPresets: NEXUS_ACCENT_PRESETS.map(preset => ({ ...preset, selected: preset.value.toLowerCase() === accentColor.toLowerCase() })),
        textSizePresets: NEXUS_TEXT_SIZE_PRESETS.map(preset => ({ ...preset, selected: preset.id === textSize }))
    };
}

async function updateSetting(app, label, update) {
    try { await update(); }
    catch (error) { ui.notifications.error(`Could not update ${label}: ${error.message}`); }
    app.render();
}

export const nexusSettingsActions = {
    async togglePlayerWheelSystem() {
        if (!game.user.isGM || (!game.modules.get("augur-fantasy")?.active && !game.modules.get("augur-scifi")?.active)) return;
        return updateSetting(this, "Player Wheel", () => setPlayerWheelEnabled(!isPlayerWheelEnabled()));
    },
    async toggleGmNexusButton() {
        if (!game.user.isGM) return;
        return updateSetting(this, "Nexus Wheel", () => game.settings.set("augur-nexus", "gmNexusButtonEnabled", !game.settings.get("augur-nexus", "gmNexusButtonEnabled")));
    },
    async toggleSceneTransitions() {
        if (!game.user.isGM || !game.modules.get("augur-cinema-fx")?.active) return;
        return updateSetting(this, "scene transitions", () => game.settings.set("augur-nexus", "cinematicSceneTransitions", game.settings.get("augur-nexus", "cinematicSceneTransitions") === false));
    },
    async setNexusAccent(_event, button) {
        if (!game.user.isGM) return;
        return updateSetting(this, "Nexus accent", () => setNexusAccentColor(button.dataset.accent));
    },
    async setNexusTextSize(_event, button) {
        return updateSetting(this, "text size", () => setNexusTextSize(button.dataset.textSize));
    }
};

const pickers = new WeakSet();
export function bindNexusSettingsPanel(app, root) {
    const picker = root.querySelector("[data-nexus-accent-picker]");
    if (!picker || pickers.has(picker)) return;
    pickers.add(picker);
    picker.addEventListener("change", event => {
        if (game.user.isGM) void updateSetting(app, "Nexus accent", () => setNexusAccentColor(event.currentTarget.value));
    });
}
