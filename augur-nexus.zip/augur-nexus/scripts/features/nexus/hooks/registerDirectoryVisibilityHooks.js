import { NexusDirectoryVisibility } from "../services/NexusDirectoryVisibility.js";
import { NexusBrowserRefreshScheduler } from "../services/NexusBrowserRefreshScheduler.js";

export function registerDirectoryVisibilityHooks() {
    Hooks.on("getFolderContextOptions", (app, items) => {
        if (app.documentName !== "Scene" || !game.user?.isGM) return;
        const getFolder = header => {
            const uuid = header.closest(".directory-item")?.dataset.uuid;
            const folder = uuid ? fromUuidSync(uuid) : null;
            return folder?.type === "Scene" && !folder.pack ? folder : null;
        };
        for (const hidden of [false, true]) {
            items.push({
                name: hidden ? "Show Folder in Nexus" : "Hide Folder from Nexus",
                icon: `<i class="fas fa-${hidden ? "eye" : "eye-slash"}"></i>`,
                condition: header => {
                    const folder = getFolder(header);
                    return !!folder && NexusDirectoryVisibility.isHidden(folder) === hidden;
                },
                callback: header => NexusDirectoryVisibility.setHidden(getFolder(header), !hidden)
            });
        }
    });
    for (const hook of ["createFolder", "updateFolder", "deleteFolder"]) {
        Hooks.on(hook, folder => {
            if (folder.type === "Scene") NexusBrowserRefreshScheduler.schedule(hook);
        });
    }
}
