export class NexusBrowserVisibilityInfo {
    static #pending = new Map();

    static show({ onShowAll } = {}) {
        const user = game.user;
        if (!user?.isGM) return;
        if (this.#pending.has(user.id)) return this.#pending.get(user.id);
        const pending = this.#show(onShowAll).finally(() => this.#pending.delete(user.id));
        this.#pending.set(user.id, pending);
        return pending;
    }

    static async #show(onShowAll) {
        try {
            const result = await foundry.applications.api.DialogV2.wait({
                window: { title: "A focused Nexus browser" },
                position: { width: 440 },
                rejectClose: false,
                content: `<p>Nexus now opens with a focused view of generated scenes and linked branches, including Sites and Locations. Your existing Hide from Nexus exclusions still apply.</p>
                    <p>Turn on <strong>Show all</strong> to browse ordinary scenes and hidden entries too. This changes only the browser display: no content is deleted, moved, or unlinked.</p>
                    <p>Older empty or image scenes created through Nexus may appear only with Show all. Open a scene's options and choose <strong>Show in Nexus</strong> to keep it in the focused view. Choose <strong>Hide from Nexus</strong> to hide it again. Scenes inside a hidden parent or folder stay hidden until that parent or folder is shown.</p>
                    <p>Player permissions still apply. Use the <strong>?</strong> beside Show all to read this again.</p>`,
                buttons: [
                    { action: "got-it", label: "Got it", icon: "fas fa-check", default: true },
                    { action: "show-all", label: "Show all scenes", icon: "fas fa-list" }
                ]
            });
            if (!["got-it", "show-all"].includes(result)) return;
            if (result === "show-all") onShowAll?.();
        } catch (error) {
            console.error("Augur: Nexus | Failed to show browser information.", error);
            ui.notifications.error("Could not open Nexus browser help. Please try again.");
        }
    }
}
