import { activateNexusPickerAppearance, deactivateNexusPickerAppearance } from "../../../api/appearance.js";

export function activatePlayerVisibilityAppearance(application) {
    application.element?.classList.add("nexus-player-visibility-window");
    activateNexusPickerAppearance(application);
}

export function deactivatePlayerVisibilityAppearance(application) {
    deactivateNexusPickerAppearance(application);
}

/** Keep native DialogV2 results and callbacks while sharing the live control palette. */
export async function waitForPlayerVisibilityDialog(options) {
    let application;
    try {
        return await foundry.applications.api.DialogV2.wait({
            ...options,
            render: (event, dialog) => {
                application = dialog;
                activatePlayerVisibilityAppearance(dialog);
                return options.render?.(event, dialog);
            },
            close: (event, dialog) => {
                deactivatePlayerVisibilityAppearance(dialog);
                return options.close?.(event, dialog);
            }
        });
    } finally {
        if (application) deactivatePlayerVisibilityAppearance(application);
    }
}
