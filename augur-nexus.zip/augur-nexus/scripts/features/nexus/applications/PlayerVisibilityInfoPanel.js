import { EntityDisclosure } from "../../campaign-entities/models/EntityDisclosure.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

const INFO_CONTENT = {
    visibility: {
        title: "Visible To Players",
        icon: "fas fa-eye",
        intro: "Controls whether players can see this place in Nexus and on the parent map.",
        rows: [
            {
                icon: "fas fa-layer-group",
                label: "Global",
                text: "Use the world default from Player Visibility."
            },
            {
                icon: "fas fa-eye",
                label: "Yes",
                text: "Show this place to players even if the global setting is Explicit Only."
            },
            {
                icon: "fas fa-eye-slash",
                label: "No",
                text: "Hide this place from players even if the global setting shows all Nexus scenes."
            }
        ],
        note: "GMs still see hidden places in Nexus. Hidden map pins appear translucent for GMs and are unavailable to players."
    },
    sceneOpen: {
        title: "Player Scene Open",
        icon: "fas fa-door-open",
        intro: "Controls whether players can use Nexus buttons to open an existing scene on their own client.",
        rows: [
            {
                icon: "fas fa-layer-group",
                label: "Global",
                text: "Use the world default from Player Scene Viewing."
            },
            {
                icon: "fas fa-door-open",
                label: "Allowed",
                text: "Players may open this scene from Nexus if Foundry permissions and vision also allow it."
            },
            {
                icon: "fas fa-ban",
                label: "Blocked",
                text: "Players cannot open this scene from Nexus, even if it remains visible in the Nexus tab."
            }
        ],
        note: "This does not control whether the place appears in Nexus or on the map. Use Visible To Players for that."
    },
    connectionVisibility: {
        title: "Connection Visibility",
        icon: "fas fa-share-nodes",
        intro: "Controls whether players can see an individual Nexus connection.",
        rows: [
            {
                icon: "fas fa-layer-group",
                label: "Global",
                text: "Use the world default from Connection Visibility."
            },
            {
                icon: "fas fa-eye",
                label: "Yes",
                text: "Show this connection to players even if the global setting is Explicit Only."
            },
            {
                icon: "fas fa-eye-slash",
                label: "No",
                text: "Hide this connection from players even if the global setting shows all connections."
            }
        ],
        note: "GMs still see hidden connections. This hides the relationship, not the connected object itself."
    },
    npcVisibility: {
        title: "People Visibility",
        icon: "fas fa-user",
        intro: "Controls whether players can see this person in Nexus and through Person connections.",
        rows: [
            {
                icon: "fas fa-layer-group",
                label: "Global",
                text: "Use the world default from People Visibility."
            },
            {
                icon: "fas fa-eye",
                label: "Yes",
                text: "Show this person to players even if the global setting is Explicit Only."
            },
            {
                icon: "fas fa-eye-slash",
                label: "No",
                text: "Hide this person from players even if the global setting shows all people."
            }
        ],
        note: "GMs still see hidden people in Nexus. Hidden Persons are not shown to players in People or through visible connections."
    },
    campaignEntityVisibility: {
        title: "Entity Visibility",
        icon: "fas fa-users-viewfinder",
        intro: "Controls whether players can see this person, organization, or ship in Nexus, on the map, and through visible connections.",
        rows: [
            {
                icon: "fas fa-layer-group",
                label: "Global",
                text: "Use the world default for this entity type."
            },
            {
                icon: "fas fa-eye",
                label: "Yes",
                text: "Show this entity to players even if the global setting is Explicit Only."
            },
            {
                icon: "fas fa-eye-slash",
                label: "No",
                text: "Hide this entity from players even if the global setting shows all entities of this type."
            }
        ],
        note: "GMs still see hidden entities in Nexus. Hidden entities are not shown to players in their tab, on map markers, or through visible connections."
    },
    locationDisclosure: {
        title: "Location Player Details",
        icon: "fas fa-map-location-dot",
        intro: "Controls how much players may learn from a visible Location before they visit it.",
        rows: [
            {
                icon: "fas fa-layer-group",
                label: "Global",
                text: "Use the world default from Default Location Details."
            },
            {
                icon: "fas fa-map-location-dot",
                label: "Visited",
                text: "Open the normal player-facing Location view. Other visibility rules still apply."
            },
            {
                icon: "fas fa-map",
                label: "Unvisited",
                text: "Show only the Location icon, name, and an Unvisited message."
            }
        ],
        note: "This does not make the Location visible. Visible To Players separately controls whether players know the Location exists. GMs always see complete Location details."
    }
};

export class PlayerVisibilityInfoPanel extends HandlebarsApplicationMixin(ApplicationV2) {
    #content = INFO_CONTENT.visibility;

    static DEFAULT_OPTIONS = {
        id: "augur-nexus-player-visibility-info",
        classes: ["augur-nexus", "player-visibility-info"],
        tag: "div",
        window: {
            title: "Player Visibility",
            resizable: false,
            minimizable: false
        },
        position: {
            width: 460,
            height: "auto"
        }
    };

    static PARTS = {
        main: {
            template: "modules/augur-nexus/templates/nexus/player-visibility-info.hbs"
        }
    };

    static show(topic = "visibility") {
        const app = new this({ topic });
        app.render(true, { focus: true });
        return app;
    }

    static showDisclosure(type, section) {
        if (!EntityDisclosure.sections({ type }).includes(section)) return null;
        const app = new this({ disclosure: { type, section } });
        app.render(true, { focus: true });
        return app;
    }

    constructor({ topic = "visibility", disclosure = null } = {}, options = {}) {
        super(options);
        this.#content = INFO_CONTENT[topic] || INFO_CONTENT.visibility;
        if (disclosure) this.#content = this.#disclosureContent(disclosure.type, disclosure.section);
    }

    _prepareContext() {
        return this.#content;
    }

    #disclosureContent(type, section) {
        const category = EntityDisclosure.categoryLabel(type, section);
        const owner = { npc: "NPC", faction: "faction", location: "location", ship: "ship" }[type];
        const entry = { traits: "personality trait", beliefs: "belief", thread: type === "ship" ? "assignment entry" : "current thread entry" }[section];
        return {
            title: `${category} Visibility`,
            icon: "fas fa-eye",
            intro: `Choose whether players can see a particular ${entry} on this ${owner}. Only GMs can change these controls.`,
            rows: [
                { icon: "fas fa-layer-group", label: "Global", text: `Follow the ${category} default. Visible or Hidden in parentheses shows the current result.` },
                { icon: "fas fa-eye", label: "Yes", text: `Reveal this ${entry}, even when the global default is Hidden.` },
                { icon: "fas fa-eye-slash", label: "No", text: `Hide this ${entry}, even when the global default is Visible.` },
                { icon: "fas fa-list", label: "Hide all / Reveal all", text: `Set every entry in this section of this ${owner} to No or Yes. Other objects and sections are unaffected.` },
                { icon: "fas fa-layer-group", label: "Reset all to Global", text: `Remove individual choices in this section of this ${owner}, so its entries follow the global default again.` },
                { icon: "fas fa-sliders", label: "Change global default", text: `Change ${category} across the world. Only entries set to Global follow the change; explicit Yes and No choices stay. Other categories have separate defaults.` }
            ],
            note: "Hidden entries remain visible to GMs with a slashed-eye icon. These choices apply in both the workspace and standalone dossier. Revealing a detail does not grant access to its parent object."
        };
    }
}
