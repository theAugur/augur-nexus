import { prepareNexusSettings, nexusSettingsActions, bindNexusSettingsPanel } from "../services/NexusSettingsPanel.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class NexusSettingsApplication extends HandlebarsApplicationMixin(ApplicationV2) {
    static #instance;
    static DEFAULT_OPTIONS = {
        id: "nexus-settings", classes: ["augur-nexus", "augur-theme-fantasy", "nexus-settings-window"],
        window: { title: "Nexus Settings", icon: "fas fa-cog", resizable: false, minimizable: true },
        position: { width: 340, height: "auto" }, actions: nexusSettingsActions
    };
    static PARTS = { body: { template: "modules/augur-nexus/templates/nexus/settings-panel.hbs" } };
    #appearanceHook;

    static async show() {
        if (!game.user.isGM) return null;
        const app = this.#instance ??= new this();
        if (!app.rendered) await app.render({ force: true });
        if (app.minimized) await app.maximize();
        app.bringToFront();
        return app;
    }
    _prepareContext() { return prepareNexusSettings(); }
    _onFirstRender(context, options) {
        super._onFirstRender(context, options);
        this.#appearanceHook = Hooks.on("augurNexusAppearanceChanged", () => { if (this.rendered) void this.render({ force: true }); });
    }
    _attachPartListeners(partId, element, options) {
        super._attachPartListeners(partId, element, options);
        bindNexusSettingsPanel(this, element);
    }
    async close(options) {
        if (this.#appearanceHook) Hooks.off("augurNexusAppearanceChanged", this.#appearanceHook);
        this.#appearanceHook = null;
        await super.close(options);
        if (NexusSettingsApplication.#instance === this) NexusSettingsApplication.#instance = null;
        return this;
    }
}
