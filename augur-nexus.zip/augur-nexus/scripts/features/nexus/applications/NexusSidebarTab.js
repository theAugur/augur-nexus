// Compact Nexus browser in Foundry's sidebar; the toolbar opens the campaign workspace.

import { NexusBrowserApplicationMixin } from "./NexusBrowserApplicationMixin.js?v=20260805-site-branch-notice";

const { HandlebarsApplicationMixin } = foundry.applications.api;
const { AbstractSidebarTab } = foundry.applications.sidebar;

export class NexusSidebarTab extends NexusBrowserApplicationMixin(HandlebarsApplicationMixin(AbstractSidebarTab)) {
    static tabName = "nexus";

    static DEFAULT_OPTIONS = {
        ...super.DEFAULT_OPTIONS,
        id: "nexus",
        classes: ["tab", "sidebar-tab", "augur-nexus", "augur-theme-fantasy", "nexus-browser-sidebar-tab"],
        window: {
            title: "Nexus"
        }
    };
}
