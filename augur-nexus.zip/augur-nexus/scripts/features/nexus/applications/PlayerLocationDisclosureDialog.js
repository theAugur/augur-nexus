import { openActionMenu } from "../../../api/ui.js";
import { CampaignEntityDisclosureManager } from "../../campaign-entities/services/CampaignEntityDisclosureManager.js";
import { PlayerVisibilityInfoPanel } from "./PlayerVisibilityInfoPanel.js";

export class PlayerLocationDisclosureDialog {
    static openEntityMenu({ anchor = null, position = null, location, onChanged = null } = {}) {
        if (!game.user?.isGM || (!anchor && !position) || !location) return;
        const current = CampaignEntityDisclosureManager.getPlayerDisclosureOverride(location);
        const global = CampaignEntityDisclosureManager.getGlobalPlayerDisclosure("location");
        const globalLabel = global === "full" ? "Visited" : "Unvisited";
        const setValue = async value => {
            await CampaignEntityDisclosureManager.setPlayerDisclosureOverride(location.id, "location", value);
            await onChanged?.();
        };
        openActionMenu({
            anchor,
            position,
            className: "nexus-scene-player-access-menu",
            items: [
                {
                    id: "inherit",
                    label: `Global (${globalLabel})${current === "inherit" ? " - Current" : ""}`,
                    icon: "fas fa-layer-group",
                    onSelect: () => setValue("inherit")
                },
                {
                    id: "full",
                    label: current === "full" ? "Visited (Current)" : "Visited",
                    icon: "fas fa-map-location-dot",
                    onSelect: () => setValue("full")
                },
                {
                    id: "limited",
                    label: current === "limited" ? "Unvisited (Current)" : "Unvisited",
                    icon: "fas fa-map",
                    onSelect: () => setValue("limited")
                },
                {
                    id: "change-global",
                    label: "Change Global Default...",
                    icon: "fas fa-sliders",
                    onSelect: () => this.showGlobalSetting()
                },
                {
                    id: "player-disclosure-info",
                    label: "What's this?",
                    icon: "fas fa-circle-info",
                    onSelect: () => PlayerVisibilityInfoPanel.show("locationDisclosure")
                }
            ]
        });
    }

    static async showGlobalSetting() {
        if (!game.user?.isGM) return null;
        const current = CampaignEntityDisclosureManager.getGlobalPlayerDisclosure("location");
        const result = await foundry.applications.api.DialogV2.wait({
            window: { title: "Default Location Details" },
            position: { width: 470 },
            modal: true,
            rejectClose: false,
            content: `
                <div class="nexus-player-open-dialog">
                    <p>Choose the default player view for visible Locations. Each Location can override this from its Player Details menu.</p>
                    <div class="nexus-player-open-options">
                        <label class="nexus-player-open-option">
                            <input type="radio" name="playerLocationDisclosure" value="full" ${current === "full" ? "checked" : ""}>
                            <span><strong>Open Information</strong><small>Visible Locations show their normal player details unless marked Unvisited.</small></span>
                        </label>
                        <label class="nexus-player-open-option">
                            <input type="radio" name="playerLocationDisclosure" value="limited" ${current === "limited" ? "checked" : ""}>
                            <span><strong>Exploration</strong><small>Visible Locations begin with the limited Unvisited view unless marked Visited.</small></span>
                        </label>
                    </div>
                </div>
            `,
            buttons: [
                {
                    action: "save",
                    label: "Save",
                    icon: "fa-solid fa-check",
                    default: true,
                    callback: (_event, button) => button.form?.elements?.playerLocationDisclosure?.value || current
                },
                {
                    action: "cancel",
                    label: "Cancel",
                    icon: "fa-solid fa-xmark",
                    callback: () => null
                }
            ]
        });
        if (!result) return null;
        return CampaignEntityDisclosureManager.setGlobalPlayerDisclosure("location", result);
    }
}
