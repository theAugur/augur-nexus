export const QUEST_STATES = Object.freeze({ available: "Available", ongoing: "Ongoing", finished: "Finished" });
export const GOAL_STATES = Object.freeze({ pending: "Pending", completed: "Completed", failed: "Failed", obsolete: "Obsolete" });
export const QUEST_INTENTS = Object.freeze({
    find: { label: "Find", icon: "fa-magnifying-glass", context: "Last known location" },
    rescue: { label: "Rescue", icon: "fa-hand-holding-heart", context: "Held at", opposition: "Captor" },
    recover: { label: "Recover", icon: "fa-box-open", context: "Recover from" },
    deliver: { label: "Deliver", icon: "fa-box", context: "Destination" },
    escort: { label: "Escort", icon: "fa-person-walking-arrow-right", context: "Destination" },
    investigate: { label: "Investigate", icon: "fa-eye", context: "Relevant location" },
    defend: { label: "Defend", icon: "fa-shield-halved", context: "Rally at", opposition: "Threat" },
    capture: { label: "Capture", icon: "fa-flag", context: "Approach from", opposition: "Defended by" },
    establish: { label: "Establish", icon: "fa-seedling", context: "Build at" },
    eliminate: { label: "Eliminate", icon: "fa-crosshairs", context: "Last known location" },
    custom: { label: "Custom", icon: "fa-circle-dot", context: "Destination" }
});
export const QUEST_SLOTS = Object.freeze({ giver: "Quest giver", target: "Target", destination: "Location", opposition: "Opposition", ally: "Ally", reward: "Reward", context: "Involved", custom: "Custom" });
const imagePath = value => {
    const path = String(value || "").trim();
    if (/^(?:javascript|data|vbscript):/i.test(path)) throw new Error("Choose an image file path.");
    return path;
};
const string = value => String(value ?? "").trim();

export function canReadQuest(quest, user) {
    return !!user && (user.isGM || quest.audience === "all");
}
export function canEditQuest(quest, user) { return !!user && (user.isGM || quest.ownerId === user.id); }

function rewardNotes(values, randomId) {
    const seen = new Set();
    return (Array.isArray(values) ? values : []).map(value => {
        const id = string(value.id) || randomId();
        if (seen.has(id)) throw new Error("Duplicate reward entry.");
        seen.add(id);
        return { id, text: string(value.text) };
    }).filter(value => value.text);
}

function customComponents(values, randomId) {
    const seen = new Set();
    return (Array.isArray(values) ? values : []).map(value => {
        const id = string(value.id) || randomId();
        const label = string(value.label);
        if (!label) throw new Error("Name the custom component.");
        if (seen.has(id)) throw new Error("Duplicate custom component ID.");
        seen.add(id);
        return { id, label };
    });
}

export function normalizeQuest(input, { id, ownerId, randomId, previous } = {}) {
    if (input.audience !== undefined && !["private", "all"].includes(input.audience)) throw new Error("Choose GM only or Players visibility.");
    if (input.status !== undefined && !Object.hasOwn(QUEST_STATES, input.status)) throw new Error("Choose Available, Ongoing or Finished.");
    const entries = values => {
        const seen = new Set();
        return (Array.isArray(values) ? values : []).map(value => {
            const entryId = string(value.id) || randomId();
            if (seen.has(entryId)) throw new Error("Duplicate quest entry.");
            seen.add(entryId);
            return { id: entryId, text: string(value.text), description: string(value.description), hidden: value.hidden === true,
                customComponents: customComponents(value.customComponents, randomId),
                intent: Object.hasOwn(QUEST_INTENTS, value.intent) ? value.intent : "find",
                customIntent: value.intent === "custom" ? string(value.customIntent) : "",
                    namedTarget: value.namedTarget?.name ? { name: string(value.namedTarget.name), image: imagePath(value.namedTarget.image) } : null,
                    status: Object.hasOwn(GOAL_STATES, value.status) ? value.status : "pending" };
        });
    };
    const title = string(input.title);
    const image = imagePath(input.image);
    return {
        id: previous?.id || id, ownerId: previous?.ownerId || ownerId,
        title, image, journalHtml: string(input.journalHtml), gmNotes: string(input.gmNotes),
        rewardNotes: rewardNotes(input.rewardNotes, randomId),
        rewardsHidden: input.rewardsHidden === true,
        status: Object.hasOwn(QUEST_STATES, input.status) ? input.status : "available",
        audience: ["private", "all"].includes(input.audience) ? input.audience : "private",
        // Browser presentation only; audience remains the authority for read permissions.
        browserUserIds: Array.isArray(input.browserUserIds) ? [...new Set(input.browserUserIds.filter(id => typeof id === "string" && id.trim()))] : null,
        objectives: entries(input.objectives),
        notes: previous?.notes || [], revision: (previous?.revision || 0) + 1,
        createdAt: previous?.createdAt || Date.now(), updatedAt: Date.now()
    };
}

export function projectQuest(quest, user) {
    if (!canReadQuest(quest, user)) return null;
    const view = structuredClone(quest);
    if (!user.isGM) {
        delete view.gmNotes;
        view.objectives = view.objectives.filter(entry => !entry.hidden);
        if (view.rewardsHidden) view.rewardNotes = [];
        delete view.rewardsHidden;
    }
    return { ...view, canEdit: canEditQuest(quest, user), isGM: user.isGM, statusLabel: QUEST_STATES[quest.status], closed: quest.status === "finished", canEditRewards: canEditQuest(quest, user) && (user.isGM || !quest.rewardsHidden) };
}

export function assertQuestRevision(quest, revision) {
    if (revision !== quest.revision) throw new Error("This quest changed. Refresh it before making that change.");
}

// Titles and goal captions resolve from authorized references; a hidden target's name is never cached here.
export function questPresentation(quest) {
    const connections = quest.connections || [];
    const goals = (quest.objectives || []).map(goal => {
        const intent = QUEST_INTENTS[goal.intent] || QUEST_INTENTS.find;
        const intentLabel = goal.intent === "custom" ? string(goal.customIntent) || intent.label : intent.label;
        const attached = connections.filter(edge => edge.goalId === goal.id);
        const target = attached.find(edge => edge.slot === "target");
        const subject = target?.name || goal.namedTarget?.name || "";
        return { ...goal, intentLabel, intentIcon: intent.icon, contextLabel: intent.context,
            oppositionLabel: intent.opposition || "Opposition", target, targetName: subject,
            caption: goal.text || (subject ? `${intentLabel} ${subject}` : intentLabel),
            destination: attached.find(edge => edge.slot === "destination"), opposition: attached.find(edge => edge.slot === "opposition"), ally: attached.find(edge => edge.slot === "ally"),
            customComponents: (goal.customComponents || []).map(component => ({ ...component, entity: attached.find(edge => edge.slot === "custom" && edge.componentId === component.id) })),
            done: goal.status === "completed", failed: goal.status === "failed", obsolete: goal.status === "obsolete" };
    });
    const customTitle = Object.hasOwn(quest, "customTitle") ? quest.customTitle : quest.title;
    return { customTitle: customTitle || "", title: customTitle || (goals[0]?.targetName || goals[0]?.text ? goals[0].caption : "New quest"), goals,
        giver: connections.find(edge => edge.slot === "giver"), rewardItems: connections.filter(edge => edge.slot === "reward"), supporting: connections.filter(edge => !edge.goalId && (!edge.slot || ["context", "ally"].includes(edge.slot))) };
}
