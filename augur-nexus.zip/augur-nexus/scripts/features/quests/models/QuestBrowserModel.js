import { QUEST_STATES } from "./QuestModel.js";
export const QUEST_FILTERS = QUEST_STATES;
export function visibleQuestRows(rows, user) {
    return rows.filter(quest => user?.isGM || (quest.audience === "all" &&
        (!Array.isArray(quest.browserUserIds) || quest.browserUserIds.includes(user?.id))));
}
export function filterQuestRows(rows, { filter = "available", query = "" } = {}) {
    return rows.filter(q => q.status === filter && (!query ||
        (q.title + " " + q.goals.map(g => g.caption).join(" ")).toLocaleLowerCase().includes(query.toLocaleLowerCase())))
        .map(q => ({ ...q, image: q.image || q.goals[0]?.target?.image || q.giver?.image,
            progress: q.objectives.filter(v => v.status === "completed").length, total: q.objectives.length,
            goalPreview: q.goals.map(g => g.caption).join(" · "), cast: q.connections.slice(0, 5) }));
}
