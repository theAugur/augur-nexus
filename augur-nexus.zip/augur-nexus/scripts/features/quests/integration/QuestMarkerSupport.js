import { QuestRecordStore } from "../storage/QuestRecordStore.js";


// Marker identity resolves from the quest document; artwork is a disposable presentation snapshot.
export function resolveQuestMarkerEntity(id) {
    const document = QuestRecordStore.document(id);
    return document ? { ...QuestRecordStore.read(document), type: "quest", uuid: document.uuid, journalEntryId: document.id } : null;
}
export const questMarkerConfig = {
    type: "quest", label: "Quest", icon: "fas fa-scroll", open: async id => (await import("../../../api/quests.js")).openQuest(id),
    model: {
        getName: entity => entity.title || "Quest",
        getImage: entity => entity.image || "icons/svg/scroll.svg",
        getAccent: () => ""
    }
};
export async function resolveQuestMarkerPresentation(id) {
    const { getQuest } = await import("../../../api/quests.js");
    const quest = await getQuest(id);
    return { ...resolveQuestMarkerEntity(id), title: quest.title,
        image: quest.image || quest.goals?.[0]?.target?.image || quest.giver?.image || "icons/svg/scroll.svg" };
}
