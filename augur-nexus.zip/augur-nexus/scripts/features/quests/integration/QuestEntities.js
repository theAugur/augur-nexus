import { NexusPlayerEntityAdapter } from "../../player-context/NexusPlayerEntityAdapter.js";
import { CampaignEntityVisibilityManager } from "../../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { PlayerAccessService, canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { resolveConnectionDrop } from "../../../api/connections.js";

// Nexus directory drags identify the entity, not its backing JournalEntry.
// Resolve that identity from storage; drag labels and images are never authoritative.
export async function resolveQuestDrop(event) {
    let data;
    try { data = JSON.parse(event?.dataTransfer?.getData("text/plain") || event?.dataTransfer?.getData("application/json") || "{}"); }
    catch { return null; }
    if (data?.kind === "nexus-entity" || data?.type === "AugurNexusEntity") {
        return NexusPlayerEntityAdapter.list().find(({ entity }) => entity.id === data.entityId)?.document.uuid || null;
    }
    if (data?.uuid) return data.uuid;
    const target = await resolveConnectionDrop(event, { convertActors: false });
    return target?.uuid || null;
}

export async function resolveQuestEntity(uuid, user) {
    if (!/^(?:(?:JournalEntry|Actor|Scene|Item)\.[A-Za-z0-9]+|Actor\.[A-Za-z0-9]+\.Item\.[A-Za-z0-9]+)$/.test(uuid || "")) return null;
    const doc = await fromUuid(uuid).catch(() => null);
    if (!doc || doc.pack) return null;
    const record = NexusPlayerEntityAdapter.resolve(uuid);
    const permitted = user.isGM || (doc.testUserPermission(user, "OBSERVER") && (record
        ? CampaignEntityVisibilityManager.canUserSee(record.entity, user) || canControlPlayerEntity(doc, user)
        : true));
    if (!permitted) return null;
    const node = record ? ConnectionTargetResolver.fromCampaignEntity(record.entity, doc) : ConnectionTargetResolver.fromDocument(doc);
    return { uuid, name: node?.name || doc.name, image: node?.img || doc.img || "icons/svg/book.svg", type: record?.entity.type || doc.documentName };
}

export async function openQuestEntity(uuid) {
    const doc = await fromUuid(uuid);
    if (!doc || !await resolveQuestEntity(uuid, game.user)) throw new Error("This entity is no longer available.");
    const record = NexusPlayerEntityAdapter.resolve(uuid);
    if (!record) return doc.sheet.render(true);
    const node = ConnectionTargetResolver.fromCampaignEntity(record.entity, doc);
    return ConnectionTargetResolver.openNode(node);
}

export async function resolveQuestLogCharacter(user) {
    const actor = user.character;
    if (!actor?.testUserPermission(user, "OWNER")) return `User.${user.id}`;
    const person = PlayerAccessService.identity(user).person;
    if (person && await resolveQuestEntity(person.document.uuid, user)) return person.document.uuid;
    return actor.uuid;
}
