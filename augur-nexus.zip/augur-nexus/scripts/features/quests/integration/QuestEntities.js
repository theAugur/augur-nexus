import { NexusPlayerEntityAdapter } from "../../player-context/NexusPlayerEntityAdapter.js";
import { CampaignEntityVisibilityManager } from "../../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { PlayerAccessService, canControlPlayerEntity } from "../../player-context/PlayerAccessService.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { SiteSceneVisibilityManager } from "../../site/services/SiteSceneVisibilityManager.js";
import { DEFAULT_SITE_ICON_SRC } from "../../site/services/SiteIconDefaults.js";
import { NexusPlayerSceneAccess } from "../../nexus/services/NexusPlayerSceneAccess.js";
import { resolveConnectionDrop } from "../../../api/connections.js";

// Nexus directory drags identify the entity, not its backing JournalEntry.
// Resolve that identity from storage; drag labels and images are never authoritative.
export async function resolveQuestDrop(event) {
    const target = await resolveConnectionDrop(event, { convertActors: false });
    if (target) return target;
    // Native Scene-directory drops are supported here without changing other connection consumers.
    let data;
    try { data = JSON.parse(event?.dataTransfer?.getData("text/plain") || event?.dataTransfer?.getData("application/json") || "null"); }
    catch { return null; }
    const match = /^Scene\.([A-Za-z0-9]+)$/.exec(data?.uuid || "");
    return match ? ConnectionTargetResolver.fromSceneReference({ sceneId: match[1] }) : null;
}

async function resolveQuestCompendiumItem(uuid, user) {
    let parsed;
    try { parsed = foundry.utils.parseUuid(uuid); }
    catch { return null; }
    const pack = parsed?.collection;
    if (pack?.documentName !== "Item" || parsed.type !== "Item" || parsed.embedded?.length) return null;
    // Quest projections run on the GM client; check the recipient's pack access before fetching.
    if (!pack.testUserPermission(user, "OBSERVER")) return null;
    const doc = await fromUuid(uuid).catch(() => null);
    if (!doc || doc.documentName !== "Item" || doc.pack !== pack.collection || doc.parent) return null;
    const node = ConnectionTargetResolver.fromDocument(doc);
    if (!node) return null;
    return { target: node, targetId: node.id, uuid: doc.uuid, name: node.name || doc.name,
        image: node.img || doc.img || "icons/svg/book.svg", type: "Item" };
}

export async function resolveQuestEntity(reference, user) {
    if (reference && typeof reference === "object" && ["nexus-site", "nexus-scene"].includes(reference.kind)) {
        const target = ConnectionTargetResolver.fromNexusNode(reference);
        const node = target ? await ConnectionTargetResolver.resolveDisplayNode(target) : null;
        if (!node || node.missing) return null;
        const scene = game.scenes.get(node.kind === "nexus-site" ? node.parentSceneId : node.sceneId);
        if (!NexusPlayerSceneAccess.canUserSeeSceneInNexus(scene, user)) return null;
        if (node.kind === "nexus-site" && !SiteSceneVisibilityManager.canUserSeeSite({ scene, siteId: node.siteId }, user)) return null;
        return { target: node, targetId: node.id, name: node.name, image: node.img || DEFAULT_SITE_ICON_SRC, type: node.kind === "nexus-site" ? "Site" : "Scene" };
    }
    // Old UUID requests and bindings enter the same document resolution path.
    const entityRecord = reference?.kind === "nexus-entity"
        ? NexusPlayerEntityAdapter.list().find(record => record.entity.id === reference.entityId)
        : null;
    const resolved = reference?.kind === "nexus-entity" && !entityRecord
        ? await ConnectionTargetResolver.resolveDisplayNode(ConnectionTargetResolver.fromEntityReference({ entityId: reference.entityId }))
        : null;
    if (resolved?.missing) return null;
    const uuid = typeof reference === "string" ? reference : entityRecord?.document.uuid || resolved?.uuid || reference?.uuid;
    if (typeof uuid === "string" && uuid.startsWith("Compendium.")) return resolveQuestCompendiumItem(uuid, user);
    if (!/^(?:(?:JournalEntry|Actor|Scene|Item)\.[A-Za-z0-9]+|Actor\.[A-Za-z0-9]+\.Item\.[A-Za-z0-9]+)$/.test(uuid || "")) return null;
    const doc = await fromUuid(uuid).catch(() => null);
    if (!doc || doc.pack) return null;
    const record = NexusPlayerEntityAdapter.resolve(uuid);
    const permitted = user.isGM || (doc.testUserPermission(user, "OBSERVER") && (record
        ? CampaignEntityVisibilityManager.canUserSee(record.entity, user) || canControlPlayerEntity(doc, user)
        : true));
    if (!permitted) return null;
    const node = record ? ConnectionTargetResolver.fromCampaignEntity(record.entity, doc) : ConnectionTargetResolver.fromDocument(doc);
    // Native Scene drops and older document links use the same icon as Nexus scene markers.
    const image = doc.documentName === "Scene"
        ? ConnectionTargetResolver.fromSceneReference({ sceneId: doc.id })?.img || DEFAULT_SITE_ICON_SRC
        : node?.img || doc.img || "icons/svg/book.svg";
    return { target: node, targetId: node.id, uuid, name: node?.name || doc.name, image, type: record?.entity.type || doc.documentName };
}

export async function openQuestEntity(reference) {
    const entity = await resolveQuestEntity(reference, game.user);
    if (!entity) throw new Error("This entity is no longer available.");
    return ConnectionTargetResolver.openNode(entity.target);
}

export async function resolveQuestLogCharacter(user) {
    const actor = user.character;
    if (!actor?.testUserPermission(user, "OWNER")) return `User.${user.id}`;
    const person = PlayerAccessService.identity(user).person;
    if (person && await resolveQuestEntity(person.document.uuid, user)) return person.document.uuid;
    return actor.uuid;
}
