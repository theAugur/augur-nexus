import { QuestFolderStore } from "../storage/QuestFolderStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";

const MIME = "application/x-augur-quest";
let draggedQuest = "";

export function bindQuestFolderDragDrop(element, host) {
    host.questDropEvents?.abort();
    host.questDropEvents = new AbortController();
    if (!game.user.isGM) return;
    const options = { signal: host.questDropEvents.signal };
    const clear = () => element.querySelectorAll(".q-folder-drop-active").forEach(el => el.classList.remove("q-folder-drop-active"));
    for (const card of element.querySelectorAll('[data-action="questListopen"]')) {
        card.draggable = true;
        card.addEventListener("dragstart", event => {
            const document = game.journal.get(card.dataset.id);
            const quest = document?.getFlag("augur-nexus", "campaignEntity");
            if (quest?.type !== "quest") return;
            draggedQuest = document.id;
            ConnectionTargetResolver.setDragData(event.dataTransfer, ConnectionTargetResolver.fromCampaignEntity({ ...quest, id: document.id, uuid: document.uuid }));
            event.dataTransfer.setData(MIME, document.id);
        }, options);
        card.addEventListener("dragend", () => { draggedQuest = ""; clear(); }, options);
    }
    for (const target of element.querySelectorAll("[data-quest-folder-drop]")) {
        target.addEventListener("dragover", event => {
            if (!draggedQuest || !event.dataTransfer.types.includes(MIME)) return;
            event.preventDefault(); event.stopPropagation();
            event.dataTransfer.dropEffect = "move";
            clear(); target.classList.add("q-folder-drop-active");
        }, options);
        target.addEventListener("dragleave", event => {
            if (!target.contains(event.relatedTarget)) target.classList.remove("q-folder-drop-active");
        }, options);
        target.addEventListener("drop", event => {
            const id = event.dataTransfer.getData(MIME);
            if (!id) return;
            event.preventDefault(); event.stopPropagation(); clear(); draggedQuest = "";
            void host.perform(async () => {
                const folderId = target.dataset.questFolderDrop;
                await QuestFolderStore.move(id, folderId, { direct: true });
                host.collapsedFolders.delete(folderId);
                await host.render({ force: true });
            });
        }, options);
    }
}
