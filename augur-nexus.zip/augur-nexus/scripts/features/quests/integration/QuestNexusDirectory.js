import { listQuests, openQuest, editQuest, openQuests } from "../../../api/quests.js";
import { filterQuestRows, QUEST_FILTERS } from "../models/QuestBrowserModel.js";

export async function prepareQuestDirectory(app) {
    const filter = Object.hasOwn(QUEST_FILTERS, app.questFilter) ? app.questFilter : "available";
    try {
        return { rows: filterQuestRows(await listQuests(), { filter, query: app.questQuery || "" }),
            query: app.questQuery || "", filters: Object.entries(QUEST_FILTERS).map(([id, label]) => ({ id, label, selected: id === filter })) };
    } catch (error) { return { error: error.message }; }
}
export function bindQuestDirectory(app) {
    const run = callback => Promise.resolve().then(callback).catch(error => ui.notifications.error(error.message));
    Object.assign(app.options.actions, {
        questOpen: (_event, button) => run(() => openQuest(button.dataset.id)),
        questCreate: () => run(() => editQuest()),
        questBrowse: () => run(() => openQuests()),
        questFilter: (_event, button) => { app.questFilter = button.dataset.filter; return app.render({force:true}); },
        questSearch: () => { app.questQuery = app.element.querySelector('[name="questSearch"]').value.trim(); return app.render({force:true}); }
    });
}
