import { QuestFolderStore } from "../storage/QuestFolderStore.js";
import { bindQuestFolderDragDrop } from "./QuestFolderDragDrop.js";
import { listQuests, editQuest, openQuests } from "../../../api/quests.js";
import { QUEST_FILTERS } from "../models/QuestBrowserModel.js";
import { prepareQuestBrowserView } from "../applications/QuestBrowserView.js";
import { QuestBrowserActions } from "../applications/QuestBrowserActions.js";

const hosts = new WeakMap();
function browserHost(app) {
    if (!hosts.has(app)) hosts.set(app, {
        collapsedFolders: new Set(),
        render: options => app.render(options),
        async perform(callback) {
            if (this.busy) return;
            this.busy = true;
            try { return await callback(); }
            catch (error) { ui.notifications.error(error.message); }
            finally { this.busy = false; }
        }
    });
    return hosts.get(app);
}
export async function prepareQuestDirectory(app) {
    const filter = Object.hasOwn(QUEST_FILTERS, app.questFilter) ? app.questFilter : "available";
    try {
        const view = await prepareQuestBrowserView(await listQuests(), { filter, collapsed: browserHost(app).collapsedFolders });
        return { ...view, expandFolders: !!view.groups?.length && view.groups.every(folder => !folder.expanded) };
    } catch (error) { return { error: error.message }; }
}
export function bindQuestDirectory(app) {
    const host = browserHost(app);
    bindQuestFolderDragDrop(app.element, host);
    const actions = {};
    for (const name of ["audience", "questOptions", "folderMenu", "toggleFolder", "open"])
        actions["questList" + name] = (event, button) => QuestBrowserActions[name].call(host, event, button);
    Object.assign(app.options.actions, actions, {
        questCreateFolder: (event, button) => QuestBrowserActions.createFolder.call(host, event, button),
        questCreate: () => host.perform(() => editQuest()),
        questCollapseAll: (_event, button) => {
            const expand = button.dataset.expand === "true";
            host.collapsedFolders = expand ? new Set() : new Set(QuestFolderStore.list().map(folder => folder.id));

            return app.render({ force: true });
        },
        questBrowse: () => host.perform(() => openQuests()),
        questFilter: (_event, button) => { app.questFilter = button.dataset.filter; return app.render({force:true}); },

    });
}
