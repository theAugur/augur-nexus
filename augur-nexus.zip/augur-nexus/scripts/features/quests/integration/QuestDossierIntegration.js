import { openQuests, editQuest, openQuest } from "../../../api/quests.js";

export function registerQuestDossierIntegration() {
    const report = error => ui.notifications.error(error.message);
    for (const [name, field] of [["SettlementDossier", "location"], ["NpcDossier", "npc"], ["ShipDossier", "ship"], ["FactionDossier", "faction"], ["LocationDossier", "location"]]) {
        Hooks.on(`render${name}`, (app, element, context) => {
            app.options.actions.openQuestConnection = (_event, button) => void openQuest(button.dataset.questId).catch(report);
            const entity = context?.[field];
            const document = game.journal.find(doc => doc.getFlag("augur-nexus", "campaignEntity")?.id === entity?.id);
            if (!document) return;
            app.questEntityUuid = document.uuid;
        });
        Hooks.on(`getHeaderControls${name}`, (app, controls) => {
            if (!game.user.isGM) return;
            app.options.actions.augurCreateQuest = () => void editQuest("", { entityUuid: app.questEntityUuid || "" }).catch(report);
            controls.push({ action: "augurCreateQuest", icon: "fas fa-scroll", label: "Create quest involving this entity" });
        });
    }
    Hooks.on("renderApplicationV2", (app, element) => {
        if (!element.querySelector?.(".nexus-browser-panel-shell")) return;
        app.options.actions.augurQuests = () => void openQuests().catch(report);
    });
}
