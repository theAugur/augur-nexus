import { executeQuestRequest } from "./QuestService.js";

const MODULE_ID = "augur-nexus", KEY = "playerMainQuest";

export async function getMainQuest({ userId = game.user.id } = {}) {
    if (userId !== game.user.id && !game.user.isGM) throw new Error("You may only read your own main quest.");
    const user = game.users.get(userId), id = user?.getFlag(MODULE_ID, KEY);
    if (!id) return null;
    try {
        const quest = await executeQuestRequest({ action: "get", id }, user);
        return quest.status === "finished" ? null : quest;
    } catch { return null; }
}

export async function selectMainQuest(id) {
    if (id) {
        const quest = await executeQuestRequest({ action: "get", id }, game.user);
        if (quest.status === "finished") throw new Error("Choose an available or ongoing quest.");
    }
    await game.user.setFlag(MODULE_ID, KEY, id || "");
    Hooks.callAll("augurNexusPlayerContextChanged");
}
