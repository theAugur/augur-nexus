import { executeQuestRequest } from "./QuestService.js";
import { createUserFlagRequests } from "../../../support/requests/UserFlagRequests.js";

const requests = createUserFlagRequests({
    moduleId: "augur-nexus", requestKey: "questRequest", resultKey: "questResult", execute: executeQuestRequest,
    unavailableMessage: "A GM must be connected to save quest changes.",
    timeoutMessage: "The GM did not respond. Reopen the quest to check its latest state before retrying."
});
export function registerQuestRequests() { requests.register(); }
export function questRequest(action, {id, data, revision} = {}) {
    const request = {action, id, data, revision};
    if (["get", "list"].includes(action)) return executeQuestRequest(request, game.user);
    return requests.request(request);
}
