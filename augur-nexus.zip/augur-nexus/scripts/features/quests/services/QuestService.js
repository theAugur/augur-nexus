import { QuestRecordStore as Records } from "../storage/QuestRecordStore.js";
import { QuestConnectionStore as Connections } from "../storage/QuestConnectionStore.js";
import { normalizeQuest, projectQuest, canReadQuest, canEditQuest, assertQuestRevision, GOAL_STATES, QUEST_SLOTS, questPresentation } from "../models/QuestModel.js";
import { resolveQuestEntity, resolveQuestLogCharacter } from "../integration/QuestEntities.js";

let writes = Promise.resolve();
export function executeQuestRequest(request, user) {
    if (["get", "list"].includes(request.action)) return execute(request, user);
    if (!game.user.isGM) return Promise.reject(new Error("A GM must execute quest changes."));
    const job = writes.then(() => execute(request, user));
    writes = job.catch(() => {});
    return job;
}
async function project(quest, user, connections) {
    const view = projectQuest(quest, user);
    if (!view) return null;
    view.connections = [];
    for (const edge of connections || await Connections.list(quest.id)) {
        if ((user.isGM || (!edge.hidden && !(edge.slot === "reward" && quest.rewardsHidden))) && (!edge.goalId || view.objectives.some(goal => goal.id === edge.goalId))) {
            const entity = await resolveQuestEntity(edge.target, user);
            if (entity) view.connections.push({ ...edge, ...entity, rolesLabel: edge.roles.join(" Ã‚Â· ") });
            else if (user.isGM) view.connections.push({ ...edge, uuid: edge.targetUuid, name: "Missing or unavailable entity", image: "icons/svg/mystery-man.svg", missing: true, rolesLabel: edge.roles.join(" Ã‚Â· ") });
        }
    }
    return { ...view, ...questPresentation(view) };
}
const cleanJournal = data => Object.hasOwn(data, "journalHtml") ? { ...data, journalHtml: foundry.utils.cleanHTML(String(data.journalHtml || "")) } : { ...data };
async function prepareConnection(data, quest, user) {
    const entity = await resolveQuestEntity(data.target || data.targetUuid, user);
    if (!entity) throw new Error("Drop an accessible person, faction, ship, place, Actor, or Item.");
    const slot = Object.hasOwn(QUEST_SLOTS, data.slot) ? data.slot : "context";
    const goalId = ["giver", "reward"].includes(slot) ? "" : String(data.goalId || "");
    const goal = quest.objectives.find(row => row.id === goalId);
    if ((goalId && (!goal || (goal.hidden && !user.isGM))) || (["target", "destination", "opposition", "ally", "custom"].includes(slot) && !goal)) throw new Error("Choose an accessible quest goal first.");
    const componentId = slot === "custom" ? String(data.componentId || "") : "";
    if (slot === "custom" && !goal?.customComponents?.some(component => component.id === componentId)) throw new Error("That custom component no longer exists.");
    if (slot === "giver" && !["npc", "faction", "location"].includes(entity.type)) throw new Error("The quest giver must be a Nexus person, faction, or location.");
    if (slot === "reward" && quest.rewardsHidden && !user.isGM) throw new Error("Rewards are not editable.");
    if (data.hidden && !user.isGM) throw new Error("Only a GM can conceal a connection.");
    return { questId: quest.id, target: entity.target, targetId: entity.targetId, goalId, slot, componentId, roles: Array.isArray(data.roles) ? data.roles : [QUEST_SLOTS[slot]], hidden: user.isGM && !!data.hidden };
}
async function execute(request, user) {
    if (!user || !game.users.get(user.id)) throw new Error("Unknown player.");
    const { action, id, data = {}, revision } = request;
    if (action === "list") {
        const rows = [];
        const byQuest = new Map();
        for (const edge of await Connections.all()) {
            if (!byQuest.has(edge.questId)) byQuest.set(edge.questId, []);
            byQuest.get(edge.questId).push(edge);
        }
        for (const quest of await Records.all()) {
            if (!canReadQuest(quest, user)) continue;
            const view = await project(quest, user, byQuest.get(quest.id) || []);
            if (!data.entityUuid || view.connections.some(row => row.uuid === data.entityUuid)) {
                // Browsing does not need every contribution and preparation paragraph in transit.
                const { notes, gmNotes, journalHtml, rewardNotes, rewardsHidden, ...summary } = view;
                rows.push(summary);
            }
        }
        return rows.sort((a, b) => b.updatedAt - a.updatedAt);
    }
    if (action === "create") {
        if (!user.isGM) throw new Error("Only a GM can create quests.");
        const quest = normalizeQuest(cleanJournal(data), { id: foundry.utils.randomID(), ownerId: user.id, randomId: () => foundry.utils.randomID() });
        const links = [];
        for (const edge of data.connections || []) links.push(await prepareConnection({ ...edge, targetUuid: edge.targetUuid || edge.uuid }, quest, user));
        for (const edge of links) if (edge.slot === "target") quest.objectives.find(goal => goal.id === edge.goalId).namedTarget = null;
        try {
            await Records.write(quest, { folderId: data.folderId || "" });
            for (const edge of links) await Connections.put(edge);
        } catch (error) {
            await Connections.removeForQuest(quest.id); await Records.remove(quest.id); throw error;
        }
        changed();
        return project(quest, user);
    }
    const quest = await Records.get(id);
    if (!quest || !canReadQuest(quest, user)) throw new Error("This quest is not available to you.");
    if (action === "get") return project(quest, user);
    assertQuestRevision(quest, revision);
    const edit = canEditQuest(quest, user);
    if (["update", "entry", "link", "unlink", "delete"].includes(action) && !edit) throw new Error("Only the quest author or a GM can make that change.");
    if (action === "delete") {
        await Connections.removeForQuest(id);
        await Records.remove(id); changed(); return null;
    }
    let next = structuredClone(quest);
    if (action === "update") {
        if (!user.isGM && Object.hasOwn(data, "audience") && data.audience !== quest.audience) throw new Error("Only a GM can change quest visibility.");
        if (!user.isGM && (data.gmNotes || data.objectives?.some(v => v.hidden) || data.rewardsHidden)) throw new Error("Only a GM can add concealed preparation.");
        const patch = cleanJournal(data);
        if (!user.isGM) {
            patch.browserUserIds = quest.browserUserIds;
            for (const key of ["objectives"]) if (Array.isArray(patch[key])) {
                const hidden = quest[key].filter(row => row.hidden);
                if (patch[key].some(row => hidden.some(secret => secret.id === row.id))) throw new Error("That quest entry is not editable.");
                patch[key] = [...patch[key], ...hidden];
            }
            patch.gmNotes = quest.gmNotes;
            patch.rewardsHidden = quest.rewardsHidden;
            if (quest.rewardsHidden) patch.rewardNotes = quest.rewardNotes;
        }
        next = normalizeQuest({ ...quest, ...patch }, { previous: quest, randomId: () => foundry.utils.randomID() });
    } else if (action === "note") {
        const text = String(data.text || "").trim();
        if (!text) throw new Error("Write a contribution first.");
        const characterUuid = await resolveQuestLogCharacter(user);
        const character = await resolveQuestEntity(characterUuid, user);
        const ownedActor = user.character?.testUserPermission(user, "OWNER") ? user.character : null;
        // Keep the identity used when writing, even if the player later switches characters.
        next.notes.push({ id: foundry.utils.randomID(), authorId: user.id,
            authorName: character?.name || ownedActor?.name || (user.isGM ? "GM" : "Adventurer"),
            characterUuid: character?.uuid || ownedActor?.uuid || "", text });
    } else if (action === "editNote") {
        const note = next.notes.find(row => row.id === data.noteId);
        if (!note || (!user.isGM && note.authorId !== user.id)) throw new Error("Only the entry author or a GM can change this log entry.");
        if (data.remove) next.notes = next.notes.filter(row => row.id !== note.id);
        else {
            const text = String(data.text || "").trim();
            if (!text) throw new Error("Write an entry first.");
            note.text = text;
        }
    } else if (action === "entry") {
        const entry = next.objectives.find(row => row.id === data.entryId);
        if (!entry || (entry.hidden && !user.isGM)) throw new Error("This entry is not available to edit.");
        if (Object.hasOwn(data, "hidden")) {
            if (!user.isGM) throw new Error("Only a GM can reveal preparation.");
            entry.hidden = !!data.hidden;
        }
        if (Object.hasOwn(GOAL_STATES, data.status)) entry.status = data.status;
        for (const key of ["text", "description", "intent", "customIntent", "namedTarget"]) if (Object.hasOwn(data, key)) entry[key] = data[key];
        if (data.remove) next.objectives = next.objectives.filter(row => row.id !== entry.id);
        next = normalizeQuest(next, { previous: quest, randomId: () => foundry.utils.randomID() });
    } else if (action === "link") {
        const edge = await prepareConnection(data, quest, user);
        const connections = await Connections.list(id);
        if (data.replaceEdgeId) {
            const replaced = connections.find(row => row.id === data.replaceEdgeId);
            if (!replaced || ! ["context", "reward"].includes(replaced.slot) || edge.slot !== replaced.slot ||
                (replaced.goalId || "") !== edge.goalId || (replaced.hidden && !user.isGM)) throw new Error("That connection is not editable.");
            Object.assign(edge, { replaceEdgeId: replaced.id, roles: replaced.roles, hidden: replaced.hidden });
        }
        const existing = connections.find(row => (row.goalId || "") === edge.goalId && (row.slot || "context") === edge.slot && (row.componentId || "") === edge.componentId && (["context", "reward"].includes(edge.slot) ? row.targetId === edge.targetId : true));
        if (existing?.hidden && !user.isGM) throw new Error("That connection is not editable.");
        if (edge.replaceEdgeId && existing && existing.id !== edge.replaceEdgeId) throw new Error("That entity is already connected to this quest.");
        await Connections.put(edge);
        if (edge.slot === "target") next.objectives.find(goal => goal.id === edge.goalId).namedTarget = null;
    } else if (action === "unlink") {
        const edge = (await Connections.list(id)).find(row => row.id === data.edgeId);
        if (!edge || (!user.isGM && (edge.hidden || (edge.slot === "reward" && quest.rewardsHidden)))) throw new Error("That connection is not editable.");
        await Connections.remove(data.edgeId, id);
    } else throw new Error("Unknown quest operation.");
    const removedTargets = [];
    if (["update", "entry"].includes(action)) {
        for (const edge of await Connections.list(id)) {
            const goal = next.objectives.find(row => row.id === edge.goalId);
            const removedComponent = edge.slot === "custom" && !goal?.customComponents?.some(component => component.id === edge.componentId);
            if (!removedComponent && (edge.slot !== "target" || !goal?.namedTarget)) continue;
            if (edge.hidden && !user.isGM) throw new Error("That target connection is not editable.");
            removedTargets.push(edge);
        }
    }
    next.revision = quest.revision + 1; next.updatedAt = Date.now();
    await Records.write(next, { writeJournal: Object.hasOwn(data, "journalHtml") });
    for (const edge of removedTargets) await Connections.remove(edge.id, id);
    for (const edge of await Connections.list(id)) if (edge.goalId && !next.objectives.some(goal => goal.id === edge.goalId)) await Connections.remove(edge.id, id);
    changed();
    return project(await Records.get(id), user);
}
function changed() {
    Hooks.callAll("augurNexusQuestsChanged");
    game.socket.emit("module.augur-nexus", { type: "questsChanged" });
}
