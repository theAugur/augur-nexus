import { QuestRecordStore } from "./storage/QuestRecordStore.js";
import { NexusMarkerService } from "../markers/services/NexusMarkerService.js";
import { registerQuestRequests } from "./services/QuestRequests.js";
import { registerQuestDossierIntegration } from "./integration/QuestDossierIntegration.js";
import { questApplications, QuestApplication } from "./applications/QuestApplication.js";
import { openQuests } from "../../api/quests.js";

import { ConnectionStore } from "../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../connections/services/ConnectionTargetResolver.js";

class QuestMenu extends QuestApplication { render() { return openQuests(); } }
export function registerQuestsFeature() {
    registerQuestRequests();
    registerQuestDossierIntegration();
    game.settings.registerMenu("augur-nexus", "quests", { name: "Quests", label: "Open quests", hint: "Campaign quests and personal pursuits.", icon: "fas fa-scroll", type: QuestMenu, restricted: false });
    game.keybindings.register("augur-nexus", "quests", { name: "Open quests", editable: [], onDown: () => { void openQuests().catch(error => ui.notifications.error(error.message)); return true; } });
    let directoryRefresh;
    const refresh = () => {
        for (const app of questApplications) app.refresh();
        clearTimeout(directoryRefresh);
        directoryRefresh = setTimeout(() => {
            for (const app of foundry.applications.instances.values()) {
                if (app.rendered && app.element?.querySelector('.nexus-quest-directory')) void app.render({ force: false });
            }
            if (ui.nexus?.rendered && ui.nexus.element?.querySelector('.nexus-quest-directory')) void ui.nexus.render({ force: false });
        }, 400);
    };
    Hooks.on("augurNexusQuestsChanged", refresh);
    Hooks.on("augurNexusConnectionsChanged", refresh);
    Hooks.on("augurNexusQuestsChanged", () => {
        if (game.user.id !== game.users.activeGM?.id) return;
        for (const document of game.journal.contents) {
            const entity = document.getFlag("augur-nexus", "campaignEntity");
            if (entity?.type !== "quest" || !entity.markerRefs?.length) continue;
            void NexusMarkerService.syncMarkersForTarget({ kind: "campaign-entity", entityType: "quest", entityId: document.id })
                .catch(error => console.error("Nexus | Quest marker sync", error));
        }
    });
    Hooks.on("ready", () => {
        if (game.user.id === game.users.activeGM?.id) void QuestRecordStore.syncReadPermissions().catch(error => console.error("Nexus | Quest read permissions", error));
        game.socket.on("module.augur-nexus", message => { if (message?.type === "questsChanged") refresh(); });
    });
    for (const hook of ["createJournalEntry", "deleteJournalEntry", "updateJournalEntry", "createJournalEntryPage", "updateJournalEntryPage", "deleteJournalEntryPage", "deleteActor", "updateActor", "deleteItem", "updateItem", "deleteScene", "updateScene", "deleteCompendium", "augurNexusCampaignEntityVisibilityChanged"]) Hooks.on(hook, refresh);
    Hooks.on("updateJournalEntry", document => {
        const entity = document.getFlag("augur-nexus", "campaignEntity");
        if (entity?.type === "quest") Hooks.callAll("augurNexusCampaignEntitiesChanged", { reason: "questUpdated", entity: { ...entity, id: document.id } });
    });
    Hooks.on("updateUser", (_user, changes) => {
        const flags = changes.flags?.["augur-nexus"];
        if (flags && ["questRequest", "questResult"].some(key => key in flags)) return;
        refresh();
    });
    Hooks.on("deleteJournalEntry", document => {
        const record = document.getFlag("augur-nexus", "campaignEntity");
        if (!document.pack && record?.type === "quest" && game.user.id === game.users.activeGM?.id) {
            // Removing the quest node already removes every incident edge and its role bindings.
            const markers = (record.markerRefs || []).map(ref => {
                const scene = game.scenes.get(ref.sceneId);
                const tile = scene?.tiles.get(ref.documentId);
                return tile ? NexusMarkerService.deleteMarker(tile, { notify: false, removeOwnerRef: false, scene }) : null;
            });
            void Promise.all([...markers, ConnectionStore.removeNode(ConnectionTargetResolver.getEntityNodeId(document.id))])
                .catch(error => console.error("Nexus | Quest link cleanup", error));
        }
    });
    Hooks.on("updateJournalEntryPage", (page, _changes, options) => {
        const doc = page.parent;
        const quest = doc?.getFlag("augur-nexus", "campaignEntity");
        if (options?.augurQuestWrite || doc?.pack || quest?.type !== "quest" || game.user.id !== game.users.activeGM?.id) return;
        void doc.update({ "flags.augur-nexus.campaignEntity.revision": quest.revision + 1,
            "flags.augur-nexus.campaignEntity.updatedAt": Date.now() }, {augurQuestWrite:true})
            .catch(error => console.error("Nexus | Quest journal revision", error));
    });
}

