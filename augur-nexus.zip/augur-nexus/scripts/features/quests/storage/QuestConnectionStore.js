import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";

// Quest slots are annotations on the ordinary relationship edge, not a second relationship store.
export class QuestConnectionStore {
    static async all() {
        return Object.values(ConnectionStore.getGraph().edges).flatMap(edge => edge.questBindings || []);
    }
    static async list(questId) { return (await this.all()).filter(row => row.questId === questId); }
    static async put({ questId, targetUuid, roles = [], hidden = false, goalId = "", slot = "context", replaceEdgeId }) {
        return ConnectionStore.runBatch(async () => {
            const rows = await this.list(questId);
            const replaced = replaceEdgeId ? rows.find(row => row.id === replaceEdgeId && row.slot === slot && (row.goalId || "") === goalId) : null;
            if (replaceEdgeId && !replaced) throw new Error("This quest connection no longer exists.");
            const existing = replaced || rows.find(row => (row.goalId || "") === goalId && row.slot === slot
                && (["context", "reward"].includes(slot) ? row.targetUuid === targetUuid : true));
            const source = ConnectionTargetResolver.fromDocument(await fromUuid(`JournalEntry.${questId}`));
            const target = ConnectionTargetResolver.fromDocument(await fromUuid(targetUuid));
            if (!source || !target) throw new Error("This quest connection target no longer exists.");
            if (existing && existing.targetUuid !== targetUuid) await this.remove(existing.id, questId);
            const prior = ConnectionStore.getConnectionsForNode(source.id).find(row => row.node.id === target.id)?.edge;
            const edge = prior || await ConnectionStore.addConnection(source, target, {
                sourceView: { category: target.category, role: roles.join(" · ") },
                targetView: { category: "quest", role: roles.join(" · ") }, trackOpinions: false
            });
            const binding = { id: existing?.id || foundry.utils.randomID(), questId, targetUuid, goalId, slot,
                roles: [...new Set(roles.map(role => String(role).trim()).filter(Boolean))], hidden: hidden === true };
            const bindings = [...(edge.questBindings || []).filter(row => row.id !== binding.id), binding];
            await ConnectionStore.updateConnection(edge.id, { questBindings: bindings, questCreatedConnection: edge.questCreatedConnection || !prior });
            return binding;
        }, { reason: "questBinding" });
    }
    static async remove(id, questId) {
        const edge = Object.values(ConnectionStore.getGraph().edges).find(edge => edge.questBindings?.some(row => row.id === id && row.questId === questId));
        if (!edge) throw new Error("This quest connection no longer exists.");
        const bindings = edge.questBindings.filter(row => row.id !== id);
        if (!bindings.length && edge.questCreatedConnection) await ConnectionStore.removeConnection(edge.id);
        else await ConnectionStore.updateConnection(edge.id, { questBindings: bindings });
    }
    static async removeForQuest(id) { for (const row of await this.list(id)) await this.remove(row.id, id); }
}
