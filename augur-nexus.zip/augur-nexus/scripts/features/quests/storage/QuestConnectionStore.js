import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";

// Quest slots are annotations on the ordinary relationship edge, not a second relationship store.
export class QuestConnectionStore {
    static async all() {
        const graph = ConnectionStore.getGraph();
        const rows = [];
        for (const edge of Object.values(graph.edges)) {
            for (const binding of edge.questBindings || []) {
                const questNodeId = ConnectionTargetResolver.getEntityNodeId(binding.questId);
                const targetId = edge.sourceNodeId === questNodeId ? edge.targetNodeId
                    : edge.targetNodeId === questNodeId ? edge.sourceNodeId : null;
                // The edge owns identity. UUID fallback only supports older bindings without a usable endpoint.
                const target = graph.nodes[targetId] || (binding.targetUuid
                    ? ConnectionTargetResolver.fromDocument(await fromUuid(binding.targetUuid).catch(() => null)) : null);
                rows.push({ ...binding, target, targetId: target?.id || "" });
            }
        }
        return rows;
    }
    static async list(questId) { return (await this.all()).filter(row => row.questId === questId); }
    static async put({ questId, target, roles = [], hidden = false, goalId = "", slot = "context", componentId = "", replaceEdgeId }) {
        return ConnectionStore.runBatch(async () => {
            const rows = await this.list(questId);
            const replaced = replaceEdgeId ? rows.find(row => row.id === replaceEdgeId && row.slot === slot && (row.componentId || "") === componentId && (row.goalId || "") === goalId) : null;
            if (replaceEdgeId && !replaced) throw new Error("This quest connection no longer exists.");
            const existing = replaced || rows.find(row => (row.goalId || "") === goalId && row.slot === slot && (row.componentId || "") === componentId
                && (["context", "reward"].includes(slot) ? row.targetId === target?.id : true));
            const source = ConnectionTargetResolver.fromDocument(await fromUuid(`JournalEntry.${questId}`));
            if (!source || !target) throw new Error("This quest connection target no longer exists.");
            if (existing && existing.targetId !== target.id) await this.remove(existing.id, questId);
            const prior = ConnectionStore.getConnectionsForNode(source.id).find(row => row.node.id === target.id)?.edge;
            const edge = prior || await ConnectionStore.addConnection(source, target, {
                sourceView: { category: target.category, role: roles.join(" · ") },
                targetView: { category: "quest", role: roles.join(" · ") }, trackOpinions: false
            });
            const binding = { id: existing?.id || foundry.utils.randomID(), questId, goalId, slot, ...(slot === "custom" ? { componentId } : {}),
                roles: [...new Set(roles.map(role => String(role).trim()).filter(Boolean))], hidden: hidden === true };
            const bindings = [...(edge.questBindings || []).filter(row => row.id !== binding.id), binding];
            await ConnectionStore.updateConnection(edge.id, { questBindings: bindings, questCreatedConnection: edge.questCreatedConnection || !prior });
            return binding;
        }, { reason: "questBinding" });
    }
    static async remove(id, questId) {
        const edge = Object.values(ConnectionStore.getGraph().edges).find(edge => edge.questBindings?.some(row => row.id === id && row.questId === questId));
        if (!edge) throw new Error("This quest connection no longer exists.");
        const bindings = edge.questBindings.filter(row => row.id !== id);
        if (!bindings.length && edge.questCreatedConnection) await ConnectionStore.removeConnection(edge.id);
        else await ConnectionStore.updateConnection(edge.id, { questBindings: bindings });
    }
    static async removeForQuest(id) { for (const row of await this.list(id)) await this.remove(row.id, id); }
}
