const MODULE = "augur-nexus";
let folderCreation;

// A quest is one world JournalEntry. Its prose belongs to its embedded Journal page.
// Dossiers use authorized projections; flag concealment follows the other Nexus entities.
export class QuestRecordStore {
    static document(id) { const doc = game.journal.get(id); return doc?.getFlag(MODULE, "campaignEntity")?.type === "quest" ? doc : null; }
    static read(doc) {
        if (!doc) return null;
        const data = structuredClone(doc.getFlag(MODULE, "campaignEntity"));
        return { ...data, id: doc.id, journalHtml: this.page(doc)?.text?.content || "" };
    }
    static page(doc) { return doc.pages?.contents?.find(page => page.type === "text") || null; }
    static assertGM() { if (!game.user.isGM) throw new Error("Only the GM can access campaign preparation."); }
    static async folder() {
        const existing = game.folders.find(f => f.type === "JournalEntry" && f.getFlag(MODULE, "questFolder"));
        if (existing) return existing;
        folderCreation ||= Folder.create({ name: "Quests", type: "JournalEntry", flags: { [MODULE]: { questFolder: true } } }).finally(() => { folderCreation = null; });
        return folderCreation;
    }
    static async all() { return game.journal.contents.filter(doc => this.document(doc.id)).map(doc => this.read(doc)); }
    static async get(id) { return this.read(this.document(id)); }
    static async write(row, { writeJournal = true } = {}) {
        this.assertGM();
        const { journalHtml, ...data } = structuredClone(row);
        data.type = "quest";
        const doc = this.document(row.id);
        if (!doc && game.journal.has(row.id)) throw new Error("This quest ID is already used by another journal.");
        const text = { content: foundry.utils.cleanHTML(journalHtml || ""), format: 1 };
        if (doc) {
            data.markerRefs = structuredClone(doc.getFlag(MODULE, "campaignEntity")?.markerRefs || []);
            // Update prose only when changed, preserving edits made through the native journal page.
            const page = this.page(doc);
            if (writeJournal && journalHtml !== undefined && page?.text?.content !== text.content) {
                if (page) await page.update({ text }, { augurQuestWrite: true });
                else await doc.createEmbeddedDocuments("JournalEntryPage", [{ name: "Journal", type: "text", text }], { augurQuestWrite: true });
            }
            await doc.update({ "ownership.default": data.audience === "all" ? 2 : 0, name: data.title || "New quest", "flags.augur-nexus.==campaignEntity": data }, { augurQuestWrite: true });
        } else {
            const folder = await this.folder();
            await JournalEntry.create({ _id: row.id, name: data.title || "New quest", folder: folder.id,
                ownership: { default: data.audience === "all" ? 2 : 0 }, flags: { [MODULE]: { campaignEntity: data } },
                pages: [{ name: "Journal", type: "text", text }] }, { keepId: true, augurQuestWrite: true });
        }
        return this.read(this.document(row.id));
    }
    static async syncReadPermissions() {
        this.assertGM();
        for (const doc of game.journal.contents) {
            if (!this.document(doc.id)) continue;
            const permission = doc.getFlag(MODULE, "campaignEntity").audience === "all" ? 2 : 0;
            if (doc.ownership.default !== permission) await doc.update({"ownership.default": permission}, {augurQuestWrite:true});
        }
    }
    static async remove(id) { this.assertGM(); await this.document(id)?.delete(); }
}

