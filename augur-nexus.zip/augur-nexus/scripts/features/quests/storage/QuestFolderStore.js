import { CampaignEntityFolderManager } from "../../campaign-entities/services/CampaignEntityFolderManager.js";
import { deleteQuest } from "../../../api/quests.js";

const MODULE = "augur-nexus";
const parentId = folder => folder?.folder?.id || folder?.folder || null;
let rootCreation;

export class QuestFolderStore {
    static async root() {
        if (!game.user.isGM) throw new Error("Only a GM can organize quest folders.");
        rootCreation ||= CampaignEntityFolderManager.getOrCreateQuestFolder().finally(() => { rootCreation = null; });
        return rootCreation;
    }

    static list() {
        const parent = game.folders.find(folder => folder.type === "JournalEntry" && folder.name === "Augur Campaign Entities" && !parentId(folder));
        const root = parent && game.folders.find(folder => folder.type === "JournalEntry" && folder.name === "Quests" && parentId(folder) === parent.id);
        if (!root) return [];
        const children = new Map();
        for (const folder of game.folders.filter(folder => folder.type === "JournalEntry")) {
            const id = parentId(folder);
            if (!children.has(id)) children.set(id, []);
            children.get(id).push(folder);
        }
        const result = [], visited = new Set([root.id]);
        const visit = id => {
            for (const folder of (children.get(id) || []).sort((a, b) => a.name.localeCompare(b.name))) {
                if (visited.has(folder.id)) continue;
                visited.add(folder.id);
                result.push(folder);
                visit(folder.id);
            }
        };
        visit(root.id);
        return result;
    }

    static async create(name, parentFolderId = "") {
        const label = String(name || "").trim();
        if (!label) throw new Error("Name the quest folder.");
        const root = await this.destination(parentFolderId);
        return Folder.create({ name: label, type: "JournalEntry", folder: root.id });
    }

    static async destination(folderId = "") {
        if (!game.user.isGM) throw new Error("Only a GM can organize quest folders.");
        if (!folderId) return this.root();
        const folder = this.list().find(folder => folder.id === folderId);
        if (!folder) throw new Error("That quest folder no longer exists.");
        return folder;
    }

    static destinations(questId) {
        const folders = this.list();
        const ids = new Set(folders.map(folder => folder.id));
        const current = parentId(game.journal.get(questId));
        const parent = parentId(folders.find(folder => folder.id === current));
        return folders.filter(folder => folder.id !== current && (folder.id === parent || !ids.has(parentId(folder)) || parentId(folder) === current));
    }

    static parentDestination(questId) {
        const folders = this.list();
        const current = folders.find(folder => folder.id === parentId(game.journal.get(questId)));
        return current ? { id: folders.find(folder => folder.id === parentId(current))?.id || "", name: "Parent folder" } : null;
    }

    static async removeKeepingQuests(folderId) {
        if (!folderId) throw new Error("Choose a quest folder to remove.");
        const folder = await this.destination(folderId);
        const destinationId = parentId(folder);
        // Only remove this container; its children retain their identities and contents.
        for (const document of game.journal.contents.filter(document => parentId(document) === folder.id)) {
            await document.update({ folder: destinationId });
        }
        for (const child of this.list().filter(child => parentId(child) === folder.id)) {
            await child.update({ folder: destinationId });
        }
        await folder.delete({ deleteSubfolders: false, deleteContents: false });
    }

    static async rename(folderId, name) {
        const folder = await this.destination(folderId);
        const label = String(name || "").trim();
        if (!label) throw new Error("Name the quest folder.");
        await folder.update({ name: label });
    }

    static deletionPlan(folderId) {
        if (!game.user.isGM) throw new Error("Only a GM can delete quest folders.");
        const folders = this.list();
        const selected = folders.find(folder => folder.id === folderId);
        if (!selected) throw new Error("That quest folder no longer exists.");
        const ids = new Set([folderId]);
        for (const folder of folders) if (ids.has(parentId(folder))) ids.add(folder.id);
        const quests = game.journal.contents.filter(document => ids.has(parentId(document)) && document.getFlag(MODULE, "campaignEntity")?.type === "quest")
            .map(document => ({ id: document.id, name: document.name, revision: document.getFlag(MODULE, "campaignEntity").revision, folderId: parentId(document) }));
        return { folderId, name: selected.name, folders: folders.filter(folder => ids.has(folder.id)).map(folder => ({ id: folder.id, name: folder.name, parentId: parentId(folder) })), quests };
    }

    static async delete(plan) {
        const current = this.deletionPlan(plan.folderId);
        if (JSON.stringify(current) !== JSON.stringify(plan)) throw new Error("This folder changed. Review its contents and try deleting again.");
        // Preserve the quest lifecycle rather than deleting its journal directly.
        for (const quest of plan.quests) await deleteQuest(quest.id, quest.revision);
        for (const entry of [...plan.folders].reverse()) {
            const folder = this.list().find(folder => folder.id === entry.id);
            if (!folder) continue;
            if (game.journal.contents.some(document => parentId(document) === folder.id && document.getFlag(MODULE, "campaignEntity")?.type === "quest")) {
                throw new Error("New quests were added during deletion. The remaining folders were preserved.");
            }
            await folder.delete({ deleteSubfolders: false, deleteContents: false });
        }
    }

    static async move(questId, folderId = "", { direct = false } = {}) {
        if (!game.user.isGM) throw new Error("Only a GM can move quests between folders.");
        const document = game.journal.get(questId);
        if (document?.getFlag(MODULE, "campaignEntity")?.type !== "quest") throw new Error("That quest no longer exists.");
        if (folderId && !(direct ? this.list() : this.destinations(questId)).some(folder => folder.id === folderId)) throw new Error("That quest folder no longer exists or is not an available destination.");
        const folder = await this.destination(folderId);
        if (!folder) throw new Error("That quest folder no longer exists.");
        await document.update({ folder: folder.id });
    }

    static group(entries, { isGM = game.user.isGM, accessibleEntries = entries, collapsed = new Set(), searching = false } = {}) {
        const groups = this.list().map(folder => ({ id: folder.id, name: folder.name, parentId: parentId(folder), children: [], entries: [], expanded: searching || !collapsed.has(folder.id) }));
        const byId = new Map(groups.map(group => [group.id, group]));
        // Visibility uses authorized quests before status/search filters; counts use the filtered rows.
        const accessibleFolders = new Set(accessibleEntries.map(entry => parentId(game.journal.get(entry.id))));
        const ungrouped = [];
        for (const entry of entries) {
            const group = byId.get(parentId(game.journal.get(entry.id)));
            (group ? group.entries : ungrouped).push(entry);
        }
        const roots = [];
        for (const group of groups) {
            const parent = byId.get(group.parentId);
            (parent ? parent.children : roots).push(group);
        }
        const project = group => {
            const children = group.children.map(project).filter(Boolean);
            const count = group.entries.length + children.reduce((sum, child) => sum + child.count, 0);
            return isGM || accessibleFolders.has(group.id) || children.length ? { ...group, children, count } : null;
        };
        return { ungrouped, groups: roots.map(project).filter(Boolean) };
    }
}
