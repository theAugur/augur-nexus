import { QuestApplication } from "./QuestApplication.js";
import { getQuest, updateQuest } from "../../../api/quests.js";

export class QuestPlayerPicker extends QuestApplication {
    static DEFAULT_OPTIONS = {
        window: { title: "Selected players" }, position: { width: 380, height: 390 },
        actions: { cancel: QuestPlayerPicker.cancel },
        form: { closeOnSubmit: false, handler: QuestPlayerPicker.save }
    };
    static PARTS = { body: { template: "modules/augur-nexus/templates/quests/player-picker.hbs" } };
    constructor({ questId, ...options }) {
        super(options);
        this.questId = questId;
        this.isEditor = true;
    }
    async _prepareContext() {
        if (!game.user.isGM) throw new Error("Only a GM can choose quest players.");
        this.quest = await getQuest(this.questId);
        return { players: game.users.contents.filter(user => !user.isGM)
            .sort((a, b) => a.name.localeCompare(b.name))
            .map(user => ({ id: user.id, name: user.name, selected: this.quest.browserUserIds?.includes(user.id) || false })) };
    }
    static cancel() { return this.close(); }
    static save(event, form) {
        event.preventDefault();
        return this.perform(async () => {
            if (!game.user.isGM) throw new Error("Only a GM can choose quest players.");
            const browserUserIds = Array.from(form.querySelectorAll('input[name="player"]:checked'), input => input.value)
                .filter(id => game.users.get(id) && !game.users.get(id).isGM);
            if (!browserUserIds.length) throw new Error("Select at least one player, or use GM only.");
            await updateQuest(this.questId, this.quest.revision, { audience: "all", browserUserIds });
            await this.close();
        });
    }
}
