const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
export const questApplications = new Set();

export class QuestApplication extends HandlebarsApplicationMixin(ApplicationV2) {
    static DEFAULT_OPTIONS = {
        classes: ["augur-nexus", "augur-theme-fantasy", "nexus-quests"], tag: "form",
        window: { resizable: true }, position: { width: 850, height: 670 }
    };
    _onRender(context, options) { super._onRender(context, options); questApplications.add(this); }
    async close(options) { clearTimeout(this.refreshTimer); questApplications.delete(this); this.dragEvents?.abort(); return super.close(options); }
    async perform(callback) {
        if (this.busy) return;
        this.busy = true;
        try { return await callback(); }
        catch (error) { ui.notifications.error(error.message || "The quest could not be updated."); }
        finally { this.busy = false; }
    }
    refresh() {
        if (this.busy || this.isEditor || !this.rendered) return;
        clearTimeout(this.refreshTimer);
        this.refreshTimer = setTimeout(() => {
            if (!this.rendered || this.busy) return;
            this.render({ force: false }).catch(error => console.warn("Nexus | Quest refresh", error));
        }, 350);
    }
}
