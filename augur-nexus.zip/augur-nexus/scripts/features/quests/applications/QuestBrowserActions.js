import { QuestFolderStore } from "../storage/QuestFolderStore.js";
import { openActionMenu, promptTextInput, confirmDestructiveAction } from "../../../api/ui.js";
import { openQuest, editQuest, getMainQuest, selectMainQuest } from "../../../api/quests.js";
import { openQuestAudienceMenu } from "./QuestAudienceMenu.js";

// Shared handlers run against a browser host with perform, render and collapse state.
export class QuestBrowserActions {
    static audience(_event, button) { return openQuestAudienceMenu(this, button, button.dataset.id); }
    static questOptions(_event, button) {
        return this.perform(async () => {
            const main = await getMainQuest();
            const isMain = main?.id === button.dataset.id;
            const items = [];
            if (isMain || button.dataset.canSelectMain === "true") items.push({
                id: "main", label: isMain ? "Remove as Main Quest" : "Set Main Quest", icon: isMain ? "far fa-star" : "fas fa-star",
                onSelect: () => QuestBrowserActions.mainQuest.call(this, null, button)
            });
            if (game.user.isGM) items.push({ id: "move", label: "Move to folder…", icon: "fas fa-folder-open",
                onSelect: () => QuestBrowserActions.moveFolder.call(this, null, button) });
            openActionMenu({ anchor: button, items });
        });
    }
    static mainQuest(_event, button) {
        return this.perform(async () => {
            const main = await getMainQuest();
            await selectMainQuest(main?.id === button.dataset.id ? "" : button.dataset.id);
            await this.render({ force: true });
        });
    }
    static open(_event, button) { return this.perform(() => openQuest(button.dataset.id)); }
    static createFolder(_event, button) {
        if (!game.user.isGM) return;
        return this.perform(async () => {
            const name = await promptTextInput({ title: "New quest folder", label: "Folder name", value: "" });
            if (typeof name !== "string" || !name.trim()) return;
            await QuestFolderStore.create(name, button?.dataset.folderId || "");
            await this.render({ force: true });
        });
    }
    static folderMenu(_event, button) {
        if (!game.user.isGM) return;
        const folderId = button.dataset.folderId;
        openActionMenu({ anchor: button, items: [
            { id: "folder", label: "New subfolder", icon: "fas fa-folder-plus", onSelect: () => QuestBrowserActions.createFolder.call(this, null, button) },
            { id: "quest", label: "New quest here", icon: "fas fa-scroll", onSelect: () => this.perform(() => editQuest("", { entityUuid: this.entityUuid, folderId })) },
            { id: "rename", label: "Rename folder", icon: "fas fa-pen", onSelect: () => this.perform(async () => {
                const folder = await QuestFolderStore.destination(folderId);
                const name = await promptTextInput({ title: "Rename quest folder", label: "Folder name", value: folder.name });
                if (typeof name !== "string" || !name.trim()) return;
                await QuestFolderStore.rename(folderId, name);
                await this.render({ force: true });
            }) },
            { id: "remove", label: "Remove folder, keep quests", icon: "fas fa-folder-minus", onSelect: () => this.perform(async () => {
                await QuestFolderStore.removeKeepingQuests(folderId);
                await this.render({ force: true });
            }) },
            { id: "delete", label: "Delete folder and quests", icon: "fas fa-trash", danger: true, onSelect: () => this.perform(async () => {
                const plan = QuestFolderStore.deletionPlan(folderId);
                const escape = foundry.utils.escapeHTML;
                const names = [...plan.folders.map(folder => "Folder: " + folder.name), ...plan.quests.map(quest => "Quest: " + quest.name)];
                const confirmed = await confirmDestructiveAction({ title: "Delete quest folder", subject: plan.name,
                    message: "Delete <strong>" + escape(plan.name) + "</strong> and all its quests and subfolders?<details><summary>Affected contents</summary><ul>" + names.map(name => "<li>" + escape(name) + "</li>").join("") + "</ul></details>",
                    impacts: [{ count: plan.quests.length, label: "quest" }, { count: plan.folders.length - 1, label: "subfolder" }],
                    warning: "Includes quests in every status, regardless of the current filters. Unrelated journals are preserved.", confirmLabel: "Delete folder and quests" });
                if (!confirmed) return;
                await QuestFolderStore.delete(plan);
                await this.render({ force: true });
            }) }
        ] });
    }
    static moveFolder(_event, button) {
        if (!game.user.isGM) return;
        const parent = QuestFolderStore.parentDestination(button.dataset.id);
        const destinations = QuestFolderStore.destinations(button.dataset.id).filter(folder => !parent || folder.id !== parent.id);
        openActionMenu({ anchor: button, items: [...(parent ? [parent] : []), ...(parent?.id === "" ? [] : [{ id: "", name: "Ungrouped" }]), ...destinations].map(folder => ({
            id: folder.id || "ungrouped", label: folder.name, icon: "fas fa-folder",
            onSelect: () => this.perform(async () => {
                await QuestFolderStore.move(button.dataset.id, folder.id);
                this.collapsedFolders.delete(folder.id);
                await this.render({ force: true });
            })
        })) });
    }
    static toggleFolder(_event, button) {
        const id = button.dataset.folderId;
        if (this.collapsedFolders.has(id)) this.collapsedFolders.delete(id);
        else this.collapsedFolders.add(id);
        return this.render({ force: true });
    }
}
