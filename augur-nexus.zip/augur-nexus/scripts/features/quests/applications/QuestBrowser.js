import { bindQuestFolderDragDrop } from "../integration/QuestFolderDragDrop.js";
import { QuestApplication } from "./QuestApplication.js";
import { QuestBrowserActions } from "./QuestBrowserActions.js";
import { listQuests, editQuest } from "../../../api/quests.js";

import { prepareQuestBrowserView } from "./QuestBrowserView.js";

export class QuestBrowser extends QuestApplication {
    static instance;
    static DEFAULT_OPTIONS = { id: "nexus-quests", window: { title: "Quests" },
        actions: { questListaudience: QuestBrowserActions.audience, questListquestOptions: QuestBrowserActions.questOptions, questListfolderMenu: QuestBrowserActions.folderMenu, createFolder: QuestBrowserActions.createFolder, moveFolder: QuestBrowserActions.moveFolder, questListtoggleFolder: QuestBrowserActions.toggleFolder, mainQuest: QuestBrowserActions.mainQuest, questListopen: QuestBrowserActions.open, create: QuestBrowser.create, filter: QuestBrowser.filter, search: QuestBrowser.search, clearContext: QuestBrowser.clearContext },
        form: { handler: QuestBrowser.search, closeOnSubmit: false } };
    static PARTS = { body: { template: "modules/augur-nexus/templates/quests/browser.hbs" }, results: { template: "modules/augur-nexus/templates/quests/browser-results.hbs", templates: ["modules/augur-nexus/templates/quests/browser-row.hbs", "modules/augur-nexus/templates/quests/browser-folder.hbs"] } };
    static async show({ entityUuid = "" } = {}) {
        this.instance ||= new this();
        this.instance.entityUuid = entityUuid;
        await this.instance.render({ force: true }); this.instance.bringToFront(); return this.instance;
    }
    constructor(options) { super(options); this.filter = "available"; this.query = ""; this.collapsedFolders = new Set(); }
    async _prepareContext() {
        let rows = [], accessibleRows = [], error = "";
        try {
            if (this.entityUuid) [rows, accessibleRows] = await Promise.all([listQuests({ entityUuid: this.entityUuid }), listQuests()]);
            else rows = accessibleRows = await listQuests();
        } catch (e) { error = e.message; }
        return { ...await prepareQuestBrowserView(rows, { accessibleRows, filter: this.filter, query: this.query, collapsed: this.collapsedFolders, expandSearch: false }), error, contextual: !!this.entityUuid };
    }

    _onRender(context, options) {
        super._onRender(context, options);
        bindQuestFolderDragDrop(this.element, this);
        const input = this.element.querySelector('[name="query"]');
        if (input && input !== this.searchInput) {
            this.searchInput = input;
            input.addEventListener("input", event => {
                this.setSearchQuery(event.currentTarget.value);
                clearTimeout(this.searchTimer);
                this.searchTimer = setTimeout(() => {
                    if (this.rendered) void this.render({ parts: ["results"] });
                }, 150);
            });
        }
    }
    setSearchQuery(value) {
        // Expand once for a new query; subsequent manual folder toggles remain authoritative.
        if (value !== this.query && value.trim()) this.collapsedFolders.clear();
        this.query = value;
    }
    async close(options) {
        clearTimeout(this.searchTimer);
        this.searchInput = null;
        return super.close(options);
    }
    static create() { return this.perform(() => editQuest("", { entityUuid: this.entityUuid })); }
    static async filter(_event, button) { this.filter = button.dataset.filter; await this.render({ force: true }); }
    static async search(event) { event?.preventDefault(); clearTimeout(this.searchTimer); this.setSearchQuery(this.element.querySelector('[name="query"]').value); await this.render({ parts: ["results"] }); }
    static async clearContext() { this.entityUuid = ""; await this.render({ force: true }); }
}
