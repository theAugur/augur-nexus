import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { filterQuestRows, QUEST_FILTERS } from "../models/QuestBrowserModel.js";
import { QuestApplication } from "./QuestApplication.js";
import { listQuests, openQuest, editQuest, getMainQuest, selectMainQuest } from "../../../api/quests.js";

export class QuestBrowser extends QuestApplication {
    static instance;
    static DEFAULT_OPTIONS = { id: "nexus-quests", window: { title: "Quests" },
        actions: { mainQuest: QuestBrowser.mainQuest, open: QuestBrowser.open, create: QuestBrowser.create, filter: QuestBrowser.filter, search: QuestBrowser.search, clearContext: QuestBrowser.clearContext },
        form: { handler: QuestBrowser.search, closeOnSubmit: false } };
    static PARTS = { body: { template: "modules/augur-nexus/templates/quests/browser.hbs" } };
    static async show({ entityUuid = "" } = {}) {
        this.instance ||= new this();
        this.instance.entityUuid = entityUuid;
        await this.instance.render({ force: true }); this.instance.bringToFront(); return this.instance;
    }
    constructor(options) { super(options); this.filter = "available"; this.query = ""; }
    async _prepareContext() {
        let rows = [], error = "";
        try { rows = await listQuests({ entityUuid: this.entityUuid }); } catch (e) { error = e.message; }
        const main = await getMainQuest();
        const entries = filterQuestRows(rows, {filter:this.filter, query:this.query}).map(row => ({ ...row, isMain: row.id === main?.id, canSelectMain: row.status !== "finished" }));
        return { entries, error, query: this.query, contextual: !!this.entityUuid, isGM: game.user.isGM,
            filters: Object.entries(QUEST_FILTERS).map(([id, label]) => ({ id, label, selected: id === this.filter })) };
    }
    _onRender(context, options) {
        super._onRender(context, options);
        for (const row of this.element.querySelectorAll("[data-quest-drag]")) row.addEventListener("dragstart", event => {
            const quest = context.entries.find(entry => entry.id === row.dataset.id);
            if (quest) ConnectionTargetResolver.setDragData(event.dataTransfer, ConnectionTargetResolver.fromCampaignEntity({ ...quest, type: "quest" }));
        });
    }
    static mainQuest(_event, button) {
        return this.perform(async () => {
            const main = await getMainQuest();
            await selectMainQuest(main?.id === button.dataset.id ? "" : button.dataset.id);
            await this.render({ force: true });
        });
    }
    static open(_event, button) { return this.perform(() => openQuest(button.dataset.id)); }
    static create() { return this.perform(() => editQuest("", { entityUuid: this.entityUuid })); }
    static async filter(_event, button) { this.filter = button.dataset.filter; await this.render({ force: true }); }
    static async search(event) { event?.preventDefault(); this.query = this.element.querySelector('[name="query"]').value.trim(); await this.render({ force: true }); }
    static async clearContext() { this.entityUuid = ""; await this.render({ force: true }); }
}
