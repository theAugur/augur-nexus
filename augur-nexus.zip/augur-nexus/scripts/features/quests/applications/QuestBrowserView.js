import { filterQuestRows, visibleQuestRows, QUEST_FILTERS } from "../models/QuestBrowserModel.js";
import { QuestFolderStore } from "../storage/QuestFolderStore.js";
import { getMainQuest } from "../../../api/quests.js";
import { questAudiencePresentation } from "./QuestAudienceMenu.js";

export async function prepareQuestBrowserView(rows, { accessibleRows = rows, filter = "available", query = "", collapsed = new Set(), expandSearch = true } = {}) {
    rows = visibleQuestRows(rows, game.user);
    accessibleRows = visibleQuestRows(accessibleRows, game.user);
    const main = await getMainQuest();
    const entries = filterQuestRows(rows, { filter, query }).map(row => ({ ...row,
        showAudience: game.user.isGM, audienceDisplay: game.user.isGM ? questAudiencePresentation(row) : null,
        isMain: row.id === main?.id, canSelectMain: row.status !== "finished",
        hasOptions: game.user.isGM || row.status !== "finished" || row.id === main?.id }));
    return { entries, ...QuestFolderStore.group(entries, { accessibleEntries: accessibleRows, collapsed, searching: !!query && expandSearch }),
        query, isGM: game.user.isGM,
        filters: Object.entries(QUEST_FILTERS).map(([id, label]) => ({ id, label, selected: id === filter })) };
}
