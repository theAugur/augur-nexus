import { QuestApplication } from "./QuestApplication.js";
import { getQuest, createQuest, updateQuest, contributeToQuest, updateQuestLogEntry, connectQuestEntity, disconnectQuestEntity, deleteQuest } from "../../../api/quests.js";
import { openActionMenu, closeActionMenu, promptTextInput } from "../../../api/ui.js";
import { openQuestEntity, resolveQuestEntity, resolveQuestDrop } from "../integration/QuestEntities.js";
import { questPresentation, QUEST_INTENTS, QUEST_STATES, GOAL_STATES, QUEST_SLOTS } from "../models/QuestModel.js";
import { QuestJournalEditor } from "./QuestJournalEditor.js";
import { openQuestAudienceMenu, questAudiencePresentation } from "./QuestAudienceMenu.js";

import { ConnectionsBoard } from "../../connections/components/ConnectionsBoard.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";

const esc = value => foundry.utils.escapeHTML(String(value || ""));
export class QuestDossier extends QuestApplication {
    static instances = new Map();
    static DEFAULT_OPTIONS = {
        window: { title: "Quest" }, position: { width: 1420, height: 780 },
        actions: { toggleCompact: QuestDossier.toggleCompact, options: QuestDossier.options, rename: QuestDossier.rename,
            intent: QuestDossier.intent, addGoal: QuestDossier.addGoal, goalMenu: QuestDossier.goalMenu, goalStatus: QuestDossier.goalStatus, goalVisibility: QuestDossier.goalVisibility,
            customComponentMenu: QuestDossier.customComponentMenu, linkMenu: QuestDossier.linkMenu, namedTarget: QuestDossier.namedTarget, addContext: QuestDossier.addContext,
            artwork: QuestDossier.artwork, status: QuestDossier.status, audience: QuestDossier.audience,
            viewTab: QuestDossier.viewTab, journal: QuestDossier.journal, preparation: QuestDossier.preparation,
            rewardNote: QuestDossier.rewardNote, removeRewardNote: QuestDossier.removeRewardNote, rewardVisibility: QuestDossier.rewardVisibility,
            contribute: QuestDossier.contribute, noteMenu: QuestDossier.noteMenu,
            openEntity: QuestDossier.openEntity },
        form: { closeOnSubmit: false, handler: event => event.preventDefault() }
    };
    static PARTS = { content: { template: "modules/augur-nexus/templates/quests/dossier.hbs", scrollable: [".qv-connection-rail", ".qv-main", ".qv-sidebar-content", ".qv-log-entries"],
        templates: ["modules/augur-nexus/templates/campaign-entities/quest-world-ties.hbs", "modules/augur-nexus/templates/quests/goal-list.hbs","modules/augur-nexus/templates/campaign-entities/npc-profile-panel.hbs", "modules/augur-nexus/templates/connections/connections-board.hbs", "modules/augur-nexus/templates/quests/entity-card.hbs", "modules/augur-nexus/templates/quests/goal-card.hbs", "modules/augur-nexus/templates/quests/rewards.hbs",
            "modules/augur-nexus/templates/campaign-entities/npc-portrait.hbs"] } };
    static async show(id) {
        if (!this.instances.has(id)) this.instances.set(id, new this({ questId: id, id: "nexus-quest-" + id }));
        const app = this.instances.get(id); await app.render({ force: true }); app.bringToFront(); return app;
    }
    static async create({ entityUuid = "", folderId = "" } = {}) {
        if (!game.user.isGM) throw new Error("Only a GM can create quests.");
        if (!game.modules.get("augur-fantasy")?.active && !game.modules.get("augur-scifi")?.active) {
            const { showQuestModuleRequiredDialog } = await import("./QuestModuleRequiredDialog.js");
            return showQuestModuleRequiredDialog();
        }
        const q = await createQuest({ folderId, objectives: [{ intent: "find" }], connections: entityUuid ? [{ targetUuid: entityUuid, slot: "context" }] : [] });
        return this.show(q.id);
    }
    constructor({ questId, ...options } = {}) {
        super(options); this.questId = questId; this.activeView = "journal"; this.contextGoals = new Map();
    }
    get title() { return this.quest ? questPresentation(this.quest).title : "Quest"; }
    async _prepareContext() {
        this.contribution = this.element?.querySelector('[name="contribution"]')?.value ?? this.contribution ?? "";
        try {
            if (this.questId) this.quest = await getQuest(this.questId);
            const q = this.quest, presentation = questPresentation(q);
            if (this.activeView === "gm" && !q.isGM) this.activeView = "journal";
            const goals = presentation.goals.map((goal, index) => ({
                ...goal, number: index + 1, statusLabel: GOAL_STATES[goal.status],
                target: goal.target || (goal.namedTarget ? { ...goal.namedTarget, named: true, goalId: goal.id } : null),
                showDestination: !!goal.destination || this.contextGoals.get(goal.id)?.has("destination"),
                showOpposition: !!goal.opposition || this.contextGoals.get(goal.id)?.has("opposition"),
                showAlly: !!goal.ally || this.contextGoals.get(goal.id)?.has("ally"),
                canEdit: q.canEdit, isGM: q.isGM
            }));
            const illustration = q.image || goals[0]?.target?.image || presentation.giver?.image;
            const target = ConnectionTargetResolver.fromCampaignEntity({ ...q, type: "quest", title: presentation.title, image: illustration, uuid: `JournalEntry.${q.id}` });
            if (!this.connectionsBoard) this.connectionsBoard = new ConnectionsBoard({ target, getCardActions: ({ node }) => this.questIconActions(node?.img) });
            else this.connectionsBoard.setTarget(target);
            return { quest: q, compact: !!this.compact, profileView: this.compact && this.activeView === "profile",
                connections: this.connectionsBoard.getContext(),
                header: { name: presentation.title, imageSrc: illustration, subtitle: `${goals.filter(g => g.done).length} / ${goals.length} goals completed`,
                    canDrag: true, showTabs: true, showHeaderActions: true, showCompactToggle: true, compactMode: !!this.compact, compactAction: "toggleCompact", showActions: q.canEdit, optionsAction: "options",
                    customTabs: [
                        ...(this.compact ? [{id:"profile",label:"Profile"}] : []),
                        { id: "journal", label: "Journal" }, { id: "log", label: "Log" },
                        { id: "connections", label: "Connections", icon: "fas fa-share-nodes" },
                        ...(q.isGM ? [{ id: "gm", label: "GM" }] : [])
                    ].map(tab => ({ ...tab, active: this.activeView === tab.id })) },
 ...presentation, goals, canEdit: q.canEdit, isGM: q.isGM,
                showRewards: q.canEditRewards || q.rewardNotes.length > 0 || presentation.rewardItems.length > 0,
                supporting: presentation.supporting.map(edge => ({ ...edge, heading: edge.rolesLabel && edge.rolesLabel !== QUEST_SLOTS.context ? edge.rolesLabel : "Connected to quest" })),
                journalView: this.activeView === "journal", gmView: q.isGM && this.activeView === "gm", logView: this.activeView === "log",
                connectionsView: this.activeView === "connections",
                log: q.notes.map(note => ({ ...note, canManage: q.isGM || note.authorId === game.user.id })),
                journalHtml: foundry.utils.cleanHTML(q.journalHtml || ""), contribution: this.contribution,
                illustration: q.image || goals[0]?.target?.image || presentation.giver?.image,
                audienceLabel: questAudiencePresentation(q).label,
                progress: goals.filter(g => g.done).length, total: goals.length };
        } catch (error) { if (this.questId) this.quest = null; return { error: error.message }; }
    }
    _onRender(context, options) {
        super._onRender(context, options);
        this.connectionsBoard?.activateListeners(this.element, this);
        if (this.window?.title) this.window.title.textContent = this.title;
        this.dragEvents?.abort(); this.dragEvents = new AbortController();
        this.element.querySelector("[data-npc-dossier-drag]")?.addEventListener("dragstart", event => {
            ConnectionTargetResolver.setDragData(event.dataTransfer, ConnectionTargetResolver.fromCampaignEntity({ ...this.quest, type: "quest", title: this.title, image: context.illustration }), { effectAllowed: "copy" });
        }, { signal: this.dragEvents.signal });
        for (const card of this.element.querySelectorAll("[data-quest-entity-drag]")) {
            card.addEventListener("dragstart", event => {
                event.stopPropagation();
                // Use the projected object reference, never the quest or its binding metadata.
                const entity = this.quest?.connections.find(edge => edge.id === card.dataset.edgeId);
                if (!entity || entity.missing || !ConnectionTargetResolver.setDragData(event.dataTransfer, entity.target, { effectAllowed: "copyMove" })) event.preventDefault();
            }, { signal: this.dragEvents.signal });
        }
        if (!context.canEdit) return;
        for (const surface of this.element.querySelectorAll("[data-quest-drop]")) {
            const signal = this.dragEvents.signal;
            surface.addEventListener("dragover", event => {
                event.preventDefault(); event.stopPropagation();
                for (const other of this.element.querySelectorAll(".is-dragover")) if (other !== surface) other.classList.remove("is-dragover");
                surface.classList.add("is-dragover");
            }, { signal });
            surface.addEventListener("dragleave", event => { if (!surface.contains(event.relatedTarget)) surface.classList.remove("is-dragover"); }, { signal });
            surface.addEventListener("drop", event => {
                event.preventDefault(); event.stopPropagation(); surface.classList.remove("is-dragover");
                void this.perform(async () => {
                    const target = await resolveQuestDrop(event);
                    if (!target) throw new Error("Drop a Nexus entity, site, scene, Actor, or Item.");
                    await this.connect(target, surface.dataset.slot || "context", surface.dataset.goalId || "", surface.dataset.replaceEdgeId, surface.dataset.componentId || "");
                });
            }, { signal });
        }
    }
    async patch(patch) {
        this.quest = await updateQuest(this.questId, this.quest.revision, patch);
        await this.render({ force: true });
    }
    async goal(id, patch) { await this.patch({ objectives: this.quest.objectives.map(g => g.id === id ? { ...g, ...patch } : g) }); }
    async connect(target, slot, goalId, replaceEdgeId, componentId = "") {
        const entity = await resolveQuestEntity(target, game.user);
        if (!entity) throw new Error("That object is not available to you.");
        if (slot === "giver" && !["npc", "faction", "location"].includes(entity.type)) throw new Error("Drop a Nexus person, faction, or location as the giver.");
        const edge = { target: entity.target, slot, goalId, componentId, roles: [QUEST_SLOTS[slot] || "Involved"], replaceEdgeId };
        this.quest = await connectQuestEntity(this.questId, this.quest.revision, edge);
        await this.render({ force: true });
    }
    async unlink(edge) {
        this.quest = await disconnectQuestEntity(this.questId, this.quest.revision, edge.id);
        await this.render({ force: true });
    }
    async text(title, value = "", multiline = false) {
        if (!multiline) return promptTextInput({ title, label: title, value, allowEmpty: true });
        return foundry.applications.api.DialogV2.prompt({ window: { title }, position: { width: 520 },
            content: '<textarea name="text" rows="6" style="width:100%">' + esc(value) + '</textarea>',
            ok: { label: "Save", callback: (_event, button) => button.form.elements.text.value }, rejectClose: false });
    }
    async close(options) {
        closeActionMenu(); QuestDossier.instances.delete(this.questId); return super.close(options);
    }
    static rename() { return this.perform(async () => { const title = await this.text("Quest title Ã‚Â· leave blank for a suggested title", this.quest.customTitle); if (typeof title === "string") await this.patch({ title }); }); }
    static intent(_event, button) {
        openActionMenu({ anchor: button, items: Object.entries(QUEST_INTENTS).map(([intent, v]) => ({ id: intent, label: v.label, icon: "fas " + v.icon,
            onSelect: () => this.perform(async () => {
                const goal = this.quest.objectives.find(goal => goal.id === button.dataset.goalId);
                if (intent !== "custom") return this.goal(goal.id, { intent, customIntent: "" });
                const label = await this.text("Custom goal action", goal.customIntent || "");
                if (typeof label !== "string" || !label.trim()) return;
                return this.goal(goal.id, { intent: "custom", customIntent: label.trim() });
            }) })) });
    }
    static addGoal() { return this.perform(() => this.patch({ objectives: [...this.quest.objectives, { id: foundry.utils.randomID(), intent: "find", text: "", status: "pending", hidden: false }] })); }
    static addContext(_event, button) {
        const id = button.dataset.goalId;
        openActionMenu({ anchor: button, items: ["destination", "opposition", "ally"].map(slot => {
            const edge = this.quest.connections.find(e => e.goalId === id && e.slot === slot);
            const shown = !!edge || this.contextGoals.get(id)?.has(slot);
            const label = {destination:"Location / destination", opposition:"Opposition", ally:"Ally"}[slot];
            return { id:slot, label: shown ? `Remove ${label.toLowerCase()}` : label, icon:shown ? "fas fa-minus" : "fas fa-plus",
                onSelect: () => this.perform(async () => {
                    const parts = this.contextGoals.get(id) || new Set(); shown ? parts.delete(slot) : parts.add(slot); this.contextGoals.set(id, parts);
                    if (edge) await this.unlink(edge); else await this.render({force:true});
                }) };
        }).concat([{ id: "custom", label: "Custom", icon: "fas fa-plus",
            onSelect: () => this.perform(async () => {
                const goal = this.quest.objectives.find(goal => goal.id === id);
                await this.goal(id, { customComponents: [...(goal.customComponents || []), { id: foundry.utils.randomID(), label: "Custom" }] });
            }) }]) });
    }
    static customComponentMenu(_event, button) {
        if (!this.quest.canEdit) return;
        const goal = this.quest.objectives.find(goal => goal.id === button.dataset.goalId);
        const component = goal?.customComponents?.find(component => component.id === button.dataset.componentId);
        if (!component) return;
        openActionMenu({ anchor: button, items: [
            { id: "rename", label: "Rename component", icon: "fas fa-pen", onSelect: () => this.perform(async () => {
                const label = await this.text("Rename custom component", component.label);
                if (typeof label !== "string" || !label.trim()) return;
                await this.goal(goal.id, { customComponents: goal.customComponents.map(row => row.id === component.id ? { ...row, label: label.trim() } : row) });
            }) },
            { id: "remove", label: "Remove component", icon: "fas fa-minus", onSelect: () => this.perform(() =>
                this.goal(goal.id, { customComponents: goal.customComponents.filter(row => row.id !== component.id) })) }
        ] });
    }
    static namedTarget(_event, button) {
        return this.perform(async () => {
            const goal = this.quest.objectives.find(g => g.id === button.dataset.goalId);
            const name = await this.text("Name a target", goal.namedTarget?.name || "");
            if (typeof name !== "string") return;
            await this.goal(goal.id, { namedTarget: name ? { name, image: goal.namedTarget?.image || "" } : null });
        });
    }
    static goalStatus(_event, button) {
        openActionMenu({ anchor: button, items: Object.entries(GOAL_STATES).map(([status, label]) => ({ id: status, label,
            icon: "fas fa-circle-check", onSelect: () => this.perform(() => this.goal(button.dataset.goalId, { status })) })) });
    }
    static goalVisibility(_event, button) {
        const goal = this.quest.objectives.find(g => g.id === button.dataset.goalId);
        return this.perform(() => this.goal(goal.id, { hidden: !goal.hidden }));
    }
    static rewardNote(_event, button) {
        return this.perform(async () => {
            const id = button.dataset.id;
            const note = this.quest.rewardNotes.find(n => n.id === id);
            const text = await this.text("Reward", note?.text || "");
            if (typeof text !== "string") return;
            const notes = this.quest.rewardNotes.filter(n => n.id !== id);
            if (text.trim()) notes.push({ id: id || foundry.utils.randomID(), text: text.trim() });
            await this.patch({ rewardNotes: notes });
        });
    }
    static removeRewardNote(_event, button) { return this.perform(() => this.patch({ rewardNotes: this.quest.rewardNotes.filter(n => n.id !== button.dataset.id) })); }
    static rewardVisibility() { return this.perform(() => this.patch({ rewardsHidden: !this.quest.rewardsHidden })); }
    questIconActions(image) {
        if (!this.quest?.canEdit || !image) return [];
        return [{ id: "quest-icon", label: "Set as Quest Icon", icon: "fas fa-image",
            onSelect: () => this.perform(() => this.patch({ image })) }];
    }
    static goalMenu(_event, button) {
        const goal = this.quest.objectives.find(g => g.id === button.dataset.goalId);
        const items = [
            { id: "wording", label: "Edit Goal Title", icon: "fas fa-pen", onSelect: () => this.perform(async () => { const text = await this.text("Edit Goal Title", goal.text); if (typeof text === "string") await this.goal(goal.id, { text }); }) },
            { id: "description", label: goal.description ? "Edit Goal Description" : "Add Goal Description", icon: "fas fa-align-left", onSelect: () => this.perform(async () => {
                const description = await this.text(goal.description ? "Edit Goal Description" : "Add Goal Description", goal.description, true);
                if (typeof description === "string") await this.goal(goal.id, { description });
            }) }
        ];
        const target = this.quest.connections.find(edge => edge.goalId === goal.id && edge.slot === "target");
        items.unshift(...this.questIconActions(target?.image || goal.namedTarget?.image));
        items.push({ id: "remove", label: "Remove goal", icon: "fas fa-trash", onSelect: () => this.perform(async () => {
            await this.patch({ objectives: this.quest.objectives.filter(g => g.id !== goal.id) });
        }) });
        openActionMenu({ anchor: button, items });
    }
    static linkMenu(_event, button) {
        const edge = this.quest.connections.find(e => e.id === button.dataset.edgeId);
        if (!edge) return;
        const items = [{ id: "remove", label: "Remove connection", icon: "fas fa-link-slash", onSelect: () => this.perform(() => this.unlink(edge)) }];
        items.unshift(...this.questIconActions(edge.image));
        if (edge.slot === "context" && !edge.goalId) items.unshift({ id: "heading", label: "Rename heading", icon: "fas fa-pen",
            onSelect: () => this.perform(async () => {
                const current = edge.rolesLabel === QUEST_SLOTS.context ? "" : edge.rolesLabel || "";
                const heading = await this.text("Connection heading", current);
                if (typeof heading !== "string") return;
                this.quest = await connectQuestEntity(this.questId, this.quest.revision, {
                    ...edge, target: edge.target, roles: [heading.trim() || QUEST_SLOTS.context]
                });
                await this.render({ force: true });
            }) });
        if (this.quest.isGM && edge.slot !== "reward") items.unshift({ id: "hide", label: edge.hidden ? "Reveal connection" : "Hide connection", icon: "fas fa-eye",
            onSelect: () => this.perform(async () => {
                if (this.questId) this.quest = await connectQuestEntity(this.questId, this.quest.revision, { ...edge, target: edge.target, hidden: !edge.hidden });
                await this.render({ force: true });
            }) });
        openActionMenu({ anchor: button, items });
    }
    static artwork() {
        if (!this.quest.canEdit) return;
        new foundry.applications.apps.FilePicker.implementation({ type: "image", current: this.quest.image || "",
            callback: path => void this.perform(() => this.patch({ image: path })) }).render(true);
    }
    static status(_event, button) {
        openActionMenu({ anchor: button, items: Object.entries(QUEST_STATES).map(([status, label]) => ({ id: status, label, icon: "fas fa-flag",
            onSelect: () => this.perform(() => this.patch({ status })) })) });
    }
    static audience(_event, button) {
        return openQuestAudienceMenu(this, button, this.questId);
    }
    static async toggleCompact() {
        if (!this.compact) {
            this.expandedPosition = { left: this.position.left, top: this.position.top, width: this.position.width, height: this.position.height };
            this.expandedView = this.activeView;
            this.activeView = "profile";
        } else if (this.activeView === "profile") this.activeView = this.expandedView || "journal";
        this.compact = !this.compact;
        await this.render({ force: true });
        const saved = this.expandedPosition;
        if (this.compact) {
            const width = Math.min(420, Math.max(320, window.innerWidth - 40));
            const left = Math.min(Math.max(20, saved.left + saved.width - width), Math.max(20, window.innerWidth - width - 20));
            this.setPosition({ left, top: saved.top, width, height: saved.height });
        } else this.setPosition(saved);
    }
    static viewTab(_event, button) { this.activeView = button.dataset.view; return this.render({ force: true }); }
    static journal() {
        const original = this.quest.journalHtml || "";
        return new QuestJournalEditor({ html: original, onSave: async journalHtml => {
            if (this.questId) {
                const current = await getQuest(this.questId);
                if ((current.journalHtml || "") !== original) throw new Error("Someone changed this journal. Your text is still here; copy it before reopening the Journal to reconcile the changes.");
                this.quest = current;
            }
            await this.patch({ journalHtml });
        } }).render({ force: true });
    }
    static preparation() { return this.perform(async () => { const gmNotes = await this.text("GM preparation", this.quest.gmNotes, true); if (typeof gmNotes === "string") await this.patch({ gmNotes }); }); }
    static openEntity(_event, button) { return this.perform(() => openQuestEntity(this.quest.connections.find(edge => edge.id === button.dataset.edgeId)?.target || button.dataset.uuid)); }
    static contribute() {
        return this.perform(async () => {
            const input = this.element.querySelector('[name="contribution"]');
            await contributeToQuest(this.questId, this.quest.revision, input.value);
            input.value = ""; this.contribution = ""; await this.render({ force: true });
            const entries = this.element.querySelector(".qv-log-entries");
            if (entries) entries.scrollTop = entries.scrollHeight;
        });
    }
    static noteMenu(_event, button) {
        const note = this.quest.notes.find(row => row.id === button.dataset.noteId);
        if (!note || !(this.quest.isGM || note.authorId === game.user.id)) return;
        const save = async data => {
            this.quest = await updateQuestLogEntry(this.questId, this.quest.revision, { noteId: note.id, ...data });
            await this.render({ force: true });
        };
        openActionMenu({ anchor: button, items: [
            { id: "edit", label: "Edit entry", icon: "fas fa-pen", onSelect: () => this.perform(async () => {
                const text = await this.text("Edit log entry", note.text, true);
                if (typeof text === "string") await save({ text });
            }) },
            { id: "delete", label: "Delete entry", icon: "fas fa-trash", onSelect: () => this.perform(() => save({ remove: true })) }
        ] });
    }
    static options(_event, button) {
        const items = [
            { id: "rename", label: "Rename quest", icon: "fas fa-pen", onSelect: () => QuestDossier.rename.call(this) },
            { id: "art", label: "Choose artwork", icon: "fas fa-image", onSelect: () => QuestDossier.artwork.call(this) }
        ];
        if (this.questId) items.push(
            { id: "delete", label: "Delete quest", icon: "fas fa-trash", onSelect: () => this.perform(async () => {
                const yes = await foundry.applications.api.DialogV2.confirm({ window: { title: "Delete quest?" }, content: "<p>Delete this quest, its goals, journal, contributions and quest links? Connected campaign entities will remain.</p>" });
                if (yes) { await deleteQuest(this.questId, this.quest.revision); await this.close(); }
            }) });
        openActionMenu({ anchor: button, items });
    }
}
