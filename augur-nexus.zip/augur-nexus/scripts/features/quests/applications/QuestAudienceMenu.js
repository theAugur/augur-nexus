import { openActionMenu } from "../../../api/ui.js";
import { getQuest, updateQuest } from "../../../api/quests.js";
import { QuestPlayerPicker } from "./QuestPlayerPicker.js";

export function questAudiencePresentation(quest) {
    if (quest.audience !== "all") return { label: "GM only", icon: "fas fa-lock", tooltip: "GM only", isGMOnly: true };
    if (!Array.isArray(quest.browserUserIds)) return { label: "Players", icon: "fas fa-users", tooltip: "All players", isGMOnly: false };
    const names = quest.browserUserIds.map(id => game.users.get(id)?.name || "Deleted player");
    return { label: `Selected players (${names.length})`, icon: "fas fa-user-check", tooltip: names.join(", ") || "No players selected", isGMOnly: false };
}

export function openQuestAudienceMenu(app, button, questId) {
    if (!game.user.isGM) return;
    const change = patch => app.perform(async () => {
        const quest = await getQuest(questId);
        await updateQuest(questId, quest.revision, patch);
        await app.render({ force: true });
    });
    return openActionMenu({ anchor: button, items: [
        { id: "private", label: "GM only", icon: "fas fa-lock", onSelect: () => change({ audience: "private" }) },
        { id: "all", label: "Players", icon: "fas fa-users", onSelect: () => change({ audience: "all", browserUserIds: null }) },
        { id: "selected", label: "Selected players…", icon: "fas fa-user-check", onSelect: () => new QuestPlayerPicker({ questId }).render({ force: true }) }
    ] });
}
