import { QuestApplication } from "./QuestApplication.js";
import { activateNexusThemeSurface, deactivateNexusThemeSurface } from "../../../support/appearance/NexusThemes.js";

export class QuestJournalEditor extends QuestApplication {
    static DEFAULT_OPTIONS = { window: { title: "Quest Journal" }, position: { width: 760, height: 650 },
        form: { closeOnSubmit: false, handler: QuestJournalEditor.save }, actions: { cancel: QuestJournalEditor.cancel } };
    static PARTS = { body: { template: "modules/augur-nexus/templates/quests/journal-editor.hbs" } };
    constructor({ html, onSave }) { super(); this.html = html; this.onSave = onSave; this.isEditor = true; }
    async _prepareContext() { return { html: foundry.utils.cleanHTML(this.html) }; }
    _onRender(context, options) {
        super._onRender(context, options);
        activateNexusThemeSurface(this, { windowClass: "nexus-quest-support-window", surfaceSelector: ".window-content" });
    }
    async close(options) {
        deactivateNexusThemeSurface(this);
        return super.close(options);
    }
    static cancel() { return this.close(); }
    static save(event) {
        event.preventDefault();
        return this.perform(async () => { await this.onSave(this.element.querySelector("prose-mirror").value); await this.close(); });
    }
}
