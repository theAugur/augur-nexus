/** Dedicated quest introduction, kept separate so it can carry quest-specific artwork. */
export function showQuestModuleRequiredDialog() {
    return foundry.applications.api.DialogV2.wait({
        window: { title: "Module Required", icon: "fa-solid fa-circle-info" },
        position: { width: 440 },
        content: `
            <p>Creating <strong>quests</strong> in Nexus is available with Augur content modules.</p>
            <p>Activate <strong>Augur: Fantasy</strong> or <strong>Augur: Sci-Fi</strong> to build visual quests connected to your people, organizations, and locations.</p>
            <p class="notes">Both modules are available now. Explore them on <a href="https://www.patreon.com/TheAugur" target="_blank" rel="noopener noreferrer">Patreon</a>.</p>
        `,
        buttons: [
            { action: "close", label: "Close", icon: "fa-solid fa-xmark" },
            { action: "viewModules", label: "View Modules", icon: "fa-solid fa-up-right-from-square", default: true,
                callback: () => window.open("https://www.patreon.com/TheAugur", "_blank", "noopener,noreferrer") }
        ]
    });
}
