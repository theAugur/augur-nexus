const DIALOG_CLASSES = ["dialog", "augur-nexus", "augur-theme-fantasy"];

export class ManagedSceneDuplicateDialog {
    static confirmDetachedCopy(scene) {
        const safeName = foundry.utils.escapeHTML(scene?.name || "this Scene");
        return foundry.applications.api.DialogV2.confirm({
            classes: DIALOG_CLASSES,
            window: {
                title: "Create Detached Scene Copy?",
                icon: "fa-regular fa-copy"
            },
            position: { width: 470 },
            content: `
                <div class="nexus-delete-confirm">
                    <p><strong>${safeName}</strong> is managed by Augur: Nexus.</p>
                    <p>A detached copy keeps the ordinary Foundry map contents, but removes all Nexus metadata, including lineage, Site ownership, navigation, connections, managed Sites, and managed markers.</p>
                </div>
            `,
            modal: true,
            rejectClose: false,
            yes: {
                label: "Create Detached Copy",
                icon: "fa-regular fa-copy"
            },
            no: {
                label: "Cancel",
                icon: "fa-solid fa-xmark"
            }
        });
    }

    static showSciFiBlocked(scene) {
        const safeName = foundry.utils.escapeHTML(scene?.name || "This Scene");
        return foundry.applications.api.DialogV2.wait({
            classes: DIALOG_CLASSES,
            window: {
                title: "Augur Sci-Fi Scene Cannot Be Duplicated",
                icon: "fa-solid fa-triangle-exclamation"
            },
            position: { width: 470 },
            content: `
                <div class="nexus-delete-confirm">
                    <p><strong>${safeName}</strong> belongs to a connected Augur Sci-Fi hierarchy.</p>
                    <p>Foundry Scene duplication cannot safely copy its journals, body identities, parentage, markers, and navigation. Create the new Scene through the Augur tools instead.</p>
                </div>
            `,
            modal: true,
            rejectClose: false,
            buttons: [{
                action: "close",
                label: "Close",
                icon: "fa-solid fa-check",
                default: true
            }]
        });
    }
}
