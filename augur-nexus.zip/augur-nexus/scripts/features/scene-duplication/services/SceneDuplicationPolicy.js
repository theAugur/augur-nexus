import { LocationSceneService } from "../../campaign-entities/services/LocationSceneService.js";
import { LocationEntityStore } from "../../campaign-entities/services/LocationEntityStore.js";
import { ConnectionStore } from "../../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";
import { NexusSceneFolderManager } from "../../nexus/services/NexusSceneFolderManager.js";
import { LegacySciFiCompatibility } from "../../../support/compatibility/LegacySciFiCompatibility.js";

const MODULE_ID = "augur-nexus";

export const SCENE_DUPLICATION_POLICY = Object.freeze({
    UNMANAGED: "unmanaged",
    NEXUS_DETACHABLE: "nexus-detachable",
    SCIFI_BLOCKED: "scifi-blocked"
});

export const SCENE_EMBEDDED_COLLECTION_FIELDS = Object.freeze([
    "tokens",
    "tiles",
    "walls",
    "drawings",
    "lights",
    "sounds",
    "templates",
    "notes",
    "regions"
]);

export class SceneDuplicationPolicy {
    static classify(scene) {
        if (!scene) return SCENE_DUPLICATION_POLICY.UNMANAGED;
        if (LegacySciFiCompatibility.isManagedScene(scene)) return SCENE_DUPLICATION_POLICY.SCIFI_BLOCKED;
        if (this.isNexusManagedScene(scene)) return SCENE_DUPLICATION_POLICY.NEXUS_DETACHABLE;
        return SCENE_DUPLICATION_POLICY.UNMANAGED;
    }

    static isNexusManagedScene(scene) {
        if (!scene) return false;
        if (Object.keys(scene.flags?.[MODULE_ID] || {}).length) return true;
        if (LocationSceneService.getLocationForScene(scene.id)) return true;
        if (this.#hasLocationChildren(scene)) return true;
        if (this.#hasConnectionNode(scene)) return true;
        if (this.isManagedSceneFolder(scene._source?.folder || scene.folder?.id || scene.folder)) return true;

        return SCENE_EMBEDDED_COLLECTION_FIELDS.some(field =>
            scene[field]?.contents?.some(document => this.hasNexusEmbeddedMetadata(document))
        );
    }

    static hasNexusEmbeddedMetadata(document) {
        return Object.keys(document?.flags?.[MODULE_ID] || {}).length > 0;
    }

    static isManagedMarkerDocument(document) {
        const flags = document?.flags?.[MODULE_ID] || {};
        return !!(flags.marker || flags.markerLabel || flags.site || flags.sitePage || flags.siteLabel);
    }

    static isManagedSceneFolder(folderId) {
        const id = String(folderId || "").trim();
        if (!id) return false;

        let rootFolderId = "";
        try {
            rootFolderId = game.settings.get(MODULE_ID, NexusSceneFolderManager.ROOT_SETTING_KEY) || "";
        } catch (_error) {
            rootFolderId = "";
        }
        if (id === rootFolderId) return true;

        return game.scenes.contents.some(scene =>
            scene.getFlag(MODULE_ID, NexusSceneFolderManager.CHILD_FOLDER_FLAG) === id
        );
    }

    static resolveDuplicateSource(sourceUuid) {
        const uuid = String(sourceUuid || "").trim();
        if (!uuid) return null;
        try {
            const source = foundry.utils.fromUuidSync(uuid);
            return source?.documentName === "Scene" ? source : null;
        } catch (_error) {
            return null;
        }
    }

    static #hasConnectionNode(scene) {
        if (!scene?.id) return false;
        try {
            const target = ConnectionTargetResolver.fromSceneReference({ sceneId: scene.id });
            const nodeId = target ? ConnectionTargetResolver.getNodeId(target) : "";
            return !!(nodeId && ConnectionStore.getNode(nodeId));
        } catch (_error) {
            return false;
        }
    }

    static #hasLocationChildren(scene) {
        if (!scene?.id) return false;
        return LocationEntityStore.getLocations().some(location => {
            const parent = location.hierarchy?.parent || null;
            if (parent?.kind === "scene") return parent.sceneId === scene.id;
            if (parent?.kind === "site") return parent.parentSceneId === scene.id;
            return false;
        });
    }
}
