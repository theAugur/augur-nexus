import { SCENE_EMBEDDED_COLLECTION_FIELDS, SceneDuplicationPolicy } from "./SceneDuplicationPolicy.js";

const MODULE_ID = "augur-nexus";

export class NexusSceneDuplicateSanitizer {
    static sanitize(pendingScene) {
        if (!pendingScene) throw new Error("A pending Scene is required for duplicate sanitation.");

        pendingScene.updateSource({ [`flags.-=${MODULE_ID}`]: null });

        const replacements = {};
        for (const field of SCENE_EMBEDDED_COLLECTION_FIELDS) {
            const collection = pendingScene[field];
            if (!collection?.contents) continue;
            replacements[field] = collection.contents
                .filter(document => !SceneDuplicationPolicy.isManagedMarkerDocument(document))
                .map(document => this.#stripNexusFlags(document.toObject()));
        }

        const folderId = pendingScene._source?.folder || pendingScene.folder?.id || pendingScene.folder || "";
        if (SceneDuplicationPolicy.isManagedSceneFolder(folderId)) replacements.folder = null;

        // EmbeddedCollectionField only removes omitted members during a non-recursive replacement.
        pendingScene.updateSource(replacements, { recursive: false });
        return pendingScene;
    }

    static #stripNexusFlags(data) {
        if (!data?.flags?.[MODULE_ID]) return data;
        delete data.flags[MODULE_ID];
        return data;
    }
}
