import { ManagedSceneDuplicateDialog } from "../applications/ManagedSceneDuplicateDialog.js";
import { NexusSceneDuplicateSanitizer } from "./NexusSceneDuplicateSanitizer.js";
import { SCENE_DUPLICATION_POLICY, SceneDuplicationPolicy } from "./SceneDuplicationPolicy.js";

const MODULE_ID = "augur-nexus";
const OPERATION_KEY = "sceneDuplication";
const DETACHED_MODE = "detached-copy";

export class SceneDuplicationCoordinator {
    static #pendingPrompts = new Set();

    static interceptPendingDuplicate(pendingScene, data = {}, options = {}, userId = null) {
        const operation = options?.[MODULE_ID]?.[OPERATION_KEY] || {};
        const sourceUuid = operation.sourceUuid
            || pendingScene?._stats?.duplicateSource
            || data?._stats?.duplicateSource
            || "";
        if (!sourceUuid) return true;

        const sourceScene = SceneDuplicationPolicy.resolveDuplicateSource(sourceUuid);
        let policy;
        try {
            policy = SceneDuplicationPolicy.classify(sourceScene || pendingScene);
        } catch (error) {
            console.error("Augur Nexus | Failed to classify a pending Scene duplicate.", error);
            ui.notifications?.error?.("Augur Nexus blocked a Scene copy because its safety could not be determined.");
            return false;
        }
        if (policy === SCENE_DUPLICATION_POLICY.UNMANAGED) return true;

        if (policy === SCENE_DUPLICATION_POLICY.SCIFI_BLOCKED) {
            this.#scheduleSciFiBlocked(sourceScene || pendingScene, userId);
            return false;
        }

        if (operation.mode === DETACHED_MODE) {
            try {
                NexusSceneDuplicateSanitizer.sanitize(pendingScene);
                operation.sanitized = true;
                return true;
            } catch (error) {
                console.error("Augur Nexus | Failed to sanitize a managed Scene duplicate.", error);
                ui.notifications?.error?.("Augur Nexus could not safely create the detached Scene copy.");
                return false;
            }
        }

        if (!sourceScene) {
            ui.notifications?.error?.("Augur Nexus could not resolve the original managed Scene, so the copy was blocked.");
            return false;
        }

        this.#scheduleDetachedCopyPrompt(sourceScene, pendingScene?.name, userId);
        return false;
    }

    static #scheduleDetachedCopyPrompt(sourceScene, duplicateName, userId) {
        if (!sourceScene || (userId && userId !== game.user?.id)) return;
        const key = sourceScene.uuid;
        if (this.#pendingPrompts.has(key)) return;
        this.#pendingPrompts.add(key);

        queueMicrotask(async () => {
            try {
                const source = game.scenes.get(sourceScene.id) || null;
                if (!source) {
                    ui.notifications?.warn?.("The original Scene no longer exists.");
                    return;
                }

                const confirmed = await ManagedSceneDuplicateDialog.confirmDetachedCopy(source);
                if (!confirmed) return;

                const copy = await source.clone({
                    name: duplicateName || game.i18n.format("DOCUMENT.CopyOf", { name: source._source.name })
                }, {
                    save: true,
                    addSource: true,
                    [MODULE_ID]: {
                        [OPERATION_KEY]: {
                            mode: DETACHED_MODE,
                            sourceUuid: source.uuid
                        }
                    }
                });
                if (copy) ui.notifications?.info?.(`Created detached Scene copy: ${copy.name}.`);
            } catch (error) {
                console.error("Augur Nexus | Failed to create a detached Scene copy.", error);
                ui.notifications?.error?.("Augur Nexus could not create the detached Scene copy.");
            } finally {
                this.#pendingPrompts.delete(key);
            }
        });
    }

    static #scheduleSciFiBlocked(scene, userId) {
        if (!scene || (userId && userId !== game.user?.id)) return;
        const key = `scifi:${scene.uuid || scene.id}`;
        if (this.#pendingPrompts.has(key)) return;
        this.#pendingPrompts.add(key);

        queueMicrotask(async () => {
            try {
                await ManagedSceneDuplicateDialog.showSciFiBlocked(scene);
            } catch (error) {
                console.error("Augur Nexus | Failed to show the Sci-Fi duplication warning.", error);
                ui.notifications?.warn?.("Augur Sci-Fi Scenes cannot be duplicated using Foundry Scene controls.");
            } finally {
                this.#pendingPrompts.delete(key);
            }
        });
    }
}
