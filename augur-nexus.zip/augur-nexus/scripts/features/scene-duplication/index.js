import { registerSceneDuplicationHooks } from "./hooks/registerSceneDuplicationHooks.js";

export function registerSceneDuplicationFeature() {
    registerSceneDuplicationHooks();
}
