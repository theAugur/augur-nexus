import { SceneDuplicationCoordinator } from "../services/SceneDuplicationCoordinator.js";

export function registerSceneDuplicationHooks() {
    Hooks.on("preCreateScene", (scene, data, options, userId) =>
        SceneDuplicationCoordinator.interceptPendingDuplicate(scene, data, options, userId)
    );
}
