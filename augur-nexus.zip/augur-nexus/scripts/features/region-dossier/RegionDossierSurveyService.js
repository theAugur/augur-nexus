import { RegionPopulationSurveyService } from "../region-population/services/RegionPopulationSurveyService.js";
import { ConnectionTargetResolver } from "../connections/services/ConnectionTargetResolver.js";

/** A viewing projection, separate from the development planner's complete survey. */
export class RegionDossierSurveyService {
    static build(scene, snapshot, user = game.user) {
        const survey = RegionPopulationSurveyService.build(scene, snapshot, { user });
        if (user?.isGM) return survey;
        const project = rows => rows.flatMap(({ entity }) => {
            const node = ConnectionTargetResolver.fromEntityReference({ entityId: entity.id });
            if (!node || !ConnectionTargetResolver.canUserSeeNode(node, user)) return [];
            const display = ConnectionTargetResolver.resolveDisplayNodeSync(node);
            if (!display || display.missing) return [];
            return [{ entity: {
                id: entity.id, type: entity.type,
                display: { name: display.name || "", imageSrc: display.img || "", thumbnailSrc: display.img || "" },
                profile: { type: display.subtitle || "" }, role: { roleLabel: display.subtitle || "" },
                access: { playerDisclosure: "full" }
            } }];
        });
        // Do not serialize planner warnings, clocks, coordinates, private profiles,
        // relationship annotations or Chronicle references into a player's surface.
        return { locations: project(survey.locations), factions: project(survey.factions), npcs: project(survey.npcs), visibleConnectionIds: survey.connections.map(edge => edge.id) };
    }
}
