import { ConnectionStore } from "../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../connections/services/ConnectionTargetResolver.js";
import { RegionChronicleViewModel } from "../region-population/services/RegionChronicleViewModel.js";

export function regionDossierNode(nodeId) {
    const id = String(nodeId || "");
    const node = ConnectionStore.getNode(id) || (id.startsWith("nexus-entity:")
        ? ConnectionTargetResolver.fromEntityReference({ entityId: id.slice("nexus-entity:".length) }) : null);
    const display = node && ConnectionTargetResolver.resolveDisplayNodeSync(node);
    return display?.missing === false && ConnectionTargetResolver.canUserSeeNode(display) ? display : null;
}

function row(source, user) {
    const node = regionDossierNode(source?.nodeId);
    if (!node) return null;
    return { ...(user?.isGM ? source : {}), nodeId: node.id, name: node.name,
        typeLabel: user?.isGM ? source.typeLabel || node.subtitle : node.subtitle, imageSrc: user?.isGM ? source.imageSrc || node.img : node.img,
        leader: source.leader ? row(source.leader, user) : null, seat: source.seat ? row(source.seat, user) : null,
        owner: source.owner ? row(source.owner, user) : null };
}

/** Identity is resolved again so deleted or inaccessible references never become dead cards. */
export function prepareRegionDossier(source = {}, { compact = false, sections = {}, category = "all", user = game.user } = {}) {
    const distinct = values => [...new Map((Array.isArray(values) ? values : []).map(source => row(source, user)).filter(Boolean).map(item => [item.nodeId, item])).values()];
    const powers = distinct(source.powers), places = distinct(source.places), people = distinct(source.people);
    const events = (user?.isGM && Array.isArray(source.events) ? source.events : []).map((event, index) => ({ event, index }))
        .sort((a, b) => Number(b.event.year || 0) - Number(a.event.year || 0) || b.index - a.index).map(row => row.event);
    const groups = [{ id: "powers", label: "Powers", rows: powers }, { id: "places", label: "Places", rows: places }, { id: "people", label: "People", rows: people }];
    return {
        label: String(source.label || "Developed Region"), year: user?.isGM ? Number(source.year || 0) : 0, canViewChronicle: user?.isGM === true,
        powers, places, people, primaryPower: powers[0] || null, secondaryPowers: powers.slice(1, 3),
        featuredPlaces: places.slice(0, 3), events, chronicleYears: RegionChronicleViewModel.groupByYear(events).reverse(), recentEvents: events.slice(0, 3).reverse(), hasEvents: events.length > 0,
        counts: { powers: powers.length, places: places.length, people: people.length },
        directoryGroups: groups.filter(group => category === "all" || group.id === category),
        directoryCategories: [{ id: "all", label: "All", active: category === "all" }, ...groups.map(group => ({ id: group.id, label: group.label, count: group.rows.length, active: category === group.id }))],
        compact, ...sections,
        sections: { powers: !compact || sections.compactSections?.powers !== false, places: !compact || sections.compactSections?.places !== false, chronicle: !compact || sections.compactSections?.chronicle !== false }
    };
}
