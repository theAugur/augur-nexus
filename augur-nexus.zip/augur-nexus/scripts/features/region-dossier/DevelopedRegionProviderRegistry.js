const providers = new Map();

/** Providers describe domain recognition and read-only content, never world records. */
export class DevelopedRegionProviderRegistry {
    static register(definition = {}) {
        const id = String(definition.id || "").trim();
        if (!id || typeof definition.matches !== "function" || typeof definition.prepare !== "function") {
            throw new Error("Developed region providers require an id, matches(context), and prepare(context).");
        }
        providers.set(id, { ...definition, id, priority: Number(definition.priority) || 0 });
        Hooks.callAll("augurNexusRegionDossierProvidersChanged");
        return id;
    }

    static find(context = {}) {
        if (!context.scene?.id || !context.user) return null;
        return [...providers.values()].sort((a, b) => b.priority - a.priority || a.id.localeCompare(b.id)).find(provider => {
            if (!context.user.isGM && provider.playerReadable !== true) return false;
            if (provider.moduleId && !game.modules.get(provider.moduleId)?.active) return false;
            try { return provider.matches(context) === true; }
            catch (error) { console.warn(`Augur: Nexus | Region dossier provider ${provider.id} could not inspect a place.`, error); return false; }
        }) || null;
    }
}
