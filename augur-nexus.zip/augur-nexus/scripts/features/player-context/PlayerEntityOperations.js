import { assertPlayerEntityControl } from "./PlayerAccessService.js";

const operations = new Map();

export function registerEntityOperation(moduleId, { id, entityType, execute }) {
    if (!moduleId || !id || !entityType || typeof execute !== "function") throw new Error("Invalid player entity operation.");
    operations.set(`${moduleId}:${id}`, { moduleId, entityType, execute });
}

export async function executeEntityOperation(request, user) {
    const operation = operations.get(request.operation.slice("extension.".length));
    if (!operation || !game.modules.get(operation.moduleId)?.active) throw new Error("This editing operation is unavailable.");
    const document = assertPlayerEntityControl(request.uuid, user);
    const entity = document?.getFlag("augur-nexus", "campaignEntity");
    if (entity?.type !== operation.entityType || entity.sourceModule !== operation.moduleId) throw new Error("This operation does not support that entity.");
    return operation.execute({ entity, document, user, data: request.args?.[0] });
}
