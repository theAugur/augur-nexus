import { MODULE_ID, REQUEST_KEY, RESULT_KEY } from "./PlayerContextPolicy.js";
import { PlayerAccessService, serializeContextWrite } from "./PlayerAccessService.js";
import { executePlayerMutation } from "./PlayerEntityMutations.js";
import { createUserFlagRequests } from "../../support/requests/UserFlagRequests.js";

export function isContextGM() { return game.user?.isGM && (game.users.activeGM?.id || game.user.id) === game.user.id; }
const requests = createUserFlagRequests({
    moduleId: MODULE_ID, requestKey: REQUEST_KEY, resultKey: RESULT_KEY,
    execute: ({ requestId, ...request }, user) => serializeContextWrite(() => {
        if (request.operation !== "access") return executePlayerMutation(request, user);
        if (Object.keys(request).some(key => !["operation", "data"].includes(key))) throw new Error("Invalid player access request.");
        return PlayerAccessService.execute(request.data, user);
    }),
    timeout: 15000, queueRequests: false, routeGmToActive: true,
    unavailableMessage: "A GM must be connected to save campaign edits. Your editor remains open.",
    timeoutMessage: "The GM did not respond. Reopen the dossier to check whether it saved before retrying.",
    busyMessage: "Wait for your current campaign edit to finish."
});
export function registerPlayerContextRequests() { requests.register(); }
export function requestPlayerMutation(data) { return requests.request(data); }

export function requestAccessMutation(data) { return requests.request({ operation: "access", data }); }
