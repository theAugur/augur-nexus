import { getPlayerAssignmentActions } from "../../../api/player-context.js";
import { openActionMenu, closeActionMenu } from "../../../api/ui.js";
import { PlayerCreationGateway } from "./PlayerCreationGateway.js";
import { createPlayerDirectoryEntity, PLAYER_CREATION_TYPES } from "./PlayerDirectoryCreation.js";
import { preparePlayerDirectory, filterPlayerDirectory, openPlayerDirectoryEntry, dragPlayerDirectoryEntry, PLAYER_DIRECTORY_FILTERS } from "./PlayerDirectoryModel.js";
import { openPlayerSetup } from "../../../api/player-gateway.js";

// One controller per browser instance; no tab state or domain logic lives in the browser shell.
export class PlayerNexusDirectory {
    constructor(app, refresh) {
        this.app = app;
        this.refresh = refresh;
        this.userId = "";
        this.filter = "all";
        this.query = "";
        this.active = false;
        this.rows = [];
    }

    prepare(active) {
        this.active = active;
        if (!active) return null;
        if (!game.user.isGM) this.userId = game.user.id;
        else if (!game.users.get(this.userId)) this.userId = "";
        const context = preparePlayerDirectory(this.userId);
        this.userId = context.userId;
        this.rows = context.rows;
        const visible = new Set(filterPlayerDirectory(this.rows, this).map(row => row.uuid));
        return { ...context, canCreate: game.user.isGM && !!game.users.get(this.userId), query: this.query, hasRows: visible.size > 0,
            rows: this.rows.map(row => ({ ...row, hidden: !visible.has(row.uuid) })),
            filters: Object.entries(PLAYER_DIRECTORY_FILTERS).map(([id, label]) => ({ id, label, selected: id === this.filter })) };
    }

    bind(element) {
        if (this.menuAnchor) closeActionMenu();
        this.events?.abort();
        if (!this.hook) this.hook = Hooks.on("augurNexusPlayerContextChanged", () => { if (this.active) this.refresh(); });
        const root = element.querySelector("[data-player-directory]");
        if (!root) return;
        this.events = new AbortController();
        const options = { signal: this.events.signal };
        root.addEventListener("dragstart", event => {
            const entry = event.target.closest(".nexus-player-directory-open[draggable='true']");
            if (!entry) return;
            event.stopPropagation();
            try {
                if (!dragPlayerDirectoryEntry(this.userId, entry.dataset.uuid, event.dataTransfer)) event.preventDefault();
            } catch { event.preventDefault(); }
        }, options);
        root.querySelector('[name="playerDirectoryUser"]')?.addEventListener("change", event => {
            if (!game.user.isGM) return;
            this.userId = event.currentTarget.value;
            void this.app.render({ force: false });
        }, options);
        root.querySelector('[name="playerDirectorySearch"]')?.addEventListener("input", event => {
            this.query = event.currentTarget.value;
            const visible = new Set(filterPlayerDirectory(this.rows, this).map(row => row.uuid));
            for (const row of root.querySelectorAll("[data-player-entry]")) row.hidden = !visible.has(row.dataset.uuid);
            root.querySelector("[data-player-empty]").hidden = visible.size > 0;
        }, options);
    }

    async action(_event, button) {
        try {
            if (button.dataset.intent === "filter") {
                if (!Object.hasOwn(PLAYER_DIRECTORY_FILTERS, button.dataset.filter)) return;
                this.filter = button.dataset.filter;
                return await this.app.render({ force: false });
            }
            if (button.dataset.intent === "new" && game.user.isGM) {
                if (!this.userId || !game.users.get(this.userId)) throw new Error("Choose a player before creating an entity.");
                if (this.menuAnchor === button) { closeActionMenu(); return; }
                const userId = this.userId;
                if (!await PlayerCreationGateway.requireModule()) return;
                openActionMenu({ anchor: button, items: PLAYER_CREATION_TYPES.map(type => ({ ...type,
                    onSelect: () => createPlayerDirectoryEntity(type.id, userId).catch(error => ui.notifications.error(error.message)) })),
                    onClose: () => { button.setAttribute("aria-expanded", "false"); this.menuAnchor = null; } });
                this.menuAnchor = button;
                button.setAttribute("aria-expanded", "true");
                return;
            }
            if (button.dataset.intent === "options" && game.user.isGM) {
                if (this.menuAnchor === button) { closeActionMenu(); return; }
                const userId = this.userId;
                const row = preparePlayerDirectory(userId).rows.find(entry => entry.uuid === button.dataset.uuid);
                if (!row) throw new Error("This entry is no longer assigned to this player.");
                const items = row.source === "character"
                    ? [{ id: "identity", label: "Player Identity - Setup", icon: "fas fa-user-gear", onSelect: () => openPlayerSetup({ userId }) }]
                    : getPlayerAssignmentActions(userId, row.uuid);
                openActionMenu({ anchor: button, items: items.map(item => ({ ...item,
                    onSelect: () => Promise.resolve().then(item.onSelect).catch(error => ui.notifications.error(error.message)) })),
                    onClose: () => { button.setAttribute("aria-expanded", "false"); this.menuAnchor = null; } });
                this.menuAnchor = button;
                button.setAttribute("aria-expanded", "true");
                return;
            }
            if (button.dataset.intent === "open") return await openPlayerDirectoryEntry(this.userId, button.dataset.uuid);
            if (button.dataset.intent === "setup" && game.user.isGM) return await openPlayerSetup({ userId: this.userId });
        } catch (error) { ui.notifications.error(error.message); }
    }

    close() {
        if (this.menuAnchor) closeActionMenu();
        this.events?.abort();
        if (this.hook) Hooks.off("augurNexusPlayerContextChanged", this.hook);
        this.hook = null;
        this.active = false;
    }
}
