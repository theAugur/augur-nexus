import { requestPremiumAccess } from "../../access/PremiumAccess.js";

export class PlayerCreationGateway {
    static async requireModule() {
        return requestPremiumAccess("playerCreation");
    }
}
