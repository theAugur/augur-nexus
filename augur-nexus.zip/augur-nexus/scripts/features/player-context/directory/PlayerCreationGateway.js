import { showPlayerModuleRequiredDialog } from "./PlayerModuleRequiredDialog.js";

export class PlayerCreationGateway {
    static async requireModule() {
        if (game.modules.get("augur-fantasy")?.active || game.modules.get("augur-scifi")?.active) return true;
        await showPlayerModuleRequiredDialog();
        return false;
    }
}
