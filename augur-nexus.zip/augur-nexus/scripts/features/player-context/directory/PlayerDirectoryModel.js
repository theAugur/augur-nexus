import { PlayerAccessService as Access } from "../PlayerAccessService.js";
import { NexusPlayerEntityAdapter as Entities } from "../NexusPlayerEntityAdapter.js";
import { openNpcDossier } from "../../../api/npcs.js";
import { openFactionDossier } from "../../../api/factions.js";
import { openShipDossier } from "../../../api/ships.js";
import { openLocation } from "../../../api/locations.js";
import { ConnectionTargetResolver } from "../../connections/services/ConnectionTargetResolver.js";

export const PLAYER_DIRECTORY_FILTERS = { all: "All", npc: "People", faction: "Organizations", ship: "Ships", location: "Places" };

// Assignment provenance comes from Access, never from fictional ownership or discovered contacts.
export function preparePlayerDirectory(userId = "") {
    const isGM = game.user.isGM;
    const fallback = isGM ? game.users.contents.find(user => !user.isGM)?.id || game.user.id : game.user.id;
    const user = Access.user(userId || fallback);
    const { identity, rows: assignments } = Access.assignments(user);
    const rows = [];
    for (const assignment of assignments) {
        const { record, mode, source, primary } = assignment;
        if (!record) {
            if (isGM) rows.push({ uuid: assignment.uuid, name: "Missing entity", type: "", accessLabel: "Unavailable", canOpen: false });
            continue;
        }
        const access = Access.inspect(record.document.uuid, user);
        if (!isGM && !access.canView) continue;
        const view = Entities.project(record, game.user, assignment, { primary });
        rows.push({ uuid: view.uuid, id: view.id, type: view.type, typeLabel: view.typeLabel, name: view.name, image: view.image,
            source, canOpen: isGM || access.canOpenDossier,
            accessLabel: primary ? "Character" : user.isGM ? "GM access" : mode === "manage" ? "Full control" : "View only",
            unavailable: isGM && !access.canOpenDossier,
            blockedReason: isGM && !access.canOpenDossier ? access.blockedReason : "" });
    }
    rows.sort((a, b) => Number(b.source === "character") - Number(a.source === "character") || a.name.localeCompare(b.name));
    return { userId: user.id, isGM, rows, error: identity.error,
        users: isGM ? game.users.contents.map(option => ({ id: option.id, name: option.name + (option.isGM ? " (GM)" : ""), selected: option.id === user.id })) : [] };
}

export function filterPlayerDirectory(rows, { filter = "all", query = "" } = {}) {
    const term = String(query).trim().toLocaleLowerCase();
    return rows.filter(row => (filter === "all" || row.type === filter)
        && (!term || `${row.name} ${row.typeLabel || ""}`.toLocaleLowerCase().includes(term)));
}

export async function openPlayerDirectoryEntry(userId, uuid) {
    // Rebuild on click so stale buttons cannot open a revoked assignment or another player's entry.
    const row = preparePlayerDirectory(userId).rows.find(entry => entry.uuid === uuid);
    if (!row?.canOpen) throw new Error("This dossier is no longer available here.");
    const open = { npc: openNpcDossier, faction: openFactionDossier, ship: openShipDossier, location: openLocation }[row.type];
    if (!open) throw new Error("This dossier is unavailable.");
    return open(row.id);
}

export function dragPlayerDirectoryEntry(userId, uuid, dataTransfer) {
    const row = preparePlayerDirectory(userId).rows.find(entry => entry.uuid === uuid);
    if (!row?.canOpen) return false;
    const record = Entities.resolve(uuid);
    if (!record) return false;
    const node = ConnectionTargetResolver.fromCampaignEntity(record.entity, record.document);
    return ConnectionTargetResolver.setDragData(dataTransfer, node, { effectAllowed: "all" });
}
