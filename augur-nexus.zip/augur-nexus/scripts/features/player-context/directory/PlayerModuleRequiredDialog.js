/** Player-specific introduction, kept separate for future artwork and copy changes. */
export function showPlayerModuleRequiredDialog() {
    return foundry.applications.api.DialogV2.wait({
        window: { title: "Module Required", icon: "fa-solid fa-circle-info" },
        position: { width: 440 },
        content: `
            <p>Creating <strong>player-controlled ships, organizations, and locations</strong> in Nexus requires an Augur content module.</p>
            <p>Install and activate <strong>Augur: Fantasy</strong> or <strong>Augur: Sci-Fi</strong> to create entities for your players using the module's generators and artwork. Available entity types depend on the active module.</p>
            <p class="notes">Both modules are available now. Explore them on <a href="https://www.patreon.com/TheAugur" target="_blank" rel="noopener noreferrer">Patreon</a>.</p>
        `,
        buttons: [
            { action: "close", label: "Close", icon: "fa-solid fa-xmark" },
            { action: "viewModules", label: "View Modules", icon: "fa-solid fa-up-right-from-square", default: true,
                callback: () => window.open("https://www.patreon.com/TheAugur", "_blank", "noopener,noreferrer") }
        ]
    });
}
