import { PlayerAccessService } from "../PlayerAccessService.js";
import { PlayerCreationGateway } from "./PlayerCreationGateway.js";
import { openShipCreator } from "../../../api/ships.js";
import { openFactionCreator } from "../../../api/factions.js";
import { openLocationCreator } from "../../../api/locations.js";
import { CampaignEntityVisibilityManager } from "../../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { CampaignEntityDisclosureManager } from "../../campaign-entities/services/CampaignEntityDisclosureManager.js";

export const PLAYER_CREATION_TYPES = [
    { id: "ship", label: "Ship", icon: "fas fa-ship" },
    { id: "faction", label: "Organization", icon: "fas fa-shield-halved" },
    { id: "location", label: "Location", icon: "fas fa-location-dot" }
];

export async function createPlayerDirectoryEntity(type, userId) {
    if (!game.user.isGM) throw new Error("Only the GM can create player entities.");
    if (!userId || !game.users.get(userId)) throw new Error("Choose a player before creating an entity.");
    const open = { ship: openShipCreator, faction: openFactionCreator, location: openLocationCreator }[type];
    if (!open) throw new Error("Choose a ship, organization, or location.");
    if (!await PlayerCreationGateway.requireModule()) return null;
    // Capture the recipient, not the directory's mutable selection. Canceling creates no assignment.
    return open({ onCreated: async entity => {
        try {
            if (!game.user.isGM || !game.users.get(userId)) throw new Error("The selected player is no longer available.");
            await PlayerAccessService.assign(userId, { uuid: entity.uuid, mode: "manage" });
            // New player-controlled entities must be usable even under restrictive campaign defaults.
            await CampaignEntityVisibilityManager.setPlayerVisibilityOverride(entity.uuid, type, "show");
            if (type === "location") await CampaignEntityDisclosureManager.setPlayerDisclosureOverride(entity.uuid, type, "full");
        } catch (error) {
            // Creation already succeeded. Finish the creator instead of offering to create a duplicate.
            ui.notifications.error(`${entity.display?.name || "The entity"} was created, but player access could not be completed: ${error.message} Review it in Player Identity - Setup.`);
        }
    } });
}
