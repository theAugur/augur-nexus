import { MODULE_ID, safeImage } from "./PlayerContextPolicy.js";
import { NexusPlayerEntityAdapter as Entities } from "./NexusPlayerEntityAdapter.js";
import { PlayerAccessService as Access } from "./PlayerAccessService.js";

export class PlayerContextService {
    static getContext(userId = game.user.id) {
        const user = Access.user(userId);
        const { identity, rows } = Access.assignments(user);
        const entries = rows.filter(row => row.record && Access.inspect(row.record.document.uuid, user).canView)
            .map(row => Entities.project(row.record, user, { mode: row.mode, source: row.source,
                reason: row.mode === "manage" ? "Full control" : "View only" }, { primary: row.primary }));
        const character = entries.find(entry => entry.primary) || null;
        if (character) for (const { record, reason } of Entities.related(identity.person, user)) {
            if (entries.some(entry => entry.uuid === record.document.uuid)) continue;
            entries.push(Entities.project(record, user, { mode: "view", source: "relationship", reason }));
        }
        const selected = user.getFlag(MODULE_ID, "playerCurrentAsset") || "";
        const currentAsset = entries.find(entry => entry.uuid === selected && ["ship", "location"].includes(entry.type)) || null;
        const primaryShipId = user.getFlag(MODULE_ID, "playerPrimaryShip") || "";
        const primaryShip = entries.find(entry => entry.uuid === primaryShipId && entry.type === "ship") || null;
        const primaryFactionId = user.getFlag(MODULE_ID, "playerPrimaryFaction") || "";
        const primaryFaction = entries.find(entry => entry.uuid === primaryFactionId && entry.type === "faction" && entry.canEdit) || null;
        return { userId: user.id, userName: user.name, character, entries, currentAsset, primaryShip, primaryFaction,
            actor: identity.actor?.testUserPermission(user, "OBSERVER") ? { uuid: identity.actor.uuid, name: identity.actor.name, image: identity.actor.img } : null,
            error: identity.error, preview: user.id !== game.user.id };
    }

    static getSetupData() {
        if (!game.user?.isGM) throw new Error("Only the GM can manage player assignments.");
        return {
            users: game.users.contents.map(user => {
                const identity = Access.identity(user);
                return { id: user.id, name: user.name, isGM: user.isGM, actorId: identity.actor?.id || "",
                    personUuid: identity.person?.document.uuid || "", shipUuid: user.getFlag(MODULE_ID, "playerPrimaryShip") || "",
                    shipActorUuid: user.getFlag(MODULE_ID, "playerShipActor") || "", identityError: identity.error, grants: Access.grants(user.id) };
            }),
            actors: game.actors.contents.map(actor => {
                const identity = Access.actorIdentity(actor);
                return { id: actor.id, uuid: actor.uuid, name: actor.name, type: actor.type, image: safeImage(actor.img),
                    personUuid: identity.person?.document.uuid || "", identityError: identity.error };
            }),
            entities: Entities.list().map(({ document, entity }) => ({ uuid: document.uuid, id: entity.id, name: entity.display?.name || document.name,
                image: Entities.image(entity), type: entity.type, actorUuid: entity.projections?.actorUuid || "" }))
        };
    }

    static async selectAsset(uuid) {
        const context = this.getContext();
        if (uuid && !context.entries.some(entry => entry.uuid === uuid && ["ship", "location"].includes(entry.type))) throw new Error("Choose an assigned vessel or place.");
        await game.user.setFlag(MODULE_ID, "playerCurrentAsset", uuid || "");
    }

    static async selectPrimaryShip(uuid) {
        if (uuid && !this.getContext().entries.some(entry => entry.uuid === uuid && entry.type === "ship")) throw new Error("Choose an available ship from Holdings.");
        await game.user.setFlag(MODULE_ID, "playerPrimaryShip", uuid || "");
    }

    static async selectPrimaryFaction(uuid) {
        if (uuid && !this.getContext().entries.some(entry => entry.uuid === uuid && entry.type === "faction" && entry.canEdit)) throw new Error("Choose a faction you have full control over from Contacts.");
        await game.user.setFlag(MODULE_ID, "playerPrimaryFaction", uuid || "");
    }

    static async openEntity(uuid, { actor = false, userId = game.user.id } = {}) {
        if (userId !== game.user.id) throw new Error("The player preview only displays the shared summary. Open full sheets from your own workspace.");
        const context = this.getContext(userId);
        const entry = context.entries.find(value => value.uuid === uuid);
        if (!entry) throw new Error("This entity is no longer assigned to you.");
        if (actor) {
            if (!entry.actorUuid) throw new Error("The linked Actor is missing or unavailable to this player.");
            const document = await fromUuid(entry.actorUuid);
            return document?.sheet.render(true);
        }
        if (!entry.canOpenDossier) throw new Error("The full dossier is not available to this player.");
        if (entry.type === "location") return (await import("../../api/locations.js")).openLocation(entry.id);
        const paths = { npc: ["../campaign-entities/applications/NpcDossier.js", "NpcDossier", "npcId"], ship: ["../campaign-entities/applications/ShipDossier.js", "ShipDossier", "shipId"], faction: ["../campaign-entities/applications/FactionDossier.js", "FactionDossier", "factionId"] };
        const [path, className, key] = paths[entry.type];
        return (await import(path))[className].show({ [key]: entry.id });
    }

    static async openCharacterSheet() {
        const actor = game.user.character;
        if (!actor?.testUserPermission(game.user, "OBSERVER")) throw new Error("Your character Actor is missing or unavailable. Ask the GM to link it in Player Setup.");
        return actor.sheet.render(true);
    }

}
