import { PlayerAccessService } from "./PlayerAccessService.js";
import { PlayerContextService } from "./PlayerContextService.js";
import { NpcHeaderModel } from "../campaign-entities/models/NpcHeaderModel.js";
import { NpcEntityModel } from "../campaign-entities/models/NpcEntityModel.js";
import { NpcDataEditor } from "../campaign-entities/applications/NpcDataEditor.js";
import { openNpcDossier } from "../../api/npcs.js";
import { ConnectionTargetResolver } from "../connections/services/ConnectionTargetResolver.js";

export class PlayerNexusHeader {
    static prepare() {
        const user = game.user;
        if (!user || user.isGM) return null;
        const { actor, person, error } = PlayerAccessService.identity(user);
        if (error || !person) return null;
        const access = PlayerAccessService.inspect(person.document.uuid, user);
        if (!access.canOpenDossier) return null;
        return {
            ...NpcHeaderModel.fromEntity(person.entity, { includeDescriptorInSubtitle: true }),
            uuid: person.document.uuid,
            id: person.entity.id,
            canEdit: access.canManage,
            coverImage: NpcHeaderModel.coverImage(person.entity),
            traits: NpcEntityModel.getTraits(person.entity),
            canOpenActor: !!actor?.testUserPermission(user, "OBSERVER")
        };
    }

    static bind(element) {
        const portrait = element.querySelector("[data-player-header-drag]");
        if (!portrait || portrait.dataset.dragBound) return;
        portrait.dataset.dragBound = "true";
        portrait.addEventListener("dragstart", event => this.dragStart(event, portrait));
    }

    static dragStart(event, portrait) {
        event.stopPropagation();
        const current = this.prepare();
        if (!current?.canEdit || current.uuid !== portrait.dataset.uuid) { event.preventDefault(); return; }
        const { person } = PlayerAccessService.identity(game.user);
        const node = ConnectionTargetResolver.fromCampaignEntity(person.entity, person.document);
        if (!ConnectionTargetResolver.setDragData(event.dataTransfer, node, { effectAllowed: "all" })) event.preventDefault();
    }

    static async action(_event, button) {
        try {
            const current = this.prepare();
            if (!current || current.uuid !== button.dataset.uuid) return;
            if (button.dataset.intent === "dossier") return await openNpcDossier(current.id);
            if (button.dataset.intent === "edit" && current.canEdit) return NpcDataEditor.show({ npcId: current.id });
            if (button.dataset.intent === "sheet" && current.canOpenActor) return await PlayerContextService.openCharacterSheet();
        } catch (error) {
            ui.notifications.warn(error.message);
        }
    }
}
