// Shared by visibility and access without importing either higher-level service.
export function resolveActorPerson(actor) {
    if (!actor) return { person: null, error: "" };
    const matches = game.journal.contents.filter(document => {
        const entity = document.getFlag("augur-nexus", "campaignEntity");
        return entity?.type === "npc" && entity.projections?.actorUuid === actor.uuid;
    });
    if (matches.length > 1) return { person: null, error: "This Actor is linked to several Nexus People. The GM must resolve the duplicate links." };
    const document = matches[0];
    return { person: document ? { document, entity: document.getFlag("augur-nexus", "campaignEntity") } : null, error: "" };
}
export function resolvePlayerIdentity(user) {
    const actor = user?.character || null;
    const { person, error } = resolveActorPerson(actor);
    const canControl = !!actor?.testUserPermission(user, "OWNER") && !!person?.document.testUserPermission(user, "OBSERVER");
    return { actor, person, canControl, error };
}
export function isPlayerCharacterEntity(entity, user = game.user) {
    const identity = resolvePlayerIdentity(user);
    return entity?.type === "npc" && identity.canControl && identity.person?.entity.id === entity?.id;
}
