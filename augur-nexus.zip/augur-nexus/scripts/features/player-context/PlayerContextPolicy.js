export const MODULE_ID = "augur-nexus";
export const GRANTS_KEY = "playerContextGrants";
export const REQUEST_KEY = "playerContextRequest";
export const RESULT_KEY = "playerContextResult";
export const ENTITY_TYPES = new Set(["npc", "faction", "ship", "location"]);
export const MODES = new Set(["view", "manage"]);

export function validateGrant(grant) {
    if (!grant || !/^JournalEntry\.[A-Za-z0-9]+$/.test(grant.uuid || "") || !MODES.has(grant.mode)) {
        throw new Error("Choose a campaign entity and a valid access level.");
    }
    return { uuid: grant.uuid, mode: grant.mode };
}

export function safeImage(value) {
    const path = String(value || "").trim();
    return path && !/^(?:javascript|data|vbscript):/i.test(path) ? path : "icons/svg/mystery-man.svg";
}

export function cleanText(value) {
    // Profiles are plain text here. Never carry secret blocks or executable markup into a player view.
    const text = String(value || "");
    if (typeof DOMParser === "undefined") return /[<>]/.test(text) ? "" : text;
    const doc = new DOMParser().parseFromString(text, "text/html");
    doc.querySelectorAll(".secret, script, style, iframe, object").forEach(element => element.remove());
    return doc.body.textContent || "";
}

export function editableDescription(entity) {
    const hidden = entity?.dossier?.hiddenDefaultFields || [];
    return !hidden.some(key => /description|summary/i.test(key));
}
