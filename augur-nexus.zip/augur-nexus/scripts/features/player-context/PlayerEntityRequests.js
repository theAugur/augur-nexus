import { assertPlayerEntityControl, resolveControlledDocument } from "./PlayerAccessService.js";

export function getPlayerEntityRevision(reference) {
    return resolveControlledDocument(reference)?._stats?.modifiedTime || 0;
}

export async function requestEntityUpdate(document, patch, options = {}) {
    assertPlayerEntityControl(document.uuid);
    const { requestPlayerMutation } = await import("./PlayerContextRequests.js");
    return requestPlayerMutation({ operation: "entity.update", uuid: document.uuid, patch,
        before: options.expectedRevision ?? document._stats?.modifiedTime ?? 0, moduleId: options.moduleId || "" });
}
