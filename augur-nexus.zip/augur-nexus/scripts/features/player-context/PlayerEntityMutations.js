import { executeEntityOperation } from "./PlayerEntityOperations.js";
import { assertPlayerEntityControl, resolveControlledDocument } from "./PlayerAccessService.js";
import { ConnectionStore } from "../connections/services/ConnectionStore.js";
import { ConnectionTargetResolver } from "../connections/services/ConnectionTargetResolver.js";

function onlyKeys(value, keys) {
    if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some(key => !keys.includes(key))) {
        throw new Error("Unsupported campaign edit.");
    }
}

function validateData(value, depth = 0) {
    if (!value || typeof value !== "object") return;
    if (depth > 40 || Object.keys(value).some(key => ["__proto__", "constructor", "prototype"].includes(key))) throw new Error("Invalid campaign data.");
    for (const child of Object.values(value)) validateData(child, depth + 1);
}

function visibleTarget(reference, user) {
    const document = resolveControlledDocument(reference);
    if (!document || (document.getFlag("augur-nexus", "campaignEntity")?.type !== "quest" && !document.testUserPermission(user, "OBSERVER"))) throw new Error("That related entity is unavailable.");
    const target = ConnectionTargetResolver.fromCampaignEntity(document.getFlag("augur-nexus", "campaignEntity"), document);
    if (!ConnectionTargetResolver.canUserSeeNode(target, user)) throw new Error("That related entity is unavailable.");
    return target;
}

function permittedEdge(edgeId, user, nodeId = "") {
    const edge = ConnectionStore.getConnectionEdge(edgeId);
    if (!edge || !ConnectionStore.canUserSeeConnection(edge, user)) throw new Error("That connection is unavailable.");
    const endpoints = [edge.sourceNodeId, edge.targetNodeId];
    endpoints.forEach(id => {
        const node = ConnectionStore.getNode(id);
        if (node?.kind === "nexus-entity") return visibleTarget(node, user);
        const resolved = node && ConnectionTargetResolver.resolveDisplayNodeSync(node);
        const document = node?.kind === "nexus-scene" ? game.scenes.get(node.sceneId)
            : node?.kind === "nexus-site" ? game.scenes.get(node.parentSceneId)
            : node?.uuid ? fromUuidSync(node.uuid) : null;
        if (!resolved || resolved.missing || !document?.testUserPermission(user, "OBSERVER")
            || !ConnectionTargetResolver.canUserSeeNode(node, user)) throw new Error("That related entity is unavailable.");
    });
    if (nodeId && !endpoints.includes(nodeId)) throw new Error("That entity is not part of this connection.");
    const controlled = nodeId || endpoints.find(id => {
        try { assertPlayerEntityControl(id, user); return true; } catch { return false; }
    });
    assertPlayerEntityControl(controlled, user);
    return edge;
}

// Requests describe domain operations; they never carry arbitrary document updates or a graph replacement.
export async function executePlayerMutation(request, user) {
    if (!game.user?.isGM || !user) throw new Error("A GM must process campaign edits.");
    if (!request || typeof request.operation !== "string") throw new Error("Invalid campaign operation.");
    validateData(request);
    onlyKeys(request, ["id", "operation", "uuid", "patch", "before", "moduleId", "args"]);
    if (request.operation === "entity.update") {
        const document = assertPlayerEntityControl(request.uuid, user);
        if (!document) throw new Error("That campaign entity no longer exists.");
        if ((document._stats?.modifiedTime || 0) !== request.before) throw new Error("This entity changed while saving. Reopen the editor before trying again.");
        const entity = document.getFlag("augur-nexus", "campaignEntity");
        if (entity.type === "quest") throw new Error("Use the quest editor to change quest content.");
        onlyKeys(request.patch, ["display", "role", "flavor", "personality", "ideology", "profile", "dossier", "currentThread", "hierarchy", "moduleData", "projections"]);
        if (request.patch.projections) {
            if (entity.type !== "npc") throw new Error("Artwork linking is only available for People.");
            onlyKeys(request.patch.projections, ["syncActorPortrait", "syncActorToken"]);
            if (Object.values(request.patch.projections).some(value => typeof value !== "boolean")) throw new Error("Invalid artwork link setting.");
            const actor = entity.projections?.actorUuid ? await fromUuid(entity.projections.actorUuid) : null;
            if (actor?.documentName !== "Actor" || !actor.testUserPermission(user, "OWNER")) throw new Error("Ownership of the linked Actor is required to change artwork linking.");
        }
        if (request.patch.hierarchy) {
            onlyKeys(request.patch.hierarchy, ["parent"]);
            const parent = request.patch.hierarchy.parent;
            if (parent && JSON.stringify(parent) !== JSON.stringify(entity.hierarchy?.parent)) {
                if (parent.kind === "location") visibleTarget(parent.locationId, user);
                else if (!["scene", "site"].includes(parent.kind) || !game.scenes.get(parent.sceneId || parent.parentSceneId)?.testUserPermission(user, "OBSERVER")) {
                    throw new Error("The selected parent place is unavailable.");
                }
            }
        }
        // A normal editor can write the entity's source namespace or a registered editor extension.
        if (request.patch.moduleData) {
            let registered = !!request.moduleId && request.moduleId === entity.sourceModule;
            if (!registered && entity.type === "faction") {
                const { FactionEditorFieldRegistry } = await import("../campaign-entities/services/FactionEditorFieldRegistry.js");
                registered = FactionEditorFieldRegistry.hasEditorNamespace(entity, request.moduleId);
            }
            if (!registered && entity.type === "location") {
                const { LocationEditorSectionRegistry } = await import("../campaign-entities/services/LocationEditorSectionRegistry.js");
                registered = LocationEditorSectionRegistry.hasEditorNamespace(entity, request.moduleId);
            }
            if (!registered) throw new Error("Invalid module editor scope.");
            onlyKeys(request.patch.moduleData, [request.moduleId]);
        }
        const { CampaignEntityJournalStore } = await import("../campaign-entities/services/CampaignEntityJournalStore.js");
        const { LocationEntityStore } = await import("../campaign-entities/services/LocationEntityStore.js");
        const store = entity.type === "location" ? LocationEntityStore : CampaignEntityJournalStore;
        const method = { npc: "updateNpc", faction: "updateFaction", ship: "updateShip", location: "updateLocation" }[entity.type];
        if (!method) throw new Error("Unsupported entity type.");
        return store[method](document.uuid, request.patch, { ...(request.moduleId ? { moduleId: request.moduleId } : {}), artworkUser: user });
    }
    const args = request.args;
    if (!Array.isArray(args) || args.length > 5) throw new Error("Invalid connection edit.");
    if (request.operation.startsWith("extension.")) return executeEntityOperation(request, user);
    if (request.operation.startsWith("domain.")) {
        const [, service, method] = request.operation.split(".");
        const methods = {
            ShipCaptainService: ["setCaptain", "clearCaptain"],
            ShipOwnershipService: ["setOwner", "clearOwner"],
            ShipCrewService: ["addCrew", "removeCrew"],
            ShipLocationService: ["setCurrentLocation", "clearCurrentLocation"],
            OwnershipService: ["setOwner", "clearOwner"],
            FactionSeatService: ["setSeat", "clearSeat"],
            LocationLeadershipService: ["setLeader", "clearLeader"],
            FactionMembershipService: ["setMember", "setLeader", "clearMembership", "setRank"]
        };
        if (!methods[service]?.includes(method)) throw new Error("Unsupported domain operation.");
        if (service === "FactionMembershipService" && ["clearMembership", "setRank"].includes(method)) {
            const edgeId = typeof args[0] === "string" ? args[0] : args[0]?.id;
            const edge = permittedEdge(edgeId, user);
            assertPlayerEntityControl(edge.factionMembership?.factionNodeId, user);
            args[0] = edgeId;
        } else {
            assertPlayerEntityControl(args[0], user);
            args[0] = visibleTarget(args[0], user);
            const controlledType = service.startsWith("Ship") ? "ship" : service.startsWith("Faction") ? "faction" : "location";
            if (args[0].entityType !== controlledType) throw new Error("Control the ship, organization, or place whose role is being changed.");
            const hasRelated = method.startsWith("set") || method.endsWith("Crew");
            if (hasRelated) args[1] = visibleTarget(args[1], user);
            const options = args[hasRelated ? 2 : 1];
            if (options) {
                onlyKeys(options, ["edgeId", "role", "sourceRole", "targetRole", "rank", "authorityType", "source"]);
                if (options.source && options.source !== "manual") throw new Error("Players can only record a location manually.");
                if (options.edgeId) {
                    const edge = permittedEdge(options.edgeId, user, args[0].id);
                    if (hasRelated && ![edge.sourceNodeId, edge.targetNodeId].includes(args[1].id)) throw new Error("The selected edge joins a different entity.");
                }
            }
            // A role replacement may touch existing relationships. Never change an undisclosed one.
            for (const { edge, node } of ConnectionStore.getGraphContext().adjacency.get(args[0].id) || []) {
                if (edge.relationType || edge.factionMembership || edge.factionSeat || edge.locationLeadership) {
                    if (!ConnectionStore.canUserSeeConnection(edge, user)) throw new Error("The GM must review a private relationship before this change.");
                    visibleTarget(node, user);
                }
            }
        }
        const implementation = await import(`../connections/services/${service}.js`);
        return implementation[service][method](...args);
    }
    switch (request.operation) {
        case "connection.add": {
            const [source, related, options = {}] = args;
            assertPlayerEntityControl(source, user);
            const a = visibleTarget(source, user), b = visibleTarget(related, user);
            onlyKeys(options, ["category", "role", "sourceView", "targetView"]);
            for (const view of [options.sourceView, options.targetView].filter(Boolean)) onlyKeys(view, ["category", "role", "note"]);
            const existing = ConnectionStore.getConnectionsForNode(a.id).find(row => row.node.id === b.id)?.edge;
            if (existing && !ConnectionStore.canUserSeeConnection(existing, user)) throw new Error("This connection cannot be changed.");
            return ConnectionStore.addConnection(a, b, options);
        }
        case "connection.view":
            permittedEdge(args[0], user, args[1]);
            onlyKeys(args[2], ["category", "role", "note", "sort"]);
            return ConnectionStore.setConnectionViewForNode(...args);
        case "connection.remove": {
            const edge = permittedEdge(args[0], user);
            if (edge.factionHierarchy) throw new Error("Only the GM can remove an organization hierarchy Connection.");
            const authority = edge.factionMembership?.factionNodeId || edge.factionSeat?.factionNodeId
                || edge.locationLeadership?.locationNodeId || edge.shipCaptain?.shipNodeId
                || edge.shipOwnership?.shipNodeId || edge.shipLocation?.shipNodeId;
            if (authority) assertPlayerEntityControl(authority, user);
            else if (edge.relationType === "ship-crew") {
                // Crew records identify their authority by the ship endpoint, without separate role metadata.
                const shipNodeId = [edge.sourceNodeId, edge.targetNodeId].find(id =>
                    resolveControlledDocument(id)?.getFlag("augur-nexus", "campaignEntity")?.type === "ship");
                assertPlayerEntityControl(shipNodeId, user);
            }
            else if (edge.relationType) {
                // Legacy managed edges may lack role metadata. Require both endpoints instead of guessing their owner.
                assertPlayerEntityControl(edge.sourceNodeId, user);
                assertPlayerEntityControl(edge.targetNodeId, user);
            }
            return ConnectionStore.removeConnection(args[0]);
        }
        case "connection.reorder":
            permittedEdge(args[0], user, args[1]);
            if (args[2]) permittedEdge(args[2], user, args[1]);
            return ConnectionStore.reorderConnectionForNode(...args);
        case "connection.group":
            assertPlayerEntityControl(args[0], user);
            return ConnectionStore.moveGroupForNode(...args);
        default:
            throw new Error("Unsupported campaign operation.");
    }
}
