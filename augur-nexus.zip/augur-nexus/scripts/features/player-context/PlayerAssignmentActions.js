import { PlayerAccessService as Access } from "./PlayerAccessService.js";
import { NexusPlayerEntityAdapter as Entities } from "./NexusPlayerEntityAdapter.js";

// Shared by Setup and the Player directory; each operation rechecks the current assignment.
export function getPlayerAssignmentActions(userId, uuid) {
    if (!game.user.isGM) return [];
    const user = Access.user(userId);
    const grant = Access.grants(user.id).find(row => row.uuid === uuid);
    if (!grant) return [];
    const current = () => {
        const value = Access.grants(user.id).find(row => row.uuid === uuid);
        if (!value) throw new Error("This assignment is no longer available.");
        return value;
    };
    const items = user.isGM ? [] : ["view", "manage"].map(mode => ({
        id: mode, label: mode === "manage" ? "Full control" : "View only", icon: mode === "manage" ? "fas fa-pen" : "fas fa-eye",
        status: grant.mode === mode ? "Current" : "", unavailable: !Entities.resolve(uuid),
        onSelect: () => Access.assign(user.id, { ...current(), mode })
    }));
    items.push({ id: "remove", label: user.isGM ? "Remove from wheel" : "Remove access", icon: "fas fa-unlink", danger: true,
        onSelect: () => Access.assign(user.id, current(), { remove: true }) });
    return items;
}
