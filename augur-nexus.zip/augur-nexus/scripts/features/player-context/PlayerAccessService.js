import { CampaignEntityVisibilityManager } from "../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { CampaignEntityDisclosureManager } from "../campaign-entities/services/CampaignEntityDisclosureManager.js";

import { resolvePlayerIdentity, resolveActorPerson, isPlayerCharacterEntity } from "./PlayerCharacterIdentity.js";

import { canReadQuest, canEditQuest } from "../quests/models/QuestModel.js";

import { MODULE_ID, GRANTS_KEY, validateGrant } from "./PlayerContextPolicy.js";
import { NexusPlayerEntityAdapter as Entities } from "./NexusPlayerEntityAdapter.js";

let writeQueue = Promise.resolve();
export function serializeContextWrite(work) {
    const next = writeQueue.then(work);
    writeQueue = next.catch(() => {});
    return next;
}
function assertGM(user = game.user) { if (!user?.isGM) throw new Error("Only the GM can manage player assignments."); }


export function resolveControlledDocument(reference) {
    const id = typeof reference === "string" ? reference : reference?.entityId || reference?.id || reference?.uuid;
    if (!id) return null;
    return game.journal.find(document => {
        const entity = document.getFlag(MODULE_ID, "campaignEntity");
        return entity && [document.uuid, document.id, entity.id, `nexus-entity:${entity.id}`].includes(id);
    }) || null;
}

// The saved character controls its own Person. Other entities require an explicit grant.
export function canControlPlayerEntity(reference, user = game.user) {
    if (user?.isGM) return true;
    const document = resolveControlledDocument(reference);
    const entity = document?.getFlag(MODULE_ID, "campaignEntity");
    if (entity?.type === "quest") return canReadQuest(entity, user) && canEditQuest(entity, user);
    if (!document?.testUserPermission(user, "OBSERVER")) return false;
    if (isPlayerCharacterEntity(entity, user)) return true;
    const assigned = PlayerAccessService.grants(user?.id)
        .some(grant => grant.uuid === document.uuid && grant.mode === "manage");
    return assigned && CampaignEntityVisibilityManager.canUserSee(entity, user)
        && (entity.type !== "location" || CampaignEntityDisclosureManager.canUserViewDetails(entity, user));
}

export function assertPlayerEntityControl(reference, user = game.user) {
    if (!canControlPlayerEntity(reference, user)) throw new Error("You no longer control this campaign entity. Ask the GM to review your character or additional access.");
    return resolveControlledDocument(reference);
}


export class PlayerAccessService {
    static user(userId = game.user.id) {
        if (userId !== game.user.id && !game.user.isGM) throw new Error("You may only open your own player home.");
        const user = game.users.get(userId);
        if (!user) throw new Error("The player no longer exists.");
        return user;
    }

    static grants(userId) { return foundry.utils.deepClone(game.settings.get(MODULE_ID, GRANTS_KEY)?.[userId] || []); }
    static actorIdentity(actor) { return resolveActorPerson(actor); }
    static identity(user) { return resolvePlayerIdentity(user); }
    static inspect(reference, user = game.user) {
        const document = resolveControlledDocument(reference);
        const entity = document?.getFlag(MODULE_ID, "campaignEntity");
        const native = !!document?.testUserPermission(user, "OBSERVER");
        const visible = !!entity && (entity.type === "quest" ? canReadQuest(entity, user) : native && CampaignEntityVisibilityManager.canUserSee(entity, user));
        const disclosed = entity?.type !== "location" || CampaignEntityDisclosureManager.canUserViewDetails(entity, user);
        const canManage = !!entity && canControlPlayerEntity(document.uuid, user);
        const blockedReason = !entity ? "This entity no longer exists." : !visible ? "This entity is not visible to this player."
            : !disclosed ? "The GM has not revealed this dossier." : !canManage ? "This player does not currently control this entity." : "";
        return { canView: visible, canOpenDossier: visible && disclosed, canManage, blockedReason };
    }
    static assignments(user) {
        const identity = this.identity(user), rows = [];
        if (identity.person) rows.push({ record: identity.person, source: "character", mode: "manage", primary: true });
        for (const grant of this.grants(user.id)) {
            if (grant.uuid === identity.person?.document.uuid) continue;
            rows.push({ record: Entities.resolve(grant.uuid), uuid: grant.uuid, source: "assignment", mode: grant.mode, primary: false });
        }
        return { identity, rows };
    }

    static async request(action, data = {}) {
        assertGM();
        const { requestAccessMutation } = await import("./PlayerContextRequests.js");
        return requestAccessMutation({ action, ...data });
    }
    static assign(userId, grant, { remove = false } = {}) { return this.request("assign", { userId, grant, remove }); }
    static linkCharacter(userId, actorId, personUuid = "", { expectedActorId, expectedPersonUuid } = {}) {
        return this.request("identity", { userId, actorId, personUuid,
            ...(expectedActorId !== undefined ? { expectedActorId } : {}),
            ...(expectedPersonUuid !== undefined ? { expectedPersonUuid } : {}) });
    }
    static unlinkPerson(userId, actorId, personUuid) { return this.request("unlinkPerson", { userId, actorId, personUuid }); }
    static clearIdentity(userId, actorId) { return this.request("clearIdentity", { userId, actorId }); }
    static assignShip(userId, shipUuid, { expectedShipUuid, expectedActorUuid } = {}) {
        return this.request("ship", { userId, shipUuid,
            ...(expectedShipUuid !== undefined ? { expectedShipUuid } : {}),
            ...(expectedActorUuid !== undefined ? { expectedActorUuid } : {}) });
    }
    static assignShipActor(userId, actorId) { return this.request("shipActor", { userId, actorId }); }
    static clearShip(userId, shipUuid, actorUuid) { return this.request("clearShip", { userId, shipUuid, actorUuid }); }
    static unlinkShip(userId, shipUuid, actorUuid) { return this.request("unlinkShip", { userId, shipUuid, actorUuid }); }
    static reconcile() { return this.request("reconcile"); }

    // Called only by the authenticated request dispatcher inside its shared execution queue.
    static async execute(data, sender) {
        assertGM(sender); assertGM();
        const allowed = {
            assign: ["action", "userId", "grant", "remove"],
            identity: ["action", "userId", "actorId", "personUuid", "expectedActorId", "expectedPersonUuid"],
            clearIdentity: ["action", "userId", "actorId"],
            unlinkPerson: ["action", "userId", "actorId", "personUuid"],
            ship: ["action", "userId", "shipUuid", "expectedShipUuid", "expectedActorUuid"],
            shipActor: ["action", "userId", "actorId"],
            clearShip: ["action", "userId", "shipUuid", "actorUuid"],
            unlinkShip: ["action", "userId", "shipUuid", "actorUuid"],
            reconcile: ["action"]
        }[data?.action];
        if (!allowed || Object.keys(data).some(key => !allowed.includes(key))) throw new Error("Invalid player access operation.");
        if (data.action === "reconcile") return this.#reconcile();
        if (typeof data.userId !== "string" || !data.userId) throw new Error("Choose a player.");
        const user = this.user(data.userId);
        if (data.action === "shipActor") {
            const actor = typeof data.actorId === "string" ? game.actors.get(data.actorId) : null;
            if (!actor) throw new Error("Choose an existing world Actor.");
            const { CampaignEntityActorBridge } = await import("../campaign-entities/services/CampaignEntityActorBridge.js");
            const linked = CampaignEntityActorBridge.getLinkedEntityForActor(actor);
            if (linked && linked.type !== "ship") throw new Error("That Actor is linked to another campaign entity. Unlink it first.");
            if (linked) {
                const record = Entities.list().find(row => row.entity.type === "ship" && row.entity.id === linked.id);
                if (!record) throw new Error("The linked Nexus Ship is unavailable.");
                return this.#saveShip(user, record.document.uuid, actor.uuid, sender);
            }
            if (!actor.testUserPermission(user, "OWNER")) await actor.update({ [`ownership.${user.id}`]: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER });
            await user.setFlag(MODULE_ID, "playerShipActor", actor.uuid);
            // Replacing the Actor must not leave the previous Ship displayed as its partner.
            await user.unsetFlag(MODULE_ID, "playerPrimaryShip");
            return null;
        }
        if (["ship", "clearShip", "unlinkShip"].includes(data.action)) {
            const selected = user.getFlag(MODULE_ID, "playerPrimaryShip") || "";
            const assignedActor = user.getFlag(MODULE_ID, "playerShipActor") || "";
            if (typeof data.shipUuid !== "string" || (data.action !== "clearShip" && !data.shipUuid)) throw new Error("Choose a Nexus Ship.");
            if ((data.action !== "ship" && selected !== data.shipUuid)
                || (Object.hasOwn(data, "expectedShipUuid") && selected !== data.expectedShipUuid)
                || (Object.hasOwn(data, "expectedActorUuid") && assignedActor !== data.expectedActorUuid)) {
                throw new Error("This player's ship changed. Review Setup before continuing.");
            }
            if (data.action === "clearShip") {
                if (data.actorUuid !== assignedActor) throw new Error("This player's Ship Actor changed. Refresh Setup before clearing it.");
                // Clear the assignments, preserving documents, their link and existing permissions.
                await user.unsetFlag(MODULE_ID, "playerPrimaryShip");
                await user.unsetFlag(MODULE_ID, "playerShipActor");
                return null;
            }
            if (data.action === "ship") return this.#saveShip(user, data.shipUuid, assignedActor, sender, { copyArtwork: true });
            const record = Entities.resolve(data.shipUuid);
            if (record?.entity.type !== "ship") throw new Error("Choose an existing Nexus Ship.");
            if (typeof data.actorUuid !== "string" || (record.entity.projections?.actorUuid || "") !== data.actorUuid) throw new Error("This Ship's Actor link changed. Refresh Setup before unlinking it.");
            if (data.actorUuid) {
                const { CampaignEntityActorBridge } = await import("../campaign-entities/services/CampaignEntityActorBridge.js");
                await CampaignEntityActorBridge.unlinkActor({ ...record.entity, uuid: record.document.uuid, journalEntryId: record.document.id });
            }
            await user.unsetFlag(MODULE_ID, "playerPrimaryShip");
            return null;
        }
        if (data.action === "unlinkPerson") {
            const { actor, person, error } = this.identity(user);
            if (error || !actor || !person || actor.id !== data.actorId || person.document.uuid !== data.personUuid
                || person.entity.projections?.actorUuid !== actor.uuid) {
                throw new Error("This player's Actor or Person link has changed. Refresh Setup before unlinking it.");
            }
            const { CampaignEntityActorBridge } = await import("../campaign-entities/services/CampaignEntityActorBridge.js");
            await CampaignEntityActorBridge.unlinkActor({ ...person.entity, uuid: person.document.uuid, journalEntryId: person.document.id });
            return null;
        }
        if (data.action === "clearIdentity") {
            if (typeof data.actorId !== "string" || user.character?.id !== data.actorId) throw new Error("This player's identity has changed. Refresh Setup before clearing it.");
            const personUuid = this.identity(user).person?.document.uuid;
            // User.character owns the assignment. Actor permissions and the Actor/Person link are independent.
            const all = foundry.utils.deepClone(game.settings.get(MODULE_ID, GRANTS_KEY) || {});
            const grants = all[user.id] || [];
            const remaining = grants.filter(grant => grant.uuid !== personUuid);
            if (remaining.length !== grants.length) {
                all[user.id] = remaining;
                await game.settings.set(MODULE_ID, GRANTS_KEY, all);
            }
            await user.update({ character: null });
            return null;
        }
        if (data.action === "identity") {
            if ((Object.hasOwn(data, "expectedActorId") && (user.character?.id || "") !== data.expectedActorId)
                || (Object.hasOwn(data, "expectedPersonUuid") && (this.identity(user).person?.document.uuid || "") !== data.expectedPersonUuid)) {
                throw new Error("This player's identity changed. Review Setup before assigning this Person.");
            }
            return this.#linkCharacter(user, data.actorId, data.personUuid || "");
        }
        const grant = validateGrant(data.grant), record = Entities.resolve(grant.uuid);
        if (data.remove !== undefined && typeof data.remove !== "boolean") throw new Error("Invalid removal option.");
        if (!data.remove && this.identity(user).person?.document.uuid === grant.uuid) throw new Error("This is the player’s character. Its full control comes from the saved identity.");
        if (!record && !data.remove) throw new Error("That campaign entity no longer exists.");
        if (!data.remove && !record.document.testUserPermission(user, "OBSERVER")) throw new Error("This journal is private. Give the player Observer access after reviewing its contents before assigning it.");
        const all = foundry.utils.deepClone(game.settings.get(MODULE_ID, GRANTS_KEY) || {});
        all[user.id] = (all[user.id] || []).filter(row => row.uuid !== grant.uuid);
        if (!data.remove) all[user.id].push(grant);
        await game.settings.set(MODULE_ID, GRANTS_KEY, all);
        if (data.remove) await this.#clearSelections(user, grant.uuid);
        else if (grant.mode !== "manage" && user.getFlag(MODULE_ID, "playerPrimaryFaction") === grant.uuid) await user.unsetFlag(MODULE_ID, "playerPrimaryFaction");
        return null;
    }

    static async #saveShip(user, shipUuid, assignedActorUuid, sender, { copyArtwork = false } = {}) {
        const record = Entities.resolve(shipUuid);
        if (record?.entity.type !== "ship") throw new Error("Choose an existing Nexus Ship.");
        const actorUuid = record.entity.projections?.actorUuid || "";
        const targetActorUuid = assignedActorUuid || actorUuid;
        const actor = targetActorUuid ? game.actors.contents.find(row => row.uuid === targetActorUuid) : null;
        if (targetActorUuid && !actor) throw new Error("The assigned Ship Actor is unavailable. Clear it before assigning a replacement.");
        if (actorUuid && actor?.uuid !== actorUuid) throw new Error("That Ship is already linked to another Actor. Unlink it first.");
        const { CampaignEntityActorBridge } = await import("../campaign-entities/services/CampaignEntityActorBridge.js");
        const entity = { ...record.entity, uuid: record.document.uuid, journalEntryId: record.document.id };
        if (actor) {
            const linked = CampaignEntityActorBridge.getLinkedEntityForActor(actor);
            if (linked && (linked.type !== "ship" || linked.id !== entity.id)) throw new Error("That Actor is linked to another campaign entity. Unlink it first.");
        }
        if (!record.document.testUserPermission(user, "OBSERVER")) throw new Error("Review this Ship's journal and give the player Observer access before assigning it.");
        if (actor) {
            if (!actor.testUserPermission(user, "OWNER")) await actor.update({ [`ownership.${user.id}`]: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER });
            if ((actorUuid !== actor.uuid || copyArtwork) && !await CampaignEntityActorBridge.linkActor(entity, actor, { useActorImage: copyArtwork, useTokenImage: copyArtwork })) throw new Error("The Actor could not be linked to this Ship.");
            await user.setFlag(MODULE_ID, "playerShipActor", actor.uuid);
        }
        // Reuse the grant writer inside this execution, without queuing another request.
        await this.execute({ action: "assign", userId: user.id, grant: { uuid: shipUuid, mode: "manage" } }, sender);
        await user.setFlag(MODULE_ID, "playerPrimaryShip", shipUuid);
        return shipUuid;
    }

    static async #linkCharacter(user, actorId, personUuid) {
        const actor = game.actors.get(actorId);
        if (!actor) throw new Error("The selected Actor no longer exists.");
        const existing = resolveActorPerson(actor);
        if (existing.error) throw new Error(existing.error);
        const record = personUuid ? Entities.resolve(personUuid) : existing.person;
        if (personUuid && !record) throw new Error("The selected Person no longer exists. Choose it again.");
        if (record && record.entity.type !== "npc") throw new Error("Choose a Person for this character.");
        if (record?.entity.projections?.actorUuid && record.entity.projections.actorUuid !== actor.uuid) throw new Error("That Person is already linked to another Actor.");
        if (record && !record.document.testUserPermission(user, "OBSERVER")) throw new Error("Review this Person's journal and give the player Observer access before linking it.");
        const { CampaignEntityJournalStore } = await import("../campaign-entities/services/CampaignEntityJournalStore.js");
        const { CampaignEntityActorBridge } = await import("../campaign-entities/services/CampaignEntityActorBridge.js");
        // Reject competing live links before writing any identity document.
        const linked = CampaignEntityActorBridge.getLinkedEntityForActor(actor);
        if (linked && (linked.type !== "npc" || (linked.id !== record?.entity.id && linked.id !== existing.person?.entity.id))) {
            throw new Error("That Actor is linked to another campaign entity. Unlink it before assigning this character.");
        }
        const previous = this.identity(user).person?.document.uuid;
        // Validate the entire pair before granting ownership or replacing the saved identity.
        if (!actor.testUserPermission(user, "OWNER")) {
            await actor.update({ [`ownership.${user.id}`]: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER });
        }
        if (record) {
            if (!await CampaignEntityActorBridge.linkActor({ ...record.entity, uuid: record.document.uuid, journalEntryId: record.document.id }, actor)) throw new Error("The Actor could not be linked to this Person.");
            await CampaignEntityJournalStore.updateNpc(record.entity.id, { identity: { personKind: "player-character" } });
        }
        await user.update({ character: actor.id });
        const all = foundry.utils.deepClone(game.settings.get(MODULE_ID, GRANTS_KEY) || {});
        const grants = all[user.id] || [];
        const remaining = grants.filter(grant => grant.uuid !== previous && grant.uuid !== record?.document.uuid).map(validateGrant);
        if (JSON.stringify(grants) !== JSON.stringify(remaining)) {
            all[user.id] = remaining;
            await game.settings.set(MODULE_ID, GRANTS_KEY, all);
        }
        return record?.document.uuid || null;
    }
    static async #clearSelections(user, uuid) {
        for (const key of ["playerCurrentAsset", "playerPrimaryShip", "playerPrimaryFaction"]) {
            if (user.getFlag(MODULE_ID, key) === uuid) await user.unsetFlag(MODULE_ID, key);
        }
    }
    static async #reconcile() {
        const all = foundry.utils.deepClone(game.settings.get(MODULE_ID, GRANTS_KEY) || {});
        let changed = false;
        for (const id of Object.keys(all)) {
            const user = game.users.get(id);
            if (!user) { delete all[id]; changed = true; continue; }
            const primary = this.identity(user).person?.document.uuid;
            const valid = all[id].filter(grant => !!Entities.resolve(grant.uuid) && grant.uuid !== primary).map(validateGrant);
            if (JSON.stringify(valid) !== JSON.stringify(all[id])) { all[id] = valid; changed = true; }
        }
        if (changed) await game.settings.set(MODULE_ID, GRANTS_KEY, all);
        // Clean permanent deletion for all users, including those without manual grants.
        // Temporary visibility or ownership changes must not erase personal selections.
        for (const user of game.users.contents) {
            const actorUuid = user.getFlag(MODULE_ID, "playerShipActor");
            if (actorUuid && !game.actors.contents.some(actor => actor.uuid === actorUuid)) await user.unsetFlag(MODULE_ID, "playerShipActor");
            for (const key of ["playerCurrentAsset", "playerPrimaryShip", "playerPrimaryFaction"]) {
                const uuid = user.getFlag(MODULE_ID, key);
                if (uuid && !Entities.resolve(uuid)) await user.unsetFlag(MODULE_ID, key);
            }
        }
        return null;
    }
}
