import { MODULE_ID, GRANTS_KEY } from "./PlayerContextPolicy.js";
import { PlayerAccessService } from "./PlayerAccessService.js";
import { isContextGM, registerPlayerContextRequests } from "./PlayerContextRequests.js";

export function registerPlayerContextFeature() {
    const changed = () => Hooks.callAll("augurNexusPlayerContextChanged");
    game.settings.register(MODULE_ID, GRANTS_KEY, { scope: "world", config: false, type: Object, default: {}, onChange: changed });
    registerPlayerContextRequests();
    const reconcile = () => {
        if (isContextGM()) void PlayerAccessService.reconcile().catch(error => console.error("Augur Nexus | Player context reconciliation failed", error));
        changed();
    };
    for (const event of ["updateActor", "updateUser", "updateJournalEntry", "createJournalEntry", "augurNexusCampaignEntitiesChanged", "augurNexusCampaignEntitiesReady", "augurNexusCampaignEntityVisibilityChanged", "augurNexusCampaignEntityDisclosureChanged", "augurNexusConnectionsChanged", "userConnected"]) Hooks.on(event, changed);
    for (const event of ["deleteActor", "deleteUser", "deleteJournalEntry"]) Hooks.on(event, reconcile);
    Hooks.on("updateUser", (_user, changes) => { if (Object.hasOwn(changes, "character")) reconcile(); });
    Hooks.on("updateJournalEntry", (_document, changes) => { if (changes.flags?.[MODULE_ID]?.campaignEntity?.projections) reconcile(); });
    Hooks.once("ready", reconcile);
}
