import { PlayerAccessService } from "./PlayerAccessService.js";
// Builds the player view from Nexus entity storage and visible relationships.
import { CampaignEntityVisibilityManager } from "../campaign-entities/services/CampaignEntityVisibilityManager.js";
import { CampaignEntityDisclosureManager } from "../campaign-entities/services/CampaignEntityDisclosureManager.js";
import { ConnectionTargetResolver } from "../connections/services/ConnectionTargetResolver.js";
import { ShipOwnershipService } from "../connections/services/ShipOwnershipService.js";
import { OwnershipService } from "../connections/services/OwnershipService.js";
import { FactionMembershipService } from "../connections/services/FactionMembershipService.js";
import { ConnectionStore } from "../connections/services/ConnectionStore.js";
import { cleanText, safeImage, editableDescription, ENTITY_TYPES, MODULE_ID } from "./PlayerContextPolicy.js";

const names = { npc: "Person", faction: "Organization", ship: "Vessel", location: "Place" };

export class NexusPlayerEntityAdapter {
    static resolve(uuid) {
        const match = /^JournalEntry\.([A-Za-z0-9]+)$/.exec(String(uuid || ""));
        const document = match ? game.journal.get(match[1]) : null;
        const entity = document?.getFlag(MODULE_ID, "campaignEntity");
        return ENTITY_TYPES.has(entity?.type) ? { document, entity } : null;
    }

    static list() {
        return game.journal.contents.map(document => this.resolve(document.uuid)).filter(Boolean);
    }

    static related(primary, user) {
        if (!primary) return [];
        const records = this.list();
        const byId = new Map(records.map(record => [record.entity.id, record]));
        const target = ConnectionTargetResolver.fromCampaignEntity(primary.entity, primary.document);
        const found = new Map();
        const add = (id, reason) => {
            const record = byId.get(id);
            if (!record || id === primary.entity.id || !record.document.testUserPermission(user, "OBSERVER")) return;
            if (!CampaignEntityVisibilityManager.canUserSee(record.entity, user)) return;
            found.set(record.document.uuid, { record, reason: cleanText(reason) });
        };
        for (const { edge, node } of ConnectionStore.getGraphContext().adjacency.get(target.id) || []) {
            if (!node || !ConnectionStore.canUserSeeConnection(edge, user) || !ConnectionTargetResolver.canUserSeeNode(node, user)) continue;
            if (!["npc", "faction"].includes(byId.get(node.entityId)?.entity.type)) continue;
            add(node.entityId, ConnectionStore.getConnectionView(edge, target.id).role || "Connected to your character");
        }
        const owners = [{ target, name: "your character" }];
        for (const membership of FactionMembershipService.getMembershipsForNpc(target, { user })) {
            if (!membership.isLeader) continue;
            const faction = byId.get(membership.faction?.entityId);
            if (!faction || !faction.document.testUserPermission(user, "OBSERVER") || !CampaignEntityVisibilityManager.canUserSee(faction.entity, user)) continue;
            owners.push({ target: ConnectionTargetResolver.fromCampaignEntity(faction.entity, faction.document), name: faction.entity.display?.name || faction.document.name });
        }
        for (const owner of owners) {
            for (const holding of OwnershipService.getHoldingsForOwner(owner.target, { user })) add(holding.asset.entityId, `Owned by ${owner.name}`);
            for (const holding of ShipOwnershipService.getShipsForOwner(owner.target, { user })) add(holding.ship.entityId, `Owned by ${owner.name}`);
        }
        return [...found.values()];
    }

    static description(entity) {
        if (entity.type === "npc") return String(entity.flavor?.description || "");
        if (entity.type === "location") return String(entity.profile?.summary || "");
        return String(entity.profile?.customFields?.find(field => field.id === "field.description")?.value || "");
    }

    static image(entity, target) {
        const image = entity.type === "faction"
            ? (target || ConnectionTargetResolver.fromCampaignEntity(entity)).img : entity.display?.imageSrc;
        // The shared faction renderer produces a WebP data URL containing every emblem layer.
        return entity.type === "faction" && String(image || "").startsWith("data:image/webp;base64,")
            ? image : safeImage(image);
    }

    static project(record, user, grant, { primary = false } = {}) {
        const { entity, document } = record;
        const actorId = /^Actor\.([A-Za-z0-9]+)$/.exec(entity.projections?.actorUuid || "")?.[1];
        const actor = actorId ? game.actors.get(actorId) : null;
        const canOpenActor = !!actor?.testUserPermission(user, "OBSERVER");
        const visibleDescription = editableDescription(entity)
            && (entity.type !== "location" || CampaignEntityDisclosureManager.canUserViewDetails(entity, user));
        const raw = this.description(entity);
        const access = PlayerAccessService.inspect(document.uuid, user);
        const canEdit = access.canManage;
        const target = ConnectionTargetResolver.fromCampaignEntity(entity, document);
        const owner = entity.type === "ship" ? ShipOwnershipService.getOwner(target, { user })
            : entity.type === "location" ? OwnershipService.getOwnership(target, { user }) : null;
        const memberships = entity.type === "npc" ? FactionMembershipService.getMembershipsForNpc(target, { user }) : [];
        return {
            uuid: document.uuid, id: entity.id, type: entity.type, typeLabel: names[entity.type],
            name: primary && canOpenActor ? actor.name : entity.display?.name || document.name,
            image: primary && canOpenActor && !entity.display?.imageSrc ? safeImage(actor.img) : this.image(entity, target),
            description: visibleDescription ? cleanText(raw) : "",
            canEdit, primary, canView: access.canView, canManage: access.canManage, blockedReason: access.blockedReason,
            actorUuid: canOpenActor ? actor.uuid : "", actorMissing: !!actorId && !actor,
            canOpenDossier: access.canOpenDossier,
            reason: primary ? "Your character" : grant.reason,
            mode: grant.mode, grantedMode: grant.mode, source: grant.source,
            ownerName: cleanText(owner?.owner?.name || ""),
            memberships: memberships.filter(m => m.faction && ConnectionTargetResolver.canUserSeeNode({ kind: "nexus-entity", entityId: m.faction.entityId }, user)).map(m => ({ name: cleanText(m.faction.name), role: cleanText(m.rankLabel || (m.isLeader ? "Leader" : "Member")) }))
        };
    }

}
