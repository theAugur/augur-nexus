import { WorldTemplateCatalog } from "../features/world-templates/services/WorldTemplateCatalog.js";
import { RaceSources } from "../features/world-templates/services/RaceSources.js";

/** Publish immutable races, an optional preview, and optional civilization editor capabilities.
 * civilization.getEditor(race) supplies declarative fields; update(race, key, value) edits module-owned draft data.
 * Fields support checkbox, select options, multiple-choice options, hints and lightweight preview images.
 */
export function registerNpcRaces(definition) { return WorldTemplateCatalog.registerRaces(definition); }
/** Current world choices. Hidden templates are omitted unless explicitly requested for editing. */
export function getNpcRaces(options) { return WorldTemplateCatalog.listRaces(options); }
export function getNpcRace(id, options) { return WorldTemplateCatalog.getRace(id, options); }
export function isNpcRaceVisible(id) { return WorldTemplateCatalog.isVisible(id); }
/** Sample names and portraits from this race's current sources without mutating linked tables. */
export function sampleNpcRace(race, options) { return RaceSources.sample(race, options); }

/** Resolve reusable, weighted race name entries without drawing or modifying a linked table. */
export function getNpcRaceNameEntries(race, pool) {
    const source = race.names?.[pool];
    return !source || source.mode === "default" ? Promise.resolve(null) : RaceSources.names(source);
}
