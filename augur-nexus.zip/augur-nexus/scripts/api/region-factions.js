import { SceneEntityPresenceModel } from "../features/campaign-entities/services/SceneEntityPresenceModel.js";
import { FactionHierarchyModel } from "../features/connections/models/FactionHierarchyModel.js";
import { FactionHierarchyService } from "../features/connections/services/FactionHierarchyService.js";
import { CampaignEntityJournalStore } from "../features/campaign-entities/services/CampaignEntityJournalStore.js";
import { FactionEntityModel } from "../features/campaign-entities/models/FactionEntityModel.js";
import { CampaignEntityVisibilityManager } from "../features/campaign-entities/services/CampaignEntityVisibilityManager.js";
import { getRegionFactionIds } from "./regions.js";

/** A paint stroke needs one faction's identity, not a world-wide presence survey. */
export function getRegionFactionBrush(factionId) {
    if (!game.user?.isGM) return null;
    const faction = CampaignEntityJournalStore.getFaction(factionId);
    if (!faction) return null;
    return { id: faction.id, name: FactionEntityModel.getName(faction),
        color: FactionEntityModel.getAccent(faction),
        secret: !CampaignEntityVisibilityManager.isVisibleToPlayers(faction) };
}

/** GM brush choices reuse Scene presence, organization hierarchy and faction presentation authorities. */
export function getRegionFactionPalette(scene, { scope = "map", search = "" } = {}) {
    if (!game.user?.isGM) return [];
    const presence = scope === "all" ? { factionIds: new Set() } : SceneEntityPresenceModel.build(scene);
    const territoryIds = new Set(getRegionFactionIds(scene));
    const localIds = new Set([...presence.factionIds, ...territoryIds]);
    const parents = FactionHierarchyService.getParentMap({ includeHidden: true });
    const factions = CampaignEntityJournalStore.getFactions();
    const byId = new Map(factions.map(faction => [faction.id, faction]));
    const rows = factions.map(faction => ({ id: faction.id, entityId: faction.id,
        nodeId: `nexus-entity:${faction.id}`, name: FactionEntityModel.getName(faction) }));
    const included = FactionHierarchyModel.buildRows(rows, parents, { sceneEntityIds: scope === "all" ? null : localIds });
    const needle = String(search || "").trim().toLocaleLowerCase();
    return included.filter(row => !needle || row.name.toLocaleLowerCase().includes(needle)).map(row => {
        const faction = byId.get(row.id);
        const parentId = parents.get(row.nodeId)?.replace(/^nexus-entity:/, "") || "";
        const parent = byId.get(parentId);
        return { id: faction.id, name: row.name, emblem: FactionEntityModel.getImage(faction),
            color: FactionEntityModel.getAccent(faction), secret: !CampaignEntityVisibilityManager.isVisibleToPlayers(faction),
            parentId, parentName: parent ? FactionEntityModel.getName(parent) : "",
            reason: territoryIds.has(faction.id) ? "territory" : presence.factionIds.has(faction.id) ? "on-map" : row.isHierarchyContext ? "parent" : "all" };
    });
}
