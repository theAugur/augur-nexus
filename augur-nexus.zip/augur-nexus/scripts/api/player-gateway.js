import { hasPremiumAccess, requirePremiumAccess, requestPremiumAccess } from "../features/access/PremiumAccess.js";
// Optional UI entry points. Domain consumers should use player-context.js.
import { getPlayerContext, openPlayerEntity } from "./player-context.js";
import { isPlayerWheelEnabled, requirePlayerWheelEnabled, isPlayerWheelEnabledFor, requirePlayerWheelAvailable } from "../features/player-gateway/PlayerGatewayAvailability.js";
import { canUseWorkspace, isPlayerWorkspaceAllowed, setPlayerWorkspaceAllowed } from "../features/workspace/services/WorkspaceAccess.js";
export { canUseWorkspace, isPlayerWorkspaceAllowed, setPlayerWorkspaceAllowed };
import { ToolWindowLifecycle } from "../support/toolbar/ToolWindowLifecycle.js";
let home;
let setup;
const previews = new Map();
const panels = new Map();
const wheelSettings = new Map();

export function isOwnGmWheelHidden() {
    return !!game.user.isGM && game.settings.get("augur-nexus", "gmPlayerWheelHidden") === true;
}

export function isPlayerWheelOpen(userId = game.user.id) {
    if (userId !== game.user.id && !game.user.isGM) throw new Error("Only the GM can inspect another player's preview.");
    return !!(userId === game.user.id ? home : previews.get(userId))?.rendered;
}

function notifyWheelPresentationChanged() {
    if (setup?.rendered && !setup.busy) void setup.render({ force: false });
    globalThis.Hooks?.callAll?.("augurNexusPlayerWheelPresentationChanged");
}

export async function hidePlayerWheel({ userId = game.user.id } = {}) {
    if (!game.user.isGM) throw new Error("Only the GM can hide a wheel or close a preview.");
    if (userId === game.user.id) {
        await game.settings.set("augur-nexus", "gmPlayerWheelHidden", true);
        await home?.close();
    } else await previews.get(userId)?.close();
    notifyWheelPresentationChanged();
}

export async function refreshPlayerWorkspaceAccess() {
    const { CampaignWorkspace } = await import("../features/workspace/applications/CampaignWorkspace.js");
    await CampaignWorkspace.reconcileAccess();
    await refreshPlayerHomes();
    Hooks.callAll("augurNexusAppearanceChanged");
}

/** Workspace permissions and session always belong to the actual viewer, including wheel previews. */
export async function openPlayerWorkspace() {
    const { CampaignWorkspace } = await import("../features/workspace/applications/CampaignWorkspace.js");
    return CampaignWorkspace.show();
}

export async function openPlayerPanel({ userId = game.user.id, section = "holdings", entityUuid = "" } = {}) {
    requirePlayerWheelEnabled();
    getPlayerContext(userId);
    if (!["contacts", "holdings", "profile"].includes(section)) throw new Error("Unknown player panel.");
    const { PlayerGatewayPanel } = await import("../features/player-gateway/PlayerGatewayPanel.js");
    requirePlayerWheelEnabled();
    const key = `${userId}-${section}-${entityUuid}`;
    if (!panels.has(key)) panels.set(key, new PlayerGatewayPanel({ userId, section, entityUuid, onClose: () => panels.delete(key), id: `nexus-player-panel-${key.replaceAll(".", "-")}` }));
    const app = panels.get(key);
    await app.render({ force: true });
    if (!isPlayerWheelEnabled()) { await app.close(); return null; }
    app.bringToFront();
    return app;
}

export async function openGatewayEntity(uuid, { userId = game.user.id } = {}) {
    requirePlayerWheelEnabled();
    const context = getPlayerContext(userId);
    const entry = context.entries.find(row => row.uuid === uuid);
    if (!entry) throw new Error("This entry is no longer available to you.");
    if (!context.preview && entry.canOpenDossier) return openPlayerEntity(uuid);
    return openPlayerPanel({ userId, section: "profile", entityUuid: uuid });
}

export async function openPlayerHome({ userId = game.user.id, automatic = false } = {}) {
    if (userId !== game.user.id && !game.user.isGM) throw new Error("Only the GM can preview another player's home.");
    requirePlayerWheelAvailable(userId);
    if (userId === game.user.id && isOwnGmWheelHidden()) {
        if (automatic) return null;
        await game.settings.set("augur-nexus", "gmPlayerWheelHidden", false);
    }
    const { PlayerGatewayApplication } = await import("../features/player-gateway/PlayerGatewayApplication.js");
    requirePlayerWheelAvailable(userId);
    if (userId === game.user.id && isOwnGmWheelHidden()) return null;
    let app;
    if (userId === game.user.id) {
        home ||= new PlayerGatewayApplication({ onClose: notifyWheelPresentationChanged }); app = home;
    } else {
        if (!previews.has(userId)) previews.set(userId, new PlayerGatewayApplication({ userId, id: `nexus-player-preview-${userId}`, onClose: notifyWheelPresentationChanged }));
        app = previews.get(userId);
    }
    if (!isPlayerWheelEnabledFor(userId)) return null;
    await app.render({ force: true });
    if (!isPlayerWheelEnabledFor(userId) || userId === game.user.id && isOwnGmWheelHidden()) { await app.close(); return null; }
    app.bringToFront();
    notifyWheelPresentationChanged();
    return app;
}

export async function openPlayerWheelSettings({ userId = game.user.id } = {}) {
    if (!game.user.isGM && userId !== game.user.id) throw new Error("You can only configure your own Player Wheel.");
    if (!await requestPremiumAccess("playerWheel")) return null;
    const { PlayerWheelSettingsApplication } = await import("../features/player-gateway/PlayerWheelSettingsApplication.js");
    if (!game.user.isGM && userId !== game.user.id) throw new Error("You can only configure your own Player Wheel.");
    requirePremiumAccess("playerWheel");
    if (!wheelSettings.has(userId)) wheelSettings.set(userId, new PlayerWheelSettingsApplication({ userId, id: `nexus-wheel-settings-${userId}` }));
    const app = wheelSettings.get(userId);
    await app.render({ force: true }); app.bringToFront();
    return app;
}

export async function openPlayerSetup(options = {}) {
    if (!game.user.isGM) throw new Error("Only the GM can configure player access.");
    if (!await requestPremiumAccess("playerSetup")) return null;
    const { PlayerSetupApplication } = await import("../features/player-gateway/PlayerSetupApplication.js");
    if (!game.user.isGM) throw new Error("Only the GM can configure player access.");
    requirePremiumAccess("playerSetup");
    setup ||= new PlayerSetupApplication({ ...options, onClose: app => ToolWindowLifecycle.released(app) });
    if (!setup.busy) {
        if (options.userId) setup.userId = options.userId;
        if (options.entityUuid) setup.entityUuid = options.entityUuid;
    }
    const alreadyCurrent = ToolWindowLifecycle.isCurrent("player-setup");
    const app = await ToolWindowLifecycle.open("player-setup", () => setup);
    if (app && alreadyCurrent) {
        if (!app.busy) await app.render({ force: true });
        app.bringToFront();
    }
    return app;
}

export async function refreshPlayerHomes({ show = false } = {}) {
    if (!hasPremiumAccess()) {
        await Promise.all([setup, ...wheelSettings.values()].filter(app => app?.rendered).map(app => app.close()));
    } else if (setup?.rendered && !setup.busy) void setup.render({ force: false });
    if (!isPlayerWheelEnabled()) {
        const apps = [home, ...previews.values(), ...panels.values()].filter(app => app?.rendered);
        await Promise.all(apps.map(app => app.close()));
        return;
    }
    if (!isPlayerWheelEnabledFor() || isOwnGmWheelHidden()) { if (home?.rendered) await home.close(); }
    else if (show && (!game.user.isGM || game.user.character)) await openPlayerHome({ automatic: true });
    else home?.refresh();
    for (const [userId, app] of previews) {
        if (!isPlayerWheelEnabledFor(userId)) { if (app.rendered) await app.close(); }
        else app.refresh();
    }
    for (const app of panels.values()) app.refresh();
}
