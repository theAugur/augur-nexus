// Optional UI entry points. Domain consumers should use player-context.js.
import { getPlayerContext, openPlayerEntity } from "./player-context.js";
import { isPlayerWheelEnabled, requirePlayerWheelEnabled } from "../features/player-gateway/PlayerGatewayAvailability.js";
let home;
let setup;
const previews = new Map();
const panels = new Map();

export async function openPlayerPanel({ userId = game.user.id, section = "holdings", entityUuid = "" } = {}) {
    requirePlayerWheelEnabled();
    getPlayerContext(userId);
    if (!["contacts", "holdings", "profile"].includes(section)) throw new Error("Unknown player panel.");
    const { PlayerGatewayPanel } = await import("../features/player-gateway/PlayerGatewayPanel.js");
    requirePlayerWheelEnabled();
    const key = `${userId}-${section}-${entityUuid}`;
    if (!panels.has(key)) panels.set(key, new PlayerGatewayPanel({ userId, section, entityUuid, onClose: () => panels.delete(key), id: `nexus-player-panel-${key.replaceAll(".", "-")}` }));
    const app = panels.get(key);
    await app.render({ force: true });
    if (!isPlayerWheelEnabled()) { await app.close(); return null; }
    app.bringToFront();
    return app;
}

export async function openGatewayEntity(uuid, { userId = game.user.id } = {}) {
    const context = getPlayerContext(userId);
    const entry = context.entries.find(row => row.uuid === uuid);
    if (!entry) throw new Error("This entry is no longer available to you.");
    if (!context.preview && entry.canOpenDossier) return openPlayerEntity(uuid);
    return openPlayerPanel({ userId, section: "profile", entityUuid: uuid });
}

export async function openPlayerHome({ userId = game.user.id } = {}) {
    requirePlayerWheelEnabled();
    if (userId !== game.user.id && !game.user.isGM) throw new Error("Only the GM can preview another player's home.");
    const { PlayerGatewayApplication } = await import("../features/player-gateway/PlayerGatewayApplication.js");
    requirePlayerWheelEnabled();
    let app;
    if (userId === game.user.id) {
        home ||= new PlayerGatewayApplication(); app = home;
        await game.settings.set("augur-nexus", "playerGatewayVisible", true);
    } else {
        if (!previews.has(userId)) previews.set(userId, new PlayerGatewayApplication({ userId, id: `nexus-player-preview-${userId}` }));
        app = previews.get(userId);
    }
    if (!isPlayerWheelEnabled()) return null;
    await app.render({ force: true });
    if (!isPlayerWheelEnabled()) { await app.close({ preserveVisibility: true }); return null; }
    app.bringToFront();
    return app;
}

export async function openPlayerSetup(options = {}) {
    if (!game.user.isGM) throw new Error("Only the GM can configure player access.");
    const { PlayerSetupApplication } = await import("../features/player-gateway/PlayerSetupApplication.js");
    setup ||= new PlayerSetupApplication(options);
    if (options.userId) setup.userId = options.userId;
    if (options.entityUuid) setup.entityUuid = options.entityUuid;
    await setup.render({ force: true }); setup.bringToFront();
    return setup;
}

export async function refreshPlayerHomes() {
    if (setup?.rendered && !setup.busy) void setup.render({ force: false });
    if (!isPlayerWheelEnabled()) {
        // World policy must not overwrite each client's personal hide/show preference.
        const apps = [home, ...previews.values(), ...panels.values()].filter(app => app?.rendered);
        await Promise.all(apps.map(app => app.close({ preserveVisibility: true })));
        return;
    }
    home?.refresh();
    for (const app of previews.values()) app.refresh();
    for (const app of panels.values()) app.refresh();
}
