// Public faction-membership capabilities for dependent modules.

import { FactionMembershipService } from "../features/connections/services/FactionMembershipService.js";

export function getFactionMemberships(factionTarget, options = {}) {
    return FactionMembershipService.getMembershipsForFaction(factionTarget, options);
}

export function getNpcFactionMemberships(npcTarget, options = {}) {
    return FactionMembershipService.getMembershipsForNpc(npcTarget, options);
}

export function getFactionLeader(factionTarget, options = {}) {
    return FactionMembershipService.getLeader(factionTarget, options);
}

export function setFactionMember(factionTarget, memberTarget, options = {}) {
    return FactionMembershipService.setMember(factionTarget, memberTarget, options);
}

export function setFactionLeader(factionTarget, memberTarget, options = {}) {
    return FactionMembershipService.setLeader(factionTarget, memberTarget, options);
}

export function clearFactionMembership(connectionId) {
    return FactionMembershipService.clearMembership(connectionId);
}

export function setFactionMembershipRank(connectionId, rank = null) {
    return FactionMembershipService.setRank(connectionId, rank);
}
