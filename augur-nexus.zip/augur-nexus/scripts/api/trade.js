import { RegionalTradeNetworkApplication } from "../features/trade/applications/RegionalTradeNetworkApplication.js";
import { TradeGoodDetailApplication } from "../features/trade/applications/TradeGoodDetailApplication.js";
import { TradeGoodsCatalogApplication } from "../features/trade/applications/TradeGoodsCatalogApplication.js";
import { TradeGoodsCatalog } from "../features/trade/services/TradeGoodsCatalog.js";
import { TradeGoodsProviderRegistry } from "../features/trade/services/TradeGoodsProviderRegistry.js";
import { TradeBasinEconomyService } from "../features/trade/services/TradeBasinEconomyService.js";
import { SettlementMarketplaceInventoryService } from "../features/trade/services/SettlementMarketplaceInventoryService.js";
import { SettlementMarketplaceModel } from "../features/trade/models/SettlementMarketplaceModel.js";
import { CumulativeTradeFlowResolver } from "../features/trade/services/CumulativeTradeFlowResolver.js";
import { LocationTradeProfileService } from "../features/trade/services/LocationTradeProfileService.js";
export { REGIONAL_MARKETPLACE_TRADE_POLICY_ID } from "../features/trade/services/RegionalMarketplaceTradePolicy.js";

export function registerTradeGoodsProvider(definition) {
    return TradeGoodsProviderRegistry.register(definition);
}

export function getTradeGoods(options = {}) { return TradeGoodsCatalog.getGoods(options); }
export function getTradeGoodsForLocation(location, options = {}) { return TradeGoodsCatalog.getGoodsForLocation(location, options); }
export function getTradeGood(id) { return TradeGoodsCatalog.getGood(id); }
export function getTradeMarketRates() { return TradeGoodsCatalog.getMarketRates(); }
export function isRegionalMarketplace(shop) { return SettlementMarketplaceModel.isMarketplace(shop); }
export function getRegionalMarketplaceRules(shop, location) { return SettlementMarketplaceModel.getRules(shop, location); }
export function serializeRegionalMarketplaceRules(rules) { return SettlementMarketplaceModel.toModuleData(rules); }
export function getLocationEconomy(location) { return SettlementMarketplaceModel.getEconomy(location); }
export function getLocationEconomyView(location) { return SettlementMarketplaceModel.getEconomyView(location); }
export function serializeLocationEconomy(producedIds) { return SettlementMarketplaceModel.toEconomy(producedIds); }
export function createRegionalMarketplaceInventory(options = {}) { return SettlementMarketplaceInventoryService.create(options); }
export function getTradeMarketState(location, goodId = "", options = {}) { return TradeBasinEconomyService.getMarketState(location, goodId, options); }
export function getTradeMarketLabel(location, options = {}) { return TradeBasinEconomyService.getMarketLabel(location, options); }
export function getKnownTradeImportMarkets(location, goodId, options = {}) { return TradeBasinEconomyService.getKnownImportMarkets(location, goodId, options); }
export function resolveCumulativeTradeFlow(options = {}) { return CumulativeTradeFlowResolver.resolve(options); }
export function setLocationTradeProfile(location, profile = {}) { return LocationTradeProfileService.set(location, profile); }

export function openRegionalTradeNetwork(locationId, options = {}) {
    return RegionalTradeNetworkApplication.show({ locationId, ...options });
}

export function openTradeGoodDetail(goodId, options = {}) {
    return TradeGoodDetailApplication.show({ goodId, ...options });
}

export function openTradeGoodsCatalog(options = {}) {
    return TradeGoodsCatalogApplication.show(options);
}
