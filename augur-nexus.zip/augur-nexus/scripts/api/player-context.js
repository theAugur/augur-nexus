import { PlayerAccessService, canControlPlayerEntity } from "../features/player-context/PlayerAccessService.js";
import { registerEntityOperation } from "../features/player-context/PlayerEntityOperations.js";
import { requestPlayerMutation } from "../features/player-context/PlayerContextRequests.js";
// Player identity and delegated campaign access. No UI classes or entity internals cross this boundary.
import { PlayerContextService } from "../features/player-context/PlayerContextService.js";
import { getPlayerAssignmentActions as assignmentActions } from "../features/player-context/PlayerAssignmentActions.js";

export function getPlayerContext(userId) { return PlayerContextService.getContext(userId); }
export function getPlayerSetupData() { return PlayerContextService.getSetupData(); }
export function assignPlayerEntity(userId, grant, options) { return PlayerAccessService.assign(userId, grant, options); }
export function linkPlayerCharacter(userId, actorId, personUuid, expectations) { return PlayerAccessService.linkCharacter(userId, actorId, personUuid, expectations); }
export function unlinkPlayerPerson(userId, actorId, personUuid) { return PlayerAccessService.unlinkPerson(userId, actorId, personUuid); }
export function clearPlayerIdentity(userId, actorId) { return PlayerAccessService.clearIdentity(userId, actorId); }
export function assignPlayerShip(userId, shipUuid, options) { return PlayerAccessService.assignShip(userId, shipUuid, options); }
export function assignPlayerShipActor(userId, actorId) { return PlayerAccessService.assignShipActor(userId, actorId); }
export function clearPlayerShip(userId, shipUuid, actorUuid) { return PlayerAccessService.clearShip(userId, shipUuid, actorUuid); }
export function unlinkPlayerShip(userId, shipUuid, actorUuid) { return PlayerAccessService.unlinkShip(userId, shipUuid, actorUuid); }
export function getPlayerAssignmentActions(userId, uuid) { return assignmentActions(userId, uuid); }
export function selectPrimaryPlayerShip(uuid) { return PlayerContextService.selectPrimaryShip(uuid); }
export function selectPrimaryPlayerFaction(uuid) { return PlayerContextService.selectPrimaryFaction(uuid); }
export function selectPlayerAsset(uuid) { return PlayerContextService.selectAsset(uuid); }
export function openPlayerEntity(uuid, options) { return PlayerContextService.openEntity(uuid, options); }
export function openPlayerCharacterSheet() { return PlayerContextService.openCharacterSheet(); }

export function resolvePlayerActionContext({ entityUuid = "", type = "", requireManage = false } = {}) {
    const context = getPlayerContext();
    const target = entityUuid ? context.entries.find(entry => entry.uuid === entityUuid) : context.currentAsset;
    if (!target || (type && target.type !== type)) return null;
    const access = PlayerAccessService.inspect(target.uuid);
    if (!access.canOpenDossier || (requireManage && !access.canManage)) return null;
    return { userId: context.userId, characterUuid: context.character?.uuid || "", actorUuid: context.actor?.uuid || "", entityUuid: target.uuid, entityType: target.type, linkedActorUuid: target.actorUuid };
}

/** Module-owned edits use the same authenticated request and live control checks as Nexus edits. */
export function canManagePlayerEntity(reference, user = game.user) { return canControlPlayerEntity(reference, user); }
export function registerPlayerEntityOperation(moduleId, definition) { return registerEntityOperation(moduleId, definition); }
export function requestPlayerEntityOperation(moduleId, id, uuid, data) {
    return requestPlayerMutation({ operation: `extension.${moduleId}:${id}`, uuid, args: [data] });
}
