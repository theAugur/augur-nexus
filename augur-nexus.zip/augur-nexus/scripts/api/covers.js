import { SiteCoverCatalog } from "../features/site/services/SiteCoverCatalog.js";

/** Add an active module's category to the shared cover picker.
 * getCovers() returns { id, name, src, thumb } entries; src is saved, thumb is previewed.
 */
export function registerCoverCatalog(definition = {}) {
    SiteCoverCatalog.register(definition);
}
