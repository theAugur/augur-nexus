// Public ideology capabilities shared by Organizations and People.

import { IdeologyCatalog } from "../features/campaign-entities/services/IdeologyCatalog.js";

export function getIdeologyTopics({ perspective = "organization" } = {}) {
    return IdeologyCatalog.getTopics({ perspective });
}

export function resolveIdeology(ideology = {}, { perspective = "organization" } = {}) {
    return IdeologyCatalog.resolve(ideology, { perspective });
}
