// Public connections API for dependent modules.

import { ConnectionsBoard } from "../features/connections/components/ConnectionsBoard.js";
import { ConnectionStore } from "../features/connections/services/ConnectionStore.js";
import { ConnectionDropResolver } from "../features/connections/services/ConnectionDropResolver.js";
import { ConnectionTargetResolver } from "../features/connections/services/ConnectionTargetResolver.js";

export function removeConnectionsForTarget(target = {}) {
    return ConnectionStore.removeConnectionsForTarget(target);
}

export function addConnection(sourceTarget, relatedTarget, options = {}) {
    return ConnectionStore.addConnection(sourceTarget, relatedTarget, options);
}

export function replaceConnectionTarget(sourceTarget, destinationTarget) {
    return ConnectionStore.replaceTarget(sourceTarget, destinationTarget);
}

export function resolveConnectionDrop(event, options = {}) {
    return ConnectionDropResolver.fromEvent(event, options);
}

/** Accept a connection target or a persisted node ID for the standard Nexus drag payload. */
export function setConnectionDragData(dataTransfer, target, options = {}) {
    const node = typeof target === "string" ? ConnectionStore.getNode(target) : target;
    return ConnectionTargetResolver.setDragData(dataTransfer, node, options);
}

export function getSceneConnectionTarget(sceneOrId) {
    const sceneId = typeof sceneOrId === "string" ? sceneOrId : sceneOrId?.id || null;
    return ConnectionTargetResolver.fromSceneReference({ sceneId });
}

export function createConnectionsBoardController({ target, isGM = game.user.isGM, activeCategory = "all" } = {}) {
    return new ConnectionsBoard({ target, isGM, activeCategory });
}

/** Open a persisted connection endpoint through its registered Nexus presentation. */
export function openConnectionNode(nodeId) {
    const node = ConnectionStore.getNode(nodeId);
    return node ? ConnectionTargetResolver.openNode(node) : null;
}

/** Show role editing and removal for a connection from the supplied target's perspective. */
export async function openConnectionActions(options = {}) {
    const { ConnectionEditingWorkflow } = await import("../features/connections/services/ConnectionEditingWorkflow.js");
    return ConnectionEditingWorkflow.openMenu(options);
}
