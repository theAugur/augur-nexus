// Supported views opt in locally; world accent and saved object covers remain authoritative.
export { getNexusTheme, prepareNexusThemeSurface } from "../support/appearance/NexusThemes.js";

import { applyNexusThemeSurface } from "../support/appearance/NexusThemes.js";

const pickerAppearanceHooks = new WeakMap();

/** Opt a picker window into the shared surround without replacing its current selection or inputs. */
export function activateNexusPickerAppearance(application) {
    const update = () => {
        const element = application.element;
        if (!element) return;
        applyNexusThemeSurface(element);
        element.classList.add("nexus-art-picker-window");
        element.dataset.nexusSurroundTheme = element.dataset.nexusTheme;
        element.style.setProperty("--nexus-surround-world-accent", element.style.getPropertyValue("--nexus-user-accent"));
    };
    update();
    if (!pickerAppearanceHooks.has(application)) {
        pickerAppearanceHooks.set(application, Hooks.on("augurNexusAppearanceChanged", update));
    }
}

export function deactivateNexusPickerAppearance(application) {
    if (!pickerAppearanceHooks.has(application)) return;
    Hooks.off("augurNexusAppearanceChanged", pickerAppearanceHooks.get(application));
    pickerAppearanceHooks.delete(application);
}
