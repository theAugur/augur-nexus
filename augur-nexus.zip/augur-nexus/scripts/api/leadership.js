// Public faction-seat and location-leadership capabilities for dependent modules.

import { FactionSeatService } from "../features/connections/services/FactionSeatService.js";
import { LocationLeadershipService } from "../features/connections/services/LocationLeadershipService.js";

export function getFactionSeat(factionTarget, options = {}) {
    return FactionSeatService.getSeat(factionTarget, options);
}

export function setFactionSeat(factionTarget, locationTarget, options = {}) {
    return FactionSeatService.setSeat(factionTarget, locationTarget, options);
}

export function clearFactionSeat(factionTarget, options = {}) {
    return FactionSeatService.clearSeat(factionTarget, options);
}

export function getLocationLeader(locationTarget, options = {}) {
    return LocationLeadershipService.getLeader(locationTarget, options);
}

export function getNpcLedLocations(npcTarget, options = {}) {
    return LocationLeadershipService.getLocationsForLeader(npcTarget, options);
}

export function setLocationLeader(locationTarget, npcTarget, options = {}) {
    return LocationLeadershipService.setLeader(locationTarget, npcTarget, options);
}

export function clearLocationLeader(locationTarget, options = {}) {
    return LocationLeadershipService.clearLeader(locationTarget, options);
}
