import { questRequest } from "../features/quests/services/QuestRequests.js";

// UI-independent creation is shared by manual authoring and future content providers.
// Callers receive only the current user's authorized projection.
export const createQuest = data => questRequest("create", { data });
export const getQuest = id => questRequest("get", { id });
export const listQuests = (options = {}) => questRequest("list", { data: options });
export const updateQuest = (id, revision, patch) => questRequest("update", { id, revision, data: patch });
export const contributeToQuest = (id, revision, text) => questRequest("note", { id, revision, data: { text } });
export const updateQuestLogEntry = (id, revision, entry) => questRequest("editNote", { id, revision, data: entry });
export const updateQuestEntry = (id, revision, entry) => questRequest("entry", { id, revision, data: entry });
export const connectQuestEntity = (id, revision, connection) => questRequest("link", { id, revision, data: connection });
export const disconnectQuestEntity = (id, revision, edgeId) => questRequest("unlink", { id, revision, data: { edgeId } });
export const deleteQuest = (id, revision) => questRequest("delete", { id, revision });

export async function openQuests(options = {}) {
    const { QuestBrowser } = await import("../features/quests/applications/QuestBrowser.js");
    return QuestBrowser.show(options);
}
export async function openQuest(id) {
    const { QuestDossier } = await import("../features/quests/applications/QuestDossier.js");
    return QuestDossier.show(id);
}
export async function editQuest(id = "", options = {}) {
    const { QuestDossier } = await import("../features/quests/applications/QuestDossier.js");
    return id ? QuestDossier.show(id) : QuestDossier.create(options);
}

/** Personal wheel preference; never changes quest ownership or campaign status. */
export async function getMainQuest(options = {}) {
    return (await import("../features/quests/services/QuestSelection.js")).getMainQuest(options);
}
export async function selectMainQuest(id) {
    return (await import("../features/quests/services/QuestSelection.js")).selectMainQuest(id);
}
