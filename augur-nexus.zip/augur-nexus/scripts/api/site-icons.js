import { SiteIconCatalogRegistry } from "../features/site/services/SiteIconCatalogRegistry.js";

/** Register a module-owned catalog for the shared Site icon picker. */
export function registerSiteIconCatalog(definition) {
    return SiteIconCatalogRegistry.register(definition);
}

export function listSiteIconCatalogs() {
    return SiteIconCatalogRegistry.list();
}

export function getSiteIconCatalogIcons(id) {
    return SiteIconCatalogRegistry.getIcons(id);
}
