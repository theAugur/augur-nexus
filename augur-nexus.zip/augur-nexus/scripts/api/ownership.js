import { OwnershipService } from "../features/connections/services/OwnershipService.js";

export function getOwnership(assetTarget, options = {}) {
    return OwnershipService.getOwnership(assetTarget, options);
}

export function getOwnedHoldings(ownerTarget, options = {}) {
    return OwnershipService.getHoldingsForOwner(ownerTarget, options);
}

export function setOwner(assetTarget, ownerTarget, options = {}) {
    return OwnershipService.setOwner(assetTarget, ownerTarget, options);
}

export function clearOwner(assetTarget, options = {}) {
    return OwnershipService.clearOwner(assetTarget, options);
}

export function openOwner(assetTarget, options = {}) {
    return OwnershipService.openOwner(assetTarget, options);
}