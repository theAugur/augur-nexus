let provider = null;

/** Register presentation behavior without transferring ownership of navigation or world content. */
export function registerSceneTransitionProvider(moduleId, definition) {
    if (typeof definition?.play !== "function" || typeof definition?.cancel !== "function") {
        throw new Error("A transition provider must implement play and cancel.");
    }
    provider = { moduleId, ...definition };
}

export function getSceneTransitionProvider() {
    return provider && game.modules.get(provider.moduleId)?.active ? provider : null;
}

export function prepareSceneTransition(request) {
    Hooks.callAll("augur-nexus.preSceneNavigation", {
        fromScene: game.scenes.get(request.sourceSceneId),
        targetScene: game.scenes.get(request.targetSceneId),
        navigation: { transitionStyle: request.transitionStyle, direction: request.direction }
    });
}

export function sceneTransitionsChanged(enabled) {
    if (!enabled) getSceneTransitionProvider()?.cancel();
    Hooks.callAll("augurNexusAppearanceChanged");
}
