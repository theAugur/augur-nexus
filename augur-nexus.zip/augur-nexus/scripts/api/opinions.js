// Public opinion capabilities for dependent modules.

import { ConnectionOpinionService } from "../features/connections/services/ConnectionOpinionService.js";
import { OpinionInfluenceProviderRegistry } from "../features/connections/services/OpinionInfluenceProviderRegistry.js";

export function enableConnectionOpinions(connectionId) {
    return ConnectionOpinionService.enable(connectionId);
}

export function disableConnectionOpinions(connectionId) {
    return ConnectionOpinionService.disable(connectionId);
}

export function resolveConnectionOpinions(connectionId) {
    return ConnectionOpinionService.resolve(connectionId);
}

export function resolveConnectionOpinion(connectionId, observerNodeId) {
    return ConnectionOpinionService.resolvePerspective(connectionId, observerNodeId);
}

export function setConnectionOpinionBase(connectionId, observerNodeId, value) {
    return ConnectionOpinionService.setBase(connectionId, observerNodeId, value);
}

export function addConnectionOpinionAdjustment(connectionId, observerNodeId, adjustment, options = {}) {
    return ConnectionOpinionService.addAdjustment(connectionId, observerNodeId, adjustment, options);
}

export function updateConnectionOpinionAdjustment(connectionId, observerNodeId, adjustmentId, patch) {
    return ConnectionOpinionService.updateAdjustment(connectionId, observerNodeId, adjustmentId, patch);
}

export function removeConnectionOpinionAdjustment(connectionId, observerNodeId, adjustmentId) {
    return ConnectionOpinionService.removeAdjustment(connectionId, observerNodeId, adjustmentId);
}

export function registerOpinionInfluenceProvider(moduleId, definition = {}) {
    return OpinionInfluenceProviderRegistry.register({
        ...definition,
        moduleId: String(moduleId || "").trim()
    });
}

export function unregisterOpinionInfluenceProvider(providerId) {
    return OpinionInfluenceProviderRegistry.unregister(providerId);
}
