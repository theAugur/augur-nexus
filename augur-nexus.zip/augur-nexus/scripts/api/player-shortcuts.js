const supportedDocuments = new Set(["Actor", "Item", "JournalEntry", "JournalEntryPage", "Macro", "RollTable"]);

function resolve(uuid, userId) {
    if (userId !== game.user.id && !game.user.isGM) return null;
    const user = game.users.get(userId);
    if (!user || typeof uuid !== "string") return null;
    let document;
    try { document = fromUuidSync(uuid); } catch { return null; }
    if (!document || document.pack || !supportedDocuments.has(document.documentName)) return null;
    // Nexus dossiers must pass player-context visibility; a native journal reference cannot bypass it.
    const journal = document.documentName === "JournalEntryPage" ? document.parent : document;
    if (journal?.getFlag?.("augur-nexus", "campaignEntity")) return null;
    const permission = document.documentName === "Macro" ? "LIMITED" : "OBSERVER";
    if (!document.testUserPermission(user, permission) || !document.testUserPermission(game.user, permission)) return null;
    if (document.documentName === "Macro" && !document.canUserExecute(user)) return null;
    return { document };
}

/** Return only live, accessible presentation for a native document shortcut. */
export function describePlayerShortcut(uuid, { userId = game.user.id } = {}) {
    const resolved = resolve(uuid, userId);
    if (!resolved) return null;
    const { document } = resolved;
    const macro = document.documentName === "Macro", table = document.documentName === "RollTable";
    const label = macro ? "Run macro" : table ? "Draw result" : "Open sheet";
    return { uuid: document.uuid, documentName: document.documentName, name: document.name, image: document.img || document.parent?.img || "icons/svg/book.svg",
        type: macro ? "macro" : "document", typeLabel: label,
        hint: `${document.name}\nLeft-click: ${label} · Right-click: Open ${macro ? "macro" : "sheet"}` };
}

/** Activate a live shortcut as the current player. A GM preview can never execute one. */
export async function activatePlayerShortcut(uuid, { alternate = false, userId = game.user.id } = {}) {
    if (userId !== game.user.id) throw new Error("Shortcuts cannot be used from a player preview.");
    const resolved = resolve(uuid, userId);
    if (!resolved) throw new Error("This shortcut is no longer available to you.");
    const { document } = resolved;
    if (alternate) return document.sheet?.render({ force: true });
    if (document.documentName === "Macro") return document.execute();
    if (document.documentName === "RollTable") return document.draw();
    return document.sheet?.render({ force: true });
}
