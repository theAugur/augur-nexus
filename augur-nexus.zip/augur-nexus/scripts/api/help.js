/** Contextual documentation links and explicit ApplicationV2 header help controls. */
export { registerHelpTopics, resolveHelpUrl, openHelp, attachHelpButton, registerDossierHelp, getDossierHelp, attachDossierHelpButton } from "../support/help/NexusHelp.js";
