const providers = new Map();
const hiddenDomains = new Set();

export function supportsRegionDomains(scene) {
    return [...providers.values()].some(provider => provider.matchesScene(scene) && typeof provider.applyDomains === "function");
}

export function applyRegionDomains(scene, batch) {
    return getProvider(scene).applyDomains(scene, batch);
}

export function getGeneratedRegionDomains(scene, source) {
    if (!supportsRegionDomains(scene)) return [];
    return getProvider(scene).getGeneratedDomains(scene, source);
}

export function clearGeneratedRegionDomains(scene, source) {
    if (!supportsRegionDomains(scene)) return Promise.resolve([]);
    return getProvider(scene).clearGeneratedDomains(scene, source);
}

/** Local display preference; never changes native visibility or generation. */
export function areRegionDomainsVisible(scene) { return !hiddenDomains.has(scene?.id); }
export function setRegionDomainsVisible(scene, visible) {
    if (!globalThis.game?.user?.isGM) throw new Error("Only a GM can toggle domain display.");
    if (visible) hiddenDomains.delete(scene.id);
    else hiddenDomains.add(scene.id);
    Hooks.callAll("augurNexusDomainDisplayChanged", scene.id);
}

/** Register module-owned territory geometry without exposing its internal services to Nexus. */
export function registerRegionTerritoryProvider(providerId, definition) {
    if (!providerId || typeof definition?.matchesScene !== "function" || typeof definition?.setHexes !== "function") {
        throw new Error("A Region territory provider requires an id, matchesScene and setHexes.");
    }
    if (definition.createRegion !== undefined && typeof definition.createRegion !== "function") {
        throw new Error("A Region territory provider's createRegion must be a function.");
    }
    if (definition.getFactionIds !== undefined && typeof definition.getFactionIds !== "function") {
        throw new Error("A Region territory provider's getFactionIds must be a function.");
    }
    if ([definition.getFactionRegions, definition.deleteFactionRegions].some(value => value !== undefined)
        && [definition.getFactionRegions, definition.deleteFactionRegions].some(value => typeof value !== "function")) {
        throw new Error("A Region territory provider requires both getFactionRegions and deleteFactionRegions for faction cleanup.");
    }
    providers.set(providerId, definition);
    return definition;
}

export function unregisterRegionTerritoryProvider(providerId) {
    return providers.delete(providerId);
}

export function setRegionHexes(scene, regionId, hexes) {
    return getProvider(scene).setHexes(scene, regionId, hexes);
}

/** Create native Region identity and presentation through the Scene's territory provider. */
export function createRegion(scene, { name, color, hexes = [], visibility, kind, factionId } = {}) {
    const provider = getProvider(scene);
    if (typeof provider.createRegion !== "function") throw new Error("The Scene's territory provider cannot create Regions.");
    const options = { hexes };
    if (name !== undefined) options.name = name;
    if (color !== undefined) options.color = color;
    if (visibility !== undefined) options.visibility = visibility;
    if (kind !== undefined) options.kind = kind;
    if (factionId !== undefined) options.factionId = factionId;
    return provider.createRegion(scene, options);
}

/** Faction references are module-owned; Nexus does not read a provider's storage flags. */
export function getRegionFactionIds(scene) {
    if (!globalThis.game?.user?.isGM) throw new Error("Only a GM can read Region faction references.");
    const matches = [...providers.values()].filter(provider => provider.matchesScene(scene));
    return [...new Set(matches.flatMap(provider => provider.getFactionIds?.(scene) ?? []).map(id => String(id)).filter(Boolean))];
}

function getProvider(scene) {
    if (!globalThis.game?.user?.isGM) throw new Error("Only a GM can edit Region territory.");
    const matches = [...providers.values()].filter(provider => provider.matchesScene(scene));
    if (matches.length !== 1) throw new Error("The Scene requires one registered Region territory provider.");
    return matches[0];
}

/** Providers own faction references and deletion; Nexus supplies world-wide orchestration. */
export function getFactionRegionTerritories(factionId) {
    if (!globalThis.game?.user?.isGM) throw new Error("Only a GM can read faction territories.");
    if (typeof factionId !== "string" || !factionId.trim()) throw new Error("Territory cleanup requires a faction.");
    const territories = [];
    for (const scene of game.scenes?.contents ?? []) for (const [providerId, provider] of providers) {
        if (!provider.getFactionRegions || !provider.matchesScene(scene)) continue;
        for (const region of provider.getFactionRegions(scene, factionId)) territories.push({
            providerId, sceneId: scene.id, sceneName: scene.name || scene.id,
            regionId: region.id, name: region.name, hexCount: region.hexCount
        });
    }
    return territories.sort((a, b) => `${a.sceneId}:${a.providerId}:${a.regionId}`.localeCompare(`${b.sceneId}:${b.providerId}:${b.regionId}`));
}

export async function deleteFactionRegionTerritories(factionId) {
    if (!globalThis.game?.user?.isGM) throw new Error("Only a GM can delete faction territories.");
    if (typeof factionId !== "string" || !factionId.trim()) throw new Error("Territory cleanup requires a faction.");
    const failures = [];
    for (const scene of game.scenes?.contents ?? []) for (const provider of providers.values()) {
        if (!provider.deleteFactionRegions || !provider.matchesScene(scene)) continue;
        try { await provider.deleteFactionRegions(scene, factionId); }
        catch (error) { failures.push(`${scene.name || scene.id}: ${error.message}`); }
    }
    if (failures.length) throw new Error(failures.join("; "));
}
