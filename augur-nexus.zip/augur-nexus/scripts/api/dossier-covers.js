import {
    resolveDossierCover as resolveCover,
    prepareDossierCover as prepareCover,
    setDossierCoverImage as setCoverImage
} from "../support/appearance/DossierCoverPresentation.js";

/** Resolve an entity's display.coverImageSrc, or an existing cover path, against the world default. */
export function resolveDossierCover(entityOrOverride = null) {
    return resolveCover(entityOrOverride);
}

/** Prepare the main dossier cover for the current user's theme and shared visibility setting. */
export function prepareDossierCover(entityOrOverride = null) {
    return prepareCover(entityOrOverride);
}

/** GM-only world default; pass an empty string to restore the built-in cover. */
export async function setDossierCoverImage(path) {
    return setCoverImage(path);
}
