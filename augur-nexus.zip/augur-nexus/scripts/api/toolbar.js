// Public toolbar API for dependent modules.

import {
    registerToolbarTools as registerToolbarToolsInternal,
    unregisterToolbarTools as unregisterToolbarToolsInternal
} from "../support/toolbar/NexusToolContext.js";

/** Tools may opt into the Nexus Wheel's counterclockwise shortcuts with wheel: { side: "left" }. */
export function registerToolbarTools(moduleId, tools = []) {
    return registerToolbarToolsInternal(moduleId, tools);
}

export function unregisterToolbarTools(moduleId) {
    return unregisterToolbarToolsInternal(moduleId);
}

