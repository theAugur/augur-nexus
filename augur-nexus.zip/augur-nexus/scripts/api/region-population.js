import { ProgressiveRegionPopulationApplication } from "../features/region-population/applications/ProgressiveRegionPopulationApplication.js";
import { PopulationProviderRegistry } from "../features/region-population/services/PopulationProviderRegistry.js";
import { RegionProviderRegistry } from "../features/region-population/services/RegionProviderRegistry.js";
import { RegionPopulationClearService } from "../features/region-population/services/RegionPopulationClearService.js";
import { RegionPopulationRunStore } from "../features/region-population/services/RegionPopulationRunStore.js";
import { RegionChronicleService } from "../features/region-population/services/RegionChronicleService.js";
import { ChronicleNarrativeModel } from "../features/region-population/models/ChronicleNarrativeModel.js";
import { ToolWindowLifecycle } from "../support/toolbar/ToolWindowLifecycle.js";

const applications = new Map();
let lifecycleHookRegistered = false;

function ensureLifecycleHook() {
    if (lifecycleHookRegistered) return;
    lifecycleHookRegistered = true;
    Hooks.on("augurNexusWorldTemplatesChanged", () => {
        for (const application of applications.values()) if (application.rendered) application.render();
    });
    Hooks.on("canvasReady", activeCanvas => {
        const activeSceneId = activeCanvas?.scene?.id || canvas.scene?.id || "";
        for (const [sceneId, application] of applications) {
            if (sceneId === activeSceneId) continue;
            applications.delete(sceneId);
            void application.close();
        }
    });
}

export function registerRegionProvider(providerId, definition) {
    return RegionProviderRegistry.register(providerId, definition);
}

export function unregisterRegionProvider(providerId) {
    return RegionProviderRegistry.unregister(providerId);
}

/**
 * Register module-owned regional development behavior.
 * Optional validateDevelopment({ scene, settings, survey }) throws a user-facing error before any run state is written.
 * Optional getDevelopmentOptions({ survey, settings }) returns { label, subtitle?, description,
 * note?, countLabel?, countHint?, placementNote?,
 * counts: [{ id, label, imageSrc?, hint?, value, min, max, existing, toAdd }],
 * toggles?: [{ id, label, value: boolean }] }.
 * Optional images and row hints are provider-owned presentation. Nexus renders and
 * persists numeric selections in settings.developmentCounts and boolean selections
 * in settings.developmentToggles (strict booleans, absent values default false);
 * the provider validates their domain meaning when running development.
 * Optional isRegionalPower(entity) excludes local organizations from expanding-power
 * counts and selection when it returns false; domain planners must apply the same policy.
 * Run operations include live ownership, leadership, connection and membership reads,
 * plus findEntityKey(entityId) for resolving persisted references in the current run.
 * getFactionParent({ factionKey }) reads the current parent organization, including hidden relationships.
 * setFactionParent({ factionKey, parentKey }) assigns a parent through the standard hierarchy rules
 * (one parent, cycle prevention), preserving annotations and tracking newly created edges for cleanup.
 * getConnectedEntities({ key }) returns direct { key, entity, edge } snapshots and
 * resolves missing connected campaign entities into the disposable run map.
 */
export function registerPopulationProvider(providerId, definition) {
    return PopulationProviderRegistry.register(providerId, definition);
}

export function unregisterPopulationProvider(providerId) {
    return PopulationProviderRegistry.unregister(providerId);
}

export function canPopulateRegion(scene = canvas.scene) {
    const regionProvider = RegionProviderRegistry.findForScene(scene);
    return !!regionProvider && PopulationProviderRegistry.listForScene(scene, regionProvider).length > 0;
}

export function getRegionPopulationRun(scene = canvas.scene) {
    return RegionPopulationRunStore.get(scene);
}

export function hasRegionChronicle(scene = canvas.scene) {
    return !!RegionChronicleService.getEntry(scene);
}

export function openRegionChronicle(scene = canvas.scene) {
    if (!scene?.id) return false;
    return RegionChronicleService.open(scene);
}

export function closeRegionChronicle() {
    return ToolWindowLifecycle.close("fantasy-region-chronicle");
}

export function createChronicleNarrative(text, participants = []) {
    return ChronicleNarrativeModel.create(text, participants);
}
export function openRegionPopulation(scene = canvas.scene) {
    if (!scene?.id || !canPopulateRegion(scene)) return null;
    ensureLifecycleHook();
    return ToolWindowLifecycle.open("fantasy-region-population", () => {
        let application = applications.get(scene.id);
        if (!application) {
            application = new ProgressiveRegionPopulationApplication({ sceneId: scene.id });
            applications.set(scene.id, application);
        }
        application.prepareToOpen();
        return application;
    });
}

export async function closeRegionPopulation(scene = canvas.scene) {
    const application = applications.get(scene?.id);
    if (!application) return false;
    await ToolWindowLifecycle.close("fantasy-region-population");
    if (application.rendered) return false;
    applications.delete(scene.id);
    return true;
}

export function clearRegionPopulation(scene = canvas.scene, options = {}) {
    return RegionPopulationClearService.clear(scene, { purpose: "clear", ...options });
}
