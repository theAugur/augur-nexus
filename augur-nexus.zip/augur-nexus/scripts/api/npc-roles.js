import { WorldTemplateCatalog } from "../features/world-templates/services/WorldTemplateCatalog.js";
import { RoleSources } from "../features/world-templates/services/RoleSources.js";

/** Publish module-owned role definitions and a preview capability. */
export function registerNpcRoles(definition) { WorldTemplateCatalog.registerRoles(definition); }
/** Visible generation choices, filtered by the consuming generator's genre. */
export function getNpcRoles(options) { return WorldTemplateCatalog.listRoles(options); }
/** includeHidden supports existing NPCs; moduleId disambiguates released role IDs. */
export function getNpcRole(id, options) { return WorldTemplateCatalog.getRole(id, options); }
export function sampleNpcRole(role, options) { return RoleSources.sample(role, options); }
