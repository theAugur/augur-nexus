import { PlaceParentService } from "../features/places/services/PlaceParentService.js";
import { PlaceTypeRegistry } from "../features/places/services/PlaceTypeRegistry.js";
import { PlacePreviewActionRegistry } from "../features/connections/services/PlacePreviewActionRegistry.js";
import { PlaceProfileRegistry } from "../features/places/services/PlaceProfileRegistry.js";

export const registerPlaceType = definition => PlaceTypeRegistry.register(definition);
export const setPlaceParent = (childKey, parentKey) => PlaceParentService.setParent(childKey, parentKey);
/** GM profile actions share both preview hosts. Return {openTarget} after an explicit action to navigate. */
export const registerPlacePreviewActions = definition => PlacePreviewActionRegistry.register(definition);
/** Register a domain panel for Scene/Site dossiers. Panels may own the full surface and its navigation via ownsSurface. */
export const registerPlaceProfile = definition => PlaceProfileRegistry.register(definition);
