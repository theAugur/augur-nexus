import { PlaceParentService } from "../features/places/services/PlaceParentService.js";
import { PlaceTypeRegistry } from "../features/places/services/PlaceTypeRegistry.js";

export const registerPlaceType = definition => PlaceTypeRegistry.register(definition);
export const setPlaceParent = (childKey, parentKey) => PlaceParentService.setParent(childKey, parentKey);
