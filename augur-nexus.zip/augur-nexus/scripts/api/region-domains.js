import { FactionHierarchyService } from "../features/connections/services/FactionHierarchyService.js";
import { buildDomainRealms } from "../features/region-population/services/RegionDomainRealms.js";

/** Callers supply visible territory only; hidden hierarchy edges are never exposed to players. */
export function getRegionDomainRealms(domains) {
    const parents = new Map([...FactionHierarchyService.getParentMap({ includeHidden: game.user?.isGM === true })]
        .map(([child, parent]) => [child.replace(/^nexus-entity:/, ""), parent.replace(/^nexus-entity:/, "")]));
    return buildDomainRealms(domains, parents);
}
