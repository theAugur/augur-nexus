import { DevelopedRegionProviderRegistry } from "../features/region-dossier/DevelopedRegionProviderRegistry.js";
import { SiteRecordManager } from "../features/site/services/SiteRecordManager.js";

/** Generic module contribution for an existing developed region's place dossier.
 * matches({scene,record,target,user}) is synchronous and must recognize actual developed content.
 * prepare(context) returns a disposable {label,year,powers,places,people,events} projection.
 * Object rows use canonical nodeId plus domain typeLabel/imageSrc/summary/drive; powers may
 * include leader and seat rows, places may include owner rows. Providers own importance order
 * and meaningful event selection. No endpoint creates or persists content.
 * Providers may opt into player matching with playerReadable:true; their prepare
 * must return only permission-filtered public identities and relationships.
 */
export function registerDevelopedRegionProvider(definition) {
    return DevelopedRegionProviderRegistry.register(definition);
}

export async function openDevelopedRegionDossier(scene = canvas.scene) {
    const record = scene?.id ? SiteRecordManager.findSiteRecordForLinkedScene(scene) : null;
    if (!DevelopedRegionProviderRegistry.find({ scene, record, user: game.user })) return null;
    const { PlacePreview } = await import("../features/connections/applications/PlacePreview.js");
    return PlacePreview.show(record ? { record } : { scene });
}
