import { ShopApplication } from "../features/shops/applications/ShopApplication.js";
import { ShopDossier } from "../features/shops/applications/ShopDossier.js";
import { ShopProductProviderRegistry } from "../features/shops/services/ShopProductProviderRegistry.js";
import { ShopPresetRegistry } from "../features/shops/services/ShopPresetRegistry.js";
import { ShopIconCatalogRegistry } from "../features/shops/services/ShopIconCatalogRegistry.js";
import { ShopStore } from "../features/shops/services/ShopStore.js";
import { ShopSystemAdapterRegistry } from "../features/shops/services/ShopSystemAdapterRegistry.js";
import { ShopTradePolicyRegistry } from "../features/shops/services/ShopTradePolicyRegistry.js";
import { ShopEditorRegistry } from "../features/shops/services/ShopEditorRegistry.js";
import { ShopPresetDraftService } from "../features/shops/services/ShopPresetDraftService.js";
import { ShopDerivedNameService } from "../features/shops/services/ShopDerivedNameService.js";
import { ShopCreationGateway } from "../features/shops/services/ShopCreationGateway.js";
import { LocationEntityStore } from "../features/campaign-entities/services/LocationEntityStore.js";
import { CampaignEntityVisibilityManager } from "../features/campaign-entities/services/CampaignEntityVisibilityManager.js";
import { CampaignEntityDisclosureManager } from "../features/campaign-entities/services/CampaignEntityDisclosureManager.js";

export const registerShopProductProvider = definition => ShopProductProviderRegistry.register(definition);
export const registerShopPreset = definition => ShopPresetRegistry.register(definition);
export const getShopPresets = options => ShopPresetRegistry.list(options);
export const generateShopPresetCandidate = options => ShopPresetDraftService.createCandidate(options);
export const registerShopIconCatalog = definition => ShopIconCatalogRegistry.register(definition);
export const getShopIconCatalogs = () => ShopIconCatalogRegistry.list();
export const getShopIcons = () => ShopIconCatalogRegistry.getIcons();
export const getShopIcon = id => ShopIconCatalogRegistry.getIcon(id);
export const registerShopSystemAdapter = definition => ShopSystemAdapterRegistry.register(definition);
export const getShopCurrencyId = () => ShopSystemAdapterRegistry.getActive()?.currencyId || "";
export const registerShopTradePolicy = definition => ShopTradePolicyRegistry.register(definition);
export const registerShopEditor = definition => ShopEditorRegistry.register(definition);
export const registerShopCreationCapability = definition => ShopCreationGateway.registerCapability(definition);
export const authorizeShopCreation = options => ShopCreationGateway.authorize(options);
export const createShop = data => ShopStore.createShop(data);
export const getShop = idOrUuid => ShopStore.getShop(idOrUuid);
export const getShops = () => ShopStore.getShops();
export const getShopsForParentLocation = locationId => ShopStore.getShopsForParentLocation(locationId);
export const updateShop = (idOrUuid, patch, options) => ShopStore.updateShop(idOrUuid, patch, options);
export const deleteShop = idOrUuid => ShopStore.deleteShop(idOrUuid);
export const getShopNamingState = idOrShop => ShopDerivedNameService.getState(idOrShop);
export const restoreShopDerivedName = idOrShop => ShopDerivedNameService.restore(idOrShop);

function canUserOpenShop(shop) {
    if (game.user?.isGM) return true;
    const locationId = String(shop?.hierarchy?.parentLocationId || "");
    if (!locationId) return true;
    const location = LocationEntityStore.getLocation(locationId);
    return !!location
        && CampaignEntityVisibilityManager.canUserSee(location, game.user)
        && CampaignEntityDisclosureManager.canUserViewDetails(location, game.user);
}

export function openShop(idOrShop) {
    const shop = typeof idOrShop === "string" ? ShopStore.getShop(idOrShop) : idOrShop;
    return shop && canUserOpenShop(shop) ? ShopDossier.show({ shopId: shop.id }) : null;
}
export function openShopTrade(idOrShop) {
    const shop = typeof idOrShop === "string" ? ShopStore.getShop(idOrShop) : idOrShop;
    return shop && canUserOpenShop(shop) ? ShopApplication.show({ shopId: shop.id }) : null;
}

export function openShopDetails(idOrShop) {
    return openShop(idOrShop);
}

export const openShopEditor = options => ShopEditorRegistry.open(options);
export const openShopCreator = options => ShopCreationGateway.open(options);
export async function openShopIconPicker(options = {}) {
    const { ShopIconPicker } = await import("../features/shops/applications/ShopIconPicker.js");
    const picker = new ShopIconPicker(options);
    picker.render(true);
    return picker;
}
