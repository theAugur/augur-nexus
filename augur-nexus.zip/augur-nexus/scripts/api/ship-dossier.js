import { ShipDossierTabRegistry } from "../features/campaign-entities/services/ShipDossierTabRegistry.js";

/** Register a read-only actor summary tab. Nexus checks actor visibility before invoking providers.
 * build({ actor, entity }) returns { rows: [{ label, value, sectionStart }], openActorLabel }.
 * Providers must not update documents or prepare actor sheets.
 */
export function registerShipDossierTab(definition = {}) {
    ShipDossierTabRegistry.register(definition);
}
