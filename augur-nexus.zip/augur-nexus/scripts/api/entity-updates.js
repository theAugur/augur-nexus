const ENTITY_APIS = Object.freeze({
    npc: ["./npcs.js", "getNpc", "updateNpc"],
    ship: ["./ships.js", "getShip", "updateShip"],
    faction: ["./factions.js", "getFaction", "updateFaction"],
    location: ["./locations.js", "getLocation", "updateLocation"]
});
const COMMON_FIELDS = ["display.name", "display.color", "tags"];
const EDITABLE_FIELDS = Object.freeze({
    npc: [...COMMON_FIELDS, "identity.gender", "role.roleId", "role.roleLabel", "personality.traitIds",
        ...["description", "descriptor", "drive", "action", "theme", "focus"].map(key => `flavor.${key}`)],
    ship: [...COMMON_FIELDS, ...["model", "class", "role", "action", "theme", "focus", "customFields"].map(key => `profile.${key}`)],
    faction: [...COMMON_FIELDS, ...["type", "method", "drive", "action", "theme", "focus", "customFields"].map(key => `profile.${key}`)],
    location: [...COMMON_FIELDS, ...["kindId", "kindLabel", "type", "summary", "fields"].map(key => `profile.${key}`),
        ...["state", "pressure", "opportunity", "secret"].map(key => `currentThread.${key}`)]
});

function assertGm() { if (!game.user?.isGM) throw new Error("Only a GM can apply reviewed entity updates."); }
function clone(value) { return foundry.utils.deepClone(value); }
function canonical(value) {
    if (Array.isArray(value)) return value.map(canonical);
    if (!value || typeof value !== "object") return value;
    return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
}
function equal(left, right) { return JSON.stringify(canonical(left)) === JSON.stringify(canonical(right)); }
function valueAt(entity, path) { return path.split(".").reduce((value, key) => value?.[key], entity); }
function fieldState(entity, path) {
    const value = valueAt(entity, path);
    return value === undefined ? { present: false } : { present: true, value: clone(value) };
}
function assertPlan(plan) {
    if (plan?.apiVersion !== 1 || plan.kind !== "entity-update" || !ENTITY_APIS[plan.target?.entityType]
        || !plan.target.id || !Array.isArray(plan.changes)) throw new Error("Refresh this entity update before approving it.");
    const allowed = new Set(EDITABLE_FIELDS[plan.target.entityType]);
    const seen = new Set();
    for (const change of plan.changes) {
        if (!allowed.has(change.path) || seen.has(change.path) || !change.before
            || !Object.hasOwn(change, "value")) throw new Error("Unsupported reviewed entity field.");
        seen.add(change.path);
    }
}
function assertCurrent(plan, entity) {
    if (!entity || entity.id !== plan.target.id || (plan.target.uuid && entity.uuid !== plan.target.uuid)) {
        throw new Error("The reviewed Nexus entity no longer exists. Attach it again and prepare a new proposal.");
    }
    const conflicts = plan.changes.filter(change => !equal(fieldState(entity, change.path), change.before));
    if (conflicts.length) throw new Error(`This proposal conflicts with newer edits to ${conflicts.map(change => change.path).join(", ")}. Attach the entity again and prepare a new proposal.`);
}
async function resolveApi(entityType) {
    const definition = ENTITY_APIS[entityType];
    if (!definition) throw new Error("Unsupported Nexus entity type.");
    return { api: await import(definition[0]), get: definition[1], update: definition[2] };
}

/** Review a bounded field patch against the entity snapshot used to compose it. */
export async function planEntityUpdate({ entityType, entityId, baseline, changes = [] } = {}) {
    assertGm();
    const { api, get } = await resolveApi(entityType);
    if (!baseline || baseline.id !== entityId) throw new Error("An entity update requires its original Nexus snapshot.");
    const plan = {
        apiVersion: 1, kind: "entity-update", target: { entityType, id: entityId, uuid: baseline.uuid || "" },
        changes: changes.map(change => ({ path: change.path, before: fieldState(baseline, change.path), value: clone(change.value) }))
    };
    assertPlan(plan);
    assertCurrent(plan, api[get](entityId));
    return clone(plan);
}

/** Check without writing, including before executing other artifacts in a batch. */
export async function validateEntityUpdatePlan(plan) {
    assertGm();
    assertPlan(plan);
    const { api, get } = await resolveApi(plan.target.entityType);
    assertCurrent(plan, api[get](plan.target.id));
    return { ok: true };
}

export async function applyEntityUpdatePlan(plan) {
    assertGm();
    assertPlan(plan);
    const { api, get, update } = await resolveApi(plan.target.entityType);
    const current = api[get](plan.target.id);
    assertCurrent(plan, current);
    if (!plan.changes.length) return current;
    const patch = {};
    for (const change of plan.changes) {
        const keys = change.path.split(".");
        const leaf = keys.pop();
        const parent = keys.reduce((value, key) => (value[key] ||= {}), patch);
        parent[leaf] = clone(change.value);
    }
    return api[update](plan.target.id, patch);
}
