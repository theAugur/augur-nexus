import { ConnectionResourceFlowService } from "../features/connections/services/ConnectionResourceFlowService.js";
import { TradingCenterService } from "../features/connections/services/TradingCenterService.js";
import { TradeNetworkService } from "../features/connections/services/TradeNetworkService.js";

export function getTradeNetwork(options = {}) {
    return TradeNetworkService.getProjection(options);
}

export function getTradingCenter(locationTarget, options = {}) {
    return TradingCenterService.getTradingCenter(locationTarget, options);
}

export function canSetTradingCenter(locationTarget, centerTarget) {
    return TradingCenterService.canSetTradingCenter(locationTarget, centerTarget);
}

export function setTradingCenter(locationTarget, centerTarget, options = {}) {
    return TradingCenterService.setTradingCenter(locationTarget, centerTarget, options);
}

export function clearTradingCenter(locationTarget, options = {}) {
    return TradingCenterService.clearTradingCenter(locationTarget, options);
}

export function openTradingCenter(locationTarget, options = {}) {
    return TradingCenterService.openTradingCenter(locationTarget, options);
}

export function getConnectionResourceFlows(edgeOrId) {
    return ConnectionResourceFlowService.getFlows(edgeOrId);
}

export function getConnectionResourceFlowPerspective(edgeOrId, nodeId) {
    return ConnectionResourceFlowService.getPerspective(edgeOrId, nodeId);
}

export function setConnectionResourceFlows(edgeId, flows = []) {
    return ConnectionResourceFlowService.setFlows(edgeId, flows);
}
