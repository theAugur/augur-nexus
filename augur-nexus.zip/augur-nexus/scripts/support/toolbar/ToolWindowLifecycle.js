// Owns the selected toolbar window, not the documents edited by that window.
export class ToolWindowLifecycle {
    static #current = null;
    static #queue = Promise.resolve();
    static #elements = new WeakSet();
    static #wrapped = new WeakSet();

    static isCurrent(tool) { return this.#current?.tool === tool; }

    static canSwitch(tool) {
        if (!this.#current?.application.toolSwitchBlocked || tool === this.#current.tool) return true;
        ui.notifications.warn("Regional development is working. Wait for it to finish or use Stop before switching tools.");
        return false;
    }

    static open(tool, create) {
        if (this.isCurrent(tool)) return Promise.resolve(this.#current.application);
        if (!this.canSwitch(tool)) return Promise.resolve(null);
        const operation = this.#queue.then(async () => {
            if (this.isCurrent(tool)) return this.#current.application;
            if (!this.canSwitch(tool)) return null;
            const previous = this.#current;
            if (previous) {
                await this.close(previous.tool);
                if (this.#current === previous) return null;
            }
            const application = create();
            this.#current = { tool, application };
            if (ui.controls?.controls?.augurTools?.tools?.[tool]) await ui.controls.activate({ control: "augurTools", tool });
            await application.render({ force: true });
            application.bringToFront();
            return application;
        });
        this.#queue = operation.catch(() => {});
        return operation;
    }

    static async close(tool) {
        if (!this.isCurrent(tool)) return;
        if (!this.canSwitch("")) { this.#restore(); return; }
        const current = this.#current;
        current.closing ||= Promise.resolve().then(() => current.application.close());
        await current.closing;
        if (this.#current === current) current.closing = null;
    }

    static released(application) {
        if (this.#current?.application !== application) return;
        const { tool } = this.#current;
        this.#current = null;
        if (ui.controls?.control?.name === "augurTools" && ui.controls.tool?.name === tool) {
            void ui.controls.activate({ control: "augurTools", tool: "augur-select" });
        }
    }

    static #restore() {
        if (this.#current) void ui.controls.activate({ control: "augurTools", tool: this.#current.tool });
    }

    static bindControls(controls) {
        const element = controls.element;
        if (element && !this.#elements.has(element)) {
            this.#elements.add(element);
            element.addEventListener("click", event => {
                const button = event.target.closest("[data-tool], [data-control]");
                if (!button || this.canSwitch(button.dataset.tool)) return;
                event.preventDefault(); event.stopImmediatePropagation();
            }, { capture: true });
        }
        // Foundry changes selection before callbacks and does not await them.
        // Guard programmatic activation as well as clicks, then reconcile selection.
        for (const tool of Object.values(controls.controls?.augurTools?.tools || {})) {
            if (this.#wrapped.has(tool)) continue;
            this.#wrapped.add(tool);
            const onChange = tool.onChange;
            tool.onChange = (event, active) => {
                if (!this.canSwitch(active ? tool.name : "")) { this.#restore(); return; }
                return onChange?.(event, active);
            };
        }
    }
}
