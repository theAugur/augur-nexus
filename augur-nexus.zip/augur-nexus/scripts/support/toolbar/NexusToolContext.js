// Scene-aware visibility rules and toolbar hook wiring for Nexus tools.

import { AugurControls } from "../utils/AugurControls.js";
import { ToolWindowLifecycle } from "./ToolWindowLifecycle.js";
import { WorldTemplatesApplication } from "../../features/world-templates/applications/WorldTemplatesApplication.js";
import { SitePanel } from "../../features/site/applications/SitePanel.js";
import { SiteEditor } from "../../features/site/services/SiteEditor.js";
import { SiteGenerator } from "../../features/site/services/SiteGenerator.js";
import { NexusMarkerService } from "../../features/markers/services/NexusMarkerService.js";
import { LegacySciFiCompatibility } from "../compatibility/LegacySciFiCompatibility.js";
import { NexusSceneNavigationManager } from "../../features/nexus/services/NexusSceneNavigationManager.js";

let sitePanelInstance = null;
const toolbarContributions = new Map();

export function registerToolbarTools(moduleId, tools = []) {
    if (!moduleId) throw new Error("A module id is required to register toolbar tools.");
    toolbarContributions.set(moduleId, Array.isArray(tools) ? tools : []);
}

export function unregisterToolbarTools(moduleId) {
    if (!moduleId) return;
    toolbarContributions.delete(moduleId);
}

export function isNexusSiteToolSuppressedScene(scene = canvas.scene) {
    return !scene;
}

export function getNexusBackTarget(scene = canvas.scene) {
    if (!scene) return null;

    const navigation = NexusSceneNavigationManager.getSceneNavigation(scene);
    if (navigation) return navigation;

    return LegacySciFiCompatibility.getBackTarget(scene);
}

export function reconcileNexusActiveToolForScene(scene = canvas.scene) {
    if (!isNexusSiteToolSuppressedScene(scene)) return;

    const activeControl = ui.controls.control?.name || ui.controls.activeControl;
    const activeTool = ui.controls.tool?.name || ui.controls.tool;
    if (activeControl !== "augurTools") return;
    if (!["nexus-sites", "nexus-back"].includes(activeTool)) return;
    ui.controls.activate({ control: "augurTools", tool: "augur-select" });
}

export function populateNexusTools({
    augur,
    scene = canvas.scene,
    handlers = {}
} = {}) {
    if (!augur) return;

    augur.tools["nexus-browser"] = {
        name: "nexus-browser",
        title: "Nexus Workspace",
        icon: "fas fa-books",
        onChange: handlers.onNexusChange
    };

    // Players get the campaign viewer, without the GM's creation and scene tools.
    if (!game.user.isGM) return;

    const backTarget = getNexusBackTarget(scene);
    if (game.modules.get("augur-fantasy")?.active) {
        augur.tools["world-templates"] = {
            name: "world-templates", title: "Nexus Templates", icon: "fas fa-wrench",
            onChange: (_event, active) => active ? WorldTemplatesApplication.open() : ToolWindowLifecycle.close("world-templates")
        };
    }
    if (backTarget) {
        augur.tools["nexus-back"] = {
            name: "nexus-back",
            title: "Back",
            icon: "fas fa-circle-arrow-left",
            button: true,
            onChange: handlers.onBackChange
        };
    }

    if (!isNexusSiteToolSuppressedScene(scene)) {
        augur.tools["nexus-sites"] = {
            name: "nexus-sites",
            title: "Nexus Placer",
            icon: "fas fa-location-dot",
            onChange: handlers.onSitesChange
        };
    }

    applyRegisteredToolbarTools(augur, scene);

    AugurControls.prioritizeTools(augur, [
        "augur-select",
        "nexus-browser",
        "world-templates",
        "nexus-back",
        "nexus-sites",
    ]);
}

function applyRegisteredToolbarTools(augur, scene = canvas.scene) {
    for (const tools of toolbarContributions.values()) {
        for (const tool of tools) {
            if (!tool?.name) continue;
            if (typeof tool.isVisible === "function" && !tool.isVisible(scene)) continue;

            const { isVisible, ...toolData } = tool;
            augur.tools[tool.name] = toolData;
        }
    }
}

function openNexusSitesTool() {
    if (!ToolWindowLifecycle.canSwitch("nexus-sites")) return;
    if (isNexusSiteToolSuppressedScene(canvas.scene)) {
        ui.notifications.warn("Nexus Placer is not available in this scene.");
        return;
    }

    if (canvas.ready && canvas.augur && !canvas.augur.active) {
        canvas.augur.activate();
    }

    SiteEditor.deactivate();
    SiteGenerator.resetGhost();

    if (ui.controls) {
        ui.controls.activate({ control: "augurTools", tool: "nexus-sites" });
    }

    if (!sitePanelInstance) {
        sitePanelInstance = SitePanel.showCreate();
    } else {
        sitePanelInstance.setActiveTab?.("create");
        sitePanelInstance.render(true, { focus: true });
    }
}

function openNexusSiteEditorTool() {
    if (!ToolWindowLifecycle.canSwitch("nexus-sites")) return;
    if (isNexusSiteToolSuppressedScene(canvas.scene)) {
        ui.notifications.warn("Nexus Placer is not available in this scene.");
        return;
    }

    if (canvas.ready && canvas.augur && !canvas.augur.active) {
        canvas.augur.activate();
    }

    SiteEditor.activate();
    SiteGenerator.resetGhost();

    if (ui.controls) {
        ui.controls.activate({ control: "augurTools", tool: "nexus-sites" });
    }

    if (!sitePanelInstance) {
        sitePanelInstance = SitePanel.showEdit();
    } else {
        sitePanelInstance.setActiveTab?.("edit");
        sitePanelInstance.render(true, { focus: true });
    }
}

export async function openNexusSiteEditorForPlaceable(placeable) {
    if (isNexusSiteToolSuppressedScene(canvas.scene)) {
        ui.notifications.warn("Nexus Placer is not available in this scene.");
        return null;
    }

    const converted = await NexusMarkerService.convertLegacySitePlaceableToMarker(placeable, { scene: canvas.scene });
    if (converted) return openNexusMarkerEditorForPlaceable(converted);

    ui.notifications.warn("This older Site note can still be opened or deleted, but only Tile-based Site visuals can be converted for marker editing.");
    return null;
}

export function openNexusMarkerEditorForPlaceable(placeable) {
    if (!ToolWindowLifecycle.canSwitch("nexus-sites")) return null;
    if (isNexusSiteToolSuppressedScene(canvas.scene)) {
        ui.notifications.warn("Nexus Placer is not available in this scene.");
        return null;
    }

    if (canvas.ready && canvas.augur && !canvas.augur.active) {
        canvas.augur.activate();
    }

    SiteEditor.activate();
    SiteEditor.clearSelection();
    NexusMarkerService.selectMarker(placeable);
    SiteGenerator.resetGhost();
    NexusMarkerService.clearGhost();

    if (ui.controls) {
        ui.controls.activate({ control: "augurTools", tool: "nexus-sites" });
    }

    if (!sitePanelInstance) {
        sitePanelInstance = SitePanel.showEdit();
    } else {
        sitePanelInstance.setActiveTab?.("edit");
        sitePanelInstance.render(true, { focus: true });
    }

    return sitePanelInstance;
}

export function registerNexusToolbarHooks() {
    Hooks.on("augurNexusOpenSitesTool", openNexusSitesTool);
    Hooks.on("augurNexusOpenSiteEditorTool", openNexusSiteEditorTool);

    Hooks.on("renderSceneControls", controls => {
        ToolWindowLifecycle.bindControls(controls);
        const activeName = controls.control?.name || controls.activeControl;
        if (activeName !== "augurTools") return;

        const layer = canvas.augur;
        if (canvas.ready && layer && !layer.active) {
            layer.activate();
        }
    });

    Hooks.on("getSceneControlButtons", controls => {
        const augur = AugurControls.getOrCreate(controls, { allowPlayers: true });
        if (!augur) return;

        populateNexusTools({
            augur,
            scene: canvas.scene,
            handlers: {
                onNexusChange: async (event, active) => {
                    if (!active) return ToolWindowLifecycle.close("nexus-browser");
                    // Place dossiers also depend on toolbar services; load their workspace host after startup.
                    const { CampaignWorkspace } = await import("../../features/workspace/applications/CampaignWorkspace.js");
                    if (ui.controls?.control?.name !== "augurTools" || ui.controls?.tool?.name !== "nexus-browser") return;
                    return CampaignWorkspace.show();
                },
                onSitesChange: (event, active) => {
                    if (active) {
                        if (!sitePanelInstance) {
                            sitePanelInstance = SitePanel.show({ tab: SiteEditor.isEditMode ? "edit" : "create" });
                        } else {
                            sitePanelInstance.setActiveTab?.(SiteEditor.isEditMode ? "edit" : "create");
                            sitePanelInstance.render(true, { focus: true });
                        }
                    } else if (sitePanelInstance) {
                        SiteGenerator.resetGhost();
                        SiteEditor.deactivate();
                        const siteApp = sitePanelInstance;
                        sitePanelInstance = null;
                        siteApp?.close();
                    } else {
                        SiteGenerator.resetGhost();
                        SiteEditor.deactivate();
                    }
                },
                onBackChange: async (event, active) => {
                    if (!active) return;

                    await ui.controls.activate({ control: "augurTools", tool: "augur-select" });
                    const returned = await NexusSceneNavigationManager.returnToParent(canvas.scene)
                        || await LegacySciFiCompatibility.returnToParent(canvas.scene);
                    if (!returned) {
                        ui.notifications.warn("No parent scene was found for this view.");
                    }
                }
            }
        });
    });
}

export function refreshNexusToolbarForScene(scene = canvas.scene) {
    reconcileNexusActiveToolForScene(scene);
    ui.nexus?.render?.();

    if (sitePanelInstance && isNexusSiteToolSuppressedScene(scene)) {
        const app = sitePanelInstance;
        sitePanelInstance = null;
        app.close();
    }

}



