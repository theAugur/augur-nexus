const ORIGIN_TYPE = "application/x-augur-nexus-drag-origin";
const boundRoots = new WeakSet();

// Capture precedes dossier handlers that stop bubbling; the ordinary identity payload stays intact.
export function bindNexusDragOrigin(root, origin) {
    if (!root?.addEventListener || boundRoots.has(root)) return;
    boundRoots.add(root);
    root.addEventListener("dragstart", event => event.dataTransfer?.setData(ORIGIN_TYPE, origin), { capture: true });
}

export function isNexusDragOrigin(event, origin) {
    return event?.dataTransfer?.getData(ORIGIN_TYPE) === origin;
}
