// Shared movement for frameless floating controls; callers own activation and persistence.
export function clampFloatingPosition(left, top, width, height, viewportWidth, viewportHeight) {
    const clamp = (value, space, size) => Math.max(8, Math.min(Number(value) || 0, space - size - 8));
    return { left: clamp(left, viewportWidth, width), top: clamp(top, viewportHeight, height), width, height };
}

export function startFloatingMove(app, event, action) {
    if (event.button !== 0 || app.drag) return;
    const handle = event.target.closest(`[data-action="${action}"]`);
    if (!handle) return;
    event.stopPropagation(); handle.setPointerCapture(event.pointerId);
    app.suppressPortraitClick = false;
    app.drag = { x: event.clientX, y: event.clientY, left: app.position.left, top: app.position.top, handle, pointerId: event.pointerId, moved: false };
}

export function moveFloatingControl(app, event) {
    if (!app.drag || event.pointerId !== app.drag.pointerId) return;
    const dx = event.clientX - app.drag.x, dy = event.clientY - app.drag.y;
    if (!app.drag.moved && Math.hypot(dx, dy) < 5) return;
    app.drag.moved = true; app.element.classList.add("is-dragging");
    app.place(app.drag.left + dx, app.drag.top + dy);
}

export function endFloatingMove(app, event, cancelled = false) {
    if (!app.drag || event.pointerId !== app.drag.pointerId) return false;
    const drag = app.drag; app.drag = null;
    app.suppressPortraitClick = drag.moved || cancelled;
    if (drag.handle.hasPointerCapture(drag.pointerId)) drag.handle.releasePointerCapture(drag.pointerId);
    app.element.classList.remove("is-dragging");
    if (drag.moved) void app.rememberPosition();
    return true;
}
