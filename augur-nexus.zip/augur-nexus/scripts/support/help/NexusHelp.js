import { WIKI_HELP_CONFIG, NEXUS_HELP_TOPICS } from "./HelpConfiguration.js";
import { NEXUS_DOSSIER_HELP } from "./DossierHelpConfiguration.js";

const topics = new Map();
const attachments = new WeakMap();
const dossierTopics = new Map();

/** One declaration serves a standalone dossier and every workspace pane. */
export function registerDossierHelp(entityType, topic) {
    if (!String(entityType || "").trim() || !(typeof topic === "function" || typeof topic === "string" && topic.trim())) {
        throw new Error("Dossier help requires an entity type and a topic ID or resolver.");
    }
    dossierTopics.set(entityType, topic);
}

export function getDossierHelp(entityType, { entity = null, user = globalThis.game?.user, ...context } = {}) {
    const declaration = dossierTopics.get(entityType);
    const topicId = typeof declaration === "function" ? declaration({ ...context, entity, user }) : declaration;
    const topic = topics.get(topicId);
    return topic ? { topicId, label: `Help: ${topic.title}` } : null;
}

export function attachDossierHelpButton(application, entityType, context) {
    const help = getDossierHelp(entityType, context);
    if (help) return attachHelpButton(application, help.topicId);
    const state = attachments.get(application);
    if (state) {
        application.removeEventListener("close", state.cleanup);
        state.cleanup();
    }
    return null;
}

function relativePath(value) {
    const path = String(value || "").trim();
    if (!path || path.startsWith("//") || /[\\%?#:]/.test(path)) throw new Error("Help topics require a relative permalink path.");
    const normalized = path.replace(/^\//, "");
    if (!normalized.split("/").every(part => /^[\w.-]+$/.test(part) && part !== "." && part !== "..")) {
        throw new Error("Help topic paths cannot escape the wiki base.");
    }
    return normalized;
}

export function registerHelpTopics(moduleId, definitions = {}) {
    const owner = String(moduleId || "").trim();
    if (!owner) throw new Error("Help topics require an owning module.");
    const entries = Object.entries(definitions).map(([id, definition]) => {
        if (!id.startsWith(`${owner}:`) || id.length === owner.length + 1) throw new Error("Help topic IDs must be namespaced to their owning module.");
        const path = relativePath(typeof definition === "string" ? definition : definition?.path);
        return [id, { path, title: String(definition?.title || id).trim() }];
    });
    for (const [id, definition] of entries) topics.set(id, definition);
}

export function resolveHelpUrl(topicId) {
    const topic = topics.get(topicId);
    if (!topic) throw new Error(`No help article is registered for '${topicId}'.`);
    const base = new URL(WIKI_HELP_CONFIG.baseUrl);
    if (!["https:", "http:"].includes(base.protocol) || base.username || base.password || base.search || base.hash) throw new Error("The wiki base must be an HTTP(S) URL without credentials, query, or fragment.");
    base.pathname = `${base.pathname.replace(/\/+$/, "")}/`;
    const url = new URL(relativePath(topic.path), base);
    if (url.origin !== base.origin || !url.pathname.startsWith(base.pathname)) throw new Error("Help topic is outside the wiki base.");
    return url.href;
}

/** Keep opening synchronous to preserve the click's browser popup permission. */
export function openHelp(topicId) {
    try {
        const url = resolveHelpUrl(topicId);
        globalThis.window?.open(url, "_blank", "noopener,noreferrer");
        return true;
    } catch (error) {
        globalThis.ui?.notifications?.warn(error.message || "This help article is unavailable.");
        return false;
    }
}

/** Explicit render-time opt-in; native header controls alone are normally overflow-menu items. */
export function attachHelpButton(application, topicId) {
    const root = application?.element;
    const close = root?.querySelector?.('.window-header button[data-action="close"]');
    if (!close?.parentElement) return null;
    let state = attachments.get(application);
    if (state && state.button.parentElement !== close.parentElement) {
        state.button.removeEventListener("click", state.click);
        state.button.remove();
        state.button = null;
    }
    if (!state) {
        state = { topicId };
        state.cleanup = () => {
            state.button?.removeEventListener("click", state.click);
            state.button?.remove();
            attachments.delete(application);
        };
        application.addEventListener("close", state.cleanup, { once: true });
        attachments.set(application, state);
    }
    state.topicId = topicId;
    if (!state.button) {
        const button = root.ownerDocument.createElement("button");
        button.type = "button";
        button.className = "header-control icon fa-solid fa-question nexus-help-control";
        state.click = event => {
            event.preventDefault();
            event.stopPropagation();
            openHelp(state.topicId);
        };
        button.addEventListener("click", state.click);
        close.parentElement.insertBefore(button, close);
        state.button = button;
    }
    const label = `Help: ${topics.get(topicId)?.title || topicId}`;
    state.button.setAttribute("aria-label", label);
    state.button.dataset.tooltip = label;
    return state.button;
}

registerHelpTopics("augur-nexus", NEXUS_HELP_TOPICS);

for (const [entityType, topic] of Object.entries(NEXUS_DOSSIER_HELP)) registerDossierHelp(entityType, topic);
