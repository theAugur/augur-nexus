/** One host and path prefix for every registered documentation topic. */
export const WIKI_HELP_CONFIG = {
    baseUrl: "https://publish.obsidian.md/augur/"
};

export const NEXUS_HELP_TOPICS = {
    "augur-nexus:sidebar": { path: "nexus/browser/use", title: "Use the Nexus Browser" },
    "augur-nexus:appearance": { path: "nexus/appearance", title: "Choose Your Theme and Interface Accent" },
    "augur-nexus:locations": { path: "nexus/campaign-entities/locations", title: "Locations and Settlements" },
    "augur-nexus:site-dossier": { path: "nexus/scenes-and-sites/manage", title: "Manage a Site and Its Scene" },
    "augur-nexus:people": { path: "nexus/campaign-entities/people", title: "People" },
    "augur-nexus:organizations": { path: "nexus/campaign-entities/organizations", title: "Organizations" },
    "augur-nexus:ships": { path: "nexus/campaign-entities/ships", title: "Ships" },
    "augur-nexus:workspace": { path: "nexus/browser/workspace", title: "Use Campaign Nexus" },
    "augur-nexus:settings": { path: "nexus/settings", title: "Use Nexus Settings" },
    "augur-nexus:quests": { path: "nexus/quests", title: "Quests" },
    "augur-nexus:quests-player": { path: "nexus/quests/player", title: "Follow Quests as a Player" },
    "augur-nexus:quest-visibility": { path: "nexus/quests/visibility", title: "Control Quest Visibility" },
    "augur-nexus:player-wheel": { path: "nexus/players/player-wheel", title: "Use the Player Wheel" },
    "augur-nexus:connections": { path: "nexus/connections", title: "Connections" },
    "augur-nexus:opinions": { path: "nexus/opinions/track-and-adjust", title: "Track and Adjust an Opinion" },
    "augur-nexus:shops": { path: "nexus/shops/use", title: "Use Shops and Marketplaces" },
    "augur-nexus:shop-editor": { path: "nexus/shops/configure", title: "Configure a Shop" },
    "augur-nexus:marketplace-editor": { path: "nexus/shops/marketplace", title: "Configure a Marketplace" },
    "augur-nexus:regional-trade-network": { path: "fantasy/regional-trade-network", title: "Use the Regional Trade Network" },
    "augur-nexus:trade-good-detail": { path: "fantasy/follow-trade-good", title: "Follow a Trade Good" },
    "augur-nexus:trade-goods-prices": { path: "fantasy/trade-goods-prices", title: "Manage Trade Goods and Prices" },
    "augur-nexus:custom-trade-good": { path: "fantasy/custom-trade-good", title: "Create a Custom Trade Good" },
    "augur-nexus:connection-categories": { path: "nexus/connections/organize", title: "Organize Categories, Roles, and Notes" },
    "augur-nexus:object-visibility": { path: "nexus/players-and-visibility/overrides", title: "Override Visibility for One Object" },
    "augur-nexus:site-visibility": { path: "nexus/scenes-and-sites/player-access", title: "Control Site and Scene Access" },
    "augur-nexus:scene-open": { path: "nexus/scenes-and-sites/player-scene-open", title: "Control Player Scene Opening" },
    "augur-nexus:connection-visibility": { path: "nexus/connections/visibility", title: "Control Connection Visibility" },
    "augur-nexus:location-details": { path: "nexus/players-and-visibility/unvisited-locations", title: "Use Unvisited Locations" },
    "augur-nexus:dossier-details": { path: "nexus/players-and-visibility/dossier-details", title: "Hide Dossier Details from Players" },
    "augur-nexus:actor-link": {
        path: "nexus/campaign-entities/import-actor",
        title: "Link a Foundry Actor"
    },
    "augur-nexus:placer": {
        path: "nexus/placer",
        title: "Use the Nexus Placer"
    },
    "augur-nexus:player-setup": {
        path: "nexus/players/player-character-setup",
        title: "Set Up Player Characters"
    }
};
