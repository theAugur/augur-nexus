/** Dossier associations only; article URLs remain in the help topic registry. */
export const NEXUS_DOSSIER_HELP = {
    quest: ({ user }) => user?.isGM ? "augur-nexus:quests" : "augur-nexus:quests-player",
    npc: "augur-nexus:people",
    faction: "augur-nexus:organizations",
    ship: "augur-nexus:ships",
    location: ({ entity }) => !entity?.dossier?.viewId || entity.dossier.viewId === "augur-nexus:settlement-dossier" ? "augur-nexus:locations" : null,
    place: ({ genericSite }) => genericSite === true ? "augur-nexus:site-dossier" : null
};
