// User document updates provide the authenticated sender; domain services own authorization.
export function createUserFlagRequests({ moduleId, requestKey, resultKey, execute, timeout = 20000, queueRequests = true, routeGmToActive = false, unavailableMessage, timeoutMessage, busyMessage }) {
    const pending = new Map(), running = new Set();
    let queue = Promise.resolve();
    function register() {
        Hooks.on("updateUser", (user, changes, _options, updaterId) => {
            const flags = changes.flags?.[moduleId];
            if (!flags) return;
            if (flags[resultKey] && user.id === game.user.id && game.users.get(updaterId)?.isGM) {
                const result = user.getFlag(moduleId, resultKey);
                const wait = pending.get(result?.id);
                if (wait?.gmId === updaterId) {
                    clearTimeout(wait.timer); pending.delete(result.id);
                    try { result.error ? wait.reject(new Error(result.error)) : wait.resolve(JSON.parse(result.payload)); }
                    catch (error) { wait.reject(error); }
                }
            }
            const request = flags[requestKey]?.id ? user.getFlag(moduleId, requestKey) : null;
            if (!request || game.user.id !== game.users.activeGM?.id || updaterId !== user.id || typeof request.id !== "string" || request.id.length > 64 || request.gmId !== game.user.id) return;
            const key = user.id + ":" + request.id;
            if (running.has(key) || user.getFlag(moduleId, resultKey)?.id === request.id) return;
            running.add(key);
            void (async () => {
                let result;
                try {
                    const data = JSON.parse(request.payload);
                    if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error("Invalid request.");
                    result = { id: request.id, error: "", payload: JSON.stringify(await execute({ ...data, requestId: request.id }, user) ?? null) };
                } catch (error) { result = { id: request.id, payload: "null", error: error.message || "The operation failed." }; }
                // Explicit fields prevent a previous error/value surviving Foundry's flag merge.
                await user.setFlag(moduleId, resultKey, result);
            })().catch(error => console.error("Nexus | Request response failed", error)).finally(() => running.delete(key));
        });
    }
    async function send(data) {
        const gm = game.users.activeGM;
        if (game.user.isGM && (!routeGmToActive || !gm || gm.id === game.user.id)) return execute(data, game.user);
        if (!gm) throw new Error(unavailableMessage);
        if (!queueRequests && pending.size) throw new Error(busyMessage);
        const id = foundry.utils.randomID();
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => { pending.delete(id); reject(new Error(timeoutMessage)); }, timeout);
            pending.set(id, {resolve, reject, timer, gmId:gm.id});
            game.user.setFlag(moduleId, requestKey, {id, gmId:gm.id, payload:JSON.stringify(data)})
                .catch(error => {clearTimeout(timer); pending.delete(id); reject(error);});
        });
    }
    function request(data) {
        if (!queueRequests) return send(data);
        const result = queue.then(() => send(data));
        queue = result.catch(() => {});
        return result;
    }
    return {register, request};
}
