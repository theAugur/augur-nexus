import { getNexusThemePreferences } from "./NexusThemes.js";

const MODULE_ID = "augur-nexus";
const COVER_IMAGE_SETTING = "dossierCoverImage";
const DEFAULT_COVER_IMAGE = "modules/augur-nexus/assets/site_abstracts/World (3).webp";

function imagePath(value) {
    return typeof value === "string" ? value.trim() : "";
}

/** Stored entity artwork remains authoritative, including covers saved by earlier releases. */
export function resolveDossierCover(entityOrOverride = null) {
    const override = imagePath(typeof entityOrOverride === "string" ? entityOrOverride : entityOrOverride?.display?.coverImageSrc);
    return override || imagePath(game.settings.get(MODULE_ID, COVER_IMAGE_SETTING)) || DEFAULT_COVER_IMAGE;
}

function cssUrl(path) {
    // CSS consumes this variable from an external stylesheet, so local paths must
    // include Foundry's route prefix instead of resolving relative to that sheet.
    const url = /^(?:[a-z][a-z0-9+.-]*:|\/)/i.test(path) ? path : foundry.utils.getRoute(path);
    // Hex escapes keep quotes, backslashes, and control characters inside the CSS string.
    const escaped = url.replace(/["\\\u0000-\u001f\u007f]/g, character => `\\${character.codePointAt(0).toString(16)} `);
    return `url("${escaped}")`;
}

/** Theme and cover visibility only affect presentation; reads never modify saved artwork. */
export function prepareDossierCover(entityOrOverride = null) {
    const preferences = getNexusThemePreferences();
    const enabled = preferences.theme === "classic-dark" && preferences.showCover;
    const src = enabled ? resolveDossierCover(entityOrOverride) : "";
    return { enabled, src, style: enabled ? `--nexus-dossier-cover-image:${cssUrl(src)};` : "" };
}

/** Cinematic subjects can retain their own stage artwork independently of the shared cover. */
export function prepareDossierBackdrop(source) {
    const src = imagePath(source);
    return { enabled: !!src, src, style: src ? `--nexus-dossier-cover-image:${cssUrl(src)};` : "" };
}

export function registerDossierCoverSettings() {
    game.settings.register(MODULE_ID, COVER_IMAGE_SETTING, {
        scope: "world", config: false, type: String, default: "",
        onChange: () => Hooks.callAll("augurNexusAppearanceChanged", { shared: true })
    });
}

/** An empty path restores the fixed default without creating entity overrides. */
export async function setDossierCoverImage(path) {
    if (!game.user?.isGM) throw new Error("Only a GM can change the shared dossier cover.");
    if (typeof path !== "string") throw new Error("The dossier cover must be an image path.");
    await game.settings.set(MODULE_ID, COVER_IMAGE_SETTING, imagePath(path));
    return resolveDossierCover();
}
