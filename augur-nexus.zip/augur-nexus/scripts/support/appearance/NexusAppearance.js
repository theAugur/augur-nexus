const MODULE_ID = "augur-nexus";
const ACCENT_SETTING = "interfaceAccentColor";
const TEXT_SIZE_SETTING = "interfaceTextSize";

export const DEFAULT_NEXUS_ACCENT = "#bf913f";
export const DEFAULT_NEXUS_TEXT_SIZE = "default";

export const NEXUS_ACCENT_PRESETS = Object.freeze([
    { id: "gold", label: "Gold", value: DEFAULT_NEXUS_ACCENT },
    { id: "crimson", label: "Crimson", value: "#b84a4a" },
    { id: "azure", label: "Azure", value: "#3f91bf" },
    { id: "emerald", label: "Emerald", value: "#4f9b68" },
    { id: "violet", label: "Violet", value: "#8a62bd" }
]);

export const NEXUS_TEXT_SIZE_PRESETS = Object.freeze([
    { id: "default", label: "Default" },
    { id: "medium", label: "Medium" },
    { id: "large", label: "Large" }
]);

export function normalizeNexusAccentColor(value) {
    try {
        return foundry.utils.Color.from(value || DEFAULT_NEXUS_ACCENT).css;
    } catch (_error) {
        return DEFAULT_NEXUS_ACCENT;
    }
}

export function getNexusAccentColor() {
    return normalizeNexusAccentColor(game.settings.get(MODULE_ID, ACCENT_SETTING));
}

export function normalizeNexusTextSize(value) {
    const normalized = String(value || "").trim().toLocaleLowerCase();
    return NEXUS_TEXT_SIZE_PRESETS.some(preset => preset.id === normalized)
        ? normalized
        : DEFAULT_NEXUS_TEXT_SIZE;
}

export function getNexusTextSize() {
    return normalizeNexusTextSize(game.settings.get(MODULE_ID, TEXT_SIZE_SETTING));
}

export async function setNexusAccentColor(value) {
    if (!game.user?.isGM) {
        throw new Error("Only a GM can change the Nexus interface accent.");
    }
    return game.settings.set(MODULE_ID, ACCENT_SETTING, normalizeNexusAccentColor(value));
}

export async function setNexusTextSize(value) {
    return game.settings.set(MODULE_ID, TEXT_SIZE_SETTING, normalizeNexusTextSize(value));
}

export function applyNexusAccentColor(value = game.settings.get(MODULE_ID, ACCENT_SETTING)) {
    const accentColor = normalizeNexusAccentColor(value);
    document.documentElement.style.setProperty("--nexus-user-accent", accentColor);
    Hooks.callAll("augurNexusAppearanceChanged", { accentColor });
    return accentColor;
}

export function applyNexusTextSize(value = game.settings.get(MODULE_ID, TEXT_SIZE_SETTING)) {
    const textSize = normalizeNexusTextSize(value);
    document.documentElement.dataset.nexusTextSize = textSize;
    Hooks.callAll("augurNexusAppearanceChanged", { textSize });
    return textSize;
}
