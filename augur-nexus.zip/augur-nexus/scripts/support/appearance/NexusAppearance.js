const MODULE_ID = "augur-nexus";
const ACCENT_SETTING = "interfaceAccentColor";

export const DEFAULT_NEXUS_ACCENT = "#bf913f";

export const NEXUS_ACCENT_PRESETS = Object.freeze([
    { id: "gold", label: "Gold", value: DEFAULT_NEXUS_ACCENT },
    { id: "crimson", label: "Crimson", value: "#b84a4a" },
    { id: "azure", label: "Azure", value: "#3f91bf" },
    { id: "emerald", label: "Emerald", value: "#4f9b68" },
    { id: "violet", label: "Violet", value: "#8a62bd" }
]);

export function normalizeNexusAccentColor(value) {
    try {
        return foundry.utils.Color.from(value || DEFAULT_NEXUS_ACCENT).css;
    } catch (_error) {
        return DEFAULT_NEXUS_ACCENT;
    }
}

export function getNexusAccentColor() {
    return normalizeNexusAccentColor(game.settings.get(MODULE_ID, ACCENT_SETTING));
}

export async function setNexusAccentColor(value) {
    if (!game.user?.isGM) {
        throw new Error("Only a GM can change the Nexus interface accent.");
    }
    return game.settings.set(MODULE_ID, ACCENT_SETTING, normalizeNexusAccentColor(value));
}

export function applyNexusAccentColor(value = game.settings.get(MODULE_ID, ACCENT_SETTING)) {
    const accentColor = normalizeNexusAccentColor(value);
    document.documentElement.style.setProperty("--nexus-user-accent", accentColor);
    Hooks.callAll("augurNexusAppearanceChanged", { accentColor });
    return accentColor;
}
