import { getNexusAccentColor } from "./NexusAppearance.js";

const THEME_MODULE_ID = "augur-nexus", APPEARANCE_FLAG = "appearance";
const COVER_SETTING = "dossierShowCover";
const DEFAULT_THEME_ID = "parchment";
// Definitions are presentation only. New themes supply roles rather than feature CSS.
export const NEXUS_THEMES = Object.freeze([
    Object.freeze({ id: "classic-dark", label: "Midnight Dark", mode: "dark",
        roles: { base: "#0a0e0f", panel: "#15191b", raised: "#171b1d", hover: "#202426", ink: "#e7dfcf", secondary: "#b8ad9c", muted: "#8b877f", rule: "color-mix(in srgb,var(--nexus-user-accent) 28%,transparent)", overlay: "linear-gradient(135deg,#0b1010ad,#090d0fd1)", texture: "none", chronicle: "linear-gradient(100deg,color-mix(in srgb,var(--nexus-user-accent) var(--nexus-thread-accent-weight),#1a1d1f),#101415)", inverseInk: "#e7dfcf", inverseMuted: "#b8ad9c", cardSurface: "linear-gradient(145deg,rgba(18,25,27,.92),rgba(8,12,14,.94))", artSurface: "linear-gradient(transparent,#16191970)", decoration: "none" } }),
    Object.freeze({ id: "parchment", label: "Parchment", mode: "light",
        roles: { base: "#f1e5c8", panel: "#ede0bf", raised: "#f8eed9", hover: "#e2cfaa", ink: "#34271d", secondary: "#604b36", muted: "#766045", rule: "#b29a7070", overlay: "linear-gradient(135deg,#f8efdcd1,#f1e5c8e0)", texture: "repeating-linear-gradient(18deg,#84633004 0px,#84633004 1px,transparent 1px,transparent 4px)", chronicle: "linear-gradient(110deg,color-mix(in srgb,var(--nexus-user-accent) var(--nexus-thread-accent-weight),#171114),#211b1b)", inverseInk: "#f6ead2", inverseMuted: "#d5bfa3", cardSurface: "var(--nexus-surface-panel)", artSurface: "transparent", decoration: "inset 0 0 45px #9a74321a" } })
]);
for (const theme of NEXUS_THEMES) Object.freeze(theme.roles);

export function getNexusTheme(id) { return NEXUS_THEMES.find(theme => theme.id === id) || NEXUS_THEMES.find(theme => theme.id === DEFAULT_THEME_ID); }

export function registerNexusThemeSettings() {
    const onChange = () => Hooks.callAll("augurNexusAppearanceChanged", { shared: true });
    game.settings.register(THEME_MODULE_ID, COVER_SETTING, {
        scope: "world", config: false, type: Boolean, default: true, onChange
    });
}

export function getNexusThemePreferences() {
    const saved = game.user?.getFlag?.(THEME_MODULE_ID, APPEARANCE_FLAG) || {};
    return { theme: getNexusTheme(saved.theme).id,
        showCover: game.settings.get(THEME_MODULE_ID, COVER_SETTING) !== false };
}

export async function setNexusThemePreferences(change = {}) {
    const shared = Object.hasOwn(change, "showCover");
    if (shared && !game.user?.isGM) throw new Error("Only a GM can change the shared dossier appearance.");
    if (Object.hasOwn(change, "showCover") && typeof change.showCover !== "boolean") throw new Error("Cover artwork must be enabled or disabled.");
    if (Object.hasOwn(change, "showCover")) await game.settings.set(THEME_MODULE_ID, COVER_SETTING, change.showCover);
    if (Object.hasOwn(change, "theme")) {
        await game.user.setFlag(THEME_MODULE_ID, APPEARANCE_FLAG, { theme: getNexusTheme(change.theme).id });
        Hooks.callAll("augurNexusAppearanceChanged", { userId: game.user.id, ...getNexusThemePreferences() });
    }
    return getNexusThemePreferences();
}

/** Explicit opt-in: these variables belong on a supported surface, never on the document root. */
export function prepareNexusThemeSurface() {
    const preferences = getNexusThemePreferences(), theme = getNexusTheme(preferences.theme), roles = theme.roles;
    const accent = getNexusAccentColor();
    // Normalized accents are CSS hex; bright colors need more charcoal beneath small strip labels.
    const channels = /^#[a-f0-9]{6}$/i.test(accent) ? accent.slice(1).match(/../g).map(value => parseInt(value, 16) / 255) : [];
    const luminance = channels.reduce((sum, value, index) => sum + (value <= .04045 ? value / 12.92 : ((value + .055) / 1.055) ** 2.4) * [.2126, .7152, .0722][index], 0);
    const threadAccentWeight = theme.mode === "light" ? luminance > .35 ? "20%" : "35%" : luminance > .35 ? "15%" : "30%";
    const variables = { "nexus-user-accent": accent, "nexus-thread-accent-weight": threadAccentWeight, "nexus-surface-base": roles.base, "nexus-surface-panel": roles.panel,
        "nexus-surface-raised": roles.raised, "nexus-surface-interactive": roles.panel, "nexus-surface-hover": roles.hover,
        "nexus-card-surface": roles.cardSurface,
        "nexus-text-primary": roles.ink, "nexus-text-secondary": roles.secondary, "nexus-text-muted": roles.muted,
        "nexus-border-subtle": roles.rule, "nexus-border-strong": "color-mix(in srgb,var(--nexus-user-accent) 65%,transparent)",
        "nexus-accent-primary": theme.mode === "light" ? "color-mix(in srgb,var(--nexus-user-accent) 35%,#211912)" : "var(--nexus-user-accent)",
        "nexus-accent-bright": theme.mode === "light" ? "color-mix(in srgb,var(--nexus-user-accent) 35%,#211912)" : "color-mix(in srgb,var(--nexus-user-accent) 72%,white)",
        "nexus-accent-surface": "color-mix(in srgb,var(--nexus-user-accent) 10%,var(--nexus-surface-base))",
        "nexus-accent-surface-strong": "color-mix(in srgb,var(--nexus-user-accent) 20%,var(--nexus-surface-base))",
        "nexus-art-surface": roles.artSurface, "nexus-surface-texture": roles.texture, "nexus-cover-overlay": roles.overlay, "nexus-surface-decoration": roles.decoration,
        "nexus-chronicle-surface": roles.chronicle, "nexus-inverse-ink": roles.inverseInk, "nexus-inverse-muted": roles.inverseMuted };
    return { id: theme.id, mode: theme.mode, showCover: theme.mode === "dark" && preferences.showCover,
        style: Object.entries(variables).map(([key, value]) => `--${key}:${value};`).join("") };
}

/** Update an opted-in live surface without replacing inputs or their unsaved state. */
export function applyNexusThemeSurface(element, appearance = prepareNexusThemeSurface()) {
    if (!element) return;
    element.dataset.nexusTheme = appearance.id;
    element.dataset.nexusThemeMode = appearance.mode;
    for (const declaration of appearance.style.split(";")) {
        const colon = declaration.indexOf(":");
        if (colon < 0) continue;
        element.style.setProperty(declaration.slice(0, colon), declaration.slice(colon + 1));
    }
}

const liveThemeSurfaces = new WeakMap();

/** Opt in a related tool window while retaining drafts, focus, and picker selections. */
export function activateNexusThemeSurface(application, { windowClass = "nexus-settlement-tool-window", surfaceSelector = ".nexus-settlement-tool-surface" } = {}) {
    const update = () => {
        const appearance = prepareNexusThemeSurface();
        application.element?.classList.add(windowClass);
        applyNexusThemeSurface(application.element, appearance);
        applyNexusThemeSurface(application.element?.querySelector(surfaceSelector), appearance);
    };
    update();
    if (!liveThemeSurfaces.has(application)) {
        liveThemeSurfaces.set(application, Hooks.on("augurNexusAppearanceChanged", update));
    }
}

export function deactivateNexusThemeSurface(application) {
    if (!liveThemeSurfaces.has(application)) return;
    Hooks.off("augurNexusAppearanceChanged", liveThemeSurfaces.get(application));
    liveThemeSurfaces.delete(application);
}
